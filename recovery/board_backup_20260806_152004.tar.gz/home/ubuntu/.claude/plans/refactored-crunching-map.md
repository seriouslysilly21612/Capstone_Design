# 실시간 물체 추종(Tracking) 모드 구현 계획

## Context

현재 시스템은 **정지 물체** 전용이다: 'v' → 15프레임 std<8mm 게이트 → goal 1개 단발 전달 → min-jerk 궤적 + refine. 목표는 사람이 물체를 손으로 옮길 때(~30 cm/s) TCP가 호버 지점을 **실시간 추종**하는 것. 사용자 결정: 로봇 속도는 안전 상한으로 제한, 검출 상실 시 그 자리 정지·유지, 자세는 추적 진입 시점 고정.

조사 결과의 핵심 (3개 탐색 + 2개 설계/적대검증 에이전트, 전부 실코드 검증):
- `/pick_target_base`는 이미 ~15 Hz 연속 스트림 (E2E 지연 p50 113 ms). **비전 쪽(ros2_ws) 수정 불필요.**
- 컨트롤러에 1 kHz 안전 연속 서보 `SetTargetPose_Jacobian`(`FullDynControllerRT.cpp:1472-1594`)이 **미배선 상태로 존재** — 적응 DLS, 가속 클램프 2 rad/s², 관절속도 0.6 rad/s, 비누적 q_ref = m_Q + qd·dt (E17 이후 안전형). 재사용이 정답.
- 배선 시 고칠 갭 4개: FK 미호출 / CTC 미호출 / `m_Qd_ref_prev` 스테일(ctor에서만 0) / `m_dKfScale` 미설정(직전 궤적 값 상속 누수).
- 빈 키: `o`, `u`, `y`. 브리지에 RT가 읽을 수 있는 "최신 샘플" API 없음(단발 PopGoal뿐) → 신설 필요.
- **적대 검증 치명 결함 2건**: ① 비전→드라이브 사이에 NaN/토크 새추레이션이 전무 (`SaturateOutput`은 정의만 되고 미호출, `MoveTorque`도 무제한) ② 동일 클래스 두 번째 물체로 pick_logic이 전환하면 goal이 박스 안에서 수 십 cm~1 m 순간이동 → 로봇이 사람 몸통을 지나는 경로를 상한 속도로 스윕.

## 아키텍처

```
[ros2_ws 무수정] /pick_target_base 15Hz
      │ OnTarget (ROS 콜백 스레드)
      ▼
[브리지] finite → in-box(+2cm) → jump(0.10m) 게이트 → EMA(α=0.4) → seqlock 슬롯
      │ PeekTrack (wait-free, 1kHz RT가 읽음)
      ▼
[RT SM] 'o' 진입게이트 → 샘플 수용/LOST 판정 → goal_tcpPose 갱신 (RT 스레드에서만 씀)
      ▼
[컨트롤러] eTrackingServo: ComputeTcpFK → SetTargetPose_Jacobian → ComputeComputedTorque
```

수정 파일: `App/Indy7/ROS2PickBridge.{h,cpp}`, `FullDynControllerRT.{h,cpp}`, `Indy7Ctrl.{h,cpp}`, `Controller.cpp`, `CRobot/ConfigRobot.{h,cpp}`, `INDY7.cfg`(커밋 금지). 총 ~280줄.

---

## Step 0 — 안전 백스톱 (선행 독립 커밋)

사람 인접 작업의 전제. tracking과 무관하게 그 자체로 결함 수정.

1. **NaN 게이트**: `OnTarget`(`ROS2PickBridge.cpp:386`) 진입부에 `!isfinite(x|y|z) → return` (2줄).
2. **토크 새추레이션 배선**: `Update()`(`FullDynControllerRT.cpp:234-255`) 출력 직전에 per-joint 클램프 + 비유한→0. 한계값은 URDF effort limit 사용. 기존 `SaturateOutput`(`Controller.cpp:67`)은 NaN을 통과시키므로 isfinite 체크 포함해 배선.
3. **`SetTorqueLimits` 인자 버그**(`Indy7Ctrl.cpp:428`): `dJerkLimitU`→`dTorLimitU` (저장만 되는 값이라 무해하지만 함께 수정).
4. **'c' 키 스테일 참조 지뢰**: `SetControllerMode`에서 `eComputedTorque` 진입 시 `m_Q_ref=m_Q; m_Qd_ref=m_Qdd_ref=0` 스냅샷 (기존 결함, grav-comp에서 팔을 손으로 옮긴 뒤 'c' 누르면 수백 Nm).

**검증**: 빌드 + 실기 'v' 원샷 접근 1회 A/B — final 오차 동급, refine 0 유지 (클램프는 정상 토크에 무개입이어야 함).

## Step 1 — 브리지: 연속 샘플 파이프 (~55줄)

`ROS2PickBridge.h` — `PopGoal` 선언(h:93) 옆:
```cpp
struct TrackSample { double dX, dY, dZ; bool bValid, bClassMatch; };  // base_link [m], 마진 없음
BOOL PeekTrack(TrackSample& astOut, uint32_t& auSeq) const;  // 단일 시도 seqlock, wait-free
void SetTrackAlpha(double adA);                              // 비RT, OP 전 1회
```
멤버: `TrackSample m_stTrackSlot{}; std::atomic<uint32_t> m_uTrackSeq{0};` + 콜백 스레드 전용 EMA 상태 + 마지막 수용 raw 좌표(jump 게이트 기준).

**Writer** (`OnTarget`, collect 분기 밖 무조건 실행):
- 게이트 순서(적대검증 S6): **finite → raw in-box+2cm → jump(직전 수용 대비 >0.10 m 거부) → EMA(α=0.4) → 발행**. 거부된 샘플은 seq를 올리지 않음 → RT 쪽 staleness로 자연 누적.
- jump 게이트 근거: 정상 이동 30 cm/s @15 Hz = 프레임당 ~2 cm, 타깃 전환은 수십 cm — 5배 분리. **rate limiter가 아니라 거부** (rate limiter는 순간이동을 "사람을 통과하는 느린 스윕"으로 바꿀 뿐).
- >1 s 공백 후 첫 샘플: EMA 재시드 + jump 기준 리셋 (원거리 재획득은 RT 쪽 근접 게이트가 잡음).
- `bClassMatch` = `desired_class` 일치 여부 (기존 `m_Mtx` 잠금 안에서 판정).
- 발행: `seq+1(홀수) → 슬롯 복사 → seq+1(짝수)`, acquire/release 페어.

**Reader** (`PeekTrack`): seq 홀수면 FALSE, 복사 후 seq 재확인, 불일치면 FALSE — 재시도 루프 없음(RT wait-free). staleness는 RT가 "마지막 수용 이후 사이클 수"로 계산 — RT에서 시계 호출 없음.

EMA를 producer에 두는 이유: α 의미가 "비전 프레임당"으로 유지되고(1 kHz에 두면 α=0.4가 τ≈수 ms로 무의미), 찢긴 읽기 노출도 mm 수준으로 축소. VisualServo의 `static bool filterInit`(리셋 불가) 패턴은 복사 금지.

## Step 2 — 컨트롤러: `eTrackingServo` 모드 (~60줄)

1. **enum**(`FullDynControllerRT.h:252-259`): `eInverseKinematics_6dof` **뒤에 append** (DataLog가 ctrl_mode를 raw byte로 기록 — 중간 삽입 시 과거 로그 전부 재라벨링됨).
2. **디스패치**(cpp:247 뒤):
```cpp
case eTrackingServo:
    ComputeTcpFK();                                  // 갭(a)
    SetTargetPose_Jacobian();
    result = ComputeComputedTorque(avOutputTorque);  // 갭(b)
    break;
```
3. **`SetTargetPose_Jacobian` 수정** (호출부 0 확인됨, 수정 안전):
   - **선속도 상한 재추가**(cpp:1522의 제거 주석 자리): `‖e_task[3..5]‖ > m_dMaxLinVel → 스케일`. `double m_dMaxLinVel = 0.20;` + `SetMaxLinVel` (setter에서 **[0.05, 0.50] 클램프** — 잘못된 cfg로도 상한 해제 불가).
   - **λ 사다리 절벽 제거**(cpp:1537-1539): λ_low 0.0005→**0.01** (근접 고게인 레짐 제거 — 정확도는 어차피 stiction ~10-15 mm가 상한), 특이점 게이트 w에 히스테리시스 0.008/0.012.
   - **z-정렬 게이트 히스테리시스**: on 0.06 / off 0.10 m (0.08 단일 문턱은 이동 목표가 반복 횡단 → 0.3 rad/s 회전속도 스텝 채터).
   - **관절 소프트리밋**(신규 5줄): 속도 캡 뒤에서 `q[i]`가 `s_adJointLo/Hi[i]`(cpp:793-798) ±0.1 rad 이내이고 qd_ref가 바깥 방향이면 0으로 — 서보 경로에는 관절 한계 인식이 전무했음.
4. **진입/이탈** (RT 스레드 전용):
```cpp
void StartTrackingServo() {
    ComputeTcpFK();
    goal_tcpPose = tcpPose;              // 초기 오차 0; R은 여기서 동결(사용자 결정)
    m_Q_ref = m_Q; m_Qd_ref.setZero(); m_Qdd_ref.setZero();
    m_Qd_ref_prev.setZero();             // 갭(c): 재진입 시 첫 사이클 lurch 방지 (S5)
    m_dKfScale = 0.0;                    // 갭(d): FF 하드오프 — 서보 레짐에서 lag 게이트 ≤30%로 미튜닝 영역
    m_traj.active = false;
    m_eControlMode = eTrackingServo;     // 모드는 마지막
}
void StopTrackingServo() {               // 동결·유지 (접근 종료 후 hold 관용구)
    m_Q_ref = m_Q; m_Qd_ref.setZero(); m_Qdd_ref.setZero();
    m_traj.active = false;
    m_eControlMode = eInverseKinematics_6dof;  // UpdateTrajectory no-op → CTC hold
}
```
데드밴드는 v1 생략: 비누적 q_ref가 근접에서 P토크 ≈0을 자체 보장, stiction이 진동 아닌 1-2 cm 주차 오프셋으로 귀결(15 cm 호버에 무해). `Kp_task_pos=1.0`은 "정확도가 아니라 안정성 담당" 주석 필수.

## Step 3 — 앱: 'o' 키 + 추적 SM (~125줄)

**멤버**(`Indy7Ctrl.h`, refine 블록 뒤):
```cpp
enum eTrackState { eTRACK_OFF=0, eTRACK_ON, eTRACK_LOST };
eTrackState m_eTrackState{eTRACK_OFF};
uint32_t m_uLastTrackSeq{0};  int m_nTrackNoSampleCyc{0};
int m_nTrackLostCyc{500};                          // cfg TRACK_LOST_MS (1 cyc = 1 ms)
RigidBodyDynamics::Math::Vector3d m_vTrackTarget;  // 마지막 수용 goal (마진+클램프 후)
static constexpr double TRACK_ENTRY_M   = 0.15;    // 진입·재획득 근접 게이트
static constexpr double TRACK_ZMARGIN_M = 0.20;    // 추적 전용 호버 마진 (접근 0.15 유지)
static constexpr int    TRACK_EXIT_CYC  = 2000;    // 2 s 상실 → 자동 이탈 래치
```
호버 마진 0.20 근거(S7): 사람이 물체를 0.3 m/s로 들어올리면 EMA+파이프라인 지연으로 z가 ~7 cm 뒤처져 TCP-물체 간격이 잠식됨 — +5 cm 헤드룸.

**'o' 핸들러** (`DoInput`, digit case 앞 ~cpp:872). 토글:
- 추적 중 → `StopTrackingServo()` + "holding here; 'g'=grav-comp" 배너.
- OFF → **진입 게이트** (각각 개별 거부 printf — E17 규율):
  1. 브리지 존재  2. RT 컨트롤러 enabled  3. 전축 servo ON('b' 핸들러 cpp:829-836 루프 재사용)
  4. 모드 == `eInverseKinematics_6dof` && `IsTrajectoryRefDone()` — 이것이 "먼저 'v' 접근" 강제
  5. `!m_bRefineActive` ("refine 끝나면")  6. approach IDLE && !ISO && !RECT
  7. **관절 정착**: Σqd² < STAGE_VEL_EPS² (staging settle 람다 cpp:1358-1368 재사용) — S5 sag/lurch 방지
  8. `PeekTrack` 성공 && valid && classMatch, goal = 클램프(sample + TRACK_ZMARGIN_M), `‖goal − tcp‖ ≤ TRACK_ENTRY_M` ("too far — 'v' approach first")
- 통과 → 상태 세팅 + `StartTrackingServo()` + vmax 표기 배너.

**퍼사이클 SM** (`proc_main_control`, refine SM 뒤 ~cpp:1540, `bCtrlOn` 가드):
- 모드 ≠ eTrackingServo 또는 servo OFF → 즉시 OFF ("cancelled") — cancel-on-any-change.
- 새 seq 도착 && valid && classMatch → `t = 클램프(raw + TRACK_ZMARGIN_M)`;
  - ON 상태: `‖t − m_vTrackTarget‖`는 브리지 jump 게이트가 이미 보증 → 수용.
  - LOST 상태: **`‖t − tcp‖ ≤ TRACK_ENTRY_M`일 때만 재획득** (원거리 재출현 = 재스윕 금지).
- `++m_nTrackNoSampleCyc > m_nTrackLostCyc` → LOST 전환 + **`m_vTrackTarget = 현재 TCP`** ("마지막 goal"이 아님 — 상한 속도 추적 중 goal은 TCP보다 ~10 cm 앞서 있어, 마지막 goal 유지는 상실 후 맹목 전진이 됨. 사용자 결정 "그 자리 정지"의 정확한 구현) (S3).
- LOST가 `TRACK_EXIT_CYC`(2 s) 지속 → `StopTrackingServo()` + OFF 래치 ("target lost 2 s — tracking OFF, press 'o' to rearm"). 파이프라인 크래시·재시작 순간이동 케이스 동시 해결.
- 매 사이클 `goal_tcpPose.m_position = m_vTrackTarget` (RT 스레드 단독 writer 유지; R 불변).
- 클램프 헬퍼: r_xy≤`WS_RMAX_XY` 방사 스케일 → `WS_BOX` AABB 클램프. 단 **1차 방어는 브리지의 in-box 거부**(박스 밖 = lost 취급), 클램프는 최종 백스톱.

**키보드 화이트리스트** (S4, DoInput 최상단 1블록): 추적 중 `{'o','j','e','x','g'}` 외 전부 무시+printf. 이것으로 지연 발화 'v'(1 s 뒤 quintic 발사), 'o' 옆 'i' 오타(문턱 없는 구식 서보), 대문자 'Q'(ISO 10분 자율 왕복), 'b'/'m'/'a'/'n' 대형 궤적을 일괄 차단.
**+ 접근 블록 게이트**(cpp:1382): `&& m_eTrackState == eTRACK_OFF` — 추적 중 PopGoal 폐기(servo-off 폐기와 같은 메시지).

## Step 4 — cfg 노브 (~35줄)

| 키 | 기본 | 소비처 |
|---|---|---|
| `TRACK_VMAX_MPS` | 0.20 | `SetMaxLinVel` (코드에서 [0.05,0.50] 클램프) |
| `TRACK_EMA_ALPHA` | 0.4 | `SetTrackAlpha` ([0.05,1.0] 클램프, 1.0=필터 끔) |
| `TRACK_LOST_MS` | 500 | `m_nTrackLostCyc` |

파싱: `ConfigRobot.cpp` KP/KD/KF 루프(cpp:421-439) 옆 동일 패턴, 기본값은 코드에 — **cfg 키 부재 시에도 동작** (INDY7.cfg는 오퍼레이터 상태, 커밋 금지 원칙 유지). 배선: `InitController`의 `SetFrictionFF` 블록(cpp:294-301) 옆.

상수로 두는 것: `TRACK_ENTRY_M`, jump 0.10 m, `TRACK_ZMARGIN_M`, `TRACK_EXIT_CYC`, 서보 내부 한계 전부.

## 검증 사다리 (실기, E-stop 상시 파지, 5단계까지 사람은 로봇 범위 밖)

1. **게이트 감사(브레이크 ON)**: 'o' 콜드 → 거부 메시지 전수 확인. 모션 불가 상태.
2. **정적 호버**: 'v' 접근 완료 후 'o' — **가시 모션 없어야 함**(goal≈TCP). 'l' 24 s 로그: goal/tcp 흔들림·qd 확인. 'o' 정지 → 'g' 해제. (Step 0의 A/B도 이때)
3. **상실/유지**: 카메라 가림 → 0.5 s 내 "[TRACK] lost — holding", TCP 동결; 해제 → "reacquired"; 2 s 방치 → 자동 이탈 래치 확인.
4. **저속 추종**: 막대에 물체 고정, ~5 cm/s ±10 cm 왕복. 로그에서 goal↔tcp 시계열 시프트로 지연 실측 (예상 150-300 ms).
5. **속도 상한 증명**: 물체를 ~0.5 m/s로 홱 당김 → 로그의 TCP 속도가 `TRACK_VMAX_MPS`에서 평탄해야 함. **손으로 들기 전 필수 관문.**
6. **경계 클램프**: 물체를 박스 밖으로 → lost 처리·정지, 복귀 시 재획득.
7. **폴트 드릴**: 추적 중 'g'/'j'/'x' 각각 → 취소 로그 + 정상 상태. 화이트리스트 차단 키 몇 개 확인.
8. **핸드헬드**: 사람이 직접, 저속부터. 로그 기반 α/vmax 재튜닝.

측정 도구는 기존 'l' DataLog(1 ms 간격 goal/tcp/q/qd/tau) — 신규 코드 0.

## 명시적 보류 (v2+)

- 지연 보상/예측 (외삽) — 4단계에서 실지연 측정 후 판단
- 자세 재계산·top-down R 추종 / 추적 중 파지
- 데드밴드·정지 시 고강성 hold — 2단계 로그가 요구할 때만
- 서보 레짐 마찰 FF 튜닝 (`TRACK_KF_SCALE` 노브)
- person detection 재활성화, GUI 시작/정지 버튼

## 실행 메모

- 구현·빌드는 로봇 유휴 시(E34), 검증은 실기 세션. HOME 재기록 금지(reach map 무효화).
- 커밋: Step 0 단독 → Step 1-4는 단계별. push는 `seriouslysilly21612/RAON-RT-Revision` `kv260-merge`만. INDY7.cfg 커밋 금지.
- 완료 후 `ros2_ws/docs/RAON-RT/merge.md`에 추적 트랙 섹션 추가.
