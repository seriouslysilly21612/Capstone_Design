# RPU 트랙 착수 계획 — Gate 1 (FreeRTOS 구동) + 문서 최신화

## Context

2026-07-08에 세운 RPU(FreeRTOS+SOEM) 계획 이후 처음으로 실행에 들어간다. 그 사이 보드 환경이 크게 변했다:
- 커널이 커스텀 RT-PREEMPT(`5.15.199-rt91-rt-kv260c`)로 교체됨 — **재검증 결과 RPU에 필요한 커널 지원 전부 생존** (`ZYNQMP_R5_REMOTEPROC=m` vermagic 일치, rpmsg 4종, `OF_OVERLAY/OF_CONFIGFS=y`, `ZYNQMP_IPI_MBOX=y`, smartcam overlay가 RT 커널에서 applied 상태로 실증). **커널 재빌드 불필요**
- APU에서 IgH EtherCAT + RAON-RT로 Indy7 실운용 중 (CPU3 격리). 단 IgH는 상시 기동이 아님: 현재 `ethercat.service` inactive, eth0은 macb 소유·IP 없음(세션 시 기동). 원격 = **Tailscale 제거됨**, AX88179B USB NIC(`192.168.120.50`) 직결 SSH
- 보드 sudo는 비밀번호 필요 (passwordless 아님) — dmesg/iomem 확인 등은 사용자 입력 필요
- RPU 문서 3종은 `docs/rpu/`로 이동됨, 내용은 7/8 이후 무변경 (경로·일부 사실 낡음)
- `apu_rpu_bridge_pkg`는 7/15 정리 때 삭제됨 (Phase 5 때 재생성 필요)
- RPU 작업물(elf/dtso/SOEM/Vitis 프로젝트)은 전무 — 깨끗한 출발점

사용자 확정 (2026-08-03): Vitis 아직 미설치 / **당분간 Phase 0~1만** (GEM3 안 건드림, APU 운용 유지) / **이번 목표 = Gate 1** (remoteproc으로 R5에 FreeRTOS 올려 로그 확인). 추가 요청: **`docs/rpu/rpu_guide_for_claude.md`를 현재 상황에 맞게 최신화** — 다른 PC에서 Kria 원격 접속으로 작업할 때 이 문서만 읽고 바로 진행 가능하도록.

## 작업 순서

### Step 1 — 문서 최신화 (보드에서 바로 실행)

`docs/rpu/rpu_guide_for_claude.md`를 전면 갱신 (다른 두 문서는 stale 경로만 정정):

1. **경로 정정**: `~/ros2_ws/rpu_*.md` → `~/ros2_ws/docs/rpu/`, `site_md/` → `docs/reference/` (guide §0·§5, plan :236-237, execution_plan :5,43,77)
2. **§1 세션 환경 재작성**: 원격 = **USB NIC(AX88179B, ax_usb_nic v4.1.0) 경유 SSH `192.168.120.50`** (Tailscale 제거됨) — eth0은 더 이상 생명줄 아님, 대신 **eth0 = IgH EtherCAT 예약 포트**(현재 macb 소유·IP 없음, RAON-RT 세션 시 IgH가 점유). "원격 작업 온보딩" 절 신설: 접속 방법, 첫 확인 명령, sudo 비밀번호 필요 명시, 로봇 운용 중 금지사항(E34: 실기 세션 중 보드에서 무거운 작업 금지 — 에이전트 포함)
3. **§3 검증 사실 표를 현재 커널 기준으로 재검증값 반영**: 커널명, 모듈 생존, CmaFree 13MB→**340MB**, cmdline에 `isolcpus=3 nohz_full=3 rcu_nocbs=3 irqaffinity=0-2 skew_tick=1` 추가됨(CPU3는 RAON-RT 전용 — RPU 작업이 침범 금지), eth0 드라이버 현황(보드 재검증 에이전트 결과 반영), UART0 여전히 disabled
4. **§2 결정사항 갱신**: 작업 순서 항목 — APU IgH "완료 후"가 아니라 "실운용 중, GEM3 이관은 별도 사용자 결정 필요"로. Phase 2 진입 전제조건에 "APU 제어 중단 합의 + macb rebind 복구 절차" 명시
5. **§12 미결 해소 2건 반영**: ①Indy7 제어 코드 master = **IgH 확정**(`RAON-RT/EMasterApp/Device/EcatCommon.h:64`) → Phase 4는 IgH→SOEM 번역 이식으로 명시 ②제어 주기 = **1kHz 확정**(RAON-RT 실운용 실증). 잔여 미결: L7N PDF, UART0 라우팅, reserved-memory 주소
6. **§5 파일 지도 갱신**: `apu_rpu_bridge_pkg` 삭제됨(7/15) — Phase 5에서 재생성으로 정정. RAON-RT 정본 문서(`docs/RAON-RT/merge.md`) 참조 추가
7. 문서 머리에 "최종 검증일 2026-08-03, 커널 5.15.199-rt91-rt-kv260c" 스탬프

### Step 2 — Phase 1 보드측: reserved-memory 주소 확정 + DT overlay 작성·적용

Vitis 설치를 기다릴 필요 없음 — remoteproc probe까지는 펌웨어 없이 검증 가능:

1. `sudo dmesg | grep -iE 'cma|reserved'` + `sudo cat /proc/iomem`으로 CMA·기존 예약 영역 실주소 확인 → RPU 예약 영역 확정 (기준안: 0x3ed00000~0x3effffff, 충돌 시 조정. **no-map reserved-memory로 잡음 — CMA와 별개**). 확정값을 guide §12에 기록. ※ sudo 비밀번호 필요 — 사용자에게 요청
2. `modinfo`로 현 커널 binding 재확인 (`xlnx,zynqmp-r5-remoteproc` 예상) 후, RT 커널 소스(x86 PC의 빌드 트리 또는 linux-xlnx 5.15 태그)의 binding 문서·예제 dts 기준으로 `rpu_rproc.dtso` 작성: R5 클러스터(split), r5f_0, reserved-memory, IPI mailbox(기존 ipi-id 4 회피). 파일 위치: `~/ros2_ws/tools/rpu/` (repo 개편 규칙에 맞춤)
3. `dtc -@`로 컴파일 → configfs 적용 → `modprobe zynqmp_r5_remoteproc` → `/sys/class/remoteproc/remoteproc0` 등장 확인. dmesg로 probe 오류 디버깅
4. 주의: 전 과정이 eth0·smartcam·CPU3와 무관함을 매 단계 확인. 로봇 실기 세션 중에는 작업 보류(E34)

### Step 3 — Phase 0 PC측: Vitis 2022.1 설치 안내 (사용자 실행, Step 2와 병행)

사용자에게 절차 안내 (Claude는 보드에서만 실행 가능):
1. AMD Unified Installer로 Vitis 2022.1, 디바이스는 Zynq UltraScale+ MPSoC만 선택 (~디스크 150GB 여유 필요, 반나절+)
2. Vivado 2022.1 KV260 board preset → ZynqMP PS 블록디자인 → Export Hardware(bitstream 불포함) → XSA
3. Vitis platform: domain `psu_cortexr5_0`, OS `freertos10_xilinx`
4. 앱 템플릿: **OpenAMP echo-test 베이스** (resource table·trace 포함 — 순정 hello는 remoteproc 로드 실패 함정)
5. 링커 스크립트를 Step 2에서 확정한 예약 영역으로 수정, elf를 scp로 보드 전송 (USB NIC 경유라 GEM3 무관)

### Step 4 — Gate 1 검증

1. `/lib/firmware`에 elf 배치 → remoteproc firmware 지정 → `start`
2. 로그 확인 1순위: `sudo cat /sys/kernel/debug/remoteproc/remoteproc0/trace0` (UART 불필요). 2순위: UART1 공유(콘솔 섞임 감수)
3. start/stop 10회 반복 안정 확인 → **Gate 1 통과**
4. 통과 시: guide·execution_plan에 Gate 1 달성 기록 + 지속 메모리 갱신. 이관(Phase 2) 시점은 사용자와 별도 결정

## 수정 파일

- `~/ros2_ws/docs/rpu/rpu_guide_for_claude.md` — 전면 갱신 (Step 1)
- `~/ros2_ws/docs/rpu/rpu_plan.md`, `rpu_freertos_soem_execution_plan.md` — stale 경로·확정사항만 정정
- `~/ros2_ws/tools/rpu/rpu_rproc.dtso` — 신규 (Step 2)
- 지속 메모리 `kria-rt-preempt-project.md` — 착수 기록

## 검증 방법

- Step 1: 문서를 처음 읽는 시점 기준으로 명령어를 그대로 복붙해 통과되는지 보드에서 재실행 확인
- Step 2: `ls /sys/class/remoteproc/` 결과와 dmesg 무오류
- Step 4: trace0 로그에 FreeRTOS 태스크 출력 + start/stop 반복 — 이것이 Gate 1 판정 그 자체
- 전 단계에서 `ethercat slaves`(IgH)·`ros2 topic hz`가 계속 정상인지 확인해 APU 운용 무영향 입증

## 부수 발견 (RPU 범위 밖, 사용자 보고만)

- **irqbalance.service가 실행 중** — `irqaffinity=0-2`에도 불구하고 런타임에 IRQ를 CPU3로 되돌릴 수 있어 RAON-RT 1kHz 지터 예산을 위협할 소지. RAON-RT 트랙에서 검토 권고 (이번 계획에서는 건드리지 않음)
- docker/containerd, cups, avahi 등 비필수 서비스 다수 상주 — RT 박스 백그라운드 부하. 참고만

## 명시적 제외 (이번 범위 아님)

- GEM3 이관·SOEM·L7N 연결 (Gate 2+, 사용자 재결정 필요)
- apu_rpu_bridge_pkg 재생성 (Phase 5)
- boot-time DT 반영 (Gate 1은 runtime configfs로 충분 — reserved-memory 실사용 전에만 필요)
