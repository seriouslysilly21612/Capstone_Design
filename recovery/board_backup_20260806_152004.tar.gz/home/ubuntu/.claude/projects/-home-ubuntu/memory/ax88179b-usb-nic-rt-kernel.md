---
name: ax88179b-usb-nic-rt-kernel
description: "AX88179B USB-이더넷이 -rt-kv260c에서 -32로 죽던 문제 — 빌트인 구형 드라이버가 원인, ASIX v4.1.0 OOT 드라이버 + 커널 =m 재빌드 + udev 규칙으로 영구해결(2026-07-20). cdc_ncm 하이재킹 함정 포함"
metadata: 
  node_type: memory
  type: project
  originSessionId: 9049162f-8c62-4f51-90bb-b85b8619caea
  modified: 2026-07-20T04:56:55.138Z
---

Kria KV260(`5.15.199-rt91-rt-kv260c`)에서 **네트워크=USB어댑터, EtherCAT=내장 eth0(native macb GEM)** 구성을 위해 USB-이더넷 어댑터를 붙였는데 SSH/인터넷 연결 실패. 관련: [[kria-rt-preempt-project]].

## 증상
- `lsusb`엔 `0b95:1790 ASIX AX88179`로 보이지만, `dmesg`의 실제 Product string은 **`AX88179B`** (신형 "B" 리비전).
- `ax88179_178a ... Failed to read reg index 0x0040: -32` 무한 반복 + register/unregister 플랩, IP 못 받음.
- `-32` = EPIPE = 컨트롤 전송에 대한 **STALL**. LPM/USB3신호/전원 문제 아님. (usb3_lpm_permit off, USB2 강등 시도 다 무효)

## 근본 원인
5.15 인트리 `ax88179_178a` 드라이버가 **빌트인(=y)**이고 원조 179용이라, AX88179**B**의 레지스터 접근을 STALL → 초기화 실패.

## 해결 (검증 완료)
1. ASIX 공식 OOT 드라이버 **`ASIX_USB_NIC_Linux_Driver_Source_v4.1.0`** 사용 → 빌드 산출물 모듈명은 **`ax_usb_nic.ko`** (AX88179B_179A_772E_772D 지원).
2. **보드 네이티브 빌드는 실패** — 헤더패키지(`/usr/src/linux-headers-5.15.199-rt91-rt-kv260c`)의 호스트툴(fixdep/conf)이 x86 바이너리라 `Exec format error`, 게다가 Kconfig 없는 stripped라 `modules_prepare` 불가.
3. **빌드 PC에서 크로스컴파일**로 해결: `jaehyeon@jaehyeon-Raimlab:~/kria-rt/linux-5.15-rt-kria` 트리에서
   `make -C ~/kria-rt/linux-5.15-rt-kria M=$PWD ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- modules` → vermagic 일치.
4. **빌트인은 rmmod 불가** → 런타임 핸드오프: `echo 2-1.3:1.0 > /sys/bus/usb/drivers/ax88179_178a/unbind` 후 `echo 2-1.3:1.0 > /sys/bus/usb/drivers/ax_usb_nic/bind`.
5. 결과: 링크 안정, DHCP IP(192.168.120.239) 획득, ping 0% loss.

## 영구화 (완료·재부팅검증 2026-07-20)
커널을 `CONFIG_USB_NET_AX88179_178A=m`으로 재빌드·재플래시(빌드PC에서). 그 뒤 보드에서 배선:
1. `ax_usb_nic.ko` → `/lib/modules/$(uname -r)/kernel/drivers/net/usb/` + `depmod -a`
2. `/etc/modprobe.d/ax_usb_nic_blacklist.conf` — **`blacklist`만으론 부족(아래 함정2)**. 반드시:
   ```
   blacklist ax88179_178a
   install ax88179_178a /bin/true
   ```
3. `/etc/modules-load.d/ax_usb_nic.conf` = `ax_usb_nic` (부팅 자동로드)
4. **`/etc/udev/rules.d/50-ax_usb_nic.rules`** ← CDC 차단 핵심 (함정1)
스크립트: `~/setup_ax_usb_nic.sh`(초기설치), `~/fix_ax_usb_nic.sh`(하드블록 보강+런타임 되돌림). 최종상태: `enxc8a362ec54c4 → ax_usb_nic`, `-32` 0.

## ⚠️ 함정2: blacklist만으론 부팅 레이스 못 이김
재부팅 후 `ax_usb_nic`(modules-load로 로드됨)과 `ax88179_178a` **둘 다 로드**되고, 구형이 장치(2-1.3:1.0) 바인드를 **먼저 낚아챔** → netdev가 다시 `ax88179_178a`. `blacklist`는 이 로드를 못 막음. 해결 = **`install ax88179_178a /bin/true`** (모듈 로드 자체를 무력화) → 다음 부팅부터 구형 안 뜸, ax_usb_nic 단독 바인드. 런타임 즉시복구는 `unbind`→`ax_usb_nic/bind`.

## ⚠️ cdc_ncm 하이재킹 함정 (놓치기 쉬움)
`blacklist ax88179_178a`만 하면 **AX88179B가 노출하는 CDC 인터페이스를 `cdc_ncm`이 대신 채감** → netdev가 `ax_usb_nic`이 아니라 `cdc_ncm`에 물림. 해결은 ASIX 제공 **`50-ax_usb_nic.rules`** — `0b95:1790`의 `bConfigurationValue`를 1(proprietary)로 강제해 CDC config를 밀어냄. 라이브로는 `echo 1 > /sys/bus/usb/devices/2-1.3/bConfigurationValue`. (Readme "make udev_install"이 이 역할.)

## 운영 노트
- **보드에서 Claude Code는 `ubuntu`로 돌고 `sudo`가 비번 요구** → 루트 필요한 설치는 스크립트로 만들어 사용자가 `sudo bash`로 실행하는 패턴.
- `ax88179_178a`가 로드돼 있어도 장치에 안 물렸으면 무해(blacklist로 다음 부팅 차단됨). 재부팅 검증은 사용자 재량으로 남김.

## 관리 접속 계획 (2026-07-20) — EtherCAT 전환 대비
- 보드 hostname `kria`, **avahi(mDNS) 켜짐** → PC에서 `ssh ubuntu@kria.local`로 IP 무관 접속. 사용자 `~/.ssh/config`의 `kria` alias를 `kria.local`로 변경함.
- 네트워크는 **NetworkManager** 관리(Ubuntu 22.04, netplan은 위임만). USB NIC 고정IP 프로파일 생성: `nmcli con add ... con-name usb-net ifname enxc8a362ec54c4 ipv4.method manual 192.168.120.50/24 gw .1 autoconnect yes`. GW `192.168.120.1`, /24.
- **케이블 1개**를 eth0→USB어댑터로 옮김(2026-07-20). 현재: USB NIC이 네트워크(default route via .50, 인터넷 OK), **eth0는 케이블 빠져 unavailable = EtherCAT용으로 비워짐**. 관리 접속은 `ssh kria`(mDNS→.50) 또는 `ssh ubuntu@192.168.120.50`.
- EtherCAT 시작 시 eth0는 이미 비어있으므로 락아웃 위험 없음. 단 USB NIC(유일 경로)이 죽으면 물리 콘솔뿐 — 재부팅류 작업 전 물리 콘솔 확보 권장.

**Why:** 겉보기 칩셋(179)만 보고 "지원됨"으로 판단하면 오진. 실제는 179**B** 신형이고 빌트인 구형 드라이버가 STALL을 냄. 그리고 드라이버만 고쳐도 **cdc_ncm이 가로채면** 여전히 안 됨.
**How to apply:** ASIX USB-NIC이 `-32`로 플랩하면 → dmesg Product string으로 B 리비전 확인 → ASIX v4.1.0 OOT 드라이버를 **빌드 PC에서 크로스컴파일**(보드 헤더는 x86툴/Kconfig 없어 네이티브 불가) → 커널 `=m` 재빌드 + blacklist + autoload + **udev 규칙(cdc_ncm 차단 필수)**. 향후 어댑터 구매는 **RTL8153(r8152)** 칩셋이 무난.
