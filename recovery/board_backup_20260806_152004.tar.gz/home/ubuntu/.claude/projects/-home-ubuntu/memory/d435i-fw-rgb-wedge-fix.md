---
name: d435i-fw-rgb-wedge-fix
description: D435i FW 5.16.0.1에서 librealsense 스트리밍 수십 초 후 RGB(나중엔 depth도) 정지 + UVC GET_CUR 스톨 — FW 5.17.0.10 업데이트로 해결 (2026-07-14)
metadata: 
  node_type: memory
  type: project
  originSessionId: 8b2c9174-5e60-4a85-b73c-06b457971acc
---

2026-07-14, 비전 파이프라인 재개 시 카메라가 "노드는 정상 기동인데 프레임 0"으로 막힘. **원인 = D435i 펌웨어 5.16.0.1의 컨트롤플레인 크래시**: librealsense 세션에서 스트리밍 수십 초(15s~80s, 비결정적) 후 RGB 프레임 정지 + dmesg `Failed to query (GET_CUR) UVC control 1 on unit 3: -32 (exp. 1024)` 반복(=librealsense global_timestamp_reader의 depth-인터페이스 HWM 폴링이 STALL 당함). 악화되면 depth도 0프레임. **`rs-fw-update -f D4XX_FW_Image-5.17.0.10.bin`으로 완치** — 직후 3분 완주(det 15.9Hz, 드랍 0).

**판별에 쓴 결정적 분리(재사용 가치):**
- cv2 V4L2 직접 캡처(`cv2.VideoCapture(N, CAP_V4L2)`)는 항상 30fps 완벽 → 하드웨어/USB/커널 uvcvideo 무죄, librealsense 경유만 사망.
- 무효였던 조치: `initial_reset:=true`(hardware_reset), 물리 replug(콜드부팅), USB 포트 변경, 보드 재부팅(잠깐 연명만).
- uvcvideo `quirks=0xFFFFFFFF`는 **미설정 sentinel 기본값** — 범인 아님 (같은 함정 재탕 금지).
- FW 직링크 패턴: `https://librealsense.intel.com/Releases/RS4xx/FW/D4XX_FW_Image-<ver>.bin` (Intel 공식, rs-fw-update로 플래싱, ~1분).

**잔여 사항:** 신FW에서도 GET_CUR 노이즈는 간헐 발생하나 **무해**(스트림 안 죽음). 거슬리면 librealsense global_time 폴링 쪽 조치 검토(realsense-ros 4.57엔 직접 파라미터 없음). realsense config에 `initial_reset: true` 추가된 상태([[kria-rt-preempt-project]] 보드의 `system_bringup_pkg/config/realsense_pick_place.yaml`) — 기동 몇 초 늘지만 웨지 방어로 유지.

**How to apply:** 카메라가 "노드 Up인데 프레임 0" 증상이면 (1) dmesg GET_CUR 확인 (2) cv2 직접 캡처로 층위 분리 (3) FW 버전 vs `rs-enumerate-devices`의 Recommended 확인 → 구버전이면 FW 업데이트가 1순위.
