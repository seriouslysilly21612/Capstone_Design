---
name: desktop-bbox-overlay-viewing
description: "데스크톱 bbox overlay 뷰어 — 완료·실물검증(2026-07-16). 보드는 압축만/그리기는 데스크톱, 15Hz·0.79코어, 5클래스 정렬 확인. +FPS HUD·CSV 로깅(2026-07-22)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 8b2c9174-5e60-4a85-b73c-06b457971acc
  modified: 2026-07-22T10:38:22.074Z
---

Kria 검출 결과를 데스크톱에서 bbox overlay 영상으로 보는 작업. **2026-07-16 완료·실물 검증.** 커밋 `915d86d`. 정본 문서 `docs/vision/desktop_viewer_plan.md`(전제 스냅샷/게이트/함정 10개).

**구조**: 보드는 JPEG 압축만, 그리기는 전부 데스크톱. `publish_overlay` 계속 OFF.
- 보드: `ros2 launch system_bringup_pkg pick_place_vitis_ai.launch.py` — **2026-07-20 단일 launch로 통합**(옛 `viewing.launch.py`/`realsense_viewing.yaml` 삭제). 전체 pick 파이프라인이 항상 돌고 뷰어는 거기 붙는다. 압축 토픽은 플러그인만 있으면 전체 파이프라인에서도 광고+**구독 시에만 인코딩(lazy)**이라 뷰잉 전용 launch가 불필요했음(보드 실측 재확인: Subscription 0에서 인코딩 0, `/detections` 15.3 Hz). color는 pick path 신선도 위해 **30 fps 유지**. 옛 "camera+detector만 0.79코어"는 검출 전용 모드 수치 — 지금은 전체 파이프라인(≈1.8코어) + 관찰 중에만 lazy JPEG. (DDS env 2줄은 이제 launch가 주입.)
- 데스크톱: `ros2 run detection_viewer_pkg detection_viewer_node` (`~/pp_ws/viewer_ws`, jaehyeon@jaehyeon-Raimlab, Humble)

**2026-07-22 추가 (뷰어 노드)**: ① **출력 FPS HUD 우상단** — `render()`(=imshow) 간격을 `time.monotonic()`으로 재 EMA(alpha 0.2) 평활, 검은 외곽선+초록 글자. render는 detection당 1회라 표시 FPS≈detection rate(~15~17, 실측 avg 16.7). ② **FPS CSV 로깅 항상 켜짐** — 런타임엔 리스트 append만(디스크 I/O 0), **종료 시 `dump_fps_csv()`가 1회 flush**. 저장 `~/pp_ws/viewer_ws/fps_log/fps_<ts>.csv`(자동생성·시각파일명, `--fps-dir`/`--fps-csv`로 변경), 컬럼 `elapsed_s,inst_fps,ema_fps,n_det`. `q`/`ESC`/`Ctrl-C`는 flush, `kill -9`는 못 함. **비자명**: dump 요약을 `get_logger()`가 아니라 `print()`로 냄 — Ctrl-C 시점엔 rclpy context가 이미 무효라 ROS 로그가 `/rosout` 발행 실패로 `publisher's context is invalid` 경고를 내기 때문(CSV·렌더는 무관, cosmetic). 정본 문서 `docs/vision/desktop_viewer_plan.md`는 이제 **as-built 명세**(§4 구현 명세, §5 scp 배포)로 재작성됨.

**실측 결과**: `/detections`·압축스트림 각 **15 Hz**, 보드 CPU **0.79코어**(camera 36.8 + detector 21.1 + worker 21.1) — 전체 파이프라인 1.8코어 대비 절반 이하. 5클래스(apple/orange/banana/tennis_ball/mustard_bottle) 동시 검출·박스 정렬·라벨 정확 확인. conf 0.81~0.88. 영상 버벅임 없음.

**★ 이 작업으로 확정된 비자명 사실** (다시 조사하지 말 것):
- **보드에서 그리면 안 된다**: overlay 44.1ms/frame + detect 37.6ms = 81.8ms > 15Hz 예산 66.6ms → **검출률이 조용히 떨어진다**(`metrics_csv_path:""`라 안 보임). 문서의 "~70ms"와 재측정 15/44ms가 다투지만 **데스크톱에서 그리면 논쟁 자체가 무의미**.
- **Humble에는 type hash가 없다** → `.msg`가 어긋나도 엔드포인트는 **정상 매칭되고 쓰레기 값을 역직렬화**한다(에러도 no-match도 아님). 최대 위험. 방어책은 `md5sum src/my_interfaces/msg/*.msg` 양쪽 대조뿐. 실측 4/4 일치.
- **color encoding은 `rgb8`인데 JPEG엔 BGR이 담긴다**(compressed_image_transport가 인코딩 전 bgr8 변환). 따라서 `cv2.imdecode`→`imshow`가 그대로 맞고 **채널 변환을 넣으면 오히려 반전된다**(오렌지가 파래짐 — 실물로 반증 완료).
- **bbox는 원본 848×480 픽셀**. worker가 letterbox를 이미 되돌리고(`vitis_ai_worker_yolo.py:332-335`) `send_resized_input:false`라 sx=sy=1. **416×416 역변환 금지.**
- **SHM 프로파일은 원격을 막지 않는다**: `useBuiltinTransports=false`는 기본 **transport**를 끄지 **locator**를 안 끈다. UDPv4가 userTransports에 있으면 거기서 metatraffic locator가 파생됨. `interfaceWhiteList` 추가 금지(eth0가 DHCP, FastDDS 2.6은 CIDR 미지원).
- **ufw는 안 막는다**: `/etc/ufw/ufw.conf` `ENABLED=no`라 룰을 안 건다. `systemctl is-active ufw`가 `active`라고 **거짓말한다**. 단 `DEFAULT_INPUT_POLICY="DROP"`이라 누가 `ufw enable` 하면 원격만 전멸(지뢰).
- **color 15fps는 공짜**: `process_period_sec:0.045`는 *최소 간격* 게이트라 66.6ms 프레임은 전부 통과 → **검출 15Hz 유지 + JPEG 절반**. 30fps면 detection 기준 렌더에서 절반을 버리므로 순수 낭비. 부수효과로 detector가 31→21.1%(버려질 프레임의 콜백이 사라짐).
- **image_transport 인코딩은 lazy**: `Publisher::publish`가 `getNumSubscribers()`(vtable slot 3)를 보고 0이면 `publish()`(slot 5)를 건너뛴다(설치된 `.so` 디스어셈블로 확인). 뷰어 끄면 비용 즉시 0. 단 raw+compressed **합산**이라 compressed만 구독해도 publish 경로 전체가 깨어남.
- 플러그인은 pluginlib ClassLoader 생성 시 **한 번만** enumerate → apt install 후 **카메라 노드(프로세스) 재시작 필수**. USB 재연결은 소용없음.
- `jpeg_quality` 정확한 이름 = `camera.color.image_raw.compressed.jpeg_quality` (선행 점 없음, 실물 관측). **틀리면 조용히 무시됨.**

**How to apply:**
- 저장소가 **private**이라 데스크톱에서 `git clone`하면 인증을 묻는다. 연구실 PC에 PAT를 남기지 말고 **`scp -r ubuntu@192.168.120.132:~/ros2_ws/src/{my_interfaces,detection_viewer_pkg} src/`** 로 받을 것. 그다음 md5 대조.
- 데스크톱은 **RMW/ROS_DOMAIN_ID/FASTRTPS 프로파일 전부 설정하지 말 것** — Humble 기본값이 이미 맞다(보드도 fastrtps, domain 0). 옛 계획서의 `export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp`는 **정확히 반대**다.
- 뷰어 색상 맵은 `decode_meta.json` names 기준. `vitis_ai_detector_node.BOX_COLORS`는 **구 SSD {car,bicycle,person}**이라 현재 6클래스와 교집합 0 — 복사 금지.
- `ros2 topic list`가 토픽을 누락하면 **`--spin-time 8`**을 줄 것(기본 discovery window가 짧아 불완전한 그래프를 정상인 양 반환).
- **조인은 양방향이어야 한다** (`8eb6338`, 100% 달성): 두 스트림이 **경합**한다 — detection은 캡처 ~37ms 뒤 발행돼 네트워크를 건너고 압축이미지는 독립 경로로 건너므로 **어느 쪽이든 먼저 올 수 있다.** 한쪽(detection 도착 시)에서만 찾으면 1~5%가 버려진다. `on_image`에서도 대기 detection과 짝을 맞출 것. 실측 `drawn=75 (hit=70 late=5) drop=0 stale=0`. 늦게 온 이미지를 무조건 그리면 화면이 뒤로 감기므로 **단조 가드** 필요(단 66ms 미만 지연은 어차피 순서 유지라 실측 `stale=0` — 보험용).
- 관련: [[perception-cpu-opt-phase1]], [[ros2ws-repo-layout]], [[yolov3-vision-swap-resume]].
