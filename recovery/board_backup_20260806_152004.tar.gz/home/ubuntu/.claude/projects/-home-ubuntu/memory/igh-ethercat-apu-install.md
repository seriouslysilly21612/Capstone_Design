---
name: igh-ethercat-apu-install
description: "APU IgH EtherCAT 마스터 설치 결정/절차 — 5.15-rt/aarch64 Kria엔 1.5.2 타르볼 불가(빌드 실패), git stable-1.6(태그 1.6.10)+generic 드라이버. lab 가이드는 x86/igc라 configure 플래그 ARM 보정 필수. RPU+SOEM은 별도 후속트랙 (2026-07-21)"
metadata: 
  node_type: memory
  type: project
  originSessionId: cde80993-41a2-4b1d-98e8-5acdbfa47cd3
  modified: 2026-07-22T08:51:02.106Z
---

2026-07-21, RT커널(`5.15.199-rt91-rt-kv260c`) 위에 **APU용 IgH EtherCAT(EtherLab) 마스터** 착수. 사용자 방침: **지금 APU는 IgH, 나중에 RPU까지 쓸 때 RPU에 SOEM** (별개 트랙, 혼동 금지).

**버전 검증(리서치 워크플로우로 적대적 검증, 3주장 모두 반박됨):**
- **1.5.2는 불가.** 2013-02-12 고정 타르볼 → 5.15에서 컴파일 실패(`timeval_poll incomplete type`, `vm_fault_t` 시그니처 변경). gitlab issue #1에 5.10-rt 동일 에러 기록. lambert 패치셋도 4.19까지만. 사용자의 "1.5.2가 맞다"는 흔한 혼동(=**git `stable-1.5` 브랜치 팁**을 타르볼과 혼동; 팁은 1.5.4까지 나감).
- **정답 = `stable-1.6` 브랜치(태그 1.6.10)**. upstream 홈페이지가 프로덕션 공식 권장. 1.6.0(2024-06)이 커널 5.14/6.1 네이티브 추가, <3.0 드롭.
- **macb=generic 확정.** Cadence GEM(`macb`, eth0, MAC `00:0a:35:0c:ff:64`, Xilinx OUI 00:0a:35)에 IgH native 드라이버 없음. (1.6.10이 macb 드라이버 추가했으나 **커널 6.18/RPi5 RP1 GEM 전용** → 5.15/ZynqMP엔 소스 변종 없음). → `--enable-generic`, `DEVICE_MODULES="generic"`.

**설치 기준 문서 = lab 가이드 MAN-20241113-LX02H0001** (인텔 NUC x86/igc용). **그대로 쓰면 안 됨** — ARM 보정:
- 1~3장(RT커널 소스빌드 2~3h) **통째 스킵** — 우리 kv260c RT커널 완료. §5.2/5.3만 해당.
- configure(우리): `--prefix=/opt/etherlab --enable-generic --enable-8139too=no --enable-cycles=no --enable-hrtimer=yes --enable-eoe=no --with-linux-dir=/lib/modules/$(uname -r)/build`
  - vs 가이드 차이: **generic 추가**, **Intel(igc/e1000e/igb) 전부 제거**, **cycles=yes→no**(aarch64엔 x86 TSC 없음). hrtimer/eoe=no/8139too=no는 유지.
- 가이드 제목만 "1.6.2"지 실제 명령은 `git checkout stable-1.6; git pull`(=브랜치 팁). 재현성 위해 `git checkout 1.6.10`(태그) 권장.

**빌드 선결 상태(전부 충족, 즉시 빌드 가능):** libtoolize·autoconf·automake·gcc·make·커널헤더 심링크 OK. 인터넷=USB NIC 경유 OK.

**★ 원격 안전 확인:** 기본경로·SSH가 **USB NIC(`enxc8a362ec54c4` ax_usb_nic, 192.168.120.50)** 로 나감 — **eth0 아님**. 따라서 빌드는 물론 `ethercatctl start`(generic이 eth0 바인딩)까지 세션 안 끊김. 계획문서 "eth0 이관 전 대체망 확보" 선결조건 이미 충족. 관련 [[ax88179b-usb-nic-rt-kernel]].

**⚠️ 성능 천장:** macb+generic 실측 **~1ms 사이클 상한**(동일 GEM RPi5: 250µs 드라이브 드롭, ~1ms 안정). DC 동기 정확도는 sub-µs 유지. 1kHz가 천장 → 더 빠르면 RPU+SOEM 트랙. 관련 [[kria-rt-preempt-project]].

**★ 크로스빌드 헤더 함정(실증·해결, 2026-07-21):** 우리 커널은 PC에서 크로스컴파일→**image+headers .deb만** 보드로 옮겨 설치. 그래서 `/lib/modules/$(uname -r)/build`의 **호스트툴(fixdep/modpost/conf)이 전부 x86-64** → 보드 네이티브 모듈 빌드가 `fixdep: Exec format error`로 즉사. **`make modules_prepare` 금지**(① 헤더 pkg에 없는 `arch/arm64/tools/Makefile` 요구로 중단 ② `utsrelease.h` 재생성하며 `rt91` 소실 → vermagic `5.15.199-rt-kv260c`로 어긋나 insmod 거부). **해결 = fixdep+modpost만 gcc로 직접 네이티브 컴파일 + x86 conf를 no-op 스텁 치환**(원본 utsrelease 유지). 스크립트 `~/prep_kbuild_native.sh`(sudo로 실행, 시스템 헤더트리 대상, 멱등). **검증**: 이렇게 준비한 트리로 hello.ko 빌드 → vermagic `5.15.199-rt91-rt-kv260c` = uname -r 정확 일치. SIG_FORCE 미설정이라 미서명 로드 자유(zocl/ax_usb_nic 동일), MODVERSIONS=y지만 Module.symvers 원본 유지라 CRC 일치. 대안=PC서 IgH 커널모듈 크로스컴파일(기존 워크플로우와 일치하나 userspace 크로스빌드 번거로움). 관련 [[ax88179b-usb-nic-rt-kernel]].

**★ prep 확장(2026-07-21, 빌드 중 발견):** 호스트툴이 fixdep·modpost 말고 **genksyms도** x86라 `make modules`가 `master/device.o`에서 `genksyms: Exec format error`. genksyms는 MODVERSIONS 커널에서 **export 심볼(ecrt_*) 있는 오브젝트**에만 호출돼 hello 테스트론 안 걸렸음. prep 스크립트에 `(cd scripts/genksyms && gcc -O2 -I. -o genksyms genksyms.c parse.tab.c lex.lex.c)` 추가(_shipped 아님, 실제 생성본 사용). 실증: export 심볼 모듈 빌드 통과. **모듈빌드용 x86 툴은 fixdep/modpost/genksyms 3개가 전부**(kallsyms/dtc/sorttable/sign-file은 vmlinux·DT·서명용이라 무관, recordmcount는 arm64 컴파일러방식이라 없음).

**★ 서명 관문:** 커널 `CONFIG_MODULE_SIG_ALL=y`(설치시 자동서명 시도)+`SIG_KEY=certs/signing_key.pem` **키는 보드에 없음(PC만)**+`sign-file`도 x86. 단 `SIG_FORCE` 미설정이라 미서명 로드 자유. → **`sudo make modules_install install mod_sign_cmd=true`** 로 서명단계 no-op(커널 서브메이크로 전파). depmod 후 로드 OK.

**미완/다음:** ① `sudo bash ~/prep_kbuild_native.sh`(genksyms 포함) → ② `make modules -j` 완주 확인 → ③ `sudo make modules_install install mod_sign_cmd=true; sudo depmod` → ④ symlink + ethercat.conf(MASTER0_DEVICE=00:0a:35:0c:ff:64/DEVICE_MODULES=generic) → ⑤ ethercatctl start→dmesg(ec_generic)→ethercat master/slaves. 사용자 실행 대기(비대화형 sudo 불가).
