---
name: perception-cpu-opt-phase1
description: "비전 파이프라인 CPU 절감 phase 1+2 완료 (76.8→~44%, ≈-1.25코어), 남은 백로그·rclpy 병합 함정 (2026-07-14)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 8b2c9174-5e60-4a85-b73c-06b457971acc
---

2026-07-14 세션에서 perception 파이프라인 CPU 절감 phase 1 완료 (순정커널 5.15.0-1070 + D435i FW 5.17.0.10 기준, [[d435i-fw-rgb-wedge-fix]] 해결 후).

**결과**: 총 CPU **76.8% → 53.1%** (4코어 평균, ≈3.07→2.12코어), target_3d **68.9→12.0%**, camera 53.6→40.2, worker 36.9→25.4, detector 43.4→39.8. e2e 124→92ms. det 중앙값 15.0Hz 유지. 전/후 산출: `~/vitis_ai_work/perf/runs/stock_fw51710_baseline_20260714` vs `runs/phase1_cpuopt_20260714`. 상세 표: `docs/STATUS.md §4.2 "CPU 절감 phase 1"`.

**적용된 것 (전부 무손실 검증)**:
1. epipolar 벡터화 (`target_3d_pkg/pick_target_3d_node.py`) — 라이브 4500 pick A/B mismatch 0. 루프 레퍼런스는 `color_pixel_to_depth_pixel_loop`로 보존, `epipolar_ab_check` 파라미터로 언제든 재검증.
2. camera_info/extrinsics 첫 수신 후 구독 prune (동 파일, 타이머 방식).
3. worker letterbox cv2 경로 (`vitis_ai_worker_yolo.py`) — bit-identical PASS, pre 17.5→9.0ms.
4. depth 30→15fps (`realsense_pick_place.yaml`), `target_3d.yaml` min/max_depth 0.19/1.6 (base gate와 정합 — **workspace 확장 시 target_base.yaml과 같이 조정**).
5. 검출률 캡 `vitis_ai_detector.yaml process_period_sec: 0.045` (=2프레임 주기 15Hz). **함정: 0.062는 프레임 지터로 3프레임 주기(13.8Hz)로 떨어짐** — 33.3~66.6ms 사이 안전값이어야 하며 45ms 검증됨. 0.0이면 ~19Hz(uncap, +3~5%p CPU).

**Phase 2 완료 (2026-07-14 동일 세션, 최종 총 ~44% ≈1.8코어)**:
- 채택: DP unbind(사용자 sudo, irq 11k/s→0) — **영구화 방법 확정(2026-07-14)**: `zynqmp-display`는 빌트인 아닌 **모듈 `zynqmp_dpsub`**(initrd에도 존재)이므로 `echo 'blacklist zynqmp_dpsub' | sudo tee /etc/modprobe.d/blacklist-zynqmp-dpsub.conf && sudo update-initramfs -u`, 확인 `lsmod|grep dpsub` 무출력. 롤백=conf 삭제+update-initramfs. (RT initrd엔 이미 반영; 이건 순정용.) / **FastDDS+SHM 전환**(-6.6%p, camera 40→29·detector 39→31). **배선 위치 변경(2026-07-15)**: 원래 `.bashrc`의 export 2줄이었으나 `pick_place_vitis_ai.launch.py`가 `SetEnvironmentVariable`로 주입하도록 이관, XML은 `~/ros2_ws/src/system_bringup_pkg/config/fastdds_shm_profile.xml`에서 `FindPackageShare`로 해석 → **clone-and-run**. `.bashrc`에 다시 export하지 말 것(셸이 launch를 이기고 절대경로는 타 머신에서 깨짐). 검증법: 가동 중 `ls -la /dev/shm/ | awk '$5>16000000'`가 노드 수(6)만큼 나오면 프로파일 적용됨 / t3d depth lazy(frombuffer, 비트동일 확인) / base 정적 TF (R,t) 캐시(오차 0, base 10.4→6.7) / worker decode 상수 hoist.
- **기각·롤백: rclpy 노드 병합** — pick_logic+t3d+base를 한 프로세스로 합치면 **+5.4pt 역효과** (rclpy executor가 매 콜백 전체 waitset 재구성 → 엔티티 수에 비례해 모든 dispatch 단가 상승). 코드는 `target_3d_pkg/pick_post_stack.py`에 사유와 함께 보존. **rclpy에서 노드 병합으로 CPU 아끼려 하지 말 것** — rclcpp composition만이 답.
- 잔여 CPU 백로그: node→worker POSIX shm IPC(-3~5pt) / detector raw 구독(-2~6pt) / rosout off(-3~6pt, 트레이드오프) / (조건부, 검출품질 A/B 필수) color YUYV(-17~30pt, bit-identity 깨짐).

**★ 전략 결정 (2026-07-14): CPU는 여기서 멈춤 — 다음은 RT 커널 완성.** EtherCAT 헤드룸 판정: 비전 ~1.8코어 → 여유 ~2.2코어, EtherCAT+제어 ~0.2~0.7코어 예상(3배+ 마진). **CPU 절감 불필요.** 비전 **성능** 개선(fps/latency)은 RT 완성 후 착수(RT 위에서 baseline 재측정이 맞음, RT 오버헤드 +5~10%p 예상). 성능 phase3 레버 카탈로그(추천순): ①node↔worker POSIX shm(latency & CPU 동반↓, 유일 win-win) ②캡 process_period_sec 조정 ③worker 3단 pipelining(VART async, latency 불변) ④color 60fps ⑤YOLOv3-tiny 교체([[yolov3-vision-swap-resume]] 합류) ⑥rclcpp composition. e2e 81ms 분해: 캡처→도착 40.7ms(센서물리)/IPC 6.1/pre 8.2/DPU 16.9/post 4.2. phase3 첫 작업 = perf_probe를 최종 target 토픽까지 확장. 상세 표 `docs/STATUS.md §4.2`.

**How to apply:**
- 측정 하네스 `~/vitis_ai_work/perf/run_gate6_perf.sh 180` — 단 하네스가 남기는 고아 `ros2 launch` 래퍼를 preflight가 잡으므로 재실행 전 `pkill -f pick_place_vitis_ai.launch` 필요할 수 있음(패턴이 자기 셸과 매치되는 pkill 자기매치 함정 주의 — bracket 트릭 `[p]ick_...` 사용).
- **`ros2 topic hz/echo` 무출력의 원인 규명(2026-07-15)** — "이 보드에선 CLI가 신뢰 불가"라고 적어뒀던 증상은 보드 탓이 아니라 원인이 둘이었다. ① **daemon이 차가움**: `ros2 daemon stop` 직후엔 그래프 캐시가 비어 `hz`/`echo`가 discovery 안에 못 끝내고 "does not appear to be published yet"를 뱉는다 → `ros2 daemon start; sleep 6` 후 측정하면 정상(15.9Hz 재현). ② **`FASTRTPS_DEFAULT_PROFILES_FILE`이 없는 파일을 가리킴**: `XMLPARSER Error: realpath failed`를 남기고 계측 도구만 오작동(파이프라인은 멀쩡). **파이프라인이 죽었다고 오판하기 전에 launch 로그부터 볼 것** — 로그에 `Published detections`가 흐르면 도구 문제다.
- 비전 파이프라인은 이제 **RT 커널에서도 동작** — [[zocl-dpu-rt-kernel-crash]] 해결·검증 완료(2026-07-15).
