---
name: person-detection-disabled
description: "person 검출을 worker threshold=2.0으로 끔 — 주석 처리는 작동 안 함(0.50 폴백), person_guard 안전 래치와 커플링"
metadata: 
  node_type: memory
  type: project
  originSessionId: 8b2c9174-5e60-4a85-b73c-06b457971acc
  modified: 2026-07-29T04:30:17.275Z
---

2026-07-27부터 **person 검출이 꺼져 있다.** `vitis_ai_worker_yolo.py`의
`CLASS_THRESHOLDS_BY_NAME`에서 `"person": 0.30` → **`2.0`**. 모델(6-class INT8)은
그대로고 후처리에서만 막는다. **원복 = `0.30`.**

**Why:** 지금 단계에선 person 박스가 불필요. 재학습/재컴파일 없이 한 줄로 끄는 방법.

**How to apply:**
- ⚠️ **그 줄을 주석 처리하면 안 된다** — `.get(n, DEFAULT_THRESHOLD)`라 **0.50으로
  폴백해 person이 계속 검출된다.** 반드시 값을 1.0 초과로 둬야 한다
  (score는 sigmoid라 최대 ~1.0 → `scores >= 2.0` 마스크가 항상 비어 skip).
- 과일 검출 손실 0: `min_thr`(pre-filter)이 0.30→0.50으로 올라가지만 score ≤ objectness라
  objectness 0.50 미만 cell은 어차피 과일(임계 0.50)도 못 통과했다. pre-filter만 약간 빨라짐.
- **안전 커플링(파일 넘어감, 코드만 봐선 안 보임)**: person이 `/detections`에 안 실리므로
  `pick_logic.yaml`의 **`person_guard`(근접 사람 → 타깃 무효화) 래치를 재활성해도 발동 못 한다.**
  현재 `person_guard_enable: false`(2026-07-27 오퍼레이터 결정: 케이블/그림자가 conf 0.32~0.41
  person으로 36% 프레임 오검출)라 당장은 무관. 안전 래치를 되살리려면 이 threshold부터 0.30으로
  되돌려야 한다.
- pick 대상 제외는 **별개**로 이미 되어 있었다(`allowed_classes`에 person 없음). 이번 변경은
  `/detections` 자체에서 없애는 것 — 뷰어 화면에서도 사라진다([[desktop-bbox-overlay-viewing]]).
- 반영에 colcon build 불필요(`vitis_ai_detector_pkg`는 egg-link editable, worker는 src 파일 직접
  실행) — 파이프라인 재시작만 하면 된다.

관련: [[yolov3-vision-swap-resume]]
