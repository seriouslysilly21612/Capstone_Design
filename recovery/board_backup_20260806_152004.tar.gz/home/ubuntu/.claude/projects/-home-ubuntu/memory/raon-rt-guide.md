---
name: raon-rt-guide
description: ~/RAON-RT_guide.md — 사람이 읽는 RAON-RT 이해 가이드(~/RAON-RT 기준) + 병합본 변경점. 2026-07-29 전면 개정
metadata: 
  node_type: memory
  type: project
  originSessionId: a8b59790-4f6d-447b-848a-e67a14fb1bb0
  modified: 2026-07-28T22:04:03.217Z
---

RAON-RT 문서는 **두 벌**이며 목적이 다르다.

**① `~/RAON-RT_guide.md`** (사람용, 210KB) — **2026-07-29 전면 개정**. 기준 디렉토리는 **`~/RAON-RT`(원본)**, Revision-main 아님.
- 구성: 1부 §1~§14(계층별 이해) + 2부 §15(병합본 변경점).
- 서술 방식: 각 계층마다 **순수 언어 설명 → `🔧 실제 코드`(클래스·함수) 분리**. 사용자가 명시적으로 요구한 형식이므로 개정 시 유지할 것.
- §11은 **RT-POSIX(`~/RT-POSIX`)** 전용 절 — 원본 소스가 로컬에 있음(1087줄, `examples/task.c` 61줄이 학습 진입점). 이전에 "저장소 밖이라 shim 필요"로 판단했던 것은 정정됨.
- §15는 `~/RAON-RT` vs `~/RAON-RT-Revision`(병합 작업 중 git 저장소) 차이: 신규 41 · 변경 24 · 삭제 0.

**② `~/RAON-RT_guide_for_CLAUDE.md`** (에이전트용 레퍼런스, 340KB) — `RAON-RT-Revision-main` 스냅샷 기준의 밀도 높은 API/PDO/버그 목록. 이름만 바뀐 옛 파일.

**세 디렉토리 구분**(혼동 주의): `~/RAON-RT`(원본, git "start cleaning") / `~/RAON-RT-Revision`(**현재 작업 중**, E27·reachmap 커밋) / `~/RAON-RT-Revision-main`(git 없는 별도 스냅샷).

**Why**: 사용자는 학습용으로 원본을 보고 있고([[raon-rt-study-log]]), 병합 작업은 Revision에서 진행 중([[raon-vs-merge-plan]]). 기준 디렉토리를 섞으면 태스크 수(5 vs 6)·제어 모드(4 vs 6)·비전 유무가 전부 어긋난다.
**How to apply**: RAON-RT 질문 시 재탐색 대신 이 두 문서를 먼저 읽되, **어느 트리 기준인지 먼저 확인**할 것. 원본 기준 사실: RT 태스크 5개(`proc_logger`는 빈 함수, TASK4 이름 "PI Controller Task"와 불일치), 제어 모드 4개 중 3개만 구현(IK 없음), 비전 계층 없음, 종료 위치 저장 주석 처리됨, `create_rt_task` 스택 0 → **aarch64에서 태스크 생성 실패**.
