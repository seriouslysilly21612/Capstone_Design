---
name: raon-rt-study-log
description: RAON-RT 학습 질문·답변은 ~/RAON-RT_study.md에 파일별·학습순서대로 누적할 것 (2026-07-29 시작)
metadata: 
  node_type: memory
  type: project
  originSessionId: aec8571c-281d-4d8d-bfc6-ac422fe8434c
  modified: 2026-07-28T21:53:29.173Z
---

사용자가 `~/RAON-RT` 코드를 공부 중이며, **질문할 때마다 그 질문과 답변을 `~/RAON-RT_study.md`에 누적**하기로 함. 규칙:

- **배치**: 문서 상단의 8단계 학습 순서에 나온 **파일 순서대로**, 해당 파일 섹션 아래에 `#### Q1, Q2…` 순번으로 추가. 파일 섹션 뼈대는 이미 만들어 두었고 `*(아직 질문 없음)*` 자리표시자를 대체하면 됨.
- **코드 포함**: 사용자가 코드 일부(IDE 선택 등)에 대해 물으면 **그 코드와 답변 근거가 된 코드까지 문서에 인용**해, 나중에 원본 파일을 다시 열 필요가 없게 함.
- **학습 대상은 `~/RAON-RT`** (더 단순한 버전) + RT 계층은 `~/RT-POSIX`. `RAON-RT-Revision-main`이 아님 — 태스크 5개(6개 아님), 비전 계층 없음, FullDynControllerRT 537줄(1463줄 아님).

**Why**: 문서가 학습 진도이자 재참조 자료라, 매번 어디에 어떻게 넣을지 다시 정하지 않기 위함. **How to apply**: RAON-RT 관련 질문에 답한 뒤 이 파일 갱신을 잊지 말 것. 관련 문서 [[raon-rt-guide]](상세 레퍼런스 + 개념 설명서 `~/RAON-RT_guide.md`).

**참고**: 사용자는 학습 단계에서 실측/빌드/테스트 제안을 원하지 않음 → [[study-before-empirical-test]]
