---
name: ros2ws-repo-layout
description: "ros2_ws 구조 개편(2026-07-15) — docs/tools/evidence 분리, 문서 본문은 일부러 옛 경로 유지, DDS는 launch 배선"
metadata: 
  node_type: memory
  type: project
  originSessionId: 8b2c9174-5e60-4a85-b73c-06b457971acc
---

2026-07-15 `ros2_ws` 루트 개편. 루트가 `.md` 21개+디렉토리 8개 → `.md` 3개(README/CLAUDE/CODEX) + `docs/ tools/ evidence/ src/ yolo_v3_tiny_training/`. 커밋 `be4f210`(DDS) → `29ad47c`(개편) → `3d260d4`(문서). 구조 자체는 저장소를 보면 되므로, 여기엔 **다시 건드리면 안 되는 판단**만 적는다.

**★ 문서 본문의 옛 경로는 버그가 아니라 의도** — `docs/` 안 문서들은 본문에서 여전히 `crash_logs/…`, `integrated_progress.md` 같은 개편 전 경로를 쓴다. 198곳을 재작성하려다 **사용자가 명시적으로 중단시켰다**("문서 내용에서의 구조 개편 반영은 하지 말자"). 이유: 히스토리 기록물이라 경로를 고치면 서술이 뒤틀리고, 이득 대비 위험이 크다. `README.md`에 "본문 경로는 개편 전 기준"이라는 경고가 있다. **다음 세션에서 이걸 "고쳐야 할 stale"로 착각하지 말 것.**
- 예외 2개는 갱신함: `README.md`(진입점)와 `CLAUDE.md`(자동 로드) — 남을 가리키는 게 존재 이유라 틀리면 개편이 해가 된다. `docs/analyses/cleanup_plan.md`도 제외(개편 前 트리를 기록한 문서라 고치면 무의미).

**분류 기준**: `tools/`=실행하는 것, `evidence/`=들여다보는 것. 그래서 옛 `kernel_configs/`가 출처가 아니라 **용도로 쪼개졌다** — radix-tree 소스는 적용하는 패치라 `tools/kernel_patches/radix-fix/`, config 덤프는 증거라 `evidence/kernel_configs/`.

**개편 3대 리네임**(모호성 제거): `integrated_progress.md`→`docs/STATUS.md`(허브임을 드러냄), `progress.md`→`docs/history.md`, `inst_claude.md`→`docs/onboarding.md`.

**How to apply:**
- `src/`는 colcon 규약상 **이동 금지**. 그래서 `src/` 참조 절대경로는 개편 영향이 없었고, 실제로 깨진 스크립트는 `crash_logs`를 하드코딩한 2개뿐이었다(`tools/rt/{soak,cyclic}_rt.sh` → `$REPO_ROOT/evidence/crash_logs`, `BASH_SOURCE` 기반). 덤으로 잠재버그 2개 제거: `soak_rt.sh`에 `mkdir -p` 없었음, `cyclic_rt.sh`는 sudo라 `$HOME`이 `/root`가 됨.
- **git mv 후 `git reset`을 하면 rename이 반쪽 난다** — 이번에 당했다. 새 경로 add만 스테이징되고 옛 경로 삭제가 빠져 HEAD에 파일이 양쪽에 남았다(213 vs 146). 부분 스테이징으로 커밋을 쪼갤 땐 `git ls-tree -r HEAD --name-only | grep -qx <옛경로>`로 유령을 확인할 것.
- DDS 배선은 이제 launch에 있다 → [[perception-cpu-opt-phase1]].
