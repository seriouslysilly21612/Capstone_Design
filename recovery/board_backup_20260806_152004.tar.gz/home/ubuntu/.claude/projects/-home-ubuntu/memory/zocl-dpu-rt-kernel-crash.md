---
name: zocl-dpu-rt-kernel-crash
description: RT 커널 zocl DPU 크래시 — KDS submit-후-타임스탬프 UAF. 완전 해결(2026-07-15): 순서교체 픽스 → kv260c 빌드·검증(계측·프로덕션 Poison/Oops 0)·cyclictest 통과. RT 트랙 종결.
metadata: 
  node_type: memory
  type: project
  originSessionId: 8b2c9174-5e60-4a85-b73c-06b457971acc
---

2026-07-14, kv260b(#8, 5.15.199-rt91-rt-kv260b) 커널에서 full 비전 파이프라인(run_gate6_perf.sh 180s)을 처음 돌리자 ~30초 만에 **커널 Oops → 시스템 프리즈 → 하드 재부팅** 발생. SSH 끊김의 원인.

**근본원인(확정, 레지스터 지문 일치):** zocl(Xilinx DPU 드라이버, out-of-tree taint C)의 KDS command 경로에서 **SLUB freelist 손상**. 15:04:15 Oops: `___slab_alloc+0x518`(=get_freepointer) ← `__kmalloc` ← `kds_alloc_command[zocl]` ← `zocl_execbuf_ioctl[zocl]`. faulting VA `0x1b9b2a51...`(user/kernel 범위 밖 쓰레기), `swab64(fault)==x0` 정확히 일치 → 하드닝된 freelist 포인터가 이전에 손상됨. `kds_alloc_command`는 손상된 freelist를 밟은 **피해자**이지 corruptor 아님. 손상 클래스는 write-after-free/overflow 쪽으로 기움(double-free 아님). systemd-oomd 워치독 타임아웃(15:07)은 Oops 후 커널 wedge의 2차 증상 — 메모리 사건 아님(OOM 0건).

**배제됨:** 메모리부족(OOM/page-alloc-fail 0), 하드웨어(MCE/thermal/EDAC 0), radix 회귀(수정됨, 다른 경로), kv260b config(NO_HZ_FULL/RCU_NOCB는 부팅인자 없어 dormant). 관련: [[kria-rt-preempt-project]]의 zocl sleeping-in-atomic(trace#1)은 이 크래시(trace#2)의 원인이 아니라 동일 zocl 락킹 붕괴의 **독립 증상**.

**미확정:** RT 특이 버그인지(=RT가 교차-CPU 선점 레이스로 노출, ~55-60%) vs 순정도 터질 잠복 zocl 버그(DMA 스크리블: 양쪽 커널 CONFIG_ARM_SMMU 미설정이라 DPU가 DDR 무보호 DMA, ~25-30%) vs non-race double-free(~15%). 결함 소유자가 zocl이라는 점(~88%)은 어느 경우든 동일. **수정은 RT가 아니라 zocl에 있음**(radix 버그와 성격 다름).

**How to apply:**
- **다음 세션에서 RT 커널로 DPU/vitis_ai 파이프라인을 그냥 돌리지 말 것** — 재크래시함. 돌리려면 계측(slub_debug=FZPU, 리빌드 불필요 SLUB_DEBUG=y) + netconsole/panic_on_oops 안전장치 먼저.
- **비전 개발 우회로: 이미 보드에 설치된 stock 5.15.0-1070-xilinx-zynqmp로 부팅**(zocl.ko 존재). 비전 알고리즘 작업은 RT 결정성과 무관하므로 stock에서 진척 가능 + E1(RT-노출 vs 잠복) 판별 겸용. 단 DMA-스크리블이 진짜면 stock도 터질 수 있음.
- **EtherCAT은 블록 아님:** boots -4/-5 증거상 zocl 미가동 시 RT 커널 안정. DPU 안 띄운 채 RT에서 EtherCAT 병행 개발 가능. 블록되는 건 "DPU+EtherCAT 단일 RT커널 통합" 마일스톤뿐.
- **freelist 하드닝 절대 끄지 말 것** — 조용한 손상을 legible 크래시로 만든 유일한 조기경보.
- 판별실험 우선순위: E1(stock 장시간 루프)/E2(slub_debug=FZPU로 corruptor 함수 지목)/E6(단일 CPU 고정=레이스 격리)/E4(KASAN, 결정적)/E5(SMMU 켜서 DMA 확정).

**★★★ 2026-07-15 — 픽스 빌드+검증 완료 (종결):** PC에서 zocl 패치(`apply_zocl_uaf_fix.py`, kds_core.c 3곳 순서교체) 적용 + DEBUG_PREEMPT/ATOMIC_SLEEP off로 rev-6 빌드 = **`-rt-kv260c` #10**. deb 검증(config DEBUG off, zocl srcversion `4971DA73`→`0754F2D6` 변경=패치반영), DTB 81개 선복사, 설치·부팅 성공(realtime=1). **검증 재현**: slub_debug=FZPU,kmalloc-256 무장 상태(poison/redzone 속성파일 확인)로 churn 5×20s + sustained 180s ≈ 330s(원래 실패임계 236s 초과), zocl 156클라이언트 → **Poison 0건·Oops 0건·시스템 생존 = 픽스 확정.** ✅ 이후 계측 제거(cmdline `skew_tick=1` 복원)→reflash→프로덕션 부팅 완료: 프로덕션(계측無 200s+, zocl 130클라이언트) Oops 0 재확인 + cyclictest(DEBUG off) idle Max 134/load Max 142µs(kv260b 282→절반)·위반 0. **RT 트랙 종결, EtherCAT 착수 가능.** **트랩: pkill -f "pick_place_vitis_ai"를 그 문자열 든 명령에 인라인하면 셸 자신을 kill(self-kill) → churn/정리는 반드시 스크립트 파일로 분리(scratchpad/churn.sh, sustained.sh).**

**★ 2026-07-14 심야 — 종결 수준 돌파 (E2 성공):** slub_debug=FZPU,kmalloc-256 계측 부팅 후 churn 재현 → 23:36:46 **`Poison overwritten` 포획(시스템 생존)**. Freed in `kds_free_command←xrt_cu_intr_thread[zocl]`, 해제 후 offset 128에 `ktime` 8바이트 = `timestamp[KDS_QUEUED]` UAF 쓰기. 원인 코드 = `drivers/gpu/drm/zocl/common/kds_core.c`의 `xrt_cu_submit(); set_xcmd_timestamp(KDS_QUEUED);` 순서 역전(3곳, upstream master에도 잔존). **메커니즘 1(RT-확폭 레이스) 확정, SMMU/DMA 가설 사망.** 픽스+절차 = `~/ros2_ws/tools/kernel_patches/zocl/`(스탬프를 submit 앞으로, PC 트리에서 빌드 — zocl은 in-tree라 linux-image 소속). 상세 = postmortem §12-8. **남은 것: PC에서 패치 적용→빌드(rev-6 합류 권장)→패치 모듈로 E2 churn 재검증(Poison 0건)→계측 해제.**

**2026-07-14 세션 진척 (resume point):**
- 실제 Oops 파일 보존: `~/ros2_ws/evidence/crash_logs/zocl_crash_boot-1_20260714.log`(161줄). 지문 firsthand 재검증 완료 — `swab64(fault 0x1b9b2a514fa690f9)==x0 0xf990a64f512a9b1b` 일치, `x2=s->offset=0x80`, kmalloc-256 mid-object freepointer 확정.
- **trace#1 side-fix 타깃 확정**: `zocl_read_sect+0x78`의 **vmalloc**(kmalloc 아님)을 `rcu_read_lock` 밖으로 hoist(RCU nest depth 1이 유일 위반, preempt/irq는 정상). §12-5 대응.
- 공유 kmalloc-256에 zocl 외 out-of-tree C모듈 다수 존재(`allegro/al5e/al5d`=VCU, `dmaproxy`, `ap1302`) → slub_debug 병합해제 시 corruptor가 진짜 zocl인지까지 갈림(zocl ~88% 유효하되 열어둠).
- **E2 무-UART 계측부팅 플랜(ready, 미적용)**: cmdline에 `slub_debug=FZPU,kmalloc-256 kfence.sample_interval=100` 추가→`flash-kernel 5.15.199-rt91-rt-kv260b`→reboot. 캡처 3겹 = slub_debug 조기리포트 + `journalctl -kf|tee`(sudo 불필요 확인) + netconsole(보드 eth0 192.168.120.132 → 데스크톱 192.168.120.7 MAC `3c:6a:d2:b7:e7:79`) + `panic_on_oops=1`. **UART 불필요 확정.**
- **현재 상태**: 순정 `5.15.0-1070-xilinx-zynqmp`로 부팅 전환(`flash-kernel --force` 필요). 파이프라인 최적화는 별도 세션에서 진행. RT 계측 미적용(cmdline 클린 `skew_tick=1`).
