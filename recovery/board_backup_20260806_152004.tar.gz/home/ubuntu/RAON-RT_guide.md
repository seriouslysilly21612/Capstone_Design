# RAON-RT 이해 가이드 (사람이 읽는 문서)

이 문서는 **`~/RAON-RT`(원본 저장소)** 를 처음 보는 사람이 개념부터 순서대로 이해하도록 쓴 설명서입니다.
각 계층마다 **먼저 "무슨 일을 하는가"를 순수한 말로 설명**하고, 그다음 **"실제로 어떤 클래스·함수를 쓰는가"를 따로 분리**해 정리했습니다. 개념만 알고 싶으면 앞부분(서술)만, 코드에 손대려면 뒷부분(🔧 실제 코드)까지 보면 됩니다.

문서 후반 **[§15](#15)** 에는 원본과 **현재 병합 작업 중인 `~/RAON-RT-Revision`** 의 차이를 파일·함수 단위로 정리했습니다.

> **기준 디렉토리**
> - 본문(§1~§14): **`~/RAON-RT`** — 원본. git HEAD `596691f "start cleaning..."`
> - 실시간 라이브러리(§11): **`~/RT-POSIX`** — RAON-RT가 쓰는 RT 태스크 라이브러리의 원본 소스
> - 변경점(§15): **`~/RAON-RT-Revision`** — 사용자가 현재 병합·개발 중인 저장소
>
> 참고: `~/RAON-RT-Revision-main`은 별도 스냅샷이며 이 문서의 기준이 아닙니다. 그 트리 기준의 상세 API 레퍼런스는 `~/RAON-RT_guide_for_CLAUDE.md`에 있습니다.

---

## 목차

**1부 — RAON-RT 이해하기 (`~/RAON-RT` 기준)**

1. [RAON-RT란 무엇이고 왜 이렇게 만들어졌나](#1)
2. [다섯 계층 아키텍처 한눈에](#2)
3. [프로그램이 켜지고 도는 순서 (생명주기)](#3)
4. [1밀리초 제어 루프 — 심장부](#4)
5. [계층 A — EtherCAT 통신 (EMasterApp)](#5)
6. [계층 A' — 슬레이브 장치 드라이버](#6)
7. [계층 B — 축 추상화 (CAxis)](#7)
8. [계층 B' — 센서와 엔드툴](#8)
9. [계층 C — 로봇 오케스트레이션 (CRobot)](#9)
10. [계층 D — 제어기 (토크를 계산하는 두뇌)](#10)
11. [계층 E — RT-POSIX, 실시간의 정체](#11)
12. [곁가지 — 공용 유틸·시뮬레이션·ROS2](#12)
13. [설정 파일(.cfg) 읽는 법](#13)
14. [빌드와 외부 의존성](#14)

**2부 — 병합본과의 차이**

15. [원본 → `~/RAON-RT-Revision` 변경점](#15)

---

<a id="1"></a>
## 1. RAON-RT란 무엇이고 왜 이렇게 만들어졌나

**RAON-RT**(Real-time Architecture for Open, Networked robotic systems)는 로봇을 실시간으로 제어하는 C++ 프레임워크입니다. 이름에 담긴 목표는 "이기종 로봇(서로 다른 모터·센서)을 하나의 표준화된 소프트웨어 골격 위에서 다루자"는 것입니다. 이 저장소의 대표 결과물은 **6축 협동로봇 Indy7을 EtherCAT으로 1밀리초마다 토크 제어하는 실행파일**(`Indy7Ctrl.out`) 하나입니다.

왜 이런 소프트웨어가 필요할까요? 로봇 팔을 부드럽고 안전하게 움직이려면, 모든 관절의 현재 각도·속도·토크를 **아주 짧은 주기로(여기서는 1밀리초, 즉 1초에 1000번)** 읽고, 그 값으로 필요한 토크를 계산해서, 다시 모터로 내려보내는 일을 **한 치의 지연도 없이 반복**해야 합니다. 만약 어쩌다 한 사이클이 늦으면 로봇이 덜컹거리거나 진동합니다. 그래서 두 가지가 핵심입니다.

- **실시간성(Real-time)**: 운영체제가 "정확히 1밀리초마다 이 일을 해라"를 보장해야 합니다. 그래서 PREEMPT_RT 리눅스 커널과, 메모리를 스왑당하지 않게 잠그는 기법(`mlockall`), 우선순위 높은 실시간 태스크를 씁니다. 이 실시간 태스크를 만들어 주는 것이 별도 라이브러리 **RT-POSIX**(§11)입니다.
- **정확한 통신(EtherCAT)**: 모터 드라이브 6개와 엔드툴 1개가 하나의 산업용 이더넷 링(EtherCAT)에 데이지체인으로 연결돼 있고, 마스터(제어 PC)가 매 사이클 모든 슬레이브의 데이터를 한 프레임에 실어 주고받습니다.

RAON-RT의 설계 철학은 **"계층으로 나눠서 각 계층이 아래 계층의 복잡함을 숨긴다"**입니다. 맨 위의 제어 로직은 "관절 각도를 읽어서 토크를 쓴다"만 알면 되고, 그것이 실제로는 EtherCAT 프레임이 되어 케이블을 타고 가는지, 아니면 시뮬레이터 안의 가상 모터로 가는지는 **몰라도 됩니다**. 덕분에 같은 제어 코드가 실물 로봇에서도, MuJoCo 물리 시뮬레이터에서도, 순수 소프트웨어 모터 모델에서도 그대로 돕니다. 이것이 이 프레임워크의 가장 중요한 아이디어입니다.

> **원본 저장소의 성격**: `~/RAON-RT`는 군더더기가 적은 깔끔한 버전입니다. 비전(카메라) 계층이 없고, 제어기도 관절공간 토크 제어 3종만 구현돼 있어 **학습용으로는 병합본보다 읽기 쉽습니다**. 병합본에서 무엇이 얼마나 늘었는지는 §15를 보세요.

---

<a id="2"></a>
## 2. 다섯 계층 아키텍처 한눈에

코드는 아래에서 위로 다섯 겹입니다. 아래로 갈수록 하드웨어에 가깝고, 위로 갈수록 "이 로봇만의 로직"에 가깝습니다.

```
 ┌──────────────────────────────────────────────────────────────┐
 │  App/        응용·제어 계층 — "이 로봇만의 로직"               │
 │   · Indy7 실행파일, 토크 제어기(RBDL 동역학)                  │
 ├──────────────────────────────────────────────────────────────┤
 │  CRobot/     로봇 하드웨어 추상화 계층(HAL)                    │
 │   · 로봇 조립·실시간 태스크 관리, 축(모터)·센서 추상화        │
 ├──────────────────────────────────────────────────────────────┤
 │  EMasterApp/ EtherCAT 통신 계층                               │
 │   · IgH EtherLab 마스터를 감싼 라이브러리, 슬레이브 드라이버  │
 ├──────────────────────────────────────────────────────────────┤
 │  Global/     공용 유틸리티                                     │
 │   · 설정파일 파서, 전역 타입/매크로, 통신(소켓·CRC·시리얼)    │
 ├──────────────────────────────────────────────────────────────┤
 │  외부 라이브러리 (저장소 밖, 미리 설치)                        │
 │   · IgH EtherLab(EtherCAT), RT-POSIX(실시간), RBDL(동역학) …  │
 └──────────────────────────────────────────────────────────────┘
```

원본 저장소의 최상위는 딱 이만큼입니다 — `App/`, `CRobot/`, `EMasterApp/`, `Global/`, `Config/`, `Makefile`, `README.md.txt`, `scripts/`. (병합본에 있는 `include/`, `lib/`, `tools/`, 설계 문서들은 원본에 없습니다.)

이 계층들이 실제로 어떻게 맞물리는지는, 정적인 그림보다 **"프로그램이 실행되며 무슨 일이 벌어지는가"**를 순서대로 따라가면 훨씬 잘 이해됩니다. 그래서 다음 두 절에서 먼저 **생명주기**와 **제어 루프**를 이야기로 풀고, 그다음 계층별 상세로 들어갑니다.

---

<a id="3"></a>
## 3. 프로그램이 켜지고 도는 순서 (생명주기)

로봇 제어기를 실행하면 다음과 같은 순서로 일이 진행됩니다. 이야기하듯 따라가 봅시다.

1. **명령줄에서 설정파일을 받습니다.** 사용자가 `./Indy7Ctrl.out -f INDY7.cfg`로 실행하면, 프로그램은 그 `.cfg` 파일(관절 게인, 태스크 주기, EtherCAT 슬레이브 목록, 기어비 등이 적힌 INI 형식)을 읽습니다. 설정 안에 "시뮬레이션 모드인가?"를 결정하는 값이 있어서, 실물 로봇을 붙일지 가상으로 돌릴지가 여기서 갈립니다.
   > ⚠️ `-f`를 안 주면 기본값은 **`ELMO.cfg`**(상대경로)입니다. `INDY7.cfg`가 아닙니다.

2. **로봇 객체를 만듭니다.** 설정을 넘겨 `CRobotIndy7`이라는 "이 로봇 전체를 대표하는 객체"를 생성합니다. 이 객체의 생성자 안에서 **다섯 개의 실시간 태스크 함수가 미리 등록**됩니다(아직 실행되진 않습니다). 태스크란 각자 독립적으로 도는 실시간 스레드라고 보면 됩니다.

3. **안전장치를 겁니다.** Ctrl+C(SIGINT)나 종료 신호(SIGTERM)를 받으면 로봇을 안전하게 정지·정리하도록 신호 핸들러를 등록합니다. 그리고 `mlockall`로 프로그램의 메모리를 물리 메모리에 못박아, 실시간 도중 페이지가 디스크로 밀려나 지연이 생기는 일을 막습니다.

4. **초기화(`Init`)가 실제 준비를 다 합니다.** 이 한 번의 호출 안에서 순서대로:
   - 먼저 **동역학 제어기**를 만들고 로봇의 URDF 모델을 읽습니다(토크 계산에 필요한 질량·관성 정보).
   - **외부 통신 인터페이스**(TCP 서버, 포트 7420)를 켜서 외부 GUI가 붙을 수 있게 합니다.
   - **EtherCAT 마스터와 슬레이브 7개**(관절 6 + 엔드툴 1)를 만들고 설정값을 적용한 뒤, 마스터를 가동해 통신이 정상 상태(OP)에 도달할 때까지 끌어올립니다.
   - 마지막으로 **다섯 개의 실시간 태스크를 생성·기동**합니다. 이때부터 로봇이 "살아 움직이기" 시작합니다.

5. **메인 스레드는 그냥 기다립니다.** 실제 일은 전부 실시간 태스크들이 하므로, `main` 함수는 "정지 신호가 올 때까지 잠깐씩 자면서 대기"만 합니다.

6. **종료.** 신호를 받으면 `DeInit`이 태스크를 멈추고(2초 여유를 주고), EtherCAT을 해제합니다.
   > ⚠️ 원본에서는 **각 축의 마지막 위치를 설정파일에 저장하는 코드가 통째로 주석 처리**돼 있습니다. 즉 `POS_BEFORE_EXIT` 값은 아무도 갱신하지 않는 고정 상수입니다. (병합본에서 되살아납니다 — §15)

> **핵심 통찰**: 실질적인 "준비"는 전부 `Init` 안에서 정해진 순서로 벌어지고, 실질적인 "동작"은 전부 실시간 태스크 안에서 벌어집니다. `main`은 켜고 기다리다 끄는 역할만 합니다.

#### 🔧 실제 코드 (생명주기)

- 진입점: `App/Indy7/main.cpp` — `main()`, `signal_handler()`
- 기본 설정파일: `DEFAULT_CONFIGURATION_FULLPATH` = `"ELMO.cfg"` (`CRobot/ConfigRobot.h:14`)
- 설정: `CConfigRobot::ReadConfiguration()`, `GetSystemConf().bSim`으로 시뮬 여부 판단
- 로봇 객체: `CRobotIndy7`(생성자에서 `AddTaskFunction()`으로 태스크 5개 등록)
- 메모리 잠금: `mlockall(MCL_CURRENT | MCL_FUTURE)`
- 초기화: `CRobotIndy7::Init()` → `InitController()` → 부모 `CRobot::Init()`(이 안에서 `InitExtInterface()` → `InitEtherCAT()` → `InitRTTasks()`)
- 대기 루프: `while(!CheckStopTask()){ cpu_relax(); usleep(1000); }`
- 종료: `CRobotIndy7::DeInit()` → `CRobot::DeInit()`(태스크 정지 → 2초 대기 → EtherCAT 해제)

---

<a id="4"></a>
## 4. 1밀리초 제어 루프 — 심장부

로봇이 살아 있는 동안, 두 개의 실시간 태스크가 1밀리초마다 짝을 이뤄 돕니다. 이것이 이 시스템의 심장입니다.

한 태스크(**EtherCAT 태스크**)는 통신을 담당합니다. 매 사이클 시작에 "다음 주기가 될 때까지" 잠들었다 깨어나, EtherCAT 링에서 방금 도착한 프레임을 **읽습니다**. 이 읽기 과정에서 각 모터 슬레이브의 현재 위치·속도·토크가 갱신되고, 그 값이 콜백을 통해 해당 "축 객체"로 흘러들어갑니다. 통신의 반대편에서는, 계산이 끝난 목표 토크를 슬레이브로 **씁니다**(프레임을 큐에 넣고 송신). 분산 클럭(DC)이 켜져 있으면 이때 슬레이브들의 시계를 마스터에 맞춰 동기화합니다.

다른 태스크(**메인 제어 태스크**)는 두뇌입니다. 역시 1밀리초마다 깨어나, 각 축에서 방금 갱신된 관절 각도·속도를 읽어 **제어기에게 넘깁니다**. 제어기는 로봇의 동역학 모델로 "지금 이 자세를 유지하거나 목표로 가려면 각 관절에 얼마의 토크가 필요한가"를 계산해 돌려줍니다. 그러면 메인 태스크는 그 토크를 각 축의 `MoveTorque`로 내려보냅니다 — 이 명령은 곧바로 슬레이브의 목표 토크 필드에 기록되고, 다음 EtherCAT 쓰기 사이클에 실려 모터로 갑니다.

그림으로 요약하면:

```
   [EtherCAT 태스크, 1ms, 우선순위 95]      [메인 제어 태스크, 1ms, 우선순위 97]
   다음 주기까지 대기                        다음 주기까지 대기
   슬레이브에서 프레임 읽기  ──콜백──▶ 각 축에 q, q̇, τ 반영
        │                                        │
        │                                 제어기가 목표 토크 τ_out 계산
        │                                 (중력보상 / 풀다이내믹 / 계산토크)
        │                                        │
   목표 토크를 슬레이브에 쓰기 ◀──MoveTorque── 각 축에 τ_out 명령
   (송신 + DC 동기)
```

즉 매 사이클의 골자는 **"현재 상태 읽기 → 토크 계산 → 토크 쓰기"**의 무한 반복입니다. 나머지 세 개의 태스크(키보드 입력, 터미널 출력, 로거)는 이 1밀리초 심장보다 느긋한 우선순위로 곁에서 돕습니다.

> **주의할 설계 특징**: 이 마스터는 입력용·출력용 EtherCAT 도메인을 **둘로 나눠** 씁니다. 그래서 한 사이클에 프레임 수신·송신이 **두 번씩** 일어납니다(읽기에서 한 번, 쓰기에서 한 번). 통신 대역폭·CPU 예산을 볼 때 기억해 둘 점입니다.

#### 🔧 실제 코드 (제어 루프)

- 통신 태스크: `proc_ethercat_control()` — `CEcatMaster::ReadSlaves()` → `UpdateExtInterfaceData()` → `IsAllSlavesOp() && IsMasterOp()`로 `m_bEcatOP` 갱신 → `CEcatMaster::WriteSlaves(tmSend)`
- 두뇌 태스크: `proc_main_control()` — `DoInput()`(키 처리) → 각 축 `GetCurrentPos()/Vel()/Tor()` → `CControllerFullDynamicsRT::Update(...)` → 각 축 `MoveTorque(τ)` → 제어모드별 엔드툴 LED
- 읽기 쪽 데이터 유입 경로: 슬레이브 → `CSlaveCIA402Base::ReadFromSlave()` → 콜백 `OnSlaveUpdateRawParam()` → `CAxis::UpdateCurrentParams()`
- 쓰기 쪽 경로: `CAxisNRMKCore::MoveTorque()` → `CSlaveCIA402::SetTargetTor()` → 다음 `WriteSlaves()`에서 프레임화
- 실시간 주기 대기: `wait_next_period(NULL)` / 현재시각 `read_timer()` (§11 RT-POSIX)

---

<a id="5"></a>
## 5. 계층 A — EtherCAT 통신 (`EMasterApp`)

### 설명

이 계층은 로봇과 실제로 대화하는 **가장 아래의 통신 계층**입니다. EtherCAT은 산업용 실시간 이더넷 규격으로, 하나의 마스터(제어 PC)가 여러 슬레이브(모터 드라이브, 센서 등)를 링 형태로 엮어, 매 사이클마다 **하나의 이더넷 프레임이 모든 슬레이브를 훑고 지나가며** 각자 자기 몫의 데이터를 읽고 쓰게 합니다. 이 방식 덕분에 수십 개 장치를 아주 낮은 지연으로 동기화할 수 있습니다.

RAON-RT는 EtherCAT을 바닥부터 구현하지 않습니다. 대신 오픈소스 **IgH EtherLab 마스터**(`ecrt.h` API)를 쓰고, 그 위에 **객체지향적인 얇은 껍데기**를 씌운 것이 `EMasterApp`입니다. 이렇게 감싸면 상위 계층이 IgH의 C 함수를 직접 부르지 않고, "마스터", "슬레이브"라는 깔끔한 객체로 다룰 수 있습니다.

이 계층을 이해하는 데 중요한 개념 몇 가지:

- **마스터와 도메인**: 마스터는 통신 전체를 관장하는 객체입니다. 그 아래 "도메인"은 주고받을 데이터를 담는 메모리 영역인데, 이 프레임워크는 **입력(슬레이브→마스터)과 출력(마스터→슬레이브)을 각각 별도 도메인**으로 만듭니다.
- **PDO(Process Data Object)**: 매 사이클 자동으로 교환되는 실시간 데이터입니다. 예를 들어 모터의 "목표 토크"는 출력 PDO, "현재 위치"는 입력 PDO입니다. 각 PDO 항목이 도메인 메모리의 어느 바이트에 있는지(오프셋)를 초기화 때 등록해 둡니다.
- **상태 머신(INIT→PRE-OP→SAFE-OP→OP)**: EtherCAT 슬레이브는 켜지면 여러 상태를 거쳐 완전 동작(OP) 상태로 올라갑니다. 중요한 점은, 이 프레임워크의 마스터 객체는 이 상태 전이를 **직접 명령하지 않고 관찰만** 한다는 것입니다. 마스터를 "활성화"하고 매 사이클 데이터를 주고받다 보면 IgH가 알아서 OP까지 올려줍니다. 상위 코드는 "모든 슬레이브가 OP인가?"를 물어보며 준비될 때까지 기다립니다.
- **분산 클럭(DC, Distributed Clocks)**: 모든 슬레이브가 같은 시각에 정확히 동작하도록 시계를 동기화하는 기능입니다. 켜면 매 사이클 마스터가 기준 시각을 뿌리고 슬레이브 시계를 맞춥니다.

초기화의 흐름은 이렇습니다. 마스터를 요청해 받고 → 입력·출력 도메인을 만들고 → 등록된 슬레이브마다 설정(어떤 벤더의 어떤 제품인지, PDO를 어떻게 맵핑할지, DC를 켤지)을 적용하고 → 마스터를 "활성화"하면 설정이 고정되고 통신이 시작됩니다. 그 뒤로는 앞서 본 대로 매 사이클 읽기/쓰기를 반복합니다.

> ⚠️ **원본의 알려진 결함**: PDO 항목을 등록하는 함수가 실패를 알릴 수 없는 타입(`UINT32`)을 반환해, **"등록 실패" 검사가 전부 죽은 코드**입니다. 실패해도 조용히 넘어가고 잘못된 오프셋이 남아 다음 사이클에 엉뚱한 메모리를 건드립니다. 병합본이 이 문제를 정면으로 고쳤습니다(§15).

### 🔧 실제 코드 (EtherCAT 통신)

**핵심 객체**
- `CEcatMasterBase` (별칭 `CEcatMaster`) — 마스터 하나 + 입력/출력 도메인 둘 + 슬레이브 목록을 소유
- `CEcatSlaveBase` — 모든 슬레이브의 부모. PDO 등록과 프로세스 데이터 접근을 제공
- `EcatCommon.h` — 공용 타입·EtherCAT 상태 열거형·CiA402 상수 모음

**마스터 주요 함수**
| 함수 | 하는 일 |
|---|---|
| `Init(cycleTimeNs, dcEnabled)` | 마스터·도메인·슬레이브 브링업, OP 준비까지 |
| `AddSlave(slave*)` | 슬레이브를 **버스 순서대로** 등록(위치 = 등록 순번) |
| `ReadSlaves()` | 수신 → 도메인 처리 → 각 슬레이브 읽기 → 큐 → 송신 |
| `WriteSlaves(appTimeNs)` | 각 슬레이브 쓰기 → DC 시각 갱신·동기 → 큐 → 송신 |
| `IsMasterOp()` / `IsAllSlavesOp()` | OP 상태 도달 여부 관찰 |
| `DeInit()` | 마지막 프레임 정리 후 마스터 해제 |

**슬레이브 베이스 주요 함수**
- `InitSlave(alias, pos, masterDesc)` → 내부 `Init()`이 `ecrt_master_slave_config` + PDO 설정
- `RegisterPDOEntry(index, sub, &bitPos, dir)` — PDO 항목을 도메인 바이트 오프셋으로 등록
- `EnableDC(cycleNs)` / `SetAsDCRef()` — 분산 클럭 설정 / 기준 클럭 지정
- `ReadFromSlave()` / `WriteToSlave()` — 매 사이클 프로세스 데이터 ↔ 멤버 필드 마샬링
- `WritePdoU/S(...)`, `ReadPdoU8..S64(...)` — 타입별 프로세스 데이터 읽기/쓰기

**그 아래 IgH(EtherLab) 함수** (감싸진 실제 C API): `ecrt_request_master`, `ecrt_master_create_domain`, `ecrt_master_slave_config`, `ecrt_slave_config_pdos`, `ecrt_slave_config_reg_pdo_entry`, `ecrt_slave_config_dc`, `ecrt_master_activate`, `ecrt_master_receive/send`, `ecrt_domain_process/queue`, `ecrt_master_application_time`, `ecrt_master_sync_reference_clock` 등.

---

<a id="6"></a>
## 6. 계층 A' — 슬레이브 장치 드라이버

### 설명

앞 절의 `CEcatSlaveBase`는 "슬레이브 일반"의 골격이고, 실제 장치마다 다른 부분(어떤 데이터를 어떤 주소에서 주고받는지 = PDO 맵)을 채우는 것이 **개별 슬레이브 드라이버**입니다. 이 저장소에는 여러 장치용 드라이버가 있습니다.

가장 중요한 것은 **CiA402 서보 드라이브 드라이버**입니다. CiA402는 산업용 서보 모터의 표준 프로파일로, "제어 워드(Control Word)"로 모터를 켜고/끄고/리셋하고, "상태 워드(Status Word)"로 모터의 현재 상태를 읽으며, "동작 모드(Mode of Operation)"로 위치·속도·토크 중 무엇을 제어할지 고릅니다. 이 로봇은 **토크 모드(CST, Cyclic Synchronous Torque)**를 씁니다 — 매 사이클 목표 토크를 직접 내려보내는 방식입니다.

이 CiA402 드라이버가 주고받는 데이터는 정해져 있습니다. 마스터가 슬레이브로 보내는 것(출력)은 제어 워드·목표 위치·목표 속도·목표 토크·동작 모드 다섯 가지, 슬레이브가 마스터로 보내는 것(입력)은 상태 워드·현재 위치·현재 속도·현재 토크·현재 동작 모드 다섯 가지입니다. 드라이버는 매 사이클 이 값들을 EtherCAT 프로세스 메모리와 자기 멤버 변수 사이에서 옮기고, 동시에 "모터 켜기" 같은 상태 전이를 상태 워드를 보며 단계적으로 진행합니다.

그 외 드라이버들은 대부분 **헤더만 있는(구현 없는) 장치 정의**입니다: ELMO·Maxon EPOS4 서보(둘 다 CiA402 드라이버를 그대로 상속), Beckhoff의 버스 커플러(EK1100)·디지털 출력(EL2024)·분기 허브(CU1124), KIST의 6축 힘/토크 센서, 광섬유(FBG) 센서, 다관절 로봇 핸드 등. 실제로 라이브러리에 컴파일되어 들어가는 슬레이브 구현은 **CiA402 베이스와 Neuromeka 엔드툴** 둘뿐이고, 나머지는 필요할 때 include해서 쓰는 형태입니다.

**엔드툴(EOAT) 드라이버**는 로봇 팔 끝에 붙는 통합 장치를 다룹니다 — 6축 힘/토크 센서, 그리퍼 출력, RGB 상태 LED, 버튼 입력이 한 슬레이브에 들어 있습니다. 힘 센서 값은 정수로 들어와 정해진 나눗셈으로 물리 단위(N, Nm)로 바뀌고, LED는 색·점멸을 명령할 수 있습니다.

### 🔧 실제 코드 (슬레이브 드라이버)

**핵심 객체**
- `CSlaveCIA402Base` (별칭 `CSlaveCIA402`) — 표준 CiA402 서보 드라이브. **라이브러리에 컴파일됨**
- `CSlaveNrmkEndtool` — Neuromeka 엔드툴(F/T + 그리퍼 + LED + 버튼). **라이브러리에 컴파일됨**
- 헤더만: `CSlaveELMO`, `CSlaveEPOS4`, `CSlaveBeckhoffEK1100/EL2024/CU1124`, `CSlaveKistFT`, `CSlaveFBGSensor`, `CSlaveKistarHand`

**CiA402 드라이버 주요 요소**
- 출력 PDO(`0x1600`): 제어워드(`0x6040`), 목표위치(`0x607A`), 목표속도(`0x60FF`), 목표토크(`0x6071`), 동작모드(`0x6060`)
- 입력 PDO(`0x1a00`): 상태워드(`0x6041`), 현재위치(`0x6064`), 현재속도(`0x606C`), 현재토크(`0x6077`), 동작모드표시(`0x6061`)
- 동작 모드 상수: 위치 프로파일 `0x01`, 속도 프로파일 `0x03`, 토크 프로파일 `0x04`, **CSP(주기위치) `0x08`, CSV(주기속도) `0x09`, CST(주기토크) `0x0A`**
- 주요 메서드: `SetServoOn(mode)`, `SetServoOff()`, `SetTargetPos/Vel/Tor(...)`, `SetDriveMode(mode)`, `GetActualPos/Vel/Tor()`, `GetStatusWord()`, `AnalyzeStatusWord()`(상태 워드 해석), `ReadFromSlave()`/`WriteToSlave()`(사이클 마샬링 + 서보 온 시퀀스)
- 상태 콜백 등록: `RegisterCallbackStateChange()`, `RegisterCallbackParamUpdate()`

**엔드툴 드라이버 주요 요소**
- 힘/토크 변환: 원시값 ÷ 50(힘), ÷ 2000(토크)
- LED: `LED_RED/GREEN/BLUE/YELLOW/OFF(점멸)`, 그리퍼 `SetGripper()`, `FTSensorOn()/Off()`

---

<a id="7"></a>
## 7. 계층 B — 축 추상화 (`CAxis`)

### 설명

한 단계 위로 올라오면, EtherCAT 슬레이브를 "모터 축 하나"라는 더 친숙한 개념으로 감싸는 계층이 있습니다. 상위 제어 코드는 "슬레이브에 정수 몇 개를 써라"가 아니라 **"이 축을 3.14 라디안으로 움직여라", "이 축에 12뉴턴미터의 토크를 걸어라", "지금 이 축의 각도는?"**처럼 물리적이고 직관적인 말로 명령하고 싶어 합니다. 그 번역을 담당하는 것이 축 계층입니다.

이 계층의 가장 핵심적인 일은 **단위 변환**입니다. 모터 드라이브는 세상을 "엔코더 카운트"와 "드라이브 내부 전류 단위"로 봅니다. 반면 제어기는 "라디안"과 "뉴턴미터"로 생각합니다. 축 객체는 기어비·엔코더 해상도·토크 상수·전류 비율 같은 물리 상수를 알고 있어서, 두 세계를 오갑니다. 예를 들어 관절 토크를 명령하면: **관절 토크 → (기어비로 나눠) 모터 토크 → (토크 상수로 나눠) 모터 전류 → (전류 비율을 곱해) 드라이브 카운트**로 바뀌어 슬레이브에 기록됩니다. 반대로 엔코더 카운트를 읽으면 라디안으로 환산됩니다. 여기에 관절이 회전형이냐 직선형이냐(한 바퀴가 2π인지 나사 리드인지)와 방향(정/역회전 부호)도 반영합니다.

또 하나 중요한 것은 **원점(홈) 잡기**입니다. 증분 엔코더는 전원을 켤 때 "지금 여기가 몇 도인지" 모릅니다. 그래서 기준점을 정해 줘야 하는데, 설정파일의 `HOMING_METHOD`가 그 방식을 고릅니다 — 전원 켤 때 서 있는 자세를 0으로 삼거나(=1), 파일에 적힌 고정 오프셋을 쓰거나(=3) 하는 식입니다. 이 선택이 로봇의 모든 각도 해석의 출발점이 되므로 대단히 중요합니다.

그리고 **안전**입니다. 각 축은 위치·속도·가속도·토크의 상한/하한을 알고 있고, 명령이 허용 범위 안인지 검사합니다. 축은 자체 **상태 머신**(비상/에러/초기화/대기/홈잉/운전/정지)을 가지며, 아래 슬레이브의 서보 상태가 바뀔 때마다 콜백으로 자기 상태를 갱신합니다.

상속 구조는 이렇습니다. 추상 베이스 `CAxis`가 단위 변환·한계 검사·상태의 뼈대를 정의하고, 그 아래 `CAxisCIA402`가 "EtherCAT CiA402 슬레이브를 붙인 실물 축"을 구현하며, 다시 그 아래 `CAxisNRMKCore`가 "Neuromeka CORE 드라이브"의 정확한 토크 변환을 채웁니다. Indy7의 실제 관절은 이 `CAxisNRMKCore`를 씁니다.

**그리고 여기서 이 프레임워크의 마법이 나옵니다.** `CAxis`와 똑같은 인터페이스를 가지되, 아래에 EtherCAT 대신 **소프트웨어 시뮬레이션**을 둔 축 변형들이 있습니다. `CAxisRT`는 슬레이브 없이 1자유도 모터 방정식과 PID를 소프트웨어로 적분해 가상 모터처럼 굴고, `CAxisMuJoCo`는 MuJoCo 물리 엔진의 관절 하나에 연결되며, `CAxisRTMuJoCo`는 실시간 스레드에서 모터 시뮬을 돌리고 비실시간 스레드에서 MuJoCo를 렌더링합니다. 상위 제어기는 자기가 실물 축을 잡았는지 가상 축을 잡았는지 **구분하지 못합니다** — 그저 `MoveTorque`, `GetCurrentPos`를 부를 뿐입니다. 이것이 같은 코드로 실물과 시뮬을 오갈 수 있는 이유입니다.

> 실무 주의: 정확한 토크 변환은 `CAxisNRMKCore`에만 제대로 구현돼 있습니다. 베이스 `CAxis`의 토크↔카운트 변환은 사실상 항등(그대로 통과)이라, 다른 드라이브를 붙이려면 이 변환을 직접 채워야 합니다.

### 🔧 실제 코드 (축)

**상속 구조**
```
CAxis  (추상 베이스: 단위변환·한계·상태)
 ├─ CAxisCIA402 (실물 EtherCAT 축; CSlaveCIA402 슬레이브를 품음)
 │    ├─ CAxisNRMKCore (Neuromeka CORE — 토크 변환 정확 구현) ← Indy7이 사용
 │    ├─ CAxisELMO     (ELMO, 토크를 mNm로)
 │    └─ CAxisEPOS4    (빈 껍데기, 베이스 기본값)
 ├─ CAxisRT       (순수 소프트웨어 실시간 시뮬)
 ├─ CAxisMuJoCo   (MuJoCo 관절 1개에 연결)
 └─ CAxisRTMuJoCo (RT 시뮬 + MuJoCo 시각화)
```

**공통 명령·조회 함수 (`CAxis`)**
- 명령: `ServoOn()/ServoOff()`, `DoHoming()`, `MoveAxis(rad)`, `MoveVelocity(rad/s)`, `MoveTorque(Nm)`, `StopAxis()/EmgStopAxis()`
- 조회: `GetCurrentPos()/Vel()/Tor()`(물리단위), `GetCurrentRawPos()...`(엔코더 카운트)
- 단위 변환: `ConvertRadMM2Res()`, `ConvertRes2RadMM()`, `ConvertTor2Cur()`, `ConvertCur2Tor()`
- 한계: `SetPositionLimits()...`, `IsAllowablePosition()/Velocity()/Torque()`
- 홈: `SetHomePosition()`, `GetHomePosition()`, `SetHomingMethod()`

**실물 축 결선 (`CAxisCIA402`)**
- `Init(CEcatMaster&, driveMode)` — 마스터에 `AddSlave`, 콜백 2개 등록, (설정에 따라) 서보 온
- 콜백 `OnSlaveStatusChanged()`(서보 상태 → 축 상태, 첫 Idle 진입 시 **원점 확정**), `OnSlaveUpdateRawParam()`(매 프레임 현재값 갱신)
- EtherCAT 식별자 전달: `SetVendorInfo(vid, pcode)`, `SetDCInfo(dcSup, actWord, shift)`

**정확한 토크 변환 (`CAxisNRMKCore::MoveTorque`)**
```
dmotorcurrent = adTor / m_dGearRatio / m_dTorqueConstant
SetTargetTor( (INT16)(dmotorcurrent * m_dCurrentRatio * m_nDirection) )
```

**원점 확정 (`CAxisNRMKCore::OnSlaveStatusChanged`, `eServoIdle` 첫 진입)**
- 원본: `SetHomePosition(nStartPos);` — "켤 때 서 있는 자세가 0"
- (병합본에서 바뀝니다 → §15)

**시뮬 축**: `CAxisRT::StepSimulation(dt)`(모터 ODE 적분), `CAxisMuJoCo::ApplyToMuJoCo()/UpdateFromMuJoCo()`, `CRobotRTMuJoCo`(다축 시뮬 컨트롤러)

---

<a id="8"></a>
## 8. 계층 B' — 센서와 엔드툴

### 설명

축이 "움직이는 것"이라면 센서는 "느끼는 것"입니다. 이 계층은 힘/토크 센서를 다룹니다. 6축 힘/토크 센서는 세 방향의 힘(Fx, Fy, Fz)과 세 축의 회전 토크(Tx, Ty, Tz)를 측정합니다. 센서 계층이 하는 일은 앞서 축이 한 것과 비슷합니다 — **원시 정수값을 물리 단위로 바꾸고, 편향(bias)을 제거하고, 캘리브레이션을 적용하고, 과부하를 검사**합니다. 로봇을 켤 때 아무 힘도 안 걸린 상태에서 여러 샘플을 평균 내 "영점"을 잡는 것(bias 제거)이 대표적입니다.

이 센서는 대개 로봇 팔 끝의 **엔드툴**에 통합돼 있고, 그래서 엔드툴 계층은 힘 센서 외에도 그리퍼 열고 닫기, 상태 표시 LED(정상이면 초록, 에러면 빨강 식으로 색을 자동으로 바꿈), 버튼 입력까지 함께 관리합니다.

상속 구조는 축과 대칭적입니다: 추상 베이스 `CSensor` → 힘/토크 처리 `CSensorFT` → 엔드툴 통합 `CSensorNRMKEndTool`. 별도로 다관절 로봇 핸드(`CKistarHand`)도 있습니다.

### 🔧 실제 코드 (센서)

**상속 구조**: `CSensor` (추상: 수명주기·상태·한계·캘리브) → `CSensorFT` (6축 F/T 처리) → `CSensorNRMKEndTool` (엔드툴 통합)

- 힘/토크 처리: `CSensorFT::ProcessRawData()`, `ZeroBias()`(100샘플 평균 영점), `ApplyCalibration()`, `GetForce()/GetTorque()`
- 엔드툴: `CSensorNRMKEndTool::ReadData()`, `LED_RED/GREEN/...`, `SetGripper()/GetGripper()`, `UpdateLEDStatus()`(상태→색 자동 매핑)
- 로봇 핸드: `CKistarHand`
- MuJoCo 시각화 유틸: `MuJoCoVisualization`(GLFW 렌더)

---

<a id="9"></a>
## 9. 계층 C — 로봇 오케스트레이션 (`CRobot`)

### 설명

이제 개별 부품(축·센서·마스터)들을 **하나의 로봇으로 조립하고 지휘하는** 계층입니다. `CRobot`은 추상 베이스로, "로봇이라면 공통으로 해야 할 일"을 정의합니다: 축 목록·센서 목록·EtherCAT 마스터·설정·외부 인터페이스를 소유하고, 실시간 태스크를 만들고, 시작·정지·정리의 수명주기를 관리합니다. 구체적인 로봇(`CRobotIndy7`)은 이 베이스를 상속해 "Indy7만의 결선"을 채웁니다. 특히 EtherCAT을 실제로 구성하는 함수(`InitEtherCAT`)는 베이스에서는 비어 있고(그냥 실패 반환), 구체 로봇이 반드시 덮어써서 "마스터를 만들고, 설정파일 대로 슬레이브 7개를 생성·등록하고, 마스터를 가동"합니다.

**이 계층에서 가장 눈여겨볼 것은 실시간 태스크를 만드는 방식**입니다. 이 프레임워크는 태스크를 코드에 하드코딩하지 않고 **설정파일이 시키는 대로** 만듭니다. 설정파일의 `[RT_TASKS]` 절이 "태스크가 몇 개고, 각 태스크의 우선순위·주기·시작 지연은 얼마다"를 적어 두면, 로봇은 그 목록만큼 태스크를 생성하고, 주기가 있는 태스크는 그 주기로 돌게 설정한 뒤, 활성화된 태스크를 실행합니다.

여기서 **반드시 지켜야 할 불변식**이 하나 있습니다. 태스크 함수는 **등록한 순번(index)으로** 설정파일의 `[TASKn]`과 짝지어집니다. 그래서 코드가 등록한 함수 개수와 설정의 `NO_OF_TASKS`가 **정확히 같아야** 하며, 다르면 초기화가 통째로 실패합니다. 그리고 설정의 `NAME`은 그냥 라벨일 뿐이라, 이름과 실제 함수가 어긋나 있을 수도 있습니다(원본이 실제로 그렇습니다 — §13).

`CRobot`은 또 **설정 로더**(`CConfigRobot`)와 **외부 통신 인터페이스**(`CExtInterface`)를 품습니다. 설정 로더는 `.cfg` INI 파일을 읽어 시스템 설정·태스크 설정·EtherCAT 설정 구조체로 만들어 줍니다. 외부 인터페이스는 TCP 서버(포트 7420)로 외부 GUI/티치펜던트가 붙어 로봇·마스터·축의 메타데이터와 상태를 받아 가고 명령을 보낼 수 있게 합니다(자체 바이너리 프로토콜 + CRC16 무결성 검사).

> 실무 주의: 외부 인터페이스로 들어온 위치 명령을 실제 모션으로 바꾸는 콜백은 **비어 있는 스텁**입니다(명령을 받아 ACK만 하고 움직이지 않음).

### 🔧 실제 코드 (오케스트레이션)

**핵심 객체**: `CRobot`(추상 베이스) ← `CRobotIndy7`(구체 로봇), `CConfigRobot`(설정 로더), `CExtInterface`(TCP 7420 서버)

**수명주기·조립 (`CRobot`)**
- `Init(sim)` — 시뮬 아니면 `InitExtInterface()` → `InitEtherCAT()` → `InitRTTasks()` 순
- `AddAxis()`, `AddTaskFunction()`, `AddHand()` — 구성요소 등록
- `InitRTTasks()` — 설정대로 `create_rt_task(&t, 이름, 스택, 우선순위)` → (주기≠0이면) `set_task_period(&t, 시작시각, 주기)` → (활성 태스크만) `start_task(&t, 함수, this)`
- `CheckStopTask()` / `StopTasks()` — 협조적 정지 플래그
- `DeInit()` — 정지 → 2초 대기 → EtherCAT 해제 (⚠️ 원본은 종료 위치 저장 루프가 주석 처리됨)
- (구체 로봇이 오버라이드) `InitEtherCAT()` — 마스터·슬레이브 생성·등록·가동

**설정 로더 (`CConfigRobot`)**
- `ReadConfiguration()` → `ReadSystemConfig()` / `ReadRTTaskConfig()` / `ReadEtherCATConfig()`
- 태스크 파서가 읽는 키: `ENABLED`, `NAME`, `PRIORITY`, `TASK_PERIOD`, `START_DELAY` **5개뿐** (원본에는 CPU 어피니티 키 없음)
- 조회: `GetSystemConf()`, `GetTaskList()`, `GetEcatMasterConf()`, `GetEcatSlaveList()`
- `WriteLastPosition()` — `POS_BEFORE_EXIT` 기록용(원본에선 호출부가 주석 처리돼 미사용)

**외부 인터페이스 (`CExtInterface`)**
- `Init(robot, port=7420)`, 패킷 파싱 `ParseRecvPacket()`/`InterpretPacket()`
- 명령 분류: `CMD_ROBOT / CMD_AXIS / CMD_ECAT_MASTER / CMD_ECAT_SLAVE`
- 메타데이터 송신 `SendMetadataRobot()/Axis()/EcatMaster()`, `SendAck()`

---

<a id="10"></a>
## 10. 계층 D — 제어기 (토크를 계산하는 두뇌)

### 설명

여기가 "지능"이 있는 곳입니다. 제어기는 매 사이클 "현재 관절 상태"를 받아 "각 관절에 걸 목표 토크"를 계산합니다. 이 로봇은 위치를 직접 명령하지 않고 **토크로 제어**하기 때문에, 로봇의 물리(질량·관성·중력)를 아는 것이 필수입니다. 그래서 제어기는 **RBDL**이라는 강체 동역학 라이브러리와 로봇의 **URDF 모델**을 씁니다.

원본의 제어기는 **관절공간(joint space) 전용**입니다. 즉 "손끝을 이 좌표로 옮겨라"(카테시안/역기구학)는 기능이 **아예 없고**, "각 관절을 이 각도로"만 다룹니다. 모드는 셋입니다.

- **중력 보상**: 로봇이 자기 무게 때문에 아래로 처지지 않을 만큼의 토크만 겁니다. 이러면 사람이 손으로 로봇을 밀면 힘없이 따라옵니다(직접 교시에 유용). 수식으로는 중력 항만 상쇄.
- **풀 다이내믹스**: 목표 가속도에 관성 행렬을 곱하고, 코리올리·중력 보상을 더하고, 오차를 줄이는 PD 보정을 **밖에서** 더합니다.
- **계산 토크(CTC)**: 목표 가속도에 PD 보정을 **먼저 더한 뒤** 관성 행렬을 곱하고, 코리올리·중력을 더합니다. 부드럽고 정확한 추종에 씁니다.

네 번째 모드로 "적응 제어"가 열거형에 있지만 **구현이 없어서** 선택하면 중력 보상으로 떨어집니다.

제어기 자체의 부모(`CController`)는 모드와 무관한 공통 기능을 제공합니다: 출력 토크가 한계를 넘지 않게 포화시키고(saturate), 입력에 NaN/무한대가 없는지 검증하고, 통계를 냅니다. 그리고 실시간성을 위해 메모리를 미리 확보하고, 매 사이클 연산 시간을 재서 **500마이크로초 데드라인**을 넘는 횟수를 셉니다.

### 🔧 실제 코드 (제어기)

**핵심 객체**: `CController`(추상 베이스) ← `CControllerFullDynamicsRT`(RBDL 동역학 제어기)

**제어 모드 enum (4개, `FullDynControllerRT.h`)**
```cpp
enum eControlMode {
    eGravityCompensation = 0,
    eFullDynamics,        // 1
    eComputedTorque,      // 2
    eAdaptiveControl      // 3  ← 계산 함수 없음(미구현)
};
```

**`Update()`의 모드 분기와 토크 법칙**
| 모드 | 호출 함수 | 토크 법칙 |
|---|---|---|
| 중력 보상 | `ComputeGravityCompensation()` | τ = g(q) |
| 풀 다이내믹스 | `ComputeFullDynamics()` | τ = M·q̈_ref + h + (Kp·e_p + Kd·e_v) |
| 계산 토크(CTC) | `ComputeComputedTorque()` | τ = M·(q̈_ref + Kp·e_p + Kd·e_v) + h |
| 적응 제어 | (없음, `default`) | → 중력 보상으로 폴백 |

**동역학 계산에 쓰는 RBDL 함수 — 딱 3개**
- `CompositeRigidBodyAlgorithm` → 질량행렬 M
- `NonlinearEffects` → 코리올리+중력 h
- `InverseDynamics(q, 0, 0)` → 중력 g

> 원본에는 자코비안·역기구학·TCP 자세 관련 코드가 **전혀 없습니다**. 상태 벡터도 관절공간(`m_Q/m_Qd/m_Qdd`, `m_Q_ref/...`)뿐입니다.

**그 밖의 API**: `SetReferenceTrajectory()`, `SetReferencePos(축, 값)`(`_ALL_AXIS` 지원), `SetControlGain()/GetControlGain()`, `EnableRTMode()`, `SetDeadline()`, `InitRTOptimizations()`

**공통(`CController`)**: `SaturateOutput()`/`Clamp()`, `ValidateInputs()`, `UpdateStats()`, `IsEnabled()`

**성능 계측**: `RTPerformance{ max/avg/total_compute_time_ns, cycle_count, rt_violations, deadline_ns }`, 기본 데드라인 500 µs

---

<a id="11"></a>
## 11. 계층 E — RT-POSIX, 실시간의 정체

### 설명

지금까지 "실시간 태스크"라는 말을 계속 썼는데, 그 실체가 바로 **RT-POSIX**입니다. 이건 RAON-RT 저장소 안에 있지 않고 **`~/RT-POSIX`에 별도 소스**로 있으며, 빌드하면 `/opt/rt_posix`에 설치되어 `-lrtposix`로 링크됩니다. RAON-RT와 저자가 같습니다(서울과기대 임베디드시스템연구실).

이 라이브러리가 하는 일은 한 문장으로 요약됩니다: **"FreeRTOS나 Xenomai 같은 실시간 OS에서 쓰던 편한 태스크 API를, 표준 POSIX(pthread) 위에 다시 만들어 주는 것"**입니다. 리눅스에서 정확한 주기로 도는 스레드를 만들려면 스케줄링 정책(SCHED_FIFO), 우선순위, 스택 크기, 절대 시각 기준 수면 같은 것들을 일일이 다뤄야 하는데, RT-POSIX가 이를 `create_rt_task` / `set_task_period` / `wait_next_period` 같은 간단한 함수로 감쌉니다.

핵심 개념은 **주기 태스크**입니다. 태스크를 만들 때 "주기 = 1밀리초"라고 정해 두면, 태스크 본문은 무한 루프를 돌면서 매 바퀴 끝에 `wait_next_period()`를 부릅니다. 그러면 이 함수가 "다음 주기 시작 시각"까지 정확히 재워 줍니다. 중요한 건 **절대 시각 기준**이라는 점입니다 — "1밀리초 자기"가 아니라 "다음 1밀리초 경계까지 자기"이므로, 처리 시간이 조금씩 달라져도 오차가 누적되지 않습니다.

또 하나 알아 둘 것은 **CPU 배치**입니다. RT-POSIX는 기본적으로 태스크를 특정 코어에 고정하며, `set_cpu_affinity()`로 원하는 코어를 지정할 수 있습니다. 실시간 태스크를 다른 잡다한 작업이 없는 전용 코어에 몰아넣으면 지터(주기 흔들림)가 크게 줄어듭니다.

> ⚠️ **원본 RAON-RT의 함정**: 태스크를 만들 때 스택 크기로 `0`(=라이브러리 기본값 64KB)을 넘깁니다. 그런데 **ARM 64비트(aarch64)에서는 pthread 최소 스택이 128KB**라 이 요청이 실패합니다. 즉 원본 코드를 그대로 aarch64 보드에서 돌리면 태스크가 안 뜹니다. (병합본이 2MB로 고쳤습니다 — §15)

### 🔧 실제 코드 (RT-POSIX, `~/RT-POSIX`)

**파일 구성 (총 1087줄)**
| 파일 | 줄수 | 내용 |
|---|---|---|
| `examples/task.c` | 61 | **가장 먼저 읽을 파일** — 주기/일회성 태스크 생성의 전형 |
| `include/posix_rt.h` | 135 | `POSIX_TASK` 구조체 + API 전체 |
| `include/commons.h` | 104 | 공용 타입·로깅 |
| `src/posix_rt.c` | 693 | 실제 구현 |
| `src/commons.c` | 89 | 로거 등 |

**태스크 관리 API**
| 함수 | 하는 일 |
|---|---|
| `create_rt_task(&task, 이름, 스택크기, 우선순위)` | 실시간 태스크 생성(SCHED_FIFO) |
| `spawn_rt_task(...)` | 생성+시작 한 번에 |
| `start_task(&task, 함수, 인자)` | 등록된 태스크 실행 |
| `set_cpu_affinity(&task, 코어번호)` | CPU 고정 |
| `suspend_task()` / `resume_task()` / `delete_task()` | 일시정지/재개/삭제 |
| `get_task_info(&task, &info)` | 상태 조회 |

**타이머 API**
| 함수 | 하는 일 |
|---|---|
| `set_task_period(&task, 시작시각, 주기ns)` | 주기 설정 (`SET_TM_NOW`로 즉시 시작) |
| `wait_next_period(&overruns)` | 다음 주기 경계까지 블록 |
| `read_timer()` | 현재 모노토닉 시각(ns) |
| `spin_timer(ns)` | 바쁜 대기 |

**주요 상수/타입**: `DEFAULT_STKSIZE`(65536), `MAX_NAME_LENGTH`(32), 우선순위 범위 `0~99`, `RTTIME`(=UINT64 ns), `POSIX_TASK`(스레드+우선순위+스택+CPU셋+주기+상태), 상태 열거형 `eInit/eReady/eWaiting/eRunning/eSuspended/eDead`

**전형적 사용 패턴** (`examples/task.c`)
```c
mlockall(MCL_CURRENT | MCL_FUTURE);
create_rt_task(&task, "PERIODIC", 0, 99);
set_task_period(&task, SET_TM_NOW, 1000000000);   // 1초
start_task(&task, &sample_periodic_proc, NULL);
// 태스크 본문:  while(1) { ...일...; wait_next_period(NULL); }
```
→ RAON-RT의 `CRobot::InitRTTasks()`가 하는 일이 정확히 이 패턴입니다.

---

<a id="12"></a>
## 12. 곁가지 — 공용 유틸·시뮬레이션·ROS2

### 설명

**공용 유틸(`Global`)**은 모든 계층이 함께 쓰는 바닥 도구입니다. `.cfg` INI 파일을 읽고 쓰는 파서, 전역 타입·로깅 매크로·시간 함수·통신 구조체가 담긴 `Defines.h`, 그리고 통신 기본기(TCP 소켓 래퍼, CRC16 체크섬, 시리얼 포트)가 있습니다.

**시뮬레이션 변형**: 계층 B에서 본 대로, EtherCAT 대신 소프트웨어/MuJoCo를 붙인 축을 쓰면 로봇 전체를 시뮬레이션으로 돌릴 수 있습니다. `App/Indy7_ROS2_Mujoco`가 이 경로를 쓰는 실행 대상으로, MuJoCo 물리 엔진과 GLFW 렌더 창을 붙여 화면에서 로봇이 움직이는 걸 보며 같은 제어 코드를 검증할 수 있습니다.

**ROS2 브릿지(`Global/Comm/ROS2*`)**: 실시간 제어 루프와 ROS2 생태계를 잇는 계층입니다. 실시간이 아닌 별도 실행기(executor) 스레드가 ROS2 노드를 돌리며, 조인트 상태·게인·제어 모드 등을 토픽/서비스로 주고받습니다. `App/Indy7_ROS2`와 `App/Indy7_ROS2_Mujoco`가 이걸 씁니다. 파이썬 GUI(PyQt 기반)로 게인 조절·모드 전환을 하는 UI도 스크립트로 딸려 있습니다.

세 가지 앱 변형을 비교하면:

| | `App/Indy7` | `App/Indy7_ROS2` | `App/Indy7_ROS2_Mujoco` |
|---|---|---|---|
| EtherCAT 실물 | ✅ | ✅ | ✅ |
| ROS2 미들웨어 | ❌ | ✅ | ✅ |
| MuJoCo 시뮬 | ❌ | ❌ | ✅ |
| 원본의 기본 모드 | 실기 | 실기 | **시뮬(`SIMULATION_MODE=1`)** |

### 🔧 실제 코드 (곁가지)

- 공용 유틸: `ConfigParser`(INI), `Defines.h`(타입·`DBG_LOG_*`·`GetCurrTimeInNs`·엔디언 변환), `CRC16`/`CRC16_ARC`, `Socket`(`CTcpServer`/`CTcpClient`), `Serial`
- ROS2 브릿지: `ROS2Node`, `ROS2Executor`, `ROS2IndyIface`(조인트/게인/모드), 그 외 `ROS2AxisInfo`/`ROS2Imu`/`ROS2PointCloud`/`ROS2PrismIface`
- 파이썬 UI: `App/Indy7_ROS2/scripts/UICtrl.py`, `UiCtrlNG.py`, `commons.py`

---

<a id="13"></a>
## 13. 설정 파일(.cfg) 읽는 법

### 설명

이 프레임워크의 동작은 대부분 코드가 아니라 **`.cfg` 파일**이 정합니다. 형식은 익숙한 INI(`[섹션]` 아래 `키=값`)입니다. 크게 세 부분입니다.

- **시스템 설정(`[SYSTEM]`)**: 로봇 이름, 시뮬레이션 여부, URDF 모델 경로, 시작 시 제어 모드, 관절 수, 관절별 PD 게인(KP/KD), 외부 인터페이스 포트 등.
- **실시간 태스크 설정(`[RT_TASKS]`, `[TASK0]`…)**: 태스크 개수와, 각 태스크의 이름·우선순위·주기(나노초)·시작 지연.
- **EtherCAT 설정(`[ECAT_MASTER]`, `[AXIS0]`…)**: 마스터의 사이클 주기·DC 사용 여부·슬레이브 수, 그리고 슬레이브(축)마다 벤더/제품 ID, 기어비, 토크 상수, 엔코더 해상도, 홈잉 방법, 위치·속도·토크 한계, 동작 모드(CST=10) 등.

**원본 `App/Indy7/INDY7.cfg`의 태스크 구성** — 여기서 이름과 실체의 불일치를 직접 확인할 수 있습니다.

| 섹션 | NAME | 우선순위 | 주기 | 활성 | **실제 바인딩 함수** |
|---|---|---|---|---|---|
| `[TASK0]` | Main Control Task | 97 | 1 ms | ✅ | `proc_main_control` |
| `[TASK1]` | EtherCAT Control Task | 95 | 1 ms | ✅ | `proc_ethercat_control` |
| `[TASK2]` | Keyboard Input Task | 50 | 0(비주기) | ✅ | `proc_keyboard_control` |
| `[TASK3]` | Terminal Printer | 49 | 1 s | ✅ | `proc_terminal_output` |
| `[TASK4]` | **PI Controller Task** | 89 | 10 ms | ❌ | **`proc_logger`** (원본에선 빈 함수) |

> 💡 `[TASK4]`의 이름은 "PI Controller Task"지만 실제로 묶이는 함수는 다섯 번째로 등록된 `proc_logger`입니다. 게다가 원본의 `proc_logger`는 본문이 `return;` 한 줄뿐인 **빈 함수**이고, 이 태스크는 `ENABLED=0`이라 뜨지도 않습니다. **이름은 라벨일 뿐**이라는 걸 보여주는 좋은 예입니다.

**주요 EtherCAT 값**: `SLAVENUMBER=7`, `DC_ENABLED=1`, `CYCLE_TIME=1000000`(1 ms), 축마다 `DRIVE_MODE=10`(CST), `GEAR_RATIO=121`, `ENCODER_RESOLUTION=65536`, 토크상수 `0.0884`(J0~J2)/`0.058`(J3~J5).
**게인**: `KP_0..5 = 800/600/400/200/150/100`, `KD_0..5 = 80/60/40/20/15/10`.

> ⚠️ 원본 `[SYSTEM] URDF_PATH`는 `/home/airlab2/indy-ros2/...`로 **다른 PC의 경로**를 가리킵니다. 실행하려면 자기 환경 경로로 바꿔야 합니다.

### 🔧 실제 코드 (설정)

- 파서: `Global/ConfigParser`(`GetPrivateProfileString/Int`, `WritePrivateProfileString`)
- 로더: `CConfigRobot::ReadSystemConfig/ReadRTTaskConfig/ReadEtherCATConfig()`
- 대표 파일: `App/Indy7/INDY7.cfg`(실배포), `Config/8_axis_testbed.cfg`(샘플 8축), `CRobot/ELMO.cfg`(기본값 파일명)
- 불변식: `[RT_TASKS] NO_OF_TASKS` == `AddTaskFunction()` 호출 횟수 (`CRobot/Robot.cpp`가 다르면 즉시 실패)

---

<a id="14"></a>
## 14. 빌드와 외부 의존성

### 설명

빌드는 순수 GNU `make`입니다(CMake 없음). 두 단계로 이해하면 됩니다. 먼저 **저장소 루트에서 `make`**를 하면 EtherCAT 라이브러리(`libEMasterApp`)만 만들어 시스템 위치(`/opt/emaster_app`)에 설치합니다. 그다음 **각 앱 폴더로 들어가 개별로 `make`**를 해서 실행파일(`bin/Indy7Ctrl.out`)을 만듭니다 — 루트 `make`는 앱을 빌드하지 않습니다.

중요한 점은 이 저장소만으로는 빌드가 안 된다는 것입니다. **미리 설치돼 있어야 하는 외부 라이브러리**들이 정해진 경로(`/opt/...`)에 있어야 합니다. 원본 `App/Indy7`이 실제로 링크하는 것은 단출합니다 — EtherCAT 라이브러리, RT-POSIX, RBDL, 그리고 시스템 라이브러리뿐입니다. **ROS2·OpenCV·RealSense·ViSP는 링크하지 않습니다.**

### 🔧 실제 코드 (빌드)

- 루트 `Makefile`: `make` → `library_ecat`(`cd EMasterApp && make install`) → `/opt/emaster_app/{include,lib}`
- 라이브러리: `EMasterApp/Makefile`이 4개 소스(`EcatMasterBase/EcatSlaveBase/SlaveCIA402Base/SlaveNRMKEndTool.cpp`)로 `libEMasterApp.{a,so}` 생성, `-lethercat -lrtposix` 링크
- 앱: `App/Indy7/Makefile` — **16개 `.cpp`** 컴파일, 산출물 `bin/Indy7Ctrl.out`

**`App/Indy7`이 컴파일하는 16개 소스**
`ConfigParser` · `CRC16` · `Socket` (Global) / `Axis` · `AxisCIA402` · `AxisNRMKCore` · `Sensor` · `SensorFT` · `SensorNRMKEndTool` · `ConfigRobot` · `ExtInterface` · `Robot` (CRobot) / `Controller` · `FullDynControllerRT` · `Indy7Ctrl` · `main` (App)

**링크 라이브러리 (7개)**: `-lm -lrt -lpthread -lEMasterApp -lrtposix -lrbdl -lrbdl_urdfreader`
**인클루드**: `Global`, `CRobot`, `Global/Comm`, `/opt/emaster_app/include`, `/opt/rt_posix/include`, `/opt/etherlab/include`, `/usr/include/eigen3`
**컴파일 플래그**: `-w -O3 -std=gnu++17 -DNDEBUG -Dlinux -mtune=native -flto`

**외부 의존성 요약**
| 의존성 | 용도 | 기대 경로 |
|---|---|---|
| IgH EtherLab | EtherCAT 마스터 | `/opt/etherlab` |
| RT-POSIX | 실시간 태스크·타이밍 | `/opt/rt_posix` (소스는 `~/RT-POSIX`) |
| libEMasterApp | 이 저장소의 EtherCAT 라이브러리 | `/opt/emaster_app` |
| RBDL + Eigen3 | 동역학·선형대수(제어기) | 시스템 |
| MuJoCo + GLFW / ROS2 | 시뮬·미들웨어 변형 앱 전용 | 개발자 경로 / `/opt/ros/*` |

---

<a id="15"></a>
# 2부 — 원본 → `~/RAON-RT-Revision` 변경점

여기서부터는 **원본 `~/RAON-RT`** 와 **현재 병합 작업 중인 `~/RAON-RT-Revision`** 의 차이를 정리합니다. 1부에서 배운 계층 구조 위에 "무엇이 어떻게 달라졌는가"를 얹는 방식입니다.

## 15.0 한눈에 보기

| 구분 | 수치 |
|---|---|
| 신규 파일 | **41개** |
| 내용이 바뀐 파일 | **24개** |
| 삭제된 파일 | **0개** |

변경 규모가 가장 큰 곳과 가장 작은 곳이 극명하게 갈립니다.

| 파일 | 원본 | 병합본 | 성격 |
|---|---|---|---|
| `App/Indy7/FullDynControllerRT.cpp` | 537 | **2058** | 제어기 대증축 (역기구학 도입) |
| `App/Indy7/Indy7Ctrl.cpp` | 798 | **1849** | 태스크 본문 전면 교체 |
| `App/Indy7/FullDynControllerRT.h` | 142 | 461 | 모드·상수·진단 구조체 추가 |
| `App/Indy7/Indy7Ctrl.h` | 100 | 213 | 상태머신 3종·상수 추가 |
| `App/Indy7/Makefile` | 103 | 190 | ROS2 링크·신규 타깃 |
| `App/Indy7/INDY7.cfg` | 319 | 348 | 영점·안전·격리 설정 |
| `Global/Comm/ROS2Executor.cpp` | 405 | **138** | 대폭 단순화 |
| `CRobot/Robot.cpp` | 252 | 273 | RT 태스크·종료 저장 |
| `EMasterApp/Device/SlaveNRMKEndTool.cpp` | 233 | 252 | PDO 가드 복원 |
| `EMasterApp/Device/SlaveCIA402Base.cpp` | 635 | 647 | PDO 가드 복원 |
| `CRobot/AxisNRMKCore.cpp` | 125 | 125 | **4줄** — 홈 원점 |
| `CRobot/Axis.cpp` | 721 | 722 | **3줄** — RT 루프 printf 제거 |

## 15.1 변경을 관통하는 다섯 줄기

수백 줄의 diff를 다섯 가지 이야기로 묶을 수 있습니다.

### ① 안전: "전원 인가 = 로봇이 움직임"을 끊었다

원본은 EtherCAT 초기화만 끝나면 5개 축의 브레이크가 풀리고(`AUTO_SERVO_ON=1`), 제어기도 자동으로 붙었습니다(`ENABLE_CONTROLLER_AT_STARTUP=1`). 병합본은 **둘 다 껐습니다**. 대신 사람이 키보드로 순서를 밟습니다 — `r`(제어기 켜기) → `g`(중력보상) → `h`(서보 온). 심지어 `h`는 "제어기가 켜져 있고 모드가 중력보상일 때"만 통과합니다. 토크 모드(CST)는 0토크로 enable되므로, 중력보상이 먼저 서 있어야 팔이 주저앉지 않기 때문입니다.

### ② 정확성: 조용히 실패하던 곳을 시끄럽게 실패하게 만들었다

원본 EtherCAT 계층에는 **타입 하나 때문에 모든 실패 검사가 죽어 있는** 문제가 있었습니다. PDO 항목 등록 함수가 부호 없는 `UINT32`를 반환해 `if (실패)` 비교가 항상 거짓이 된 것입니다. 실패해도 아무 로그 없이 넘어가고, 잘못된 오프셋(`0xFFFFFFFF`)이 남아 1kHz 루프가 엉뚱한 메모리를 읽고 씁니다. 병합본은 반환형을 `INT64`로 바꿔 **원래 있던 실패 처리 배선에 신호가 도달하게** 했습니다. 고친 곳은 서보 드라이브(10개 PDO)와 엔드툴(17개 PDO)입니다.

### ③ 영점(원점): 로봇 각도의 기준이 흔들렸고, 사고가 났고, 되돌렸다

이것이 이번 병합에서 가장 위험했던 부분입니다. 세 가지가 맞물립니다.

- 원본에서 주석 처리돼 죽어 있던 **"종료 시 위치 저장"** 코드가 되살아났습니다. 이제 프로그램을 정상 종료할 때마다 설정파일의 `POS_BEFORE_EXIT`가 갱신됩니다.
- 동시에 `CAxisNRMKCore`의 **원점 계산식이 바뀌었습니다**: `홈 = 현재위치` → `홈 = 현재위치 − 지난 종료 위치`.
- 이 둘이 겹치면, `HOMING_METHOD=1`인 축의 영점이 **"직전에 어떤 자세로 껐는가"에 좌우되는 움직이는 표적**이 됩니다.

실제로 사고가 났습니다. 접힌 자세로 종료한 뒤 편 자세로 재시작하자 손목 축이 93° 틀린 각도를 보고했고, **중력보상이 그 틀린 각도를 믿고 손목을 능동 구동**했습니다. 대응은 운영 설정에서 AXIS4/5를 `HOMING_METHOD=3`(파일에 박힌 고정 오프셋)으로 되돌리고, 6축 영점을 실기에서 전면 재취득한 것입니다. **즉 코드는 뺄셈을 켰고, 운영 설정은 그 경로를 다시 꺼 둔 상태**입니다 — 한쪽만 보면 오판합니다.

### ④ 실시간성: aarch64에서 아예 안 뜨던 것을 뜨게 하고, 코어를 격리했다

원본은 태스크 스택 크기로 `0`(기본 64KB)을 넘기는데, **ARM 64비트에서는 pthread 최소 스택이 128KB**라 태스크 생성이 실패합니다. 병합본은 2MB로 올렸습니다. 여기에 설정파일에 **`CPU=` 키를 신설**해, 1kHz 짝(제어+EtherCAT)을 격리된 코어에 고정할 수 있게 했습니다. 그리고 1kHz 루프 안에서 초당 6000번 호출되던 `printf` 한 줄을 제거했습니다.

### ⑤ 기능: 관절공간 제어기에 "손끝을 어디로"가 생겼다

원본 제어기는 관절 각도만 다뤘습니다. 병합본은 **역기구학 두 모드**(자코비안 기반, RBDL 6DOF)를 추가하고, 그 위에 실전에서 필요한 방어 장치를 층층이 쌓았습니다 — 고정 시드에서 푸는 결정적 IK, 자세 가중치 사다리, 팔꿈치가 반대로 접히는 해(브랜치 플립)를 걸러내는 판정, 목표까지 거리가 멀면 중간 자세를 경유하는 스테이징, 도달 후 오차를 줄이는 리파인 반복. 여기에 ROS2 인지 파이프라인과 통신하는 픽앤플레이스 브리지, 작업공간 박스, 그리고 로봇 없이 도달 가능 영역을 미리 계산하는 오프라인 도구(`tools/reachmap.cpp`)까지 붙었습니다.

## 15.2 계층별 영향 요약

| 계층 | 변경 규모 | 핵심 |
|---|---|---|
| **EtherCAT (`EMasterApp`)** | 4파일 93줄 | PDO 등록 실패 검사 복원 (타입 버그 수정). 마스터 로직·상태워드·서보온 시퀀스는 **무변경** |
| **HAL (`CRobot`)** | 6파일 50줄 | 홈 원점 계산식, 종료 위치 저장 부활, 2MB 스택, `CPU=` 키, RT printf 제거. **토크 변환식·한계검사·상태머신은 무변경** |
| **제어기 (`App`)** | 2파일 +1840줄 | 역기구학 2모드 + 안전 게이트 + 궤적 계층 |
| **로봇 제어 (`App`)** | 2파일 +1164줄 | 태스크 5개 유지·본문 교체, 키맵 11→33, 상태머신 4종 |
| **설정 (`.cfg`)** | 3파일 | 영점 재취득, 안전 기본값, CPU 격리 |
| **ROS2** | 1파일 −267줄 | executor 단순화 |
| **신규** | 41파일 | 비전·브리지·URDF·도구 모음 |

## 15.3 통합·학습 시 꼭 알아야 할 주의점

1. **설정파일이 이제 읽기 전용이 아닙니다.** 정상 종료할 때마다 `POS_BEFORE_EXIT`가 자동으로 덮어써집니다. 버전 관리에 잡음이 생기고, 비정상 종료(강제 kill)하면 낡은 값이 남습니다.
2. **세 개의 `.cfg`가 서로 다릅니다.** 안전 픽스(`HOMING_METHOD=3`, `AUTO_SERVO_ON=0`)는 `App/Indy7`에만 적용됐고, ROS2·MuJoCo 변형 설정에는 사고 조건이 그대로 남아 있습니다. 게다가 그쪽은 `AUTO_SERVO_ON=1`이라 **사람 개입 없이 초기화만으로 그 조건에 도달**합니다.
3. **PDO 가드 복원은 두 슬레이브에만 적용됐습니다.** KistFT·FBG·EL2024·KistarHand는 여전히 원본 패턴이라 가드가 죽어 있습니다(현재 빌드에 포함되진 않음).
4. **헤더 사본이 세 벌**입니다(`EMasterApp/Device/`, `include/EMasterApp/`, `/opt/emaster_app/include/`). 앱 빌드는 `/opt` 쪽을 먼저 보므로, 라이브러리를 고치면 `make install`로 세 사본을 반드시 맞춰야 합니다.
5. `s` 키(캘리브 포즈 저장)는 세션 첫 캡처 때 파일을 새로 열어 **기존 캘리브 세트를 덮어씁니다.**

---

아래부터는 서브시스템별 상세 분석입니다. 각 절은 "어느 파일의 어느 함수/설정키가 어떻게 바뀌었는지"를 코드 근거와 함께 기록합니다.

---

## 15.4 EtherCAT 통신 계층 (`EMasterApp`) 변경점

이 계층의 변경은 **총 93라인, 파일 4개**뿐이지만 성격은 "기능 추가"가 아니라 **하드웨어 안전에 직결되는 단일 타입 버그의 전면 수정**이다. 변경 전체가 하나의 원인 — `RegisterPDOEntry()`의 반환형이 `UINT32`(부호 없음)였다 — 에서 파생된다. 커밋은 `b3b8209 kv260-merge: Phase 2a` 한 건이며(커밋 전체는 12개 파일 `+149/−167`, 그중 `EMasterApp`이 4개), 코드 주석에도 `[kv260-merge]` 태그가 붙어 추적 가능하다.

디렉토리 전체 비교(`diff -rq`) 결과 `EMasterApp` 아래에서 내용이 달라진 파일은 아래 4개뿐이고, 나머지 차이는 빌드 산출물(`lib/`, `obj/`)이다. 즉 **마스터 구동 로직(`EcatMasterBase`), 상태워드 해석, 서보온 시퀀스, 홈잉은 한 줄도 손대지 않았다.** `EMasterApp/Makefile`도 무변경이다.

| 파일 | 원본 | 병합본 | 변경 성격 |
|---|---|---|---|
| `EMasterApp/Device/EcatSlaveBase.h` | 120줄 | 122줄 | `RegisterPDOEntry` 반환형 `UINT32`→`INT64` + 사유 주석 2줄 (`+3/−1`) |
| `EMasterApp/Device/EcatSlaveBase.cpp` | 374줄 | 374줄 | 같은 함수 정의부 반환형 + 지역변수 `unRet` 타입 (`+2/−2`, 순증 0) |
| `EMasterApp/Device/SlaveCIA402Base.cpp` | 635줄 | 647줄 | `RegisterPDO()` 한 함수만, 10개 PDO 가드 복원 (`+22/−10`) |
| `EMasterApp/Device/SlaveNRMKEndTool.cpp` | 233줄 | 252줄 | `RegisterPDO()` 한 함수만, 17개 PDO 가드 복원 (`+36/−17`) |

"93라인"의 근거: 추가 55 + 삭제 38 = 93 (4+4+32+53). 순증만 보면 +31줄이다.

---

### 1. 근본 원인: `CEcatSlaveBase::RegisterPDOEntry` 반환형

`/home/ubuntu/RAON-RT-Revision/EMasterApp/Device/EcatSlaveBase.h:36`, `EcatSlaveBase.cpp:92~115`(함수 전체 범위).

```
- UINT32  RegisterPDOEntry (UINT16, UINT8, UINT32*, ECAT_COMM_DIR anEcatCommDir = eInput);
+ /* [kv260-merge] was UINT32 — unsigned return made every "<0" failure guard
+  * dead code and left offsets at 0xFFFFFFFF on failure (OOB next cycle). */
+ INT64   RegisterPDOEntry (UINT16, UINT8, UINT32*, ECAT_COMM_DIR anEcatCommDir = eInput);
```

`.cpp` 쪽도 정의부 시그니처(`EcatSlaveBase.cpp:92`)와 함께 지역변수 한 줄이 바뀌었다: `UINT32 unRet = -1;` → `INT64 unRet = -1;`(`:95`). **이 두 줄이 `.cpp` 변경의 전부이며 함수 본문 로직은 동일하다.**

이 함수가 감싸는 IgH API `ecrt_slave_config_reg_pdo_entry()`는 원본 주석에도 명시되어 있듯 **`>=0`이면 프로세스 데이터 오프셋, `<0`이면 에러 코드**를 반환한다. 그런데 반환형이 `UINT32`였으므로:

| 지점 | 원본에서의 실제 동작 | 병합본 |
|---|---|---|
| 함수 내부 `if(unRet < 0) DBG_LOG_ERROR(...)` (`:107~108`) | `unRet`이 `UINT32` → 비교가 항상 거짓 → **등록 실패 로그가 한 번도 안 찍힘** | `INT64`라서 실제로 실패를 잡아 `"[%d:%d] Register PDO(index:%x subindex:%x) Failed!"`(alias:position 포맷) 출력 |
| 호출부 `if (0 > (offset = RegisterPDOEntry(...))) return FALSE;` | `UINT32` 필드에 대입한 결과와의 비교 → `0`이 unsigned로 승격되어 **항상 거짓**, `return FALSE` 도달 불가 | 부호 있는 임시변수로 받아 비교 → 정상 동작 |
| 실패 시 오프셋 값 | `-1`이 `0xFFFFFFFF`로 저장됨 | 실패 시 그 자리에서 `RegisterPDO()`가 `FALSE` 반환, 저장 안 함 |

**왜 아무도 못 봤나:** `EMasterApp/Makefile:31`의 `CFLAGS_OPTIONS = -Wall -O3 -mtune=native -flto`인데, "comparison of unsigned expression in `< 0` is always false"는 `-Wtype-limits`(= `-Wextra`에 포함)라 `-Wall`만으로는 경고가 나오지 않는다(로컬 g++로 재현 확인). 게다가 이를 링크해 쓰는 `App/Indy7/Makefile:31`은 `-w`로 경고를 아예 끈다.

`INT32`가 아니라 **`INT64`를 고른 이유는 코드상 정합적**이다. 오프셋 필드는 `UINT32`(`EcatSlaveBase.h:15` `#define SET_OFFSET(N) SET_PREFIX_VAR(UINT32,off,N)`)이므로, 부호 있는 32비트로 받으면 `0x8000_0000` 이상의 큰 오프셋이 음수로 오인될 수 있다. `INT64`는 `UINT32` 전 범위를 양수로 담으면서 음수 에러 코드도 구분한다.

**왜 이게 위험한가(코드상 확인되는 범위):** 오프셋은 `CEcatSlaveBase::WritePdoU/WritePdoS/ReadPdoU8..ReadPdoS64`(`EcatSlaveBase.cpp:255~`)에서 `EC_WRITE_U8(m_stEcatMasterDesc.pEcatDomainPdOut + aunOffset, ...)` 형태로 **경계 검사 없이 도메인 베이스 포인터에 그대로 더해진다**. 원본대로면 등록 실패한 항목의 오프셋이 `0xFFFFFFFF`로 남고, 64비트에서 이 값은 양수로 승격되므로 다음 사이클부터 1 kHz RT 루프가 도메인 시작점에서 약 4 GB 떨어진 주소에 읽기/쓰기를 시도한다 — 그것도 조용히. 병합본은 이걸 **기동 시점의 명시적 실패**로 바꾼다: `RegisterPDO()`가 `FALSE`를 돌려주면 이미 원본에 존재하던 `EcatSlaveBase.cpp:204~209` 경로가 `"Registering PDO Failed!"`를 찍고 `Init()`을 `FALSE`로 종료시킨다. 즉 **실패 처리 배선은 원래 다 있었고, 타입 하나 때문에 그 배선에 신호가 도달하지 못했던 것.**

### 2. `CSlaveCIA402Base::RegisterPDO()` — 서보 드라이브 PDO 10개 (635→647, +12)

`/home/ubuntu/RAON-RT-Revision/EMasterApp/Device/SlaveCIA402Base.cpp:426~478`. **이 파일에서 바뀐 곳은 `RegisterPDO()` 단 하나**이며, `AnalyzeStatusWord()`(71행), `SetServoStatus()`, `ReadFromSlave()`(240행), `WriteToSlave()`(331행, 서보온 상태천이), `SetServoOn/Off`(539·556행), `SetNewSetPoint`(607행), `SetEmgStop`(620행), `SetHalt`(627행), `GoHome()`(640행)은 **전부 원본 그대로**다. 요청하신 후보 중 정답은 **상태워드/서보온/홈잉이 아니라 PDO 등록**이다.

패턴 변경(모든 항목 동일):

```c
- if (0 > (m_stSlaveParams.GET_OFFSET(ControlWord) = CEcatSlaveBase::RegisterPDOEntry(0x6040, 0x00, &..., eOutput)))
-     return FALSE;
+ if (0 > (nPdoOff = CEcatSlaveBase::RegisterPDOEntry(0x6040, 0x00, &..., eOutput)))
+     return FALSE;
+ m_stSlaveParams.GET_OFFSET(ControlWord) = (UINT32)nPdoOff;
```

함수 선두에 `INT64 nPdoOff = -1;` 한 줄과 사유 주석 한 줄(`/* [kv260-merge] signed capture revives the dead "<0" guards (UINT32 return made them no-ops) */`)이 추가되었고, **성공이 확인된 뒤에만** `(UINT32)` 캐스팅해 오프셋 필드에 대입한다. 순증 12줄 = 주석 1 + 선언 1 + 대입 10.

가드가 복원된 CiA402 객체 목록:

| 방향 | Index:Sub | 이름 | 역할 |
|---|---|---|---|
| Output | `0x6040:00` | ControlWord | 서보온/폴트리셋 등 전 제어 |
| Output | `0x607A:00` | TargetPos | CSP 목표 위치 |
| Output | `0x60FF:00` | TargetVel | CSV 목표 속도 |
| Output | `0x6071:00` | TargetTor | CST 목표 토크 (중력보상·CST 제어에 사용) |
| Output | `0x6060:00` | DriveMode | 모드 전환(6060h) |
| Input | `0x6041:00` | StatusWord | 상태워드 |
| Input | `0x6064:00` | ActualPos | 실제 위치(엔코더) |
| Input | `0x606C:00` | ActualVel | 실제 속도 |
| Input | `0x6077:00` | ActualTor | 실제 토크 |
| Input | `0x6061:00` | DriveModeDisplay | 현재 모드 표시 |

주석 처리된 항목은 원본과 동일하게 주석 상태로 남아 있다 — 총 9개: `0x6081 ProfileVel`, `0x6083 ProfileAcc`, `0x6084 ProfileDec`, `0x6085 QuickStopDec`, `0x607F MaxProfileVel`, `0x60C5 MaxProfileAcc`(이상 Output), `0x603F ErrorCode`, `0x2FE4:02 AdditionalPos`, `0x6075 MotorRatedCurrent`(이상 Input). **활성 항목만 손댔고 PDO 매핑 구성 자체는 변하지 않았다.**

의미: 이 팀의 제어는 `TargetTor`(CST) 기반이다. 원본에서 만약 `0x6071` 등록이 실패했다면 컨트롤러는 아무 경고 없이 기동해 4 GB 밖 주소에 토크 명령을 쓰고, 드라이브는 토크 0을 유지하거나 마지막 값을 물고 있게 된다. 병합본은 그런 조합이 아예 기동되지 않도록 만든다.

### 3. `CSlaveNrmkEndtool::RegisterPDO()` — 엔드툴 PDO 17개 (233→252, +19)

`/home/ubuntu/RAON-RT-Revision/EMasterApp/Device/SlaveNRMKEndTool.cpp:36~96`. **+19줄의 정체는 F/T 신기능도 LED 신기능도 그리퍼 신기능도 아니다.** 주석 1 + `INT64 nPdoOff = -1;` 1 + 성공 후 대입 17 = 19. CIA402와 완전히 동일한 패턴이며(주석 문구까지 동일), 이 파일의 나머지 — `ReadFromSlave()`의 `FT_FORCE_DIVIDER`(50.)/`FT_TORQUE_DIVIDER`(2000.) 환산과 `FTErrorFlag` 처리, `WriteToSlave()`의 F/T 상태머신(실행 순서 `FT_NONE→FT_READY→FT_SET_FILTER→FT_SET_DATARATE→FT_SET_START→FT_SET_BIAS`, 폴트 시 `FT_STOP_DATA_OUTPUT`), `FTSensorOn/Off`(179·191행), `GetFTDataRate()`(200행)/`GetFTLPFCof()`(215행) 룩업 테이블 — 은 **한 글자도 바뀌지 않았다.**

다만 가드가 복원된 대상은 F/T·LED·그리퍼 **셋 다**이다:

| 방향 | Index:Sub | 이름 | 계통 |
|---|---|---|---|
| Output | `0x7000:01` | ILed | LED (디지털 출력) |
| Output | `0x7000:02` | IGripper | **그리퍼 구동 출력** |
| Output | `0x7000:03` | FTConfigParam | F/T 설정 커맨드(필터·데이터레이트·바이어스·시작/정지) |
| Output | `0x7000:04~07` | LEDMode / LEDG / LEDR / LEDB | RGB LED |
| Input | `0x6000:01` | IStatus | 툴 상태 |
| Input | `0x6000:02` | IButton | 툴 버튼 |
| Input | `0x6000:03~08` | FTRawFx/Fy/Fz/Tx/Ty/Tz | F/T 원시값 (16bit signed) |
| Input | `0x6000:09` | FTOverloadStatus | **F/T 과부하 상태** |
| Input | `0x6000:0A` | FTErrorFlag | F/T 에러 플래그 |

특히 `IGripper`(0x7000:02)와 `FTOverloadStatus`(0x6000:09)가 이 수정의 실질적 수혜자다. 그리퍼 출력 오프셋이 조용히 깨진 채 기동하면 파지 명령이 엉뚱한 메모리로 나가고, 과부하 입력 오프셋이 깨지면 `WriteToSlave()`의 F/T 폴트 처리가 쓰레기 값을 읽는다. 메모리 상 사용자의 현재 작업이 "**파지는 그리퍼 하드웨어 대기**" 상태이므로, 그리퍼를 처음 물릴 때 이 가드가 실제로 의미를 갖게 된다.

### 4. 이번 수정이 커버하지 **않는** 범위 (통합 시 주의)

`RegisterPDOEntry`를 호출하는 파일은 병합본에 총 6개지만(호출문 자체는 KistarHand 하나만 100개가 넘는다), **고쳐진 것은 CIA402와 NRMKEndTool 2개뿐**이다. 나머지 4개는 원본 패턴(`GET_OFFSET(X) = RegisterPDOEntry(...)`를 `if (0 > ...)` 안에서 직접 대입)이 그대로 남아 있다:

- `EMasterApp/Device/SlaveKistFT.h:169~187`
- `EMasterApp/Device/SlaveFBGSensor.h:201~235`
- `EMasterApp/Device/SlaveBeckhoffEL2024.h:57`
- `EMasterApp/Device/SlaveKistarHand.cpp:43~246`

이들은 반환형이 `INT64`가 되어도 **`UINT32` 필드에 대입한 결과를 비교하므로 여전히 부호 없는 비교 = 가드가 죽어 있다.** 다만 `EMasterApp/Makefile:40~43`의 `SOURCES`는 `EcatMasterBase.cpp`, `EcatSlaveBase.cpp`, `SlaveCIA402Base.cpp`, `SlaveNRMKEndTool.cpp` **4개만** 빌드하므로(나머지는 헤더-only이거나 미참조) 현재 Indy7 구성에서는 링크되지 않는다. 나중에 KistarHand 등 다른 슬레이브를 살릴 경우 같은 패턴을 함께 적용해야 한다.

추가 주의: `SlaveKistFT.h`에는 타입과 무관한 **별도의 복붙 버그**가 그대로 있다 — `0x6000:04/05/06`(Tx/Ty/Tz)의 오프셋을 `GET_OFFSET(Fx)/(Fy)/(Fz)`에 덮어쓰고, `Count`가 `Tz`와 같은 서브인덱스 `0x06`을 쓴다. 이 슬레이브를 살릴 때는 타입 수정만으로 부족하다.

또 하나, **헤더 사본이 3벌**이라는 점: 현재 세 곳 모두 `INT64`로 동일함을 `diff -q`로 확인했다.

- `EMasterApp/Device/EcatSlaveBase.h` (in-tree, git 추적됨 — 이번 커밋의 대상)
- `RAON-RT-Revision/include/EMasterApp/EcatSlaveBase.h` — **git 미추적**(`git ls-files include` = 0). `EMasterApp/Makefile:66~67`의 `make install`이 `cp -rfp Device/*.h`로 만들어내는 산출물이며, 커밋 `2cdba3a`에서 의도적으로 untrack되었다. 원본 저장소에는 `include/` 디렉토리 자체가 없다.
- `/opt/emaster_app/include/EcatSlaveBase.h` — **`App/Indy7/Makefile:26`의 `ECAT_INCLUDE` 기본값**이 바로 이 경로다(`ECAT_LIB=/opt/emaster_app/lib`). 커밋 메시지에 나오는 `ECAT_INCLUDE=../../include/EMasterApp`는 Makefile 기본값이 아니라 그 빌드에서 준 **override**다.

통합 시 실제 함정: `App/Indy7/Makefile:32`의 CFLAGS는 `-I$(ECAT_INCLUDE)`가 `-I$(ECAT_DIR)/Device`보다 **앞에** 온다. 즉 `/opt/emaster_app/include`에 옛 `UINT32` 헤더가 남아 있으면 in-tree 소스를 고쳐도 앱은 낡은 시그니처로 컴파일되고, `libEMasterApp`(`INT64`)와 시그니처가 어긋난다. `EMasterApp`을 고칠 때는 `make install`(또는 `ECAT_INCLUDE` override)로 세 사본을 반드시 함께 맞출 것.

### 5. 참고: EtherCAT 계층 바깥의 연동 변경 1건

`EMasterApp` 자체는 아니지만 같은 커밋에서 `CRobot/AxisCIA402.h:69~70`에 주석 1줄과 `CSlaveCIA402& GetEcatSlave() { return m_cEcSlave; }`가 추가되어(파일 순증 3줄), `App/Indy7/Indy7Ctrl.cpp:459`에서 `m_pEcatAxis[0]->GetEcatSlave().SetAsDCRef()`로 **슬레이브 0을 DC 기준 클럭으로 명시 지정**한다. `SetAsDCRef()` 자체는 원본 `EcatSlaveBase.cpp:147`에 이미 있던 **public 멤버**이고 이번에 전혀 손대지 않았다 — 그래서 접근자 하나만 뚫으면 바로 호출된다.

주의할 점은 이게 "주석상 no-op"이 아니라 **실제 코드 가드**라는 것이다:

```c
if (nCnt == 0 && stSlaveInfo.bDCSupported)      // Indy7Ctrl.cpp:457
    if (FALSE == m_pEcatAxis[0]->GetEcatSlave().SetAsDCRef())
        DBG_LOG_WARN("(%s) SetAsDCRef(slave 0) failed", "CRobotIndy7");
```

`bDCSupported`가 거짓이면 호출 자체가 일어나지 않는다. 그리고 **원본 `INDY7.cfg`에는 `DC_SUPPORT` 키가 아예 없었고**, 병합본이 `App/Indy7/INDY7.cfg:103~106`에 주석 처리된 템플릿(`;DC_SUPPORT=1`)과 사유를 새로 넣었다(저자 검증 세팅은 SM-sync). 즉 지금은 비활성, `DC_SUPPORT=1`을 푸는 순간 축별로 활성화된다.

---

## 15.5 로봇 HAL 계층 (`CRobot`) 변경점

`CRobot/` 디렉토리 전체를 `diff -rq`로 훑은 결과 **변경 파일은 정확히 6개, 신규·삭제 파일은 없습니다**(`Only in ...` 라인 0). 총 변경량은 **추가 42줄 / 삭제 8줄(순증 +34)** 로 작지만, 그 안에 **원점(홈) 결정 로직**, **RT 태스크 스택·CPU 배치**, **종료 시 위치 영속화**라는 로봇 거동에 직결되는 세 가지가 들어 있습니다.

| 파일 | 바뀐 대상 | 성격 | 라인 |
|---|---|---|---|
| `CRobot/Axis.cpp` | `CAxis::GetCurrentTor()` | RT 루프 내 printf 제거 | +2 / −1 |
| `CRobot/AxisCIA402.h` | `CAxisCIA402` public 접근자 | `GetEcatSlave()` 신규 노출 | +3 |
| `CRobot/AxisNRMKCore.cpp` | `OnSlaveStatusChanged()` / `eServoIdle` 분기 | **홈 원점 계산식 활성 라인 교체** | +2 / −2 |
| `CRobot/ConfigRobot.h` | `stConfigTask` 구조체 | `INT32 nCpu` 필드 추가 | +4 |
| `CRobot/ConfigRobot.cpp` | 태스크 섹션 파서 | **신규 cfg 키 `CPU=` 파싱** | +5 |
| `CRobot/Robot.cpp` | `DeInit()`, `InitRTTasks()` | 종료 위치 저장 부활 + CPU 핀 + 스택 크기 | +26 / −5 |

이력상 출처(병합본 git): 위치 저장 루프 부활은 `d34d1fd`(2026_05_17) — 즉 원본 대비로는 변경이지만 이번 kv260 작업분은 아닙니다. `CPU=` 키와 2 MiB 스택은 `a6e2097`(D10 3+1 격리), cfg 쪽 홈잉 방식 변경은 `7f9495b`(E24)입니다.

---

### 1. `AxisNRMKCore.cpp` — 토크 공식이 아니라 **홈 원점** 변경 (가장 중요)

먼저 결론부터: **토크→전류→카운트 변환 코드는 단 한 글자도 바뀌지 않았습니다.** `MoveTorque()`, `ConvertTor2Res()`, `ConvertRes2Tor()` 세 함수 모두 원본과 동일하며, 다음 식이 그대로 유지됩니다.

```
dmotorcurrent = adTor / m_dGearRatio / m_dTorqueConstant
SetTargetTor( (INT16)(dmotorcurrent * m_dCurrentRatio * m_nDirection) )
```

즉 부호(`m_nDirection`)·스케일(`m_dCurrentRatio`, `m_dTorqueConstant`, `m_dGearRatio`) 어느 것도 손대지 않았습니다.

실제 4라인 변경은 `CAxisNRMKCore::OnSlaveStatusChanged()`의 `case eServoIdle:` → `if (TRUE == m_bFirstHome)` 블록, 즉 **서보가 처음 Idle에 진입한 순간 딱 한 번 실행되는 원점 확정 코드**입니다(`AxisNRMKCore.cpp:74-75`). 주석/활성 라인이 서로 뒤바뀌었습니다.

| 항목 | 원본 | 병합본 |
|---|---|---|
| 활성 라인 | `SetHomePosition(nStartPos);` | `SetHomePosition(nStartPos - GetPositionBeforeExit());` |
| 주석 라인 | `// SetHomePosition(nStartPos - GetPositionBeforeExit());` | `// SetHomePosition(nStartPos);` |
| 조건 | `eAxisHomeStartPos == GetHomingMethod()` | 동일 |

의미:

- 원본은 **"전원 켰을 때 서 있는 자세가 곧 0도"** 였습니다(상대 원점). 병합본은 **"현재 엔코더 카운트 − 지난 종료 시 저장해 둔 카운트"** 를 원점으로 삼습니다. 즉 이전 세션의 자세를 기준으로 절대 각도를 복원하는 방식으로 바뀌었습니다.
- `GetPositionBeforeExit()`가 반환하는 값은 `App/*/Indy7Ctrl.cpp`가 `SetPositionBeforeExit(stSlaveInfo.nPosBeforeExit)`로 주입한 것이고(`App/Indy7/Indy7Ctrl.cpp:411`, `App/Indy7_ROS2/Indy7Ctrl.cpp:649`, `App/Indy7_ROS2_Mujoco/Indy7Ctrl.cpp:842`), 그 원천은 cfg `[AXISn] POS_BEFORE_EXIT` 입니다(`ConfigRobot.cpp:352`에서 파싱).
- 따라서 **cfg의 `POS_BEFORE_EXIT` 값이 실제 팔 자세와 어긋나면, 그 차이가 그대로 해당 축의 각도 오프셋**이 됩니다. 원본에서는 이 키가 읽히기만 하고 원점에 반영되지 않아 무해했지만, 병합본에서는 직접 각도를 좌우합니다.
- **형제 클래스와의 일관성 회복**: `AxisCIA402.cpp:516`과 `AxisELMO.cpp:89`는 **원본에서도 이미** 뺄셈 형태였습니다(두 파일 모두 diff 없음). `CAxisNRMKCore`만 뺄셈이 주석 처리된 예외 상태였고, 이번 변경으로 세 HAL 구현이 동일 규칙을 따르게 되었습니다.
- 적용 범위는 `HOMING_METHOD` 값에 따라 갈립니다. `eHomingMethod` 열거는 `Axis.h:14-21`에서 `eAxisHomingNotSet=0, eAxisHomeStartPos=1, eAxisHomeSearch=2, eAxisHomeManual=3, eAxisHomeBuiltin=4` 이므로 이 코드는 **`HOMING_METHOD=1`인 축에만** 적용됩니다.
- **⚠️ 실행 중인 설정에서는 지금 이 경로를 타는 축이 하나도 없습니다.** 실제 구동 앱은 `App/Indy7`이고(그 cfg만 `CPU=3`를 갖고, `FullDynControllerRT`/`ROS2PickBridge`가 여기 있으며, 실행 때마다 cfg가 갱신됨), **`App/Indy7/INDY7.cfg`는 병합에서 AXIS4/5를 `HOMING_METHOD=1 → 3`으로 바꿔 AXIS0~5 전부 `=3`(Manual, `HOME_POSITION_OFFSET` 사용)** 입니다. cfg 주석이 이유를 직접 적어 둡니다 — "그 방식은 홈을 *이 파일 안의 숫자*로 디코드하므로, 접힌 자세로 종료 후 곧게 편 상태로 재시작하면 손목 각도가 93° 틀리고 중력보상이 손목을 능동 구동했다(2026-07-27 22:47)". `=1`이 남아 이 뺄셈을 타는 건 `App/Indy7_ROS2/INDY7.cfg`·`App/Indy7_ROS2_Mujoco/INDY7.cfg`의 AXIS4/5뿐이고, 이 두 cfg의 `HOMING_METHOD` 배치는 원본과 동일합니다. 정리하면 **코드는 뺄셈을 켰고, 운영 cfg는 그 경로를 다시 꺼 둔 상태**입니다 — 어느 한쪽만 보면 오판합니다.
- 이 변경은 아래 3번 `Robot.cpp::DeInit()`의 위치 저장 부활과 **한 쌍**입니다. 저장(DeInit)이 죽어 있으면 뺄셈(부팅)은 낡은 값을 쓰게 되므로, 둘은 반드시 함께 켜져야 성립합니다.
- 코드상 사소한 관찰: `m_nPosBeforeExit` 저장 타입은 `INT32`(`Axis.h:313`)인데 접근자 시그니처는 `double`(`Axis.h:180-181`, setter/getter 양쪽)이라 주입 때 한 번, `nStartPos - GetPositionBeforeExit()` → `SetHomePosition(INT32)`에서 또 한 번 암시적 축소가 일어납니다. 값이 정수라 실사용 정밀도 손실은 없습니다.

### 2. `Axis.cpp` — 단위 변환/한계검사가 아니라 **RT 루프 로그 제거**

바뀐 곳은 `CAxis::GetCurrentTor()` 단 한 곳이며, 반환값 `m_pstAxisParams->dTor`은 그대로입니다. 스케일링·클램프·상태 전이 어느 것도 건드리지 않았고, `printf("[CAxis::GetCurrentTor] Current Torque: ...")` 한 줄을 주석 처리하고 `// jieun` 표식을 남긴 것이 전부입니다(삭제 1 + 추가 2 = 3라인).

영향이 작지 않은 이유는 **호출 지점이 1 kHz RT 태스크 내부**이기 때문입니다. `App/Indy7_ROS2/Indy7Ctrl.cpp:896`의 `proc_main_control` 루프는 `wait_next_period()` 직후 축 개수(`udof`)만큼 도는 for 문 안에서 `pRobot->m_vCurrentTor[nCnt] = ax->GetCurrentTor();`를 호출합니다. 다만 이 세 줄(`GetCurrentPos/Vel/Tor`)은 **`if (bUseRTController)` 가드 안**에 있으므로(구동 앱 `App/Indy7/Indy7Ctrl.cpp:1058`은 `if (bCtrlOn)`, `App/Indy7_ROS2_Mujoco/Indy7Ctrl.cpp:1132`은 `bUseRTController`), 컨트롤러가 켜진 동안에만 해당됩니다. 그 조건에서 6축이면 **초당 6,000회 printf**가 SCHED_FIFO 태스크 안에서 stdout 락과 I/O를 유발하던 셈이라, 제거만으로 사이클 지터의 큰 원인이 사라집니다.

### 3. `Robot.cpp` (순증 +21라인, 추가 26 / 삭제 5) — `DeInit()` 위치 저장 부활 **과** `InitRTTasks()` CPU 핀, 둘 다

질문의 "셋 중 무엇인가"에 대한 답은 **둘 다**입니다. 축 등록(`AddAxis`)은 변경 없습니다.

**(a) `CRobot::DeInit()` — 종료 위치 저장 루프 복원 (주석 → 실행)**

원본에서 통째로 주석 처리돼 있던 3줄 루프가 살아났고, 진단 로그 2개가 추가됐습니다.

```c
for (INT nCnt = 0; nCnt < GetTotalAxis(); nCnt++)
{
    INT32 nRawPos = m_vAxis[nCnt]->GetCurrentRawPos();
    DBG_LOG_INFO("(DeInit) AXIS[%d] CurrentRawPos: %d, HomePosition: %d, Diff: %d",
        nCnt, nRawPos, m_vAxis[nCnt]->GetHomePosition(), nRawPos - m_vAxis[nCnt]->GetHomePosition());
    m_pcConfigRobot->WriteLastPosition(nCnt, nRawPos);
    DBG_LOG_INFO("(DeInit) AXIS[%d] POS_BEFORE_EXIT saved: %d", nCnt, nRawPos);
}
```

- `CConfigRobot::WriteLastPosition()`(`ConfigRobot.cpp:468`, 실제 쓰기는 474행)는 `WritePrivateProfileString("AXISn", "POS_BEFORE_EXIT", ...)`로 **cfg 파일을 실제로 덮어씁니다**. 즉 프로그램을 정상 종료할 때마다 INI가 갱신됩니다.
- **동작 증거(가장 직접적)**: 병합본 저장소의 `git status`에 ` M App/Indy7/INDY7.cfg` 하나만 떠 있고, 커밋본과 작업 트리의 `POS_BEFORE_EXIT`가 서로 다릅니다(HEAD `23235183, 593047, 14738594, −7031572, 48169982, −544404` → 작업 트리 `23108487, 582262, 13178747, −7122453, 45762761, −542153`). 사람이 손댄 diff가 아니라 이 루프가 매 종료 시 써 넣은 결과입니다.
- 원본 3개 cfg는 모두 동일한 옛 값(`46888, 29197, 63103, −29781, 26943, −2457587`)을 갖고 있습니다. 병합본에서 `App/Indy7_ROS2/INDY7.cfg`는 `15755198, 28194, 15841836, −20393020, 33130760, −6573591`(과거 그 앱을 돌리던 시기의 기록), `App/Indy7_ROS2_Mujoco/INDY7.cfg`는 **원본 값 그대로**입니다 — 즉 앱마다 마지막 실행 시점이 다르게 화석처럼 남습니다.
- 추가된 로그는 `CurrentRawPos`, `HomePosition`, 그리고 그 차이(=현재 관절 각도의 카운트 표현)를 함께 찍어, 다음 부팅의 원점 계산이 맞는지 종료 시점에 검증할 수 있게 합니다.
- 실행 순서 주의: 루프는 `StopTasks()` → `usleep(2000000)`(2초) → `m_pcEcatMaster->DeInit()` **이후**에 돕니다. 즉 EtherCAT이 이미 내려간 뒤 마지막으로 캐시된 `m_pstAxisParams` 값을 기록합니다.
- 코드상 확인되는 위험 하나: `m_pcConfigRobot`의 NULL 검사는 이 루프 **뒤**에 있는 `if (NULL != m_pcConfigRobot)` 블록에서만 이루어지므로, 루프 내부의 `m_pcConfigRobot->WriteLastPosition(...)`은 널 가드 없이 역참조합니다. 원본에서는 루프가 주석이라 드러나지 않던 경로입니다.

**(b) `CRobot::InitRTTasks()` — 스택 크기 명시 + cfg 기반 CPU 핀**

| 항목 | 원본 | 병합본 | 의미 |
|---|---|---|---|
| `create_rt_task` 스택 인자 | `0` | `2*1024*1024` (2 MiB) | **aarch64 필수 픽스**(아래) |
| CPU 배치 | 없음 (RT-POSIX 기본 = CPU0) | `nCpu >= 0`이면 `set_cpu_affinity(&taskTemp, nCpu)` | 태스크별 코어 고정 가능 |
| 실패 처리 | — | `RET_SUCC` 아니면 `DBG_LOG_WARN`만 남기고 계속 진행 | 핀 실패해도 기동은 막지 않음(기본 코어로 동작) |

스택 2 MiB는 튜닝(프리폴트/mlock)이 아니라 **기동 가능 여부를 가르는 픽스**입니다. `create_rt_task(POSIX_TASK*, PCHAR, INT anStkSize, INT anPriority)`에 `0`을 주면 라이브러리 기본값 `DEFAULT_STKSIZE (65536)`(`/opt/rt_posix/include/posix_rt.h:22`)이 쓰이는데, **aarch64에서는 `PTHREAD_STACK_MIN`이 128 KiB라 64 KiB 요청이 `EINVAL`로 실패**합니다. 병합본 자신의 하네스 `tools/gate0_rtposix_test.c:86-88`이 같은 상수를 쓰며 이유를 주석으로 남겨 두었습니다("mirroring `CRobot::InitRTTasks`"). x86 환경에서 문제없던 코드가 KV260에서 깨지는 전형적 지점이므로, 다른 곳에서 `create_rt_task`를 호출한다면 함께 고쳐야 합니다.

`set_cpu_affinity(POSIX_TASK*, INT)`는 `/opt/rt_posix/include/posix_rt.h:98`에 선언된 외부 RT-POSIX API로, 저장소 안에 구현은 없고 호출부만 둘(`Robot.cpp:139`, `tools/gate0_rtposix_test.c:94`) 있습니다. 코드 주석은 RT-POSIX가 기본적으로 모든 태스크를 CPU0에 핀한다고 명시하며, `CPU=` 키는 그 기본값을 덮어쓰는 용도입니다. 배치는 `create_rt_task()` 직후·`set_task_period()` 이전, 즉 두 번째 루프의 **`start_task()`로 실행되기 전**에 이루어지므로 첫 사이클부터 지정 코어에서 돕니다.

### 4. `ConfigRobot.h` / `ConfigRobot.cpp` — 신규 설정 키 `CPU=`

이번 병합에서 **CRobot 계층에 추가된 유일한 새 cfg 키**입니다.

| 위치 | 변경 |
|---|---|
| `ConfigRobot.h` `stConfigTask` | `INT32 nCpu;` 필드 추가, 기본 생성자에서 `nCpu = -1` |
| `ConfigRobot.cpp` 태스크 파서 | `ZeroMemory(str)` → `GetPrivateProfileString(strKey, "CPU", "-1", ...)` → `stTask.nCpu = atoi(str)` |

- 위치는 `[TASKn]` 섹션 파싱, `START_DELAY` 바로 뒤 · `m_vstTaskList.push_back(stTask)` 직전입니다(`ConfigRobot.cpp:112-116`).
- 기본값 `-1`은 "키 없음 = 기존 동작 유지"를 뜻해 **하위 호환**이 보장됩니다. 실제로 `App/Indy7_ROS2/INDY7.cfg`, `App/Indy7_ROS2_Mujoco/INDY7.cfg`, `Config/8_axis_testbed.cfg`, `CRobot/ELMO.cfg`에는 `CPU` 키가 없어 종전과 동일하게 동작합니다.
- 실제 사용처는 `App/Indy7/INDY7.cfg` 하나로, **1 kHz 짝(TASK0 "Main Control Task" prio 97 / TASK1 "EtherCAT Control Task" prio 95, 둘 다 `TASK_PERIOD=1000000`)에만 `CPU=3`** 이 붙어 있습니다(45, 53행). cfg 주석은 커널 cmdline `isolcpus=3 nohz_full=3 rcu_nocbs=3 irqaffinity=0-2`와 짝을 이루며, "CPU 키를 지우거나 −1로 두면 기존 CPU0 핀으로 되돌아간다"고 되돌리는 방법까지 명시합니다. 나머지 태스크(Keyboard Input prio 50, Terminal Printer prio 49, Logger prio 30)에는 키가 없어 기본 코어에 남습니다 — 3+1 격리(비RT 3코어 + RT 1코어) 구도가 설정만으로 표현됩니다.
- 같은 cfg의 `[RT_TASKS]` 구성도 함께 바뀌었습니다(참고): 원본 TASK4 = "PI Controller Task" prio 89(비활성) → 병합본 TASK4 = "Logger" prio 30, 그리고 `NO_OF_TASKS=5`라 읽히지 않는 TASK5(Visual Servo, 비활성)가 뒤에 남아 있습니다.

### 5. `AxisCIA402.h` — `GetEcatSlave()` 접근자 노출

`SetTargetTorq()` / `SetTargetPos()` 바로 아래에 3라인이 추가됐습니다(`AxisCIA402.h:68-70`).

```c
/* [kv260-merge] expose the slave for master-level ops (DC reference clock) */
CSlaveCIA402&	GetEcatSlave		() { return m_cEcSlave; }
```

- 기존에는 `protected` 멤버 `m_cEcSlave`를 축 클래스가 제공하는 얇은 래퍼(`SetTargetTor` 등)로만 만질 수 있었습니다. 축 API로 감쌀 수 없는 **마스터 레벨 조작**을 위해 참조를 그대로 내보내는 것이 목적입니다.
- 유일한 소비자는 `App/Indy7/Indy7Ctrl.cpp:459`의 `m_pEcatAxis[0]->GetEcatSlave().SetAsDCRef()` 로, `nCnt == 0 && stSlaveInfo.bDCSupported` 조건 아래 **슬레이브 0을 DC(Distributed Clock) 기준 클록으로 고정**합니다. 실패 시 `DBG_LOG_WARN`만 남기고 진행합니다.
- 코드상 확인되는 범위: `DC_SUPPORT`는 `App/Indy7/INDY7.cfg`에서 축마다 주석 처리(`;DC_SUPPORT=1`), ROS2 계열 cfg에는 키 자체가 없어 파서 기본값 `"0"`(`ConfigRobot.cpp:202`)입니다. 따라서 `bDCSupported == FALSE`라 호출 자체가 일어나지 않아 **현행 동작에는 영향이 없고**, 축별로 DC를 켜는 순간 활성화되는 준비 코드입니다.

### 6. 통합 시 주의점

1. **`HOMING_METHOD=1`인 축의 원점은 이제 cfg 값에 종속**됩니다. `POS_BEFORE_EXIT`가 실제 자세와 어긋난 상태로 부팅하면 그 차이만큼 각도가 통째로 밀립니다(E24에서 손목 93° 오차 + 중력보상 폭주로 실증). 이 위험 때문에 **구동 cfg(`App/Indy7/INDY7.cfg`)는 전 축을 `=3`으로 돌려 두었으니, 다른 앱 cfg를 가져다 쓰거나 `=1`로 되돌릴 때는 반드시 저장/복원 한 쌍이 정상인지부터 확인**해야 합니다. 값 자체는 매 정상 종료 시 `DeInit()`이 갱신하므로, **비정상 종료(강제 kill/전원 차단)로 저장 루프를 건너뛰면 낡은 값이 남습니다.**
2. `DeInit()`이 cfg 파일을 쓰기 때문에 **INI가 더 이상 읽기 전용 산출물이 아닙니다.** 실제로 지금도 `App/Indy7/INDY7.cfg`가 실행할 때마다 dirty 상태가 되어 버전 관리에 잡음을 만듭니다(현재 저장소의 유일한 미커밋 변경).
3. `CPU=` 키는 커널 cmdline의 `isolcpus`와 짝일 때만 의도한 격리 효과가 납니다. 격리 없이 `CPU=3`만 주면 단순 코어 고정입니다. 그리고 CPU 키는 **구동 앱 cfg에만** 있으므로, 다른 앱을 돌릴 계획이면 그 cfg에도 추가해야 합니다.
4. `create_rt_task`의 스택 인자 `0`은 **aarch64에서 태스크 생성 실패(EINVAL)** 를 부릅니다. 이 저장소 밖 코드(예제·툴·다른 앱)를 병합할 때 `0`을 쓰는 호출이 있으면 함께 2 MiB로 올려야 합니다.
5. 6개 파일 어디에도 **토크 변환식·리미트 검사·상태 머신 전이 로직 변경은 없습니다.** 제어 게인/스케일 회귀를 의심할 때 이 계층은 후보에서 제외해도 됩니다.

---

## 15.6 설정 파일(`.cfg`) 변경점

### 0. 대상 파일과 변경 규모

| 파일 | 원본 | 병합본 | diff 규모 | 성격 |
|---|---|---|---|---|
| `App/Indy7/INDY7.cfg` | 319줄 | 348줄 | ±89줄 | **운영 정본** — 실기 구동에 실제로 쓰이는 설정. `; [kv260-merge]` 주석이 달린 유일한 cfg(7곳) |
| `App/Indy7_ROS2/INDY7.cfg` | 319줄 | 328줄 | ±55줄 | 값 갱신은 일부만 반영, 안전 픽스는 **미반영** |
| `App/Indy7_ROS2_Mujoco/INDY7.cfg` | 320줄 | 320줄 | −52/+52줄 (52줄 치환) | 시뮬 전용 설정이 하드웨어 설정으로 전환됨 |
| `Config/8_axis_testbed.cfg` | 364줄 | 364줄 | — | **완전 동일** (변경 없음) |
| `CRobot/ELMO.cfg` | 134줄 | 134줄 | — | **완전 동일** (변경 없음) |

**새로 추가된 "섹션"은 없습니다.** 새 섹션 헤더는 `App/Indy7/INDY7.cfg`의 `[TASK5]` 하나뿐인데, 이것도 `NO_OF_TASKS=5` 때문에 **파서가 읽지 않는 자리표시자**입니다(아래 1-2 참조). 새로 추가된 **키**는 `[TASKn] CPU=` 하나이고, 이것만이 파서 측 코드 변경을 동반합니다.

**config 서브시스템의 코드 변경은 정확히 두 곳, 총 9줄입니다.**

- `CRobot/ConfigRobot.h` +4줄 — `ST_CONFIG_TASK`에 `INT32 nCpu;`(:23-25) 선언 + 생성자 기본값 `nCpu = -1;`(:34)
- `CRobot/ConfigRobot.cpp` +5줄 — `ReadRTTaskConfig()` 안 `GetPrivateProfileString(..., "CPU", "-1", ...)`(:112-115)

`ConfigRobot.cpp`의 나머지(축·시스템 파싱, `WriteLastPosition`)는 **한 줄도 안 바뀌었습니다.** 즉 cfg diff가 이렇게 큰데도 파서는 사실상 그대로이고, 변경의 99%는 **값**입니다.

---

### 1. App/Indy7/INDY7.cfg (운영 정본)

#### 1-1. `[SYSTEM]`

| 키 | 원본 | 병합본 | 의미 |
|---|---|---|---|
| `URDF_PATH` | `/home/airlab2/indy-ros2/indy_description/urdf_files/indy7.urdf` | `/home/ubuntu/RAON-RT-Revision/App/Indy7/indy7.urdf` | 원본 경로는 **이 보드에 존재하지 않는 타 머신 경로**였음(원본 저장소 어디에도 그 파일이 없음). 병합본은 저장소 안에 새로 들어온 `indy7.urdf`(신규 파일, 16,558 B)를 가리킴. 이 값은 `ConfigRobot.cpp:399` → `m_stSystem.strURDFPath` → `Indy7Ctrl.cpp:86 InitController()` → `CControllerFullDynamicsRT` 생성자 → `FullDynControllerRT.cpp:157 LoadURDF()` 로 흘러 **RBDL 동역학 모델 로드에 직접 쓰임**. 즉 이 한 줄이 틀리면 신규 RT 컨트롤러 자체가 뜨지 않음 |
| `ENABLE_CONTROLLER_AT_STARTUP` | `1` | `0` (+ `; [kv260-merge] bring-up safety: controller enabled manually ('r' key), not at startup` 주석) | 기동 즉시 토크 컨트롤러가 붙지 않게 함. 소비 지점은 `Indy7Ctrl.cpp:294`(`bEnableControllerAtStartup` → `EnableController(TRUE)`)로 원본과 동일. 코드 쪽에서 이와 짝을 이루는 수정이 있음 — `Indy7Ctrl.cpp:1024-1031` 주석에 따르면 상류 코드는 태스크 시작 시 `IsEnabled()`를 **1회 스냅샷**해 두어서, 이 값이 0이면 런타임 `'r'` 키가 무력화됐음. 병합본은 `bUseRTController = (pRTController != NULL)`(가용성)만 스냅샷하고 활성 여부는 매 사이클 재조회로 바꿔 "기본 OFF + 수동 활성화"가 실제로 동작하게 만듦 |
| 그 외 (`SIMULATION_MODE=0`, `EXTERNAL_INTERFACE_*`, `TELEOPERATION_*`, `DEFAULT_CONTROLLER_MODE=0`, `ROBOT_DOF=6`, `KP_0..5`/`KD_0..5`) | — | **변경 없음** | `KP_n`/`KD_n`(800/80, 600/60, 400/40, 200/20, 150/15, 100/10)과 `ROBOT_DOF`는 원본에도 이미 있었고 값도 그대로. `ConfigRobot.cpp:417-431`에서 읽혀 `Indy7Ctrl.cpp:250-251` → `SetControlGains()`로 전달되는 소비 경로도 원본과 **동일**. **이번 병합에서 게인은 cfg·코드 어느 쪽에서도 바뀌지 않았습니다** |

#### 1-2. `[RT_TASKS]` / `[TASKn]` — 가장 구조적인 변경

`NO_OF_TASKS`는 **5 → 5로 그대로**입니다. 이 값은 바꿀 수 없는 값입니다: `CRobot/Robot.cpp:124`가 `m_vTaskFunctions.size() != nTotalRtTasks`이면 `InitRTTasks()`를 즉시 FALSE로 반환하는데, `App/Indy7/Indy7Ctrl.cpp:60-64`가 등록하는 함수는 정확히 5개(`proc_main_control`, `proc_ethercat_control`, `proc_keyboard_control`, `proc_terminal_output`, `proc_logger`)이기 때문입니다. ⚠️ **누가 `NO_OF_TASKS=6`으로 올리면 `[TASK5]`가 파싱되면서 태스크 수 6 ≠ 함수 수 5가 되어 로봇 초기화가 통째로 실패합니다.**

| 섹션 | 키 | 원본 | 병합본 | 의미 |
|---|---|---|---|---|
| `[RT_TASKS]` | (섹션 헤더 위 주석) | 없음 | `; [kv260-merge] 5 tasks: Visual Servo task removed (TASK5 section below is unread)` | `NO_OF_TASKS` 값은 5로 불변, 의도만 문서화 |
| `[TASK0]` Main Control Task | `CPU` | (키 없음) | **`3` (신규 키)** | D10 3+1 격리. `ConfigRobot.cpp:114`가 기본값 `-1`로 읽고, `Robot.cpp:137-148`에서 `nCpu >= 0`일 때만 `set_cpu_affinity()` 호출 → 실패 시 경고만 남기고 RT-POSIX 기본 CPU0에 머무름. cfg 주석에 커널 cmdline(`isolcpus=3 nohz_full=3 rcu_nocbs=3 irqaffinity=0-2`)과 되돌리는 법(키 삭제 또는 `-1`)까지 명시 |
| `[TASK1]` EtherCAT Control Task | `CPU` | (키 없음) | **`3` (신규 키)** | TASK0(97)/TASK1(95)의 1 kHz(`TASK_PERIOD=1000000`) 페어를 같은 격리 코어에 묶음. 나머지 태스크는 `CPU` 키가 없어 CPU0에 남음 = 의도적 3+1 분리 |
| `[TASK2]` Keyboard Input Task, `[TASK3]` Terminal Printer | 전부 | 전부 | **변경 없음** (우선순위 50/49, 주기 0 / 1 s) | |
| `[TASK4]` | `ENABLED` | `0` | **`1`** | 슬롯 4에 바인딩된 함수는 원본·병합본 모두 `proc_logger`였는데(원본 `Indy7Ctrl.cpp:59`), 원본 cfg는 이 슬롯을 `PI Controller Task`로 **잘못 이름 붙이고 비활성화**해 두어 로거가 한 번도 뜨지 않았음 |
| `[TASK4]` | `NAME` | `PI Controller Task` | **`Logger`** | 이름을 실제 바인딩 함수와 일치시킴 (cfg의 NAME은 `create_rt_task()`의 스레드 이름으로만 쓰임 → 로그/`ps` 가독성) |
| `[TASK4]` | `PRIORITY` | `89` | **`30`** | 로거가 1 kHz 제어 루프(97/95)는 물론 터미널(49)보다도 뒤로 밀림 = RT 경로 방해 최소화 |
| `[TASK4]` | `TASK_PERIOD` | `10000000` (10 ms) | **`0`** | `Robot.cpp:150`이 `nPeriod != 0`일 때만 `set_task_period()`를 걸므로, 0은 **주기 웨이크업 없이 자기 페이스로 도는 태스크**를 뜻함. 실제 `proc_logger`(`Indy7Ctrl.cpp:1658-1727`)는 `m_bLogTrigger` 폴링(`usleep(10000)`) → 링버퍼 flush → `sleep(24)` 수집 → CSV(`timestamp_ns,q0..5,q_ref0..5,qd0..5,tau0..5,tcp_xyz,tcp_rpy,goal_xyz,goal_rpy,ctrl_mode`) 저장 구조라 주기 스케줄이 무의미 |
| `[TASK5]` | (섹션 전체 신설) | 없음 | `ENABLED=0` / `NAME=Visual Servo Task (removed on kv260-merge)` / `PRIORITY=20` / `TASK_PERIOD=0` / `START_DELAY=0` | **`NO_OF_TASKS=5`이므로 `ConfigRobot::ReadRTTaskConfig()`의 `for (nCnt < nNoOfTasks)` 루프(`ConfigRobot.cpp:80-84`)가 TASK0~TASK4까지만 읽고 이 섹션은 파싱되지 않음.** 값이 아니라 "여기에 비주얼 서보 태스크가 있었고 제거했다"는 이력 기록용 |

**같은 태스크 생성 경로의 동반 변경(cfg 아님, 참고)**: `Robot.cpp:132`의 `create_rt_task()` 스택 인자가 `0` → `2*1024*1024`(2 MB)로 바뀌었습니다. `CPU=` 픽스와 같은 커밋 라인에 있으므로 RT 태스크 생성 동작을 볼 때 함께 봐야 합니다.

#### 1-3. `[ECAT_MASTER]` 및 DC 관련

`[ECAT_MASTER]`(`SLAVENUMBER=7`, `DC_ENABLED=1`, `CYCLE_TIME=1000000`)는 **완전 무변경**(원본 74-77행 ≡ 병합본 89-92행). 대신 `[AXIS0]`에 슬레이브측 DC 키 3종이 **주석 상태의 템플릿**으로 추가됨:

```
;DC_SUPPORT=1
;DC_ACTIVATE_WORD=0x300
;DC_SYNC0_SHIFT=0
```

세 키 모두 `ConfigRobot.cpp:202/206/217`에서 기본값 0으로 읽히므로 주석 상태에서는 **SM-sync 동작(현행 검증된 설정)**이 유지됩니다. 주석은 "실험 시 모든 구동축에 풀어야 하고, 그 순간 slave 0이 DC 기준 클럭이 된다"고 명시하는데, 이는 코드 쪽 신규 로직(`Indy7Ctrl.cpp:457-463`: `nCnt == 0 && stSlaveInfo.bDCSupported`일 때만 `GetEcatSlave().SetAsDCRef()` 호출)과 정확히 대응합니다. 즉 **cfg는 스위치, 코드는 그 스위치가 켜졌을 때의 동작을 이미 갖춰 둔 상태**입니다.

#### 1-4. `[AXIS0]`~`[AXIS5]` — 안전·영점 관련

**(a) `AUTO_SERVO_ON`: 전 축 0으로 통일**

| 축 | 원본 | 병합본 |
|---|---|---|
| AXIS0 | `0` (`AUTO_SERVO_ON= 0`, 공백 포함) | `0` (공백 제거) |
| AXIS1~AXIS5 | `1` | **`0`** |

`AxisCIA402.cpp:109-115`에서 `IsAutoServoOn()`이 TRUE면 `Init()` 시점에 곧바로 `ServoOn(driveMode)`를 호출합니다. 즉 원본은 **EtherCAT 초기화만으로 5축 브레이크가 풀리는** 설정이었습니다. 병합본은 전부 0으로 내려 `SetDriveMode()`만 하고 서보는 끈 채 두며, 대신 `App/Indy7/Indy7Ctrl.cpp:530-548`에 새로 생긴 `'h'`(전축 `ServoOn(CIA402_CYCLIC_TORQUE)`) / `'j'`(전축 `ServoOff()`) 키로 사람이 켭니다. `'h'`는 심지어 **컨트롤러가 켜져 있고 모드가 중력보상일 때만** 통과시킵니다(`m_bRTControllerEnabled` + `eGravityCompensation` 게이트, 거부 시 `[ARM] refused — press 'r' … then 'g' …` 출력). 결국 `ENABLE_CONTROLLER_AT_STARTUP=0`과 `AUTO_SERVO_ON=0`은 "전원 인가 = 로봇 움직임"을 끊는 한 쌍의 변경입니다. 덧붙여 같은 커밋에서 `'o'`(LED_OFF) case의 fall-through를 막았는데(`break; // was falling through into 'h'`), 이게 없으면 LED 끄기가 서보 온으로 흘러 들어갑니다.

**(b) `HOMING_METHOD`: AXIS4/AXIS5만 `1 → 3` (가장 위험했던 항목)**

`CRobot/Axis.h:16-20`의 열거형: `eAxisHomingNotSet=0, eAxisHomeStartPos=1, eAxisHomeSearch=2, eAxisHomeManual=3, eAxisHomeBuiltin=4`.

| 축 | 원본 | 병합본 | 코드상 의미 |
|---|---|---|---|
| AXIS0~3 | `3` | `3` (불변) | `eAxisHomeManual` — `Indy7Ctrl.cpp:425-426`에서 `SetHomePosition(stSlaveInfo.nHomePositionOffset)` 즉 **파일에 박힌 고정 기준** |
| AXIS4 | `1` | **`3`** | `1` = `eAxisHomeStartPos` → `AxisNRMKCore.cpp:71-75`가 `SetHomePosition(nStartPos - GetPositionBeforeExit())`. cfg 주석이 지적하듯 **기동 시 이 축이 보고하는 각도가 팔의 실제 자세가 아니라 파일 속 `POS_BEFORE_EXIT` 숫자에서 디코드**됨 |
| AXIS5 | `1` | **`3`** | 동일 (`; same file-borne zero as AXIS4`) |

cfg 주석에 사고 경위가 그대로 기록돼 있습니다: 접힌 자세로 종료 → 편 자세로 재시작하면 중력보상이 **93° 틀린 손목 각도**를 받고 손목을 능동 구동해버림(2026-07-27 22:47). 이 변경은 두 손목 축의 영점을 "직전 종료 자세에 의존하는 상대 기준"에서 "AXIS0~3과 동일한 절대 고정 기준"으로 되돌린 것입니다. **`.cfg` 3개 중 이 픽스가 적용된 파일은 `App/Indy7`뿐입니다.**

**(c) `HOME_POSITION_OFFSET`: 6축 전면 재취득 (실기 엔코더 원시 카운트)**

| 축 | 원본 | 병합본 | 배율 |
|---|---|---|---|
| AXIS0 | `50080` | `15755196` | ×314 |
| AXIS1 | `5699` | `28218` | ×5 |
| AXIS2 | `41470` | `15841818` | ×382 |
| AXIS3 | `-21035` | `-20393022` | ×969 |
| AXIS4 | `-6619836` | `33130756` | 부호 반전 |
| AXIS5 | `-1021383` | `-6573591` | ×6.4 |

원본 값들은 대부분 단일 회전 범위(≲ `ENCODER_RESOLUTION=65536`) 안의 숫자인 반면 병합본은 10⁷ 규모의 **다회전 누적 원시 카운트**입니다. `HOMING_METHOD=3` 축에서 이 값은 `SetHomePosition()`으로 직결되므로, **이 여섯 줄이 로봇의 관절 0점을 통째로 정의**합니다. AXIS4/5는 `HOMING_METHOD=1→3` 전환과 함께 새 값이 들어왔으므로, 원본 값과 병합본 값은 애초에 의미가 다른 숫자입니다(전자는 사실상 쓰이지 않던 값).

**재취득 방법의 흔적**: `App/Indy7_ROS2/INDY7.cfg` 병합본에서는 6축 전부 `POS_BEFORE_EXIT ≈ HOME_POSITION_OFFSET`입니다(AXIS0 `15755198` vs `15755196`, AXIS5는 `-6573591`로 완전 일치). 즉 **팔을 원하는 영점 자세에 두고 정상 종료 → 자동 기록된 `POS_BEFORE_EXIT`를 그대로 `HOME_POSITION_OFFSET`에 복사**하는 절차로 새 영점을 잡았음을 강하게 시사합니다. `App/Indy7` 쪽은 그 뒤로도 계속 운용되어 두 값이 벌어져 있습니다.

**(d) `POS_BEFORE_EXIT`: 런타임 자동 갱신 — 그리고 이 병합에서 **되살아난** 기능**

| 축 | 원본 | 병합본 |
|---|---|---|
| AXIS0 | `46888` | `23108487` |
| AXIS1 | `29197` | `582262` |
| AXIS2 | `63103` | `13178747` |
| AXIS3 | `-29781` | `-7122453` |
| AXIS4 | `26943` | `45762761` |
| AXIS5 | `-2457587` | `-542153` |

**⚠️ 여기가 동료 정리에서 가장 중요한 정정 지점입니다.** 이 키를 프로그램이 스스로 덮어쓰는 것은 **병합본에서만 참**입니다.

- **원본** `CRobot/Robot.cpp:86-89`: `DeInit()`의 write-back 루프가 **통째로 `//` 주석 처리되어 죽어 있었음.** 즉 원본에서 `POS_BEFORE_EXIT`는 아무도 갱신하지 않는 **얼어붙은 상수**였습니다.
- **병합본** `CRobot/Robot.cpp:87-94`: 루프가 되살아나 `GetCurrentRawPos()` → `m_pcConfigRobot->WriteLastPosition(nCnt, nRawPos)` → `ConfigRobot.cpp:474` `WritePrivateProfileString(..., "POS_BEFORE_EXIT", ...)`로 매 종료 시 파일에 되씁니다(로그도 함께 남김).

따라서 이 여섯 줄의 diff는 "설계 의도가 아닌 실행 스냅샷"이면서 동시에 **되살아난 기능의 증거**이기도 합니다. 그리고 이 재활성화가 **E24 사고의 숨은 촉매**입니다: 원본에서는 `HOMING_METHOD=1`이어도 감산 항이 고정 상수라 최소한 재현 가능했지만, write-back이 살아난 순간 그 항이 "직전 종료 자세"라는 **움직이는 표적**이 되어 매 기동마다 영점이 달라졌습니다. `=3` 전환은 이 결합을 끊은 것입니다. 리뷰·머지 시 `HOMING_METHOD=3`인 축에서는 이 줄의 충돌을 무시해도 되지만, `=1`이 남은 축(ROS2/Mujoco의 AXIS4/5)에서는 결코 무해하지 않습니다.

**(e) 무해한 정리 항목**

| 키 | 원본 | 병합본 | 의미 |
|---|---|---|---|
| `PHYSICAL_POS` (AXIS1/2/4/5) | 전부 `0` | `1`/`2`/`4`/`5` | **동작에는 영향 없음** — `ConfigRobot.cpp:177`이 `stSlave.nPhyPos`에 담기만 하고, 저장소 전체에서 `nPhyPos`를 **소비하는 코드가 전혀 없음**(등장 5곳 전부: `ConfigRobot.h:59`/`:174` 선언, `:115`/`:190` 0 초기화, `ConfigRobot.cpp:177` 대입). `[AXIS6]`는 원본부터 `PHYSICAL_POS=6`이었으므로 그 관례에 맞춘 문서적 정합성 정리 |
| `PHYSICAL_POS` (AXIS3) | **키 자체가 없음** | `3` 추가 | 원본은 이 축만 키가 누락돼 기본값 0으로 읽혔음 |
| `TRANSMISSION_RATIO` (AXIS1) | `1.` | `1.0` | `atof("1.")`도 1.0이므로 **순수 표기 통일** |
| `AUTO_SERVO_ON` (AXIS0) | `AUTO_SERVO_ON= 0` | `AUTO_SERVO_ON=0` | 공백 제거(표기) |
| `GEAR_RATIO`, `ENCODER_RESOLUTION`, `TORQUE_CONSTANT`, `CURRENT_RATIO`, `ONE_TURN_REF`, `DRIVE_MODE`, `POSITION/VELOCITY/ACCELERATION/TORQUE/JERK_LIMIT_*`, `OPERATING_*`, `MOVE_CCW`, `ABSOLUTE_ENCODER`, `HOME_SEARCH_REFERENCE` | — | **전부 무변경** | 기어비 121(전축), 토크상수 0.0884/0.0884/0.0884/0.058/0.058/0.058 등 기구 파라미터는 그대로. 이번 병합은 **기구 상수는 건드리지 않고 영점·안전·스케줄링만 손봄** |

#### 1-5. `[AXIS6]` (EOAT, 엔드툴 슬레이브)

`NAME=EOAT`, `PHYSICAL_POS=6`, `SLAVE_TYPE=1`, `PRODUCT_CODE=0x10000007`인 센서/툴 슬레이브 섹션은 **세 파일 모두에서 바이트 단위로 완전 동일**합니다.

---

### 2. App/Indy7_ROS2/INDY7.cfg (319 → 328줄)

| 섹션 | 키 | 원본 | 병합본 | 의미 |
|---|---|---|---|---|
| `[SYSTEM]` | `URDF_PATH` | `/home/airlab2/...` | `/home/raimlab/RAON-RT/App/Indy7/indy7_v2.urdf` | **이 보드(`/home/ubuntu`)에는 없는 경로**. 파일 자체(`indy7_v2.urdf`, 15,413 B)는 병합본 저장소에 신규로 들어와 있으나 cfg가 가리키는 절대경로가 틀림. 게다가 `indy7_v2.urdf`는 `App/Indy7`이 쓰는 `indy7.urdf`와 **링크 질량·관성이 전부 다른 모델**(link5 `2.32413397` vs `2.22412271`, link2 `6.11383823` vs `5.84766553`, link6 `0.39652271` vs `0.38254932`). 결정적으로 **`tcp` 링크가 `indy7.urdf`에는 질량 0.285의 실체 링크인데 `indy7_v2.urdf`에는 빈 링크(`<link name="tcp"/>`)** → 중력보상 토크가 달라짐 |
| `[SYSTEM]` | `ENABLE_CONTROLLER_AT_STARTUP` | `1` | `1` (불변) | `App/Indy7`의 안전 픽스가 **여기엔 반영 안 됨** |
| `[TASK4]` | `ENABLED`/`NAME`/`PRIORITY`/`TASK_PERIOD` | `0` / `PI Controller Task` / `89` / `10000000` | `1` / `Logger` / `30` / `0` | `App/Indy7`과 동일한 로거 정상화 |
| `[TASK5]` | (신설) | 없음 | **전체가 `;`로 주석 처리된 `PI Controller Task` 블록**(`;[TASK5]` … `;START_DELAY=0`) | `App/Indy7`이 섹션을 살려두고 `NO_OF_TASKS`로 무력화한 것과 달리, 여기선 아예 주석 처리. 결과는 같음(파싱 안 됨) |
| `[TASKn]` | `CPU` | 없음 | **없음** | **CPU 격리는 `App/Indy7`에만 적용됨** |
| `[AXIS0]` | `AUTO_SERVO_ON` | `0` | **`1`** | `App/Indy7`과 **정반대 방향**. 이 파일은 6축 전부 `AUTO_SERVO_ON=1` = 초기화 즉시 서보 온 |
| `[AXIS0..5]` | `HOME_POSITION_OFFSET` | 구 값 | `App/Indy7` 병합본과 **동일한 신규 값** (`15755196`, `28218`, `15841818`, `-20393022`, `33130756`, `-6573591`) | 재취득한 영점은 공유됨 |
| `[AXIS4]`, `[AXIS5]` | `HOMING_METHOD` | `1` | **`1` (그대로)** | **E24 사고의 원인이 된 설정이 그대로 남아 있음.** 게다가 `Robot.cpp` write-back이 되살아났으므로(1-4(d)) 이 앱을 실기에 붙이면 매 종료마다 감산 항이 갱신되어 위험도가 원본보다 **높아졌습니다** |
| `[AXIS0..5]` | `POS_BEFORE_EXIT` | 구 값 | `15755198`, `28194`, `15841836`, `-20393020`, `33130760`, `-6573591` | 런타임 자동 갱신 값. 6축 모두 `HOME_POSITION_OFFSET`과 거의 동일 → 영점 취득 직후의 스냅샷(1-4(c) 참조) |
| `[AXIS1/2/4/5]` | `PHYSICAL_POS` | `0` | `1`/`2`/`4`/`5` | 무해한 정리 (AXIS3은 키 신규 추가) |
| `[AXIS1]` | `TRANSMISSION_RATIO` | `1.` | `1.0` | 표기 통일 |
| `[AXIS6]` | — | — | 무변경 | |

---

### 3. App/Indy7_ROS2_Mujoco/INDY7.cfg (320 → 320줄, 52줄 치환)

이 파일의 변경은 성격이 완전히 다릅니다. **시뮬레이터 설정을 실기 설정으로 갈아끼운 것**입니다.

| 섹션 | 키 | 원본 | 병합본 | 의미 |
|---|---|---|---|---|
| `[SYSTEM]` | `SIMULATION_MODE` | **`1`** | **`0`** | `App/Indy7_ROS2_Mujoco/main.cpp:62`가 `GetSystemConf().bSim`을 읽어 `:78`의 `Init(bSimMode)`로 넘기고, `App/Indy7_ROS2_Mujoco/Indy7Ctrl.cpp:127`이 `m_bSimulationMode`에 저장 → `:141`에서 `"Initializing in HARDWARE mode"` 로그, `:173/:363/:698/:1046` 등의 MuJoCo 분기가 전부 비활성. 즉 **MuJoCo 앱이 실제 EtherCAT 하드웨어 경로로 도는 설정** |
| `[SYSTEM]` | `URDF_PATH` | `models/indy7.urdf` (상대경로) | `/home/raimlab/RAON-RT/App/Indy7/indy7.urdf` | ⚠️ **개선이 아니라 회귀**: 원본이 가리키던 `App/Indy7_ROS2_Mujoco/models/indy7.urdf`는 양쪽 저장소에 **실존**하는 파일(14,244 B, 두 저장소 동일)이라 앱 디렉터리에서 실행하면 열렸습니다. 병합본이 바꾼 절대경로의 `/home/raimlab`은 이 보드에 없으므로 **원본은 열리던 것이 병합본에서 못 열립니다** |
| `[SYSTEM]` | `MOJUCO_XML_PATH` | `models/indy7.xml` | **키 삭제** | 파서(`ConfigRobot.cpp:406`)는 이 키를 여전히 읽으며 기본값 `TEST.xml`로 폴백. 키를 지운 것은 시뮬 경로를 쓰지 않겠다는 의사표시 |
| `[TASK3]` | `ENABLED` | `0` | **`1`** | Terminal Printer(우선순위 49, 1 s 주기) 활성화 |
| `[TASK4]` | — | — | **무변경** (`PI Controller Task`, `ENABLED=0`, `PRIORITY=89`, `TASK_PERIOD=10000000`) | 다른 두 파일과 달리 **로거가 여전히 죽어 있음** (바인딩 함수는 여기서도 `proc_logger`, `Indy7Ctrl.cpp:72`) |
| `[AXIS0]` | `AUTO_SERVO_ON` | `0` | **`1`** | 6축 전부 auto servo-on |
| `[AXIS0..5]` | `ACCELERATION_LIMIT_U` | `1000.0` | **`10000`** | 아래 (a) 참조 |
| `[AXIS0..5]` | `ACCELERATION_LIMIT_L` | `-1000.0` | **`0`** | |
| `[AXIS0..5]` | `DECELERATION_LIMIT_U` | `1000.0` | **`10000`** | |
| `[AXIS0..5]` | `DECELERATION_LIMIT_L` | `-1000.0` | **`0`** | |
| `[AXIS0..5]` | `TORQUE_LIMIT_L` | AXIS0·1 `-117.730`, AXIS2 `-47.50`, AXIS3~5 `-21.00` | **전부 `0`** | `TORQUE_LIMIT_U`(117.73 / 117.73 / 47.5 / 21.0 / 21.0 / 21.0)는 무변경 |
| `[AXIS0..5]` | `JERK_LIMIT_U` / `_L` | `100.0` / `-100.0` | **`0`** / **`0`** | |
| `[AXIS1/2/4/5]` | `PHYSICAL_POS` | `0` | `1`/`2`/`4`/`5` (AXIS3은 키 추가) | 무해한 정리 |
| `[AXIS1]` | `TRANSMISSION_RATIO` | `1.` | `1.0` | 표기 통일 |
| `[AXIS0..5]` | `HOME_POSITION_OFFSET`, `POS_BEFORE_EXIT` | 구 값 | **무변경** (`50080`/`46888`, `5699`/`29197`, `41470`/`63103`, `-21035`/`-29781`, `-6619836`/`26943`, `-1021383`/`-2457587`) | 재취득 영점이 **반영되지 않음** |
| `[AXIS4/5]` | `HOMING_METHOD` | `1` | **`1` (그대로)** | E24 픽스 미반영 |
| `[AXIS6]` | — | — | 무변경 | |

**(a) 한계값 치환의 정체**: 병합본 값(`ACCELERATION_LIMIT_U=10000`, `_L=0`, `DECELERATION_LIMIT_U=10000`, `_L=0`, `TORQUE_LIMIT_L=0`, `JERK_LIMIT_U/_L=0`)은 **원본** `App/Indy7/INDY7.cfg`의 AXIS0 한계 블록과 `diff` 기준 **완전 일치**합니다(직접 대조 확인). 즉 새로 계산한 한계가 아니라 **실기 cfg의 한계 프로파일을 그대로 복사해 온 것**입니다. 시뮬 전용이던 대칭 음수 한계(`-1000.0`/`-117.730`/`-100.0`)가 사라진 것이 이 변경의 실체이고, `SIMULATION_MODE=0`과 세트로 "이 파일도 실기용"이라는 선언입니다.

---

### 4. 런타임 자동 갱신 키 정리

| 키 | 갱신 주체 | 근거 | 원본과의 차이 |
|---|---|---|---|
| `[AXISn] POS_BEFORE_EXIT` | **프로그램이 종료 시 자동 기록** | `CRobot/Robot.cpp:87-94` `DeInit()` → `CConfigRobot::WriteLastPosition()`(`ConfigRobot.h:281`) → `ConfigRobot.cpp:468-474` `WritePrivateProfileString()` | **원본에서는 이 루프가 주석 처리되어 있었음**(`RAON-RT/CRobot/Robot.cpp:86-89`). 병합본이 재활성화 |
| 그 외 전 키 | 사람이 편집 | 저장소 전체에서 `WritePrivateProfileString` 호출은 `ConfigRobot.cpp:474` 한 곳뿐 | — |

세 파일에서 관찰된 `POS_BEFORE_EXIT` diff는 **설계 변경이 아니라 실행 이력**이지만, 그 "이력이 남는 기능 자체"가 이번 병합에서 새로 켜졌다는 점을 함께 봐야 합니다. `HOMING_METHOD=1`인 축(ROS2/Mujoco의 AXIS4/5)에서는 이 값이 영점 계산에 직접 들어가므로 무해하지 않으며, write-back 재활성화로 **원본보다 더 불안정해졌습니다**.

### 5. 세 파일 간 비일관성 (통합 시 주의)

| 항목 | App/Indy7 | Indy7_ROS2 | Indy7_ROS2_Mujoco |
|---|---|---|---|
| `; [kv260-merge]` 주석 | **7곳** | 0 | 0 |
| `[TASKn] CPU=3` (D10 격리) | **적용** (TASK0/TASK1) | 없음 | 없음 |
| `ENABLE_CONTROLLER_AT_STARTUP` | **0 (안전)** | 1 | 1 |
| `AUTO_SERVO_ON` (전축) | **0 (안전)** | 1 | 1 |
| AXIS4/5 `HOMING_METHOD` | **3 (E24 픽스)** | **1 (미적용)** | **1 (미적용)** |
| 재취득 `HOME_POSITION_OFFSET` | 적용 | 적용 | **미적용(구 값)** |
| `TASK4` 로거 | 활성 (`Logger`/30/0) | 활성 (`Logger`/30/0) | **비활성 (`PI Controller Task`/89/10 ms)** |
| `SIMULATION_MODE` | 0 | 0 | **1 → 0 (전환됨)** |
| `URDF_PATH` 실존 여부 | **이 보드에 존재** | `/home/raimlab/...` 부재 | `/home/raimlab/...` 부재 (원본 상대경로는 **실존했음**) |
| `URDF` 모델 | `indy7.urdf` (tcp 질량 0.285) | `indy7_v2.urdf` (질량/관성 상이, tcp 빈 링크) | `indy7.urdf` |
| DC 템플릿 주석 | 있음 | 없음 | 없음 |

`App/Indy7/INDY7.cfg`만이 kv260 병합 작업의 결과를 온전히 담고 있고, 나머지 둘은 값 일부만 따라온 상태입니다. 특히 **AXIS4/5의 `HOMING_METHOD=1`이 두 파일에 남아 있다는 점**은, 그 앱들을 실기에 붙이면 E24와 동일한 손목 폭주 조건이 재현될 수 있다는 뜻입니다(코드상 `AxisNRMKCore.cpp:71-75` 경로가 세 앱 공통인 `CRobot/`에 있으므로 동일). 그리고 `AUTO_SERVO_ON=1`이 함께 남아 있어 **사람의 키 입력 없이 초기화만으로 그 조건에 도달**합니다.

---

## 15.7 제어기 (`FullDynControllerRT`) 변경점 — 최대 증축

원본 `FullDynControllerRT`는 **RBDL 기반 순수 관절공간 토크 제어기**였습니다. 헤더 142줄 / 소스 537줄에 담긴 것은 중력보상·완전동역학·계산토크 3종 토크식과 RT 성능 카운터가 전부였고, **역기구학·FK·TCP·궤적 생성 코드는 단 한 줄도 없었습니다**(원본 `.cpp`에서 `InverseKinematics`, `Jacobian`, `body_id` 문자열 검색 결과 0건). 병합본은 여기에 **작업공간(Task-space) 계층 전체**를 얹어 헤더 461줄(+319), 소스 2058줄(+1521)이 되었습니다.

변경은 성격이 뚜렷하게 두 갈래입니다.

1. **`// jieun` 계열** — TCP FK, Pose 구조체, RBDL 6DOF IK, 자코비안 DLS IK, ISO 큐브 검증, CSV 로깅. 소스 말미에 `//trash code! spaghetti code!!` 주석과 함께 격리되어 있고, 일부는 `// Lagacy function`으로 명시됨.
2. **`// [kv260-merge]` 계열** — ready-seed 결정론적 IK, 브랜치 판정, 2π 폴딩, tilt 게이트, sticky-float 홀드, IkDiag 진단 구조체. 주석에 E13/E17/E23/E25/E26/E27/E28 같은 **현장 사고 번호와 실측 수치**가 근거로 박혀 있습니다.

---

### 1. 제어 모드 enum — 2개 추가

| | 원본 | 병합본 |
|---|---|---|
| enum 전체 | `eGravityCompensation = 0`<br>`eFullDynamics`<br>`eComputedTorque`<br>`eAdaptiveControl` | `eGravityCompensation = 0`<br>`eFullDynamics`<br>`eComputedTorque`<br>`eAdaptiveControl`<br>**`eInverseKinematics`** — `'i'` : Jacobian-based IK<br>**`eInverseKinematics_6dof`** — `'m'` : RBDL IK (position + orientation) + CTC |

`Update()`의 `switch`에도 두 case가 추가되었습니다.

```
case eInverseKinematics:       result = ComputeJacobianBasedInverseKinematics(avOutputTorque); break;
case eInverseKinematics_6dof:  UpdateTrajectory(); result = ComputeComputedTorque(avOutputTorque); break;
```

의미: `eInverseKinematics_6dof`는 **자체 토크식이 없습니다**. 매 사이클 `UpdateTrajectory()`로 5차 다항식 레퍼런스(`m_Q_ref/m_Qd_ref/m_Qdd_ref`)만 굴리고, 실제 토크는 기존 CTC가 계산합니다. 즉 IK는 "목표 관절벡터를 만드는 단계"로 분리되고 **저수준 토크 경로는 원본 그대로 재사용**됩니다 — 이게 이 증축이 원본 제어 안정성을 건드리지 않은 이유입니다. (참고: `eAdaptiveControl`은 원본에서도 `switch`에 case가 없었고 병합본에서도 없습니다 — 선언만 존재.)

`Update()`에는 그 밖에 두 줄이 더 들어갔습니다.

- `SetTcpReferencePose();` — 모드 무관하게 매 사이클 호출, `m_bSetRefPoseTrigger`가 서면 현재 FK를 `goal_tcpPose`로 스냅샷.
- `if (m_eControlMode != eGravityCompensation) m_bHoldAnchored = false;` — sticky-float 앵커를 중력보상 모드 밖에서 무효화.

---

### 2. ready-seed 결정론적 IK (`[kv260-merge]` 핵심 블록)

RBDL IK는 **로컬 반복 해법**이라 브랜치 선택 입력이 시드뿐입니다. 원래처럼 라이브 자세(`m_Q`)를 시드로 쓰면 "팔을 어디 세워뒀는지"에 따라 성공/실패가 갈립니다. 병합본은 **고정 시드 `m_QReady` 하나**를 두고 모든 접근을 거기서 풉니다.

| 요소 | 위치 | 하는 일 |
|---|---|---|
| `m_QReady`, `m_EReady`, `m_bReadySet` | private 멤버 | 기준 자세 관절벡터 + 그 자세의 base→body FK 회전 |
| `ComputeReadySeed(probes, center, anchorSeed)` | cpp:823 | init 시 1회(비RT). **v3에서 합성 시드 사다리 완전 제거** — `apAnchorSeed == NULL`이면 `WARN` 후 `FALSE` 리턴하고 라이브 시드로 폴백. 이후 전체 probe를 인라인 검증해 `nPass/총개수` 로깅 |
| `SetReadyAnchor(q)` | cpp:903 | 운영자가 기록한 HOME 자세로 앵커 재베이스. `CheckLimitsPhysical`로 정규화 후 감긴 턴 수를 `J%d ... wound %+d turn(s)`로 로깅, 그리고 `m_nAnchorVerifyIdx = 0`으로 분할 검증 시작 |
| `TickAnchorVerify()` | cpp:946 | **RT 루프에서 사이클당 probe 1개씩만** 재검증. 주석에 "a 9-solve burst would stall the 1 kHz task"라고 이유가 명시됨 |
| `SolveReadyIK(target, qSol, posErr, dqMaxFromCur, dqAxis)` | cpp:1034 | 순수 해석 — 모션 없음. 시드 = `m_QReady`, soft-R 목표 = `m_EReady` |
| `HasReadySeed()`, `GetReadyQ()` | 헤더 인라인 | 앱 측 direct/staged 분기 판단용 |

**시드 자체의 성격 변화**가 코드 주석에 남아 있습니다: `ComputeReadySeed`는 "ANCHOR-ONLY (v3) ... The synthetic seed ladder was removed after producing two contorted postures"라고 적혀 있고, 헤더 `SetReadyAnchor` 주석에는 실패 사례가 수치로 남았습니다 — `J4 2.61 wrist fold`, `J2 -2.80 elbow fold`. 즉 **"운동학적으로 유효 = 자세가 멀쩡"이 아니라는 결론**이 코드 구조로 굳어진 것입니다.

#### 2-1. weight ladder + warm start (E25)

```c
static const double adLadder[] = { IK_ORI_WEIGHT, 0.1, 0.03, 0.01 };
...
RigidBodyDynamics::Math::VectorNd vqSeed = m_QReady;
for (int i = 0; i < nLadder; i++) {
    if (SolvePositionIK(vqSeed, avTarget, adLadder[i], &m_EReady, aqSol, adPosErrM, IK_SOLVE_STEPS) &&
        ReadyBranchGap(aqSol, nBranchAxis) <= IK_DQ_MAX_RAD)
    { dWUsed = adLadder[i]; break; }
    vqSeed = aqSol;             // stalled iterate seeds the next rung
}
```

- 자세 가중치를 **0.3 → 0.1 → 0.03 → 0.01로 계단 하강**. 주석 근거: E23은 `IK_ORI_WEIGHT` 다음 바로 0으로 떨어뜨려서 "banana at 0.877 m 은 87 deg에서 거부, 더 먼 mustard 0.912 m 는 36 deg로 통과"하는 모순이 났음.
- **각 단이 통과하려면 위치 2 mm 이내 + `ReadyBranchGap ≤ 2.0 rad`를 동시에** 만족해야 합니다. 위치만으로는 부족하다는 것이 E27의 결론.
- 실패한 단의 정지 반복점을 다음 단 시드로 물려주는 warm start. 주석에 "the surviving half of the 32 ms attack"이라고 명시 — 뉴턴 예산 축소(다른 절반)는 폐기됨.

#### 2-2. 바닥 단 + E25 polish + E28 가드

가중치 없이(`w = 0`) 위치만 푸는 마지막 단은 `anMaxSteps`를 넘기지 않아 **기본값 1000**("full Newton budget")으로 돕니다. 여기서 실패하면 `eIkNoSolution`, 브랜치 갭 초과면 `eIkBranch`.

통과 후 **polish 루프**가 해에서 다시 출발해 약한 가중치로 재해석, 자세 편차가 실제로 줄어들 때만 채택합니다. 그런데 이 polish가 브랜치 가드를 우회하던 것이 **E28**이고, 그 수정이 코드에 그대로 있습니다.

```c
const double dPolGap = ReadyBranchGap(vqPol, nPolAxis);
if (dPolGap > IK_DQ_MAX_RAD) {
    DBG_LOG_WARN("(SolveReadyIK) polish w=%.2f would flip the arm branch (J%d %.2f rad from q_ready) — polish dropped, keeping the in-branch solution", ...);
    break;
}
```

주석의 재현 사례: `target (0.828, 0.234, 0.300)` → 바닥 단은 통과, polish가 `J2` 갭 2.96 rad로 옮겨놓고 그대로 채택됨. **"플립된 자세가 오히려 자세 편차가 좋아 보이므로 polish가 능동적으로 선호한다"**는 것이 근본 원인으로 적혀 있습니다.

#### 2-3. 브랜치·자세·한계 판정 함수 3종 (private)

| 함수 | 계산 | 게이트 |
|---|---|---|
| `ReadyBranchGap(q, &axis)` | `FoldTowardRef(q, m_QReady)` 후 관절별 `|Δ|` 최대값과 축 | `> IK_DQ_MAX_RAD` → 브랜치 플립 |
| `AttitudeDevDeg(q)` | `E_sol * m_EReady^T`의 trace로 axis-angle 각도(deg) | `> APPROACH_RDEV_MAX_DEG` → tilt 거부 |
| `CheckLimitsPhysical(q)` | **in-place**로 0 근처 2π 폴딩 후 `s_adJointLo/Hi` 검사 | 유효성은 **물리 자세**로만 판정 |

`ReadyBranchGap` 헤더 주석이 왜 위치·자세 게이트로는 못 잡는지 실측으로 설명합니다 — 어깨를 ~180° 돌리고 나머지를 접으면 **툴 자세는 1 deg밖에 안 움직이는데 J0는 3.13 rad 떨어져** 있어서 60° 게이트가 통과시켜 버립니다. 그리고 "Staging cannot rescue that — staging moves the arm TO q_ready, which is exactly where this gap is measured from"이라고 대안까지 차단해 둡니다.

#### 2-4. 2π 폴딩 — 판정 좌표계 vs 실행 좌표계 분리

`static void FoldTowardRef(q, qRef, dof)`가 새로 생겼고, 각 관절을 `qRef`에 가장 가까운 2π 등가로 접습니다. 헤더 주석의 근거: E17 / E-stop 버스 전원 사이클이 멀티턴 카운터를 재참조해서 **팔이 물리적으로 0 근처인데 `J1 -6.2`, `J4 -18.9 rad`이 관측**됨. 그래서

- **판정**(한계·브랜치)은 `CheckLimitsPhysical`이 0으로 접은 **물리 자세**에서,
- **실행**은 `SolveReadyIK` 마지막의 `FoldTowardRef(aqSol, m_Q, m_uDOF)`로 **라이브 카운터 프레임**에서 —

이렇게 분리됩니다. 결과적으로 관절당 지령 이동량이 항상 ≤ π로 묶여 실제 한 바퀴 회전 명령이 나갈 수 없습니다.

#### 2-5. IkDiag — 해석 결과를 데이터로 노출

```c
enum eIkVerdict { eIkPass = 0, eIkNoSolution, eIkBranch, eIkLimits, eIkTilt, eIkNoSeed };
struct IkDiag { eIkVerdict eVerdict; double dW; int nSolves; double dMs;
                double dPosErrM; double dTiltDeg; double dBranchGap; int nBranchAxis; };
const IkDiag& GetLastIkDiag() const;
```

`StampIkDiag()`가 **모든 exit 경로에서 무조건** 기록합니다. 헤더 주석: 이 값들은 원래 전부 계산되고 `printf` 후 버려졌고, "예산 초과 WARN 경로는 이긴 가중치조차 출력하지 않아 사다리가 가장 깊게 들어간 순간에 정보가 사라졌다". 이 구조체를 소비하는 쪽이 `tools/reachmap.cpp`인데, 그 파일 주석이 설계 의도를 명확히 합니다 — "links `FullDynControllerRT.o` and calls the very same `SolveReadyIK`. If the solver changes, the map changes" (**솔버를 두 번 구현해 드리프트하는 것을 구조적으로 차단**).

---

### 3. 새 상수·안전 한계 총정리

#### 헤더 `static constexpr` (공개)

| 상수 | 값 | 역할 / 코드상 근거 |
|---|---|---|
| `IK_DQ_MAX_RAD` | `2.0` rad | dq 게이트 겸 브랜치 갭 임계. 초과 시 `REFUSED` |
| `IK_QD_PEAK_RADPS` | `0.6` rad/s | 5차 다항식 **피크** 관절속도 상한. `T ≥ 1.875·dq/0.6` |
| `IK_T_MAX_S` | `10.0` s | 위 스트레치의 상한 캡 |
| `IK_ORI_WEIGHT` | `0.3f` | soft keep-R 가중치(하드 제약은 시작 자세에 과민해서 폐기) |
| `IK_POS_TOL_M` | `0.002` m | **FK 잔차로 판정** — RBDL 수렴 플래그는 soft 잔차 때문에 항상 false |
| `IK_SOLVE_STEPS` | `300` | `CS.max_steps`에 기록 |
| `APPROACH_RDEV_MAX_DEG` | `60.0` | 완화 단에서만 적용되는 툴 자세 콘 게이트 |
| `HOLD_DB_RAD` | `0.03` rad | sticky-float 데드밴드 |
| `HOLD_KP_FRAC` / `HOLD_KD_FRAC` | `0.15` / `0.03` | 관절 `m_Kp`/`m_Kd` 대비 비율 (최대 스프링력 = `frac·Kp·DB`로 구조적 상한) |
| `HOLD_UNLOCK_QD` | `0.08` rad/s | 이 속도 초과 시 앵커가 그냥 따라감(핸드가이딩 감각 유지) |
| `m_Kp_task_pos` / `m_Kp_task_rot` | `1.0` / `0.2` | 작업공간 게인(회전은 flip 방지로 작게) |
| `m_dt` / `m_lambda` | `0.001` / `0.01` | 1 kHz 주기, DLS 기본 damping |

#### 소스 내 지역 한계

| 상수 | 값 | 위치 |
|---|---|---|
| `MAX_REF_LEAD` | `0.15` rad | `UpdateTrajectory()` settling 클램프 |
| `MAX_REF_LEAD` | `0.10` rad | `SetTargetPose_Jacobian()`, `ComputeJacobianBasedInverseKinematics()`, `ComputeInverseKinematics_6dof()` 오버슈트 방지 |
| `MAX_JOINT_VEL` | `0.6` rad/s | `SetTargetPose_Jacobian()` (절대 안전 한계) |
| `MAX_JOINT_VEL` | `0.5` rad/s | 자코비안 IK / 6DOF IK 레거시 경로 |
| `MAX_JOINT_ACC` | `2.0` rad/s² | `SetTargetPose_Jacobian()` — `m_Qd_ref_prev`와의 차분 클램핑 |
| `MAX_ROT_VEL` | `0.30` rad/s | 각속도 클램핑 |
| adaptive DLS | `w_threshold 0.01`, `lambda_high 0.05`, `lambda_low 0.0005` | manipulability `w = √det(JJᵀ)` 기반 |
| 자세오차 활성 문턱 | 위치오차 `< 0.08` m | 그 밖에서는 회전 오차 0 (먼 거리에서 자세부터 돌리지 않음) |
| `s_adJointLo/Hi` | J1–J5 `±3.0543261909900767` (±175°), J6 `±3.7524578917878086` (±215°) | cpp:747 — "RBDL's IK iteration is limit-blind, so the check lives here" |

---

### 4. 궤적 생성 (5차 다항식)

| 항목 | 내용 |
|---|---|
| `struct TrajState` | `q_start`, `q_goal`, `T`, `t_elapsed`, `active` (private) |
| `UpdateTrajectory()` | `p = 10s³ − 15s⁴ + 6s⁵`, 그 1·2차 미분으로 `m_Q_ref/m_Qd_ref/m_Qdd_ref` 생성. `t_elapsed += m_dt` |
| settling 단계 | `t ≥ T` 이후 `q_goal` 고정, 단 `MAX_REF_LEAD=0.15 rad` 클램핑. **모든 관절이 클램프에 안 걸릴 때만** `active=false` |
| `StartJointTrajectory(q_goal, T)` | 관절공간 직접 지령(IK 우회). ready 자세 복귀·staging에 사용 |
| `ScaledTrajTime(dqMax, TBase)` | E13 속도 캡을 **재사용 가능한 규칙으로 static 함수화** — 앱(`Indy7Ctrl.cpp:826, 938, 986`)이 직접 호출 |
| `IsTrajectoryDone()` | `!m_traj.active` (settle 조건 포함) |
| `IsTrajectoryRefDone()` | **신규** — `!active || t_elapsed >= T`. 헤더 주석: 정상상태 처짐(droop)에서는 0.15 rad settle 기준이 영영 안 잡혀 "완료 대기가 무한 대기"가 되므로 분리 |

이 이중 완료 판정은 실전 버그 대응의 흔적입니다. 앱이 `IsTrajectoryRefDone()`을 쓰는 곳이 `Indy7Ctrl.cpp:1244, 1268, 1366`입니다.

---

### 5. 목표 자세 설정 경로 — 3종

| 함수 | 제약 | 특징 |
|---|---|---|
| `SetTargetPose(Pose)` (cpp:586) | `AddFullConstraint` (위치+자세 하드) | 레거시. `CS.num_steps = 1000` (아래 함정 참조) |
| `SetTargetPosePositionOnly(Pose, adOriWeight = IK_ORI_WEIGHT, abQuiet = FALSE)` (cpp:626) | `AddPointConstraint` + 조건부 `AddOrientationConstraint(w)` | **E13 대응 본체**. 아래 상세 |
| `SetTargetPose_Jacobian()` (cpp:1291) | 자코비안 DLS, 매 사이클 | 비주얼 서보잉용 |

`SetTargetPosePositionOnly`의 게이트 순서가 그대로 안전 로직입니다.

1. `CS.max_steps = IK_SOLVE_STEPS`(=300), `AddPointConstraint` + soft `AddOrientationConstraint(w)`
2. `CheckLimitsPhysical` — 2π 폴딩 후에도 한계 밖이면 `REFUSED: solution outside joint limits even after 2π fold`
3. `FoldTowardRef(vjointspace, m_Q, m_uDOF)` — 실행 프레임으로 재표현
4. **FK 위치 잔차** > 2 mm → `IK failed — residual %.1f mm`
5. `dq_max > IK_DQ_MAX_RAD` → `REFUSED: J%d jumps %.2f rad ... IK branch flip`
6. `T` 스트레치(`1.875·dq/0.6`, 10 s 캡) 후 궤적 시동, 자세 드리프트를 `R held within %.1f deg`로 로깅

E13 주석의 원인 설명이 구체적입니다: 점 제약만 걸면 **3차원 널스페이스**가 남아 RBDL이 `m_Q`에서 먼 해(팔꿈치 플립/손목 풀림)를 반환할 수 있고, 관절공간 5차 다항식이 그 사이를 잇는 순간 **직교공간에서는 임의의 호를 그리며 테이블을 쓸고 지나갑니다**.

`adOriWeight` / `abQuiet` 파라미터는 **E26 refine 사다리용**으로 추가되었습니다. 헤더 주석: 국소 재타깃(refine)에 큰 bias를 주면 위치/자세 평형에서 정체해 FK 판정이 거부해버리므로 `0.0`을 넘기고, 사다리 중간 단의 실패는 정상이므로 로그를 억제합니다.

`ToolRotAt(q)` (cpp:617)도 E26 산물입니다 — "**팔이 우연히 세워져 있던 자세**"가 아니라 **접근 해가 실제로 도달하는 자세**를 refine의 기준점으로 잡게 해줍니다. 앱이 `Indy7Ctrl.cpp:934`에서 `stTarget.m_rotation = pC->ToolRotAt(vqSol);`로 사용합니다.

---

### 6. sticky-float 홀드 (`ComputeGravityCompensation` 내부)

원본은 `τ = g(q)` 6줄이 전부였습니다. 병합본은 그 뒤에 조건부 블록을 붙였습니다.

```c
if (m_eControlMode == eGravityCompensation && m_bStickyEnable.load(std::memory_order_relaxed))
```

- **모드 가드가 핵심**: 이 함수는 다른 모드의 폴백으로도 불리므로("must stay pure g(q)"), 중력보상이 **현재 활성 모드일 때만** 스프링이 붙습니다.
- 관절별 로직: `|qd| > HOLD_UNLOCK_QD(0.08)` → 앵커가 그냥 따라감(스프링 없음) / 데드밴드 `±0.03 rad` 밖으로 밀리면 앵커가 **끌려감**(drag) / 그 안에서는 `−0.15·Kp·err − 0.03·Kd·qd`.
- 목적(주석): 모델 잔차(링크 질량 오차 + 마찰)로 인한 **서서히 가라앉는 현상**을 잡되 핸드가이딩 감각은 유지. 속도 게이트는 "always-on 스프링이 뻣뻣하게 느껴진다"는 2026-07-27 운영자 피드백으로 추가됨.
- 토글은 `std::atomic<bool> m_bStickyEnable{true}` (기본 ON), 앱 `Indy7Ctrl.cpp:767`의 `'k'` 키.

---

### 7. RT 성능 모니터링 — 구조는 그대로, **IK 전용 서브 예산이 추가**

`RTPerformance` 구조체, `deadline_ns = 500000`(500 µs), `CheckRTViolation()`의 100회마다 1회 로깅 — **전부 원본과 동일**(diff에 해당 hunk 없음). 대신 새 IK 경로가 **자체 계측**을 갖습니다.

```c
const double dIkMs = (double)(read_timer() - tIkStart) / 1.0e6;
if (dIkMs > 0.8)
    DBG_LOG_WARN("(SolveReadyIK) %d IK solve(s) took %.2f ms (settled at w=%.2f) — over the 1 kHz cycle budget, amortize the ladder", ...);
else
    DBG_LOG_INFO("(SolveReadyIK) ladder settled at w=%.2f after %d solve(s), %.2f ms", ...);
```

그리고 `IkDiag.dMs`에도 같은 값이 남습니다. 헤더 `IK_SOLVE_STEPS` 주석이 **RT 위반을 은폐하지 않고 문서화**한 점이 중요합니다 — "the ladder costs up to ~32 ms. That is a real 1 kHz violation". 나아가 **정직한 해법까지 명시**되어 있습니다: 해를 RT 스레드 밖(브릿지의 비RT 워커)으로 옮기고 **그쪽에 별도 RBDL 모델 인스턴스**를 두어야 한다(모델이 thread-safe가 아니므로), RT에는 완성된 관절벡터만 넘긴다. 현재 완화 근거는 "operator command 시 1회성, 팔은 중력보상으로 정지 상태, 버스는 무손상 실측"입니다.

#### ⚠ `num_steps` vs `max_steps` 함정 (코드에 3회 경고 주석으로 박제됨)

| 경로 | 기록 필드 | 실효 예산 |
|---|---|---|
| `SetTargetPose` (cpp:594) | `CS.num_steps = 1000` — **RBDL 출력 필드** | RBDL 기본 `max_steps = 300` |
| `ComputeInverseKinematics_6dof` (cpp:1760) | 동일 | 300 |
| `RunISOCubeIKValidation` (cpp:2006) | 동일 | 300 |
| `SetTargetPosePositionOnly` (cpp:635) | `CS.max_steps = IK_SOLVE_STEPS` | **300 (실효)** |
| `SolvePositionIK` (cpp:808) | `CS.max_steps = anMaxSteps` | 호출자 지정. 사다리 단 = 300, **바닥 단·probe 검증 = 기본값 1000** |

주석은 "고치지 말라"까지 씁니다: 예산을 40 step으로 조였더니(2026-07-28 17:18) **타이밍은 고쳐졌지만 해가 망가졌고**, mustard가 `(w=0.01, dq 1.11 rad, direct, refine 3 passes → 7.0 mm)`에서 `(w=0.10, dq 2.98 rad, staged, staged leg refused)`와 `(w=0.00, tilt 3 deg, refine이 16.7 mm로 진동)`으로 퇴화했다는 실측이 남아 있습니다.

---

### 8. FK / 검증 / 로깅 계층 (`jieun` 계열)

| 항목 | 내용 |
|---|---|
| `struct Pose` | `m_position`, `m_rotation_rpy` (Vector3d), `m_rotation` (Matrix3d). 생성자에서 R=I |
| `tcp_local_point` | `{0.0, 0.0, 0.0}` — **`{0,0,0.07}` 버전이 주석 처리된 채 바로 위에 남아 있음** (TCP 오프셋 재정의가 미해결 상태임을 시사) |
| `m_body_id` | `Init()`에서 `m_rbdlModel.GetBodyId("tcp")` |
| `RPYToRot(r,p,y)` (public static) / `RotToRPY()` (파일 static) | ZYX(Rz·Ry·Rx) 규약 |
| `ComputeTcpFK()` / `GetCurrentPose(Pose&)` | 동일 계산. `CalcBodyToBaseCoordinates` + `CalcBodyWorldOrientation().transpose()` → `Pose::m_rotation`은 **body→base** 규약 |
| `IsJointSettled(vel_threshold)` / `IsJointStopped()` (`0.04` 고정) | 정지 판정 |
| `CheckIKConvergence()` | 속도 `> 0.02`로 기동 감지 후, `< 0.01`을 **5000 사이클(=5 s) 연속** 유지해야 정지 확정 → FK 캡처 → `PrintTcpVerificationResult()` |
| `PrintTcpVerificationResult()` | Start/Goal/Final 위치·RPY, `R_err = R_goal·R_final^T`의 vee map 회전오차, 그리고 `rt_ik_error_log/ik_accuracy_log.csv`에 **20열 append**(헤더 자동 생성) |
| `LogDistanceError(Pose)` | 위치/RPY 오차와 norm을 `'D'` 키로 즉시 출력 |
| `RunISOCubeIKValidation()` | **별도 `local_model`을 URDF에서 새로 로드**해 RT 루프의 `m_rbdlModel`을 건드리지 않음. ISO 9283 250 mm 큐브의 P1(중심)+P2~P5(대각면, `a = 0.100`)+clearance(Z+0.08), 각각 cold(q=0)/warm(현재 `m_Q`) 시드로 풀어 CSV 기록 후 `system("python3 .../plot_iso_virtual.py")` |

⚠ `RunISOCubeIKValidation()`의 경로가 **`/home/raimlab/RAON-RT/...` 하드코딩**입니다(`mkdir` 3회 + CSV + python 호출). 현재 사용자 홈(`/home/ubuntu`)에서는 동작하지 않습니다. 또한 `const char* pt_label = (pt < 5) ? std::to_string(pt+1).c_str() : "C";`는 임시 `std::string`의 수명이 끝난 뒤 포인터를 쓰는 형태입니다 — 코드상 확인되는 사실만 적습니다.

---

### 9. 자코비안 DLS IK 두 갈래

`ComputeJacobianBasedInverseKinematics()`(모드 `'i'`)와 `SetTargetPose_Jacobian()`(비주얼 서보잉)은 골격이 같지만 안전 처리 수준이 다릅니다.

| 항목 | `ComputeJacobianBasedInverseKinematics` | `SetTargetPose_Jacobian` |
|---|---|---|
| 자세 오차 | `R_err`의 vee map, 항상 활성 | **위치오차 `< 0.08 m`일 때만** `curZ × goalZ` (z축 정렬만, roll 무시) |
| DLS λ | `pos_err < 0.01` → `0.0005`, else `m_lambda` | manipulability `w = √det(JJᵀ)`: `w < 0.01` → `0.05`, `pos_err < 0.01` → `0.0005`, else `m_lambda` |
| 가속도 제한 | 없음 | `MAX_JOINT_ACC = 2.0 rad/s²` (`m_Qd_ref_prev` 차분 클램핑) |
| 각속도 클램핑 | 없음 | `MAX_ROT_VEL = 0.30 rad/s` |
| 속도 상한 | `0.5 rad/s` | `0.6 rad/s` |
| 선속도 클램핑 | — | **제거됨** — 주석: "관절 속도 한계(MAX_JOINT_VEL)로만 제한" |
| 진단 | — | 1000 사이클마다 `[VS-DBG]` printf (예측속도 `v6 = J·q̇_ref` 대조) |

둘 다 공통으로 **적분을 제거**했습니다: `m_Q_ref = m_Q; m_Q_ref += m_Qd_ref * m_dt;` — 매 주기 실측 자세를 기준으로 재계산해 드리프트를 원천 차단하고, 그 위에 `MAX_REF_LEAD` 클램프로 오버슈트를 막습니다.

---

### 10. 그 밖의 소소한 변경

| 항목 | 내용 |
|---|---|
| SSE 헤더 가드 | `#include <xmmintrin.h>` / `<pmmintrin.h>`를 `#if defined(__SSE__)`로 감쌈. 주석: "SSE headers exist only on x86 ... (no aarch64 effect)" — **KV260(aarch64) 포팅용**. 호출부의 `#ifdef __SSE__`는 원본에도 있었음 |
| 신규 include | `<cstdlib>`, `<fstream>`, `<ctime>`, `<sys/stat.h>` (CSV 로깅·`mkdir`·`system` 용) |
| 신규 멤버 벡터 | `m_Qd_ref_prev`(가속도 제한용), `m_Q_ik_target`(6DOF IK 해), `m_Q_hold`(sticky 앵커), `m_J`(6×DOF), `m_JJt`(6×6), `m_J_pinv`(DOF×6), `m_e_task`(6D) — 전부 **생성자에서 resize + setZero**(RT 중 할당 없음) |
| 기본 목표 위치 | `Init()`에 `goal_tcpPose = (-0.011930, -0.188431, 1.326710)`. 주석: "실수로 다른 모드 진입 시 로봇이 안전한 위치로 이동" |
| 트리거 플래그 | `std::atomic<bool> m_bIkTrigger`, `m_bSetRefPoseTrigger` — 비RT 키 입력 스레드 → RT 루프 전달용 |
| 파일 말미 | 원본은 `newline 없음`으로 끝났으나 병합본은 정상 종료 |

---

### 11. 학습·통합 관점 요약

- **IK는 "명령을 만드는 단계", 토크는 원본 그대로** — `eInverseKinematics_6dof`가 `UpdateTrajectory() + ComputeComputedTorque()`로 구성된 것이 이 분리의 증거입니다. EtherCAT 파이프라인에 붙일 때도 이 경계(관절 레퍼런스 3종 벡터)가 인터페이스가 됩니다.
- **거부(REFUSED)는 실패가 아니라 기능**입니다. `SolveReadyIK`가 반환하는 5가지 거부 사유(`eIkNoSolution`/`eIkBranch`/`eIkLimits`/`eIkTilt`/`eIkNoSeed`)가 각각 다른 대응을 요구합니다 — 특히 `eIkBranch`는 **staging으로 구제 불가**하다고 코드가 명시합니다.
- **q_ready는 반드시 운영자가 시연한 자세여야 합니다.** `ComputeReadySeed`가 `apAnchorSeed == NULL`일 때 실패를 반환하도록 설계된 것 자체가 "합성 부트스트랩 금지"의 코드화입니다.
- **미해결로 코드에 남아 있는 것**: (a) IK 사다리의 최대 ~32 ms가 1 kHz 주기를 침범 — 해법은 헤더에 적혀 있으나 미구현, (b) `tcp_local_point`가 `{0,0,0}`이고 오프셋 버전이 주석 처리, (c) `RunISOCubeIKValidation`의 `/home/raimlab/...` 하드코딩 경로. **충돌 모델은 이 파일 어디에도 없습니다 — 모든 게이트는 운동학·한계·자세 기준이며 PASS가 충돌 안전을 뜻하지 않습니다.**

---

## 15.8 로봇 제어 클래스 (`Indy7Ctrl`) · 진입점 · 빌드 변경점

App/Indy7의 "애플리케이션 층"은 원본 998줄(`Indy7Ctrl.h/.cpp/main.cpp`) → 병합본 2163줄로 늘었다. 핵심은 **RT 태스크를 새로 만든 것이 아니라, 기존 5개 태스크의 내용물을 전면 교체**한 것이다. 특히 `proc_main_control` 한 루프 안에 4개의 상태머신(ISO 하드웨어 테스트 / 사각형 모션 / 비전 접근 / 위치 리파인)이 얹혔고, 빈 껍데기였던 `proc_logger`가 실제 CSV 덤퍼가 되었다.

---

### 1. RT 태스크 구성 — 개수·등록 순서는 **불변(5개)**, 내용은 전면 교체

`CRobotIndy7::CRobotIndy7()` 생성자의 `AddTaskFunction()` 등록부를 양쪽 모두 grep한 결과는 다음과 같다.

| 등록 순서 | 원본 (`Indy7Ctrl.cpp:55~59`) | 병합본 (`Indy7Ctrl.cpp:60~64`) | 본문 변화 |
|---|---|---|---|
| 1 | `&proc_main_control` | `&proc_main_control` | 123줄 → 469줄 (상태머신 4종 + 로깅 수집기 추가) |
| 2 | `&proc_ethercat_control` | `&proc_ethercat_control` | 실질 동일 |
| 3 | `&proc_keyboard_control` | `&proc_keyboard_control` | ESC 시퀀스/개행 필터, `'z'` 소프트 검증, `m_cKeyPress` 대입 위치 이동 |
| 4 | `&proc_terminal_output` | `&proc_terminal_output` | 본문 **전량 주석 처리** → 사실상 no-op 폴링 루프 |
| 5 | `&proc_logger` | `&proc_logger` | `return;` 한 줄 → 24초 수집 + 37열 CSV 덤프 (약 90줄) |

**결론: 태스크는 여전히 5개이고 등록 순서도 완전히 동일하다.** 새 RT 태스크는 추가되지 않았다. 비전/ROS2 관련 동시성은 RT 태스크가 아니라 `CROS2PickBridge` 내부의 **비-RT 스레드**(`SpinLoop`/`WorkerLoop`)로 빠져 있고, RT 루프는 그 브리지의 wait-free API(`PopGoal`/`PopHomeRecord`)만 폴링한다. 즉 "RT 태스크 수를 늘리지 않고 기능을 늘린" 구조다.

헤더의 `friend` 선언은 순서만 재배치(`proc_logger`가 `proc_terminal_output` 뒤로)되었고, **`friend FILE* make_csv(CRobotIndy7*);` 한 줄이 신규 추가**되어 로거의 CSV 파일 생성 헬퍼가 private 멤버에 접근한다.

#### 태스크별 상세

- **`proc_main_control`** — 원본의 치명적 패턴 하나가 고쳐졌다. 원본은 태스크 시작 시점에 `BOOL bUseRTController = (pRTController != NULL && pRTController->IsEnabled());`로 **한 번만 스냅샷**했다. 병합본은 이를 `const BOOL bUseRTController = (pRTController != NULL);` (가용성만)로 바꾸고, 루프 안에서 매 사이클 `const BOOL bCtrlOn = bUseRTController && pRTController->IsEnabled();`를 다시 읽는다. 주석에 명시된 대로 `ENABLE_CONTROLLER_AT_STARTUP=0`으로 안전 기동할 때 런타임 `'r'` 키가 영원히 먹지 않던 문제를 없앤다.
- **`proc_main_control` — else 분기 제거**: 원본은 컨트롤러가 없으면 `MoveTorque(0.0)`을 매 사이클 명령했다. 병합본은 이 `else` 블록을 삭제해, 컨트롤러 미가동 시 **토크 명령 자체를 내보내지 않는다**.
- **`proc_terminal_output`**: 슬레이브별 `DBG_LOG_TRACE`(TargetPos/RawVel/ControlWord/StatusWord/DriveMode) 출력 블록 전체가 주석화. `wait_next_period()`만 도는 빈 루프가 되었다. (`pRTController` 지역 변수만 새로 잡아두고 사용처는 전부 주석)
- **`proc_logger`**: 원본 `void proc_logger(void*) { return; }` → 병합본은 `m_bLogTrigger` 대기 → 링버퍼 flush → `sleep(24)` → 트리거 해제 → `make_csv()`로 파일 생성 → 헤더 37열(`timestamp_ns, q0..5, q_ref0..5, qd0..5, tau0..5, tcp_xyz, tcp_rpy, goal_xyz, goal_rpy, ctrl_mode`) 기록. 실제 수집(push)은 `proc_main_control` 쪽에서 이뤄지고, 로거는 소비자다.
- **신규 `make_csv(CRobotIndy7*)`**: `/home/ubuntu/RAON-RT-Revision/App/Indy7/rt_log_results/DataLog_YYYYMMDD_HHMMSS.csv`를 `mkdir`+`fopen`. 주석에 "was the author's absolute home path — every log write failed"라 적혀 있어, 원저자 절대경로를 kv260 환경 경로로 교정한 변경임이 확인된다.

---

### 2. 키보드 명령 맵(`DoInput`) — 12키 → 33키(숫자 10개 포함)

원본 `DoInput`의 case는 `y/u/o/h/e/x/t/r/g/f/c` 11종(+`default`)뿐이었다. 병합본에서 추가·수정된 것은 다음과 같다.

| 키 | 원본 | 병합본 동작 (실제 코드) | 의미 |
|---|---|---|---|
| `o` | LED_OFF **후 `break` 없음 → `h`로 fall-through** | `break;` 추가 (주석: "was falling through into 'h'") | 원본의 fall-through 버그 수정 |
| `h` | (빈 `break`) | **서보 ON**: `m_bRTControllerEnabled` 및 모드==`eGravityCompensation` 인터록 검사 후 전 축 `ServoOn(CIA402_CYCLIC_TORQUE)` | 기존엔 키보드 서보-온 경로가 없어 `AUTO_SERVO_ON=1`에 의존했음. CST는 0토크로 enable되므로 중력보상 선행을 강제 |
| `j` | 없음 | 전 축 `ServoOff()` (브레이크 체결) | 운전자 주도 disarm |
| `l` | 없음 | `m_bLogTrigger = TRUE` | 로거 태스크 24초 수집 시작 |
| `i` | 없음 | `eInverseKinematics` 모드 + `m_pController->m_bIkTrigger = TRUE` | 자코비안 IK 모드 |
| `m` | 없음 | `SetTargetPose(m_Pose)` 성공 시 `eInverseKinematics_6dof` + 로깅 트리거 | `'s'`로 저장한 포즈로 6DOF IK 이동 |
| `n` | 없음 | **사각형 모션 토글**. 현재 TCP를 중심으로 `d=0.25 m` 오프셋 4점을 **YZ 평면**(X 고정)에 생성 → 4개 코너 `SetTargetPosePositionOnly()`로 IK 선계산(키보드=non-RT라 안전) → `m_rectJointTargets[4]`에 관절해 캐시 → 첫 코너로 2.0 s 궤적 시작 | RT 루프에서 IK를 돌리지 않기 위한 "선계산 후 관절궤적 재생" 패턴의 원형 |
| `Q` | 없음 | **ISO 9283 하드웨어 테스트 시작**. 현재 TCP+X0.02를 중심으로 `a=0.100 m` 큐브 5점 + 클리어런스(Z+0.08) 생성, `m_eISOHWState=eISO_HW_TO_TARGET`, `m_bIsoHWTrigger=true` | ⚠️ **소문자 `q`는 `proc_keyboard_control`이 먼저 가로채 `StopTasks()`로 종료**하므로 이 기능은 대문자 `Q`로만 도달한다 |
| `d` | 없음 | `m_pController->LogDistanceError(m_Pose)` | 목표-실제 거리 오차 로그 |
| `s` | 없음 | `GetCurrentPose(m_Pose)` → `SaveRobotPose()` (CSV) → `s_calibCapture.Capture(m_Pose)` (YAML) → TCP t/R 콘솔 출력 | 핸드-아이 캘리브 포즈 수집 |
| `a` | 없음 | 하드코딩 참조 포즈 `t=(-0.1806,-0.1808,0.9307)`, `rpy=(0.0872,-0.0860,1.5670)`를 `RPYToRot()`로 변환 → `SetTargetPose()` → 6DOF IK + `StartRefine(ref_pose)` | 재현 가능한 단일 목표 + 리파인 검증용 |
| `p` | 없음 | `m_pPickBridge->RequestMenu()` (널이면 안내 출력) | 인지 파이프라인 클래스 메뉴 |
| `0`~`9` | 없음 | `m_pPickBridge->FeedDigit(m_cKeyPress)` | 메뉴 선택 |
| `v` | 없음 | `m_pPickBridge->RequestApproach()` | 목표 확정 요청 (`p` → 숫자 → `v` 흐름) |
| `k` | 없음 | `m_pController->m_bStickyEnable` 토글 (`HOLD_DB_RAD` 데드밴드 표시) | 중력보상 sticky-hold ↔ 순수 float |
| `b` | 없음 | **HOME 복귀**. `m_bHomeSet`이면 `m_vHomeQ`, 아니면 `HasReadySeed()` 시 `GetReadyQ()`. 컨트롤러 enable·전 축 `IsServoOn()` 검사 → `FoldTowardRef()`로 라이브 카운터 기준 접기 → `dDqMax` 계산 → `ScaledTrajTime()`로 T 산출 → grav-comp로 낮췄다가 `StartJointTrajectory()` 후 `eInverseKinematics_6dof` 복귀 | IK 없는 순수 관절복귀라 브랜치 점프 위험이 구조적으로 없음. `FoldTowardRef`는 멀티턴 엔코더 감김(전체 바퀴 회전 명령) 방지 |

`proc_keyboard_control` 자체의 변경도 명령 맵의 일부다.

| 항목 | 원본 | 병합본 |
|---|---|---|
| `m_cKeyPress` 대입 시점 | `getche()` 직후 (종료 검사보다 **앞**) | ESC/개행/`q`/`z` 필터를 모두 통과한 **뒤** |
| ESC 시퀀스 | 없음 | `'\033'`이면 `getche()` 2회 소비 후 `continue` (방향키 무시) |
| 개행 | 없음 | `'\n'`/`'\r'` 무시. 주석: 파이프로 `"p\n"` 넣을 때 1 kHz 소비자가 샘플링하기 전에 `'\n'`이 덮어쓰는 문제 |
| `z`/`Z` | 없음 | `pRTController->RunISOCubeIKValidation()` (소프트웨어 전용, `m_cKeyPress`를 건드리지 않고 `continue`) |

---

### 3. `Init()` / `DeInit()` — 시동 시퀀스에 3가지가 끼어듦

`CRobotIndy7::Init(BOOL abSim)`은 원본에서 `InitController()` → `CRobot::Init()` 두 단계뿐이었다. 병합본은 그 사이에 다음을 넣었고, **모두 `CRobot::Init()`(=태스크 생성) 이전**에 끝난다.

1. **결정적 ready-seed 부트스트랩** — `CROS2PickBridge::DEF_BOX`(작업공간 박스)의 8개 코너를 만들고, `DEF_RMAX_XY`를 넘는 코너는 `dX *= dRMax/dR` 식으로 반경 클램프한 뒤 `m_pController->ComputeReadySeed(vProbes, vCenter, 파일시드)`를 호출.
2. **영속 시드 로드** — `CROS2PickBridge::ReadySeedPath()`(=`$HOME/.indy7_ready_seed`)를 `fscanf`로 최대 8개 double 읽어, DOF 이상이면 앵커로 넘김. 주석에 "합성 사다리만으로는 뒤틀린 q_ready(J4 2.61 / J5 1.65 rad)가 나온 적 있음"이라 근거가 적혀 있다.
3. **ROS2 픽 브리지** — `m_pPickBridge = new CROS2PickBridge();` 실패 시 **비치명적**으로 `delete` 후 `nullptr` 유지 → 파이프라인 없이도 로봇 단독 구동 보장.

또 `InitEcatSlaves()` 안 축 등록 루프에 **DC 레퍼런스 클록 고정**이 추가됐다: `nCnt == 0 && stSlaveInfo.bDCSupported`일 때 `m_pEcatAxis[0]->GetEcatSlave().SetAsDCRef()`. 주석대로 현재 cfg가 `DC_SUPPORT=0`이면 no-op이고, DC를 켜는 순간 활성화된다.

`DeInit()`은 주석 처리된 죽은 코드를 지우고 `m_pPickBridge->DeInit(); delete; nullptr;`(비-RT 스레드 join)을 추가했다.

---

### 4. 새 멤버 / 상태머신 (헤더 100 → 213줄)

헤더에 enum 3개가 새로 선언됐다: `eISOHWState{eISO_HW_IDLE, TO_TARGET, TO_CLEARANCE, DONE}`, `eRectState{eRECT_IDLE, TO_CORNER}`, `eApproachState{eAPPROACH_IDLE, MOVING, STAGING}`. 각각을 `proc_main_control` 안의 블록이 소비한다.

| 상태머신 | 멤버 | `proc_main_control` 내 동작 |
|---|---|---|
| **TCP 로깅** | `LogRingBuffer m_logBuffer`, `std::atomic<bool> m_bLogTrigger` | `bCtrlOn && m_bLogTrigger`일 때 매 사이클 `ComputeTcpFK()` → `ST_LOG_ENTRY` 채워 `push()`. R→RPY 변환은 `atan2(R(2,1),R(2,2))` 등 ZYX 관례. 링버퍼는 `DataRecorder.h`의 SPSC 무잠금 65536칸(가득 차면 드롭) |
| **ISO 하드웨어** | `m_bIsoHWTrigger`, `m_eISOHWState`, `m_nISOPointIdx`, `m_nISOCycle`, `m_bISOCmdSent`, `m_isoHWRecords[5][10][3]`, `m_isoTargets[5]`, `m_isoClearance` | `goal_tcpPose` 설정 + `m_bIkTrigger` → `m_bVerifyDone` 대기 → TCP 기록 → 클리어런스 → 5점×10사이클 후 `SaveISOHWResults()` + 중력보상 복귀 |
| **사각형 모션** | `m_bRectTrigger`, `m_eRectState`, `m_nRectCornerIdx`, `m_nRectWaitCount`, `m_rectCorners[4]`, `m_rectJointTargets[4]` | 모드가 `eInverseKinematics_6dof`일 때만 카운트. 1230카운트(=1.23 s)에 로깅 자동 트리거, 2000카운트(=2.0 s @1 ms)마다 다음 코너로 `StartJointTrajectory(..., 2.0)` |
| **비전 접근** | `CROS2PickBridge* m_pPickBridge`, `m_eApproachState`, `m_stStagedGoal`, `m_nStageSettleCnt`, `APPROACH_DURATION_S=3.0`, `STAGE_VEL_EPS=0.05`, `STAGE_SETTLE_CYC=200` | 아래 §5 |
| **HOME 기록** | `m_vHomeQ`, `m_bHomeSet` | `m_pPickBridge->PopHomeRecord()`가 참이면 **현재 관절값 스냅샷**(IK 없음) → `SetReadyAnchor()`로 q_ready 재기준 → 성공 시 `PersistReadySeed()`로 캐노니컬(폴딩된) 값을 파일에 영속 |
| **앵커 검증** | (컨트롤러 측) | `TickAnchorVerify()`를 매 사이클 1회 호출 — 9솔브 버스트가 루프를 멈추는 것을 피하려 **1사이클 1솔브로 분할 상환** |
| **위치 리파인** | `m_bRefineActive`, `m_nRefineIter`, `m_nRefineSettleCnt`, `m_vRefineDesired`, `m_stRefineCmd` + 상수 6개 | 아래 §6 |

신규 메서드는 `StartRefine(const Pose&)`, `TryReadyApproach(const Goal&, BOOL abAllowStage)`, `SaveISOHWResults()`, `SaveRobotPose()`이고, 헤더 끝에 `extern CalibCapture s_calibCapture;`가 선언되어 `.cpp`에서 `CalibCapture s_calibCapture("/home/ubuntu/RAON-RT-Revision/App/CalibUtils/kv260")`로 정의된다.

---

### 5. 비전 접근 경로 — `TryReadyApproach()`와 3단 방어

`'v'` → 브리지 → `PopGoal()` → `proc_main_control` 소비 흐름에서, 목표를 실행하기 전에 세 겹의 게이트가 걸린다.

1. **서보 OFF 거부**: 전 축 `IsServoOn()` 확인. 하나라도 꺼져 있으면 목표를 **버린다**(보류하지 않음). 주석에 "보류하면 `'h'` 누르는 순간 예기치 못한 모션이 나간다(2026-07-27 `j`→`v` 사고)"라고 근거가 있다.
2. **ready-seed 경로**: `HasReadySeed()`면 `TryReadyApproach(stGoal, TRUE)`. 아니면 원본에 가까운 **레거시 라이브-포즈 시딩** 경로(현재 R 유지 + `SetTargetPosePositionOnly`)로 폴백한다.
3. **staging**: `SolveReadyIK()` 결과의 `dDqMax`가 `IK_DQ_MAX_RAD`(2.0 rad) 이내면 직행, 넘으면 q_ready로 먼저 이동(`eAPPROACH_STAGING`). 2번째 다리는 **모드가 여전히 `eInverseKinematics_6dof`이고 전 축 서보 ON일 때만** 발사되고, 아니면 목표를 폐기하며 경고를 남긴다. 정지 판정은 `Σqd² ≤ STAGE_VEL_EPS²`가 `STAGE_SETTLE_CYC`(0.2 s) 연속일 때.

`TryReadyApproach()`에서 눈여겨볼 두 줄:
- `stTarget.m_rotation = pC->ToolRotAt(vqSol);` — 리파인의 자세 기준점을 "팔이 주차돼 있던 자세"가 아니라 **해가 실제로 도달하는 자세**로 잡는다(주석: tennis_ball에서 24° 차이).
- `pC->goal_tcpPose = stTarget;` — 관절궤적 경로가 `goal_tcpPose`를 채우지 않아 `'d'` 키가 목표를 0,0,0으로 표시하던 문제 수정.

또한 모든 궤적 시작은 `SetControllerMode(eGravityCompensation)` → `StartJointTrajectory()` → `SetControllerMode(eInverseKinematics_6dof)` 순서로 **감싸져** 있다(IK6dof 소비자가 반쯤 만들어진 궤적을 보지 않게 하는 패턴, `'b'`/`'n'`/접근 모두 동일).

---

### 6. 위치 리파인 상태머신 (CTC 정상상태 오차 보상)

트리거는 `'a'` 키와 모든 비전 접근. 동작은 `proc_main_control` 말미 블록에서:

- 모드가 `eInverseKinematics_6dof`가 아니거나 컨트롤러가 꺼지면 **즉시 중단**(`"[REFINE] aborted"`).
- `IsTrajectoryRefDone()` && `Σqd² ≤ REFINE_VEL_EPS²`가 `REFINE_SETTLE_CYC`(0.3 s) 연속 → 측정.
- `vErr = m_vRefineDesired - GetTcpPose().m_position`. `‖vErr‖ ≤ REFINE_TOL_M`(12 mm)이면 완료, `m_nRefineIter ≥ REFINE_MAX_ITER`(6)이면 잔차 경고 후 중단.
- 아니면 `m_stRefineCmd.m_position += REFINE_DAMPING(0.65) * vErr`로 **감쇠 바이어스 누적** 후 재-IK.
- 재-IK는 **자세 가중치 사다리**를 탄다: `adRefineW[] = {0.1, 0.03, 0.01, 0.0}`을 순서대로 `SetTargetPosePositionOnly(cmd, w, quiet)`에 넣어 처음 성공한 rung을 채택(마지막 rung만 `quiet=FALSE`). 주석에 "가중치 0이면 툴이 3차원 널스페이스를 배회해 잔차가 37.9→23.7→39.9 mm로 튀었다"는 실측 근거가 적혀 있다.

상수는 헤더에 모두 `static constexpr`로 노출: `REFINE_TOL_M 0.012`, `REFINE_MAX_ITER 6`, `REFINE_DAMPING 0.65`, `REFINE_TRAJ_T_S 1.5`, `REFINE_VEL_EPS 0.02`, `REFINE_SETTLE_CYC 300`.

---

### 7. 부수 변경 · 코드상 확인되는 주의점

| 항목 | 내용 |
|---|---|
| LED | `proc_main_control`의 모드별 LED switch에서 `eAdaptiveControl`/`default` 분기가 `LED_RED(FALSE)` → `LED_RED(bBlink)`로 변경 — 알 수 없는 모드에서도 이동 중임을 표시 |
| `SaveRobotPose()` | `/home/ubuntu/RAON-RT-Revision/App/CalibUtils/kv260/robot_poses.csv`에 `capture,tx..r22` 13열 append. 첫 캡처(`m_nPoseCapture==1`)에서만 `"w"`로 열어 헤더를 씀 → **`'s'`를 다시 세션 처음부터 누르면 기존 캘리브 세트를 덮어씀** |
| `SaveISOHWResults()` 경로 | `make_csv`/`SaveRobotPose`는 kv260 경로로 고쳐졌지만, 이 함수만 **`/home/raimlab/RAON-RT/App/Indy7/iso_csv/...` 원저자 경로가 그대로 남아 있다.** 코드상 `mkdir`/`fopen`이 실패하고 `DBG_LOG_ERROR` 후 반환한다 |
| `SaveISOHWResults()` 평균 | 10 사이클 합을 `mean[i] /= 30.0`으로, 표준편차도 `d_sq_sum/30.0`으로 나눈다(사이클 수는 10). 코드상 확인되는 범위에서 AP/RP 수치가 스케일 왜곡된다 |
| `'q'` 충돌 | `DoInput`의 `case 'q'`(ISO HW)는 `proc_keyboard_control`이 소문자 `q`를 종료로 먼저 가로채므로 **대문자 `Q`로만 도달 가능** |

---

### 8. `main.cpp` — 1라인, 주석뿐

```
     // lagacy code..maybe..
     // g_cRobot->WriteDataLog();
```
`WriteDataLog()` 호출은 원본에서 이미 주석 처리돼 있었고, 병합본은 그 위에 `// lagacy code..maybe..` 한 줄을 덧붙였을 뿐이다. **진입점의 실행 흐름 변경은 없다** (`Init(bSimMode)` → `while(!CheckStopTask()) { cpu_relax(); usleep(1000); }` 동일). 로깅은 `main`이 아니라 `proc_logger` 태스크로 완전히 이관되었다는 표식으로 읽힌다.

---

### 9. Makefile (103 → 190줄)

#### 컴파일 플래그

| 항목 | 원본 | 병합본 | 의미 |
|---|---|---|---|
| 최적화 | `-O3` | `-O2` | |
| `-DNDEBUG` | 있음 | **제거** | Eigen/RBDL의 `assert` 계열 런타임 검사가 활성 상태로 빌드됨 |
| `-flto` | 있음 | **제거** | 링크타임 최적화 해제 (오브젝트를 툴 타겟에서 재사용하려면 LTO 오브젝트는 다루기 까다로움 — 실제로 `reachmap`/`gate2b_test`가 `.o`를 직접 링크한다) |
| include | 6개 | `-I$(ECAT_DIR)/Device`, `$(CFLAGS_ROS)` 추가 | |

#### RBDL 경로 오버라이드 (신규)

```
RBDL_DIR ?=
ifneq ($(RBDL_DIR),)
CFLAGS  += -I$(RBDL_DIR)/include
LDFLAGS += -L$(RBDL_DIR)/lib -Wl,-rpath,$(RBDL_DIR)/lib
endif
LDFLAGS += -lrbdl -lrbdl_urdfreader
```
기본은 시스템 설치(`/usr/local`)지만, 스테이징 prefix를 지정해 사전 검증 빌드가 가능해졌다.

#### 라이브러리 링크 비교

| 라이브러리 | 원본 | 병합본 |
|---|---|---|
| `EMasterApp`, `rtposix`, `rbdl`, `rbdl_urdfreader` | 링크 | 유지 |
| **ViSP / librealsense / OpenCV / PCL** | 없음 | **의도적으로 없음.** 주석: ViSP 비주얼서보는 이 앱에서 제외(카메라는 ROS2 인지 파이프라인 소유), `CalibCapture`는 `Eigen::AngleAxisd`로 재구현해 ViSP 의존 제거 |
| **ROS2 (humble)** | 없음 | 신규. `ROS_DIR=/opt/ros/humble`, `MY_IFACE_DIR=/home/ubuntu/ros2_ws/install/my_interfaces`. `rclcpp/rcl/rcutils/rmw` + `my_interfaces`·`std_msgs`·`builtin_interfaces`·`rcl_interfaces`의 typesupport 4종(cpp/c/fastrtps_cpp/fastrtps_c) + `tracetools`, `libstatistics_collector`. `-Wl,-rpath`를 박아 **ROS 환경을 source하지 않고도 실행 가능** |

include 경로는 상류의 `find -maxdepth 1` 방식 대신 **화이트리스트(`ROS_PKGS` 18개)**를 쓴다. 주석에 근거가 명시돼 있다 — CycloneDDS의 `include/dds`, `include/idl`가 glibc의 `features.h`/`string.h`/`endian.h`를 **가리는(shadow)** 바람에 libstdc++ 컴파일이 깨졌고, 상류가 붙여둔 `-include cstdio/cstring/cstdlib`는 그 증상에 대한 임시방편이었다.

#### 소스 파일 · 신규 타겟

| 구분 | 내용 |
|---|---|
| `SOURCES` 추가 | `$(CURR_DIR)/CalibCapture.cpp`, `$(CURR_DIR)/ROS2PickBridge.cpp` (기존 12개 뒤, `Indy7Ctrl.cpp` 앞) |
| 빌드 제외 | `VisualServo.cpp/.h`는 트리에 남아 있으나 `SOURCES`에 **없다** (폐루프 참조용으로만 보존) |
| `gate2b_test` | `$(OBJECT_DIR)/ROS2PickBridge.o` + `tools/gate2b_bridge_test.cpp` → `gate2b_bridge_test.out`. EtherCAT·로봇 없이 stdin 명령으로 브리지만 구동 |
| `reachmap` | `$(OBJECT_DIR)/FullDynControllerRT.o` + `Controller.o` + `tools/reachmap.cpp` → `reachmap.out`. **로봇이 실제로 쓰는 솔버 오브젝트를 그대로 링크**하므로 맵이 솔버와 어긋날 수 없다 |
| `.PHONY` | `all clean` → `all clean gate2b_test reachmap` |

---

## 15.9 신규 파일 — App/Indy7 확장 (비전·로깅·픽앤플레이스)

원본 `/home/ubuntu/RAON-RT/App/Indy7`은 `Controller.{h,cpp}` / `FullDynControllerRT.{h,cpp}` / `Indy7Ctrl.{h,cpp}` / `main.cpp` / `INDY7.cfg` / `Makefile` 9개 파일뿐이다. 병합본은 여기에 **비전(AprilTag)·핸드아이 캘리브·비RT 로깅·ROS2 픽앤플레이스 브리지·로봇 모델(URDF)·오프라인 플로팅**이 통째로 추가됐다. 즉 원본이 "EtherCAT 1 kHz 토크 제어기"였다면, 병합본은 그 위에 **인지 → 목표 게이트 → RT IK → 로그/시각화**로 이어지는 애플리케이션 계층이 얹힌 형태다.

### 0. 신규 파일 한눈에 보기

| 파일 | 라인 | 계층 | 빌드 포함 | 역할 |
|---|---|---|---|---|
| `ROS2PickBridge.h/.cpp` | 178 / 606 | 비RT 스레드 ↔ RT 루프 경계 | ✅ `Makefile:122` SOURCES | ROS2 인지 파이프라인 구독 + 통계/작업공간 게이트 + 운영자 메뉴 |
| `WorkspaceBox.h` | 35 | 순수 상수 헤더 (ROS-free) | 헤더 전용 | 실측 작업공간 박스/반경 캡의 단일 진실원 |
| `DataRecorder.h` | 46 | RT → 로거 스레드 | 헤더 전용 (`Indy7Ctrl.h:20`) | lock-free SPSC 링버퍼 + `ST_LOG_ENTRY` 정의 |
| `CalibCapture.h/.cpp` | 25 / 49 | 비RT (키 핸들러) | ✅ `Makefile:121` | 핸드아이 캘리브용 TCP 포즈 YAML 덤프 (ViSP-free) |
| `VisualServo.h/.cpp` | 50 / 234 | 비RT 워커 스레드 | ❌ **SOURCES에 없음** | ViSP AprilTag 폐루프 서보 — 참조용으로만 트리에 잔류 |
| `indy7.urdf` | 16.6 KB | 모델 데이터 | `INDY7.cfg:8` 참조 | RBDL이 로드하는 실제 동역학 모델 (**F/T 페이로드 포함**) |
| `indy7_v2.urdf` | 15.4 KB | 모델 데이터 | 미참조 | v2 메시/관성 세트, tcp 링크는 빈 링크 |
| `plot_tcp_trajectory.py` 외 3종 | — | 오프라인 도구 | — | 로그 CSV → PNG 시각화 |

---

### 1. `ROS2PickBridge.{h,cpp}` — 인지 파이프라인 ↔ RT 루프의 유일한 경계

원본에는 ROS2 접점이 전혀 없었다(`App/Indy7_ROS2`는 별개 앱). 이 클래스는 **KV260 비전 파이프라인이 뽑은 3D 목표를 1 kHz RT 루프에 안전하게 넘기는 전용 어댑터**다. `Indy7Ctrl.h:26`에서 포함되고, `Indy7Ctrl.h:148`에 `CROS2PickBridge* m_pPickBridge`로 보유된다.

#### 1-1. 구독/파라미터 인터페이스

| 항목 | 값 | 설명 |
|---|---|---|
| 구독 1 | `/pick_target_base` (`my_interfaces/PickTarget3D`) | base_link 좌표계 목표. `x,y,z,class_name,target_valid,depth_valid` 사용 |
| 구독 2 | `/detections` (`my_interfaces/DetectionArray`) | 메뉴용 "지금 보이는 클래스" 집계 원천 |
| 파라미터 클라이언트 | `/pick_logic_node` 의 `desired_class` | `AsyncParametersClient`로 **LIVE 파라미터**를 원격 설정 |

#### 1-2. 스레딩 계약 (이 클래스의 존재 이유)

`Init()`가 두 스레드를 띄운다 — `SpinLoop()`(`SingleThreadedExecutor::spin`)와 `WorkerLoop()`(50 ms 폴링). ROS I/O·메뉴 출력·통계 게이트는 **전부 비RT 스레드**에서만 돌고, RT 루프(`proc_main_control → DoInput`)는 **뮤텍스를 절대 잡지 않는** 아래 API만 호출한다.

| RT 호출 API | 구현 | 의미 |
|---|---|---|
| `RequestMenu()` / `RequestApproach()` | `atomic<bool>` store(release) | 키 `p` / `v` 를 워커에 전달만 |
| `FeedDigit(char)` | 메뉴 열림일 때만 `m_nDigit` store | 숫자 선택 |
| `PopGoal(Goal&)` | `m_bGoalReady` acquire → 복사 → false store | SPSC 슬롯. 생산자는 ready==true 동안 절대 덮어쓰지 않음 |
| `HasLockedTarget()` | `m_bLocked` acquire | 즉시 락 상태 |
| `PopHomeRecord()` | `exchange(false, acq_rel)` | 메뉴의 "record HOME" 1회성 신호 |
| `PersistReadySeed(const double*, int)` | `m_adSeedMail[8]` + `m_nSeedMailN` | **RT는 메일박스만 채우고 파일 IO는 워커의 `TickSeedPersist()`가 수행** |

`Goal` 구조체는 의도적으로 Eigen/ROS 타입을 배제한 POD다: `double dX,dY,dZ` (dZ에 Z 마진이 이미 포함) / `char szClass[32]` / `double dStdMM[3]` / `int nSamples`.

#### 1-3. 운영자 플로우 (`p` → 숫자 → `v`)와 게이트

`ShowMenu()` — 최근 `MENU_WINDOW_S=1.0 s` 안에 `MENU_MIN_COUNT=3` 프레임 이상 잡힌 클래스만 나열, `std::sort`로 **번호가 결정적**이 되게 하고, 메뉴를 띄울 때마다 카운트를 0으로 리셋한다. `person`은 목록에서 빼고 "pick_logic will veto if close" 경고만 찍는다. 마지막 두 항목은 `n) AUTO(desired_class 비움)`와 `n+1) record HOME here`.

`HandleDigit()` — `0`=취소, `n+1`=`m_bHomeRecordReq` 세트(→ RT가 현재 관절 스냅샷), 그 외는 `SetDesiredClass()`로 원격 파라미터 설정. `SetDesiredClass()`는 **3회 재시도** 루프(서비스 대기 2 s, `set_parameters` future 2 s)로 파이프라인이 늦게 뜬 경우를 흡수한다.

`StartCollect()` → `TickCollect()` — `v` 한 번에 **4중 게이트**를 통과해야 목표가 RT로 넘어간다.

| # | 게이트 | 기준값(기본) | 실패 시 메시지 |
|---|---|---|---|
| 0 | 진입 조건 | 수집 중 아님 + 이전 goal 소비됨 + 최신 샘플 나이 < 1 s 이며 `target_valid` | "no live valid target — … wait for TARGET LOCKED" |
| 1 | 샘플 수 | `DEF_SAMPLES=15` (≈1 s @15 Hz), `DEF_TIMEOUT=3.0 s` | `GATE FAIL: timeout — k/15 samples` |
| 2 | 축별 표준편차 | `DEF_STD_GATE=0.008 m` | `GATE FAIL: std mm (…) — object/camera moving?` |
| 3 | 작업공간 박스 | `WS_BOX` 6면 (z에 `DEF_ZMARGIN=0.15 m` 더한 뒤 검사) | `GATE FAIL: goal (…) outside workspace box` |
| 4 | 반경 캡 | `r_xy ≤ WS_RMAX_XY = 0.92 m` | `GATE FAIL: goal r_xy … > reach` |

통과하면 SPSC 슬롯에 쓰고 `m_bGoalReady`를 release store → `GOAL READY:` 로그. RT 쪽(`Indy7Ctrl.cpp:1297`)은 이걸 `PopGoal`로 받아 **서보 ON 확인 → `HasReadySeed()`면 결정적 q_ready 시드 경로(`TryReadyApproach`), 아니면 레거시 라이브 자세 시드**로 분기한다.

#### 1-4. 세션 위생 — 실험에서 나온 방어들

코드 주석에 근거가 남아 있는, "실기에서 데인" 처리들:

| 처리 | 위치 | 이유(주석 근거) |
|---|---|---|
| `rclcpp::init(..., SignalHandlerOptions::None)` | `Init()` | 앱이 SIGINT/SIGTERM을 소유. rclcpp 핸들러가 끼면 Ctrl+C가 `CRobot::DeInit`을 우회 |
| `WorkerLoop()` 진입 즉시 `desired_class=""` | 워커 시작 | LIVE 파라미터가 앱보다 오래 살아 **부팅 직후 stale 클래스로 목표가 계속 발행**됨 |
| `DeInit()`에서 500 ms best-effort로 다시 클리어 | `DeInit()` | 세션 종료 시 파이프라인 중립화, 단 teardown은 빠르게 |
| 락 알림의 세션 스코프(`m_bAnnounceLock`) + 1 s 디바운스(`LOCK_LOST_DEBOUNCE_S`) | `TickLockWatch()` | 없으면 파이프라인 깜빡임을 영원히 나레이션. **단, `m_bLocked`(RT 가시 상태)는 알림과 무관하게 항상 갱신** |
| `ReadySeedPath()` = `$HOME/.indy7_ready_seed` | 정적 함수 | 다음 부팅이 "사람이 시연한 브랜치"에 IK 부트스트랩을 앵커링 |

#### 1-5. 상수 요약

| 상수 | 값 | 의미 |
|---|---|---|
| `DEF_ZMARGIN` | 0.15 m | 물체 위 호버 높이 (게이트 통과 전에 z에 가산) |
| `DEF_SAMPLES` / `DEF_STD_GATE` / `DEF_TIMEOUT` | 15 / 0.008 m / 3.0 s | 통계 게이트 |
| `MENU_WINDOW_S` / `MENU_MIN_COUNT` | 1.0 s / 3 | 메뉴 집계 |
| `LOCK_MAX_AGE_S` / `LOCK_LOST_DEBOUNCE_S` | 1.0 s / 1.0 s | 락 신선도 / 소실 디바운스 |

---

### 2. `WorkspaceBox.h` — 게이트 상수를 ROS에서 떼어낸 단일 진실원

35줄짜리 상수 전용 헤더. `namespace kv260` 안에 두 값만 있다.

```
static constexpr double WS_BOX[6]  = {0.30, 0.94, -0.37, 0.63, 0.10, 0.50};  // x,y,z min/max [m]
static constexpr double WS_RMAX_XY = 0.92;                                   // 베이스 축 기준 [m]
```

핵심은 **분리 이유**다. 이 값들은 원래 `ROS2PickBridge.h` 안에 있었는데, 그러면 값을 읽으려는 쪽이 `rclcpp`+`my_interfaces`를 통째로 끌고 와야 했다. 실제 소비자는 셋이다.

| 소비자 | 위치 | 용도 |
|---|---|---|
| 브리지 게이트 | `ROS2PickBridge.h:90` — `DEF_BOX`/`DEF_RMAX_XY`가 이 값들의 별칭 | goal 박스/반경 거부 |
| RT 앱의 ready-seed 부트스트랩 | `Indy7Ctrl.cpp:99` | 박스의 **8개 코너를 r-캡으로 클램프해 IK 프로브**로 삼아 결정적 `q_ready` 생성 |
| 오프라인 리치맵 툴 | `tools/reachmap.cpp:38` (`// not ROS2PickBridge.h: that one pulls rclcpp`) | ROS 없이 같은 박스를 스캔 |

주석에 남은 수치 근거(코드상 확인되는 범위): 박스는 2026-07-27 핸드아이 캘리브에서 나왔고, 같은 날 저녁 **베이스가 밀린 것(yaw +5.14°, t (+4.5, +10.4) cm)**을 반영해 옛 박스 코너를 fit 변환에 통과시킨 뒤 AABB로 바깥쪽 반올림한 값이다. `z_max 0.50`은 카메라 아래 여유 확보용. `WS_RMAX_XY`는 옛 0.80(밀리기 전 프레임에서의 경험적 추정)이 **실제로 닿는 물체를 막았기 때문에** 0.92로 완화됐고, 주석은 "진짜 도달 가능성 판정은 IK 솔버의 몫, 박스는 말도 안 되는 goal만 거른다"고 역할을 명시한다.

---

### 3. `VisualServo.{h,cpp}` — ViSP AprilTag 폐루프 서보 (트리에 남되 **빌드 제외**)

`Makefile`의 `SOURCES`에 없고, `Indy7Ctrl.h:22-25`가 이유를 적어놨다: **"카메라를 직접 열기 때문에 ROS2 인지 파이프라인과 공존 불가"** → 목표 포즈는 `/pick_target_base`로 대체, 이 파일들은 폐루프 참조 구현으로만 잔류.

구조상 확인되는 설계:

- **PIMPL**: `struct Impl { vpCameraParameters cam; vpHomogeneousMatrix rMc; }`를 .cpp에 숨겨, ViSP/librealsense 헤더가 앱 헤더로 새지 않게 한다(`FullDynControllerRT.h`와의 헤더 충돌 회피).
- `Init()`은 `camera.xml`(`vpXmlParserCamera`, `RealSense_color`) + `rPc.yaml`(핸드아이 결과)만 읽고, RealSense는 **`ctx.query_devices()`로 존재만 확인**한다 — 주석에 "no stream open, avoids errno=16 on busy device".
- `pipe.start()`는 일부러 `Loop()` 안(비RT `proc_visual_servo` 스레드)에서 호출한다. 주석: RealSense USB 워커 스레드를 비RT 우선순위로 유지해 **EtherCAT Sync Manager 워치독을 방지**하기 위함.
- 검출: 640×480 RGBA8@30, 수동 luma 변환, `TAG_36h11`, `tagSize=0.09 m`, `HOMOGRAPHY_VIRTUAL_VS`, `setAprilTagNbThreads(1)`(CPU 점유 억제).
- 목표 계산: `goal = rMc * cMo * s_Toffset`, `s_Toffset = t(-0.15,0,0) · Rxyz(π/2, 0, −π/2)` — 태그 x축이 로봇 −x라서 로봇 +x 방향 15 cm 오프셋.
- **α=0.15 EMA**로 위치·회전 성분을 함께 평활 후, `m_buf[2]` 더블버퍼 + `m_latest/m_valid` 원자 스왑으로 RT에 전달 (`GetGoalPose`).
- 상태기계 `IDLE / TRACKING / TAG_LOST / SINGULARITY`. 태그 소실은 상태만 바꾸고 마지막 포즈 유지, `NotifySingularity()`가 걸리면 `GetGoalPose()`가 **무조건 false**를 반환해 중력보상으로 빠지게 한다.
- 헤더 기본 `calibDir = "/home/raimlab/RAON-RT/App/CalibUtils"` — 현재 머신 경로가 아니지만, 빌드에서 빠져 있어 영향 없음(코드상 확인되는 사실).

---

### 4. `CalibCapture.{h,cpp}` — 핸드아이 캘리브용 포즈 캡처 (ViSP 의존 제거)

빌드에 포함되는 작은 유틸(49줄). `Indy7Ctrl.cpp:14`에 전역 인스턴스 `CalibCapture s_calibCapture("/home/ubuntu/RAON-RT-Revision/App/CalibUtils/kv260")`가 있고, **`s`/`S` 키**(`Indy7Ctrl.cpp:706`)에서 `GetCurrentPose` → `SaveRobotPose()` 직후 `Capture(m_Pose)`가 불린다.

- `Capture()`는 `Eigen::AngleAxisd`로 회전행렬 → **theta-u(axis-angle)** 변환 후 `<outDir>/pose_rPe_<N>.yaml`에 `rows: 6 / cols: 1 / data:` 레이아웃으로 `%.9f` 6줄을 쓴다.
- 헤더 주석이 의도를 명시: ViSP가 해주던 유일한 수학이 이 변환뿐이라 **ViSP 의존을 걷어내되 출력은 `vpPoseVector::saveYAML`과 바이트 호환**으로 유지 → `App/CalibUtils/eye_to_hand_calib.py`가 그대로 읽는다.
- 코드상 확인되는 사소한 비일관: 생성자는 `m_count(1)`로 시작하는데 `Reset()`은 `m_count = 0`으로 되돌린다(첫 파일 인덱스가 리셋 전후로 달라짐).

이것이 병합본에서 **`Makefile`이 ViSP/librealsense/OpenCV/PCL 링크를 전부 걷어낼 수 있게 한 열쇠**다(`Makefile:47-49` 주석).

---

### 5. `DataRecorder.h` — RT 안전 로깅의 뼈대

원본의 로깅은 `Indy7Ctrl.h`의 `stDataLog`(축별 `std::list<INT32>` 4개, `WriteDataLog()`가 축마다 CSV 생성)뿐이었다. 즉 **RT 루프에서 `std::list` 할당**이 일어나는 구조였다. 신규 헤더는 이를 대체하는 두 요소를 정의한다.

| 요소 | 내용 |
|---|---|
| `struct ST_LOG_ENTRY` | `timestamp_ns`, `q[6]`, `q_ref[6]`, `qd[6]`, `tau[6]`, `tcp_x/y/z`, `tcp_roll/pitch/yaw`, **`goal_x/y/z`, `goal_roll/pitch/yaw`**, `ctrl_mode` — 실제값과 **목표값을 같은 행에** 담아 오차 계산이 후처리로 가능 |
| `template<T,N> RingBuffer` | `atomic<size_t> head/tail`, `push`는 relaxed load + acquire 확인 + release store. **가득 차면 블로킹 없이 드롭**(RT 루프가 절대 멈추지 않음), `pop`은 로거 스레드 전용 |
| `using LogRingBuffer` | `RingBuffer<ST_LOG_ENTRY, 65536>` — 주석상 1 kHz 여유 버퍼 |

연결부: `Indy7Ctrl.h:118`의 `LogRingBuffer m_logBuffer`에 RT가 `Indy7Ctrl.cpp:1095` 부근에서 `ComputeTcpFK()` 결과와 `goal_tcpPose`를 채워 push하고, 비RT `proc_logger`(`Indy7Ctrl.cpp:1657~`)가 트리거 후 24초간 모았다가 `timestamp_ns,q0..,q_ref0..,qd0..,tau0..,tcp_*,goal_*,ctrl_mode` 헤더의 CSV로 flush한다. **아래 파이썬 스크립트들이 읽는 스키마가 정확히 이것**이다.

---

### 6. `indy7.urdf` / `indy7_v2.urdf` — 저장소 내부로 들어온 로봇 모델

원본 `INDY7.cfg:8`은 `URDF_PATH=/home/airlab2/indy-ros2/indy_description/urdf_files/indy7.urdf` — **저장소 밖 남의 머신 경로**였다. 병합본은 URDF 2종을 트리에 넣고 `URDF_PATH=/home/ubuntu/RAON-RT-Revision/App/Indy7/indy7.urdf`로 바꿔 자급자족 빌드가 된다.

공통 구조(둘 다 `indy.urdf.xacro` 자동 생성물, `<robot name="indy">`): `world` + `link0~link6` + `tcp` 링크, `global`(fixed) + `joint0~joint5`(revolute, 전부 축 `0 0 1`, `damping 0.1 / friction 10.0`) + `tcp`(fixed) 조인트, 끝에 `ros2_control`(`fake_components/GenericSystem`) 블록. 관절 한계는 J0~J4 `±3.05433 rad`(±175°), J5 `±3.75246 rad`(±215°), effort 431.97/431.97/197.23/79.79×3.

두 파일의 실질 차이:

| 항목 | `indy7_v2.urdf` | `indy7.urdf` (실사용) |
|---|---|---|
| 메시 세트 | `meshes/indy7_v2/…Indy7_v2_N.stl` | `meshes/indy7/…Indy7_N.stl` |
| 링크 관성 | v2 값 (예: link2 mass 6.114, com y=+0.291) | 다른 값 (link2 mass 5.848, com x=−0.296) |
| 조인트 원점 규약 | 예: `joint2 origin xyz "0 0.45 -0.0305" rpy "0 0 π"` | `xyz "-0.45 0 -0.0305" rpy "0 0 0"` — **좌표 규약 자체가 다른 변환본** |
| `tcp` 조인트 z 오프셋 | 0.057 | 0.06 |
| `tcp` 링크 | `<link name="tcp"/>` (빈 링크, 질량 0) | **관성 포함**: `mass 0.285`, `origin xyz "-0.021 0 0"`, `ixx 2.5e-4 / iyy=izz 1.5e-4` |

`indy7.urdf`의 `tcp` 링크 위 20줄짜리 `[kv260-merge 2026-07-27]` 주석이 이 섹션에서 가장 중요한 내용이다 — 코드상 확인되는 범위로 요약하면:

- 실물 엔드이펙터 하중을 **모델에 처음 넣었다**: RFT76-HA01 F/T 센서(D76×17 mm, 200 g) + 금속 태그 플레이트(D90×5 mm, ~85 g 추정), 플랜지 면에서 18.5 mm 돌출. 이 질량이 **통째로 빠져 있어서 중력보상이 가라앉고 팔을 뻗을수록 CTC 처짐이 커졌다**고 적혀 있다.
- **AXIS WARNING**: 이 기계 변환 URDF에서 `tcp` 프레임의 **공구축은 +Z가 아니라 −X**다. 두 가지로 교차검증됐다고 기록 — (a) 태그를 위로 둔 캘리브 자세들에서 tcp x가 정확히 아래를 향함(7° 이내), (b) 핸드아이 `eMo`가 태그를 x=−29.4 mm(플랜지 면 −10.9 mm + 스택 18.5 mm)에 놓음.
- 첫 시도인 `z=-0.060`은 질량을 **옆으로 6 cm** 매다는 셈이 되어 중력보상이 손목을 능동적으로 기울였다. 최종값은 합성 CoM(200 g @면+8.5 mm, 85 g @면+16 mm) → 21 mm 외측 = `x=-0.021`, 관성은 공구축(x) 기준 반경 ~0.04 m 실린더 근사.

---

### 7. 파이썬 플로팅 4종 — RT 로그를 그림으로

| 스크립트 | 입력 | 무엇을 그리나 |
|---|---|---|
| `App/Indy7/plot_tcp_trajectory.py` (57줄) | `rt_log_results/DataLog_*.csv` 중 **최신 1개** | TCP 3D 궤적 + XYZ vs 시간 + XY 평면 투영 3-패널 (tcp가 전부 0이면 "IK 모드에서 `l` 키로 기록했나요?" 경고) |
| `App/Indy7/rt_log_results/plot_tcp_trajectory.py` (206줄) | 해당 폴더의 **모든** `DataLog_*.csv` | 회차별 색상 오버레이 궤적 + **마지막 500행(정착 구간) 기준 goal 대비 위치오차(mm)와 자세오차(deg, `acos((tr(R_g R_aᵀ)−1)/2)`)** 막대. goal 컬럼이 없거나 원점이면 "평균 최종위치 대비 편차(반복도)"로 폴백. 저장 후 CSV를 `plotted_csv/`로 이동 |
| `App/Indy7/iso_csv/plot_iso_virtual.py` (약 250줄) | `iso_csv/virtual/iso_cube_ik_validation.csv` (생산자: `FullDynControllerRT.cpp:1983` `RunISOCubeIKValidation`) | ISO 큐브 IK 검증의 cold/warm 시드 비교 — 위치오차(symlog)·회전오차·계산시간·성공/실패 히트맵 4패널 + 큐브 와이어프레임 위 goal vs FK 3D. 추가로 "전부 수렴했을 때"의 SUCCESS 레퍼런스 도표 2장 |
| `App/Indy7/rt_ik_error_log/plot_ik_accuracy.py` (약 100줄) | `ik_accuracy_log.csv` (생산자: `FullDynControllerRT.cpp:462` `LogDistanceError`, append 누적) | 시행별 IK 정확도 4단 — 축별 위치오차(mm), 위치 norm 오차 + 평균/±1σ, 축별 회전오차(deg), 회전 norm 오차 + 평균/±1σ. 처리 후 CSV를 `plotted_csv/`로 이동 |

두 곳의 `plot_tcp_trajectory.py`는 **동명이지만 다른 파일**이다(상위본은 단일 파일 뷰어, 하위본은 다회차 비교 + 오차 정량 + 아카이빙). 또한 ISO CSV 경로는 C++ 쪽이 `/home/raimlab/RAON-RT/App/Indy7/iso_csv/...`로 하드코딩된 반면 파이썬은 `__file__` 상대 경로를 쓴다 — 현재 머신에서 C++ 산출 경로와 스크립트 입력 경로가 어긋난다(코드상 확인되는 사실).

---

### 8. 원본 대비 새로 열린 것

| 능력 | 원본 | 병합본 | 근거 파일 |
|---|---|---|---|
| 외부 인지 결과로 목표 지정 | 불가 (키보드/하드코딩 목표만) | `/pick_target_base` → 4중 게이트 → RT SPSC 슬롯 | `ROS2PickBridge.*` |
| 목표 안전 판정 | 없음 | 통계 안정도(std≤8 mm) + 박스 + 반경 캡 | `ROS2PickBridge.cpp:490-531`, `WorkspaceBox.h` |
| 작업공간 상수 공유 | — | RT 앱·브리지·오프라인 리치맵이 **같은 헤더** 참조 | `WorkspaceBox.h` ← `Indy7Ctrl.cpp:99`, `tools/reachmap.cpp:38` |
| 운영자 자세 학습/영속 | 없음 | 메뉴 "record HOME" → RT 스냅샷 → `SetReadyAnchor` → `$HOME/.indy7_ready_seed` | `ROS2PickBridge.cpp:211-253`, `Indy7Ctrl.cpp:1196-1226` |
| RT 안전 고속 로깅 | 축별 `std::list` (RT 내 할당) | lock-free SPSC 65536 엔트리, 가득 차면 드롭 | `DataRecorder.h` |
| 실제·목표 동시 기록 | 없음 | `ST_LOG_ENTRY`에 `goal_*` 6필드 | `DataRecorder.h`, `Indy7Ctrl.cpp:1095~` |
| 핸드아이 캘리브 데이터 수집 | 없음 | `s` 키 → ViSP 호환 YAML | `CalibCapture.*` |
| 동역학 모델 자급 + 공구 하중 반영 | 외부 절대경로 URDF, 하중 0 | 트리 내 `indy7.urdf`, tcp 285 g / CoM −X 21 mm | `indy7.urdf`, `INDY7.cfg:8` |
| 결과 시각화/검증 | 없음 | 궤적·오차·ISO IK·IK 정확도 4개 스크립트 | `*.py` 4종 |

**주의로 남겨둘 지점(코드상 확인되는 범위)**: ① `VisualServo`는 빌드에서 빠져 있으므로 "동작하는 기능"이 아니라 참조 코드다. ② `WorkspaceBox.h` 주석 자체가 "박스는 도달성 판정이 아니다"라고 명시하며, 실제 거부/수락은 RT의 ready-seed IK가 결정한다. ③ 브리지의 어떤 게이트도 **충돌 검사는 하지 않는다** — 통과했다는 것은 "샘플이 안정적이고 박스 안"이라는 뜻일 뿐이다.

---

## 15.10 신규 파일 — `tools/` 및 캘리브레이션 유틸

원본 `/home/ubuntu/RAON-RT`에는 `tools/` 디렉토리 자체가 없고 `App/` 아래에도 `Indy7/`, `Indy7_ROS2/`, `Indy7_ROS2_Mujoco/` 세 개뿐이다. 병합본은 여기에 **`tools/` (도달맵·베이스보정·캘리브·게이트 테스트)** 와 **`App/CalibUtils/` (핸드아이 캘리브 데이터셋 + 솔버)** 를 통째로 추가했다. 공통 성격은 "**RT 앱 본체를 건드리지 않고 앱이 실제로 쓰는 코드/데이터를 그대로 재사용해 오프라인에서 검증하는 도구**"다.

| 파일 | 종류 | 입력 | 산출 |
|---|---|---|---|
| `tools/reachmap.cpp` | C++ (실제 제어기 오브젝트 링크) | URDF, `~/.indy7_ready_seed`, 그리드 범위 또는 `--targets` 파일 | `reachmap.csv` (셀별 IK 판정) + `reachmap.log` |
| `tools/reachmap_plot.py` | Python/matplotlib | 위 CSV | 높이별 2D 패널 PNG |
| `tools/reachmap_plot3d.py` | Python/matplotlib | 여러 `--z` 평면을 담은 CSV | 3뷰(iso/side/top) 볼륨 PNG |
| `tools/base_shift_fit.py` | Python/numpy | 스크립트 내 `PAIRS` (LOCKED 좌표, 프로브 TCP 좌표) | yaw+tx+ty 적합, 새 launch static TF (x y z qx qy qz qw) |
| `tools/calib_grab.py` | Python/rclpy | ROS2 압축 이미지·CameraInfo 토픽 | `image%04d.png`, `camera_info.yaml` |
| `tools/calib_cpo.py` | Python/OpenCV | 위 이미지 + `camera_info.yaml` + `--tag-mm` | `pose_cPo_N.yaml` (camera→tag) |
| `App/CalibUtils/eye_to_hand_calib.py` | Python/scipy | `pose_rPe_*.yaml` + `pose_cPo_*.yaml` | `rPc.yaml`, `rPc.txt`, `rMc_visualization.png` |
| `tools/gate2b_bridge_test.cpp` | C++ 하네스 | stdin 한 글자 명령 | 브리지 동작 로그 (`GOAL CONSUMED`) |
| `tools/test_gate2b_bridge.py` | Python 드라이버 | 위 하네스 + 실제 `pick_logic` 노드 | C1~C5 PASS/FAIL |
| `tools/test_phase3_smoke.py` | Python 드라이버 | 실제 파이프라인 + `Indy7Ctrl.out` + EtherCAT 버스 | P0~P6 PASS/FAIL, `tools/phase3_logs/` |

---

### 1. `tools/reachmap.cpp` — 제어기 오브젝트를 **링크**한 오프라인 도달맵

**핵심: 솔버를 재구현하지 않는다.** 빌드 규칙은 `App/Indy7/Makefile` 172~179행에 새로 붙은 `reachmap` 타깃이며

```
REACHMAP_OBJS = $(OBJECT_DIR)/FullDynControllerRT.o $(OBJECT_DIR)/Controller.o
```

즉 로봇이 실제로 돌리는 `FullDynControllerRT.o`(와 베이스 클래스 `Controller.o`)를 그대로 링크해 `bin/reachmap.out`을 만든다. EtherCAT도 ROS도 링크하지 않으며, 이를 위해 워크스페이스 상수를 `ROS2PickBridge.h`(rclcpp/my_interfaces를 끌어옴)에서 떼어내 **`App/Indy7/WorkspaceBox.h`의 `kv260::WS_BOX` / `kv260::WS_RMAX_XY`** 로 분리한 것이 짝을 이루는 변경이다. 헤더 주석이 이유를 명시한다 — 사다리/워ム스타트/폴딩/브랜치/틸트 로직을 두 번 구현하면 로봇과 드리프트할 수 있고, "로봇과 불일치하는 지도는 지도가 없느니만 못하다".

**실행 흐름 (`main`)**

| 단계 | 코드 | 의미 |
|---|---|---|
| 인자 파싱 | `ParseArgs` | `--urdf/--seed/--out/--log/--x/--y/--z/--step/--rmax/--clamp-r/--mark/--targets` |
| 로그 분리 | `fdopen(dup(fileno(stderr)))` 후 stdout/stderr를 `--log`로 `freopen` | 셀당 여러 줄 쏟아내는 솔버 로그를 파일로 보내고, 진행률만 원래 stderr로 |
| 제어기 생성 | `CControllerFullDynamicsRT cCtrl(urdf, 6); cCtrl.Init()` | 앱과 동일한 RBDL 모델 |
| 시드 적재 | `LoadSeed()` — `$HOME/.indy7_ready_seed` | D13 ready-seed 앵커 파일을 그대로 읽음 |
| q_ready 산출 | `BuildProbes()`(WS_BOX 8코너 + rmax 클램프) → `cCtrl.ComputeReadySeed(probes, center, &seed)` → `GetReadyQ()` | 앱 init과 **같은 진입점**이라 여기 q_ready == 로봇 q_ready, 8-프로브 n/8 카운트도 동일 |
| 모델 파킹 | `Enable(TRUE)` 후 `Update(q_ready, 0, 0, out)` 1회 | `SolveReadyIK`가 **라이브 자세** 기준으로 폴딩/이동량을 보고하므로, `m_Q`가 초기 쓰레기면 결과가 무의미(또는 NaN)해진다는 주석 |
| 셀 생성 | 그리드(`--x/--y/--z/--step`) 또는 `--targets` 파일(`x y z [label]` 한 줄씩) | `--targets`가 **실기 로그 좌표 재생 모드** |
| 판정 | 셀마다 `cCtrl.SolveReadyIK(...)` → `cCtrl.GetLastIkDiag()` | 판정/진단이 전부 솔버 내부 값 |

**출력 CSV 스키마**: 헤더에 `# reachmap urdf= seed=`, `# q_ready = [6개]`, `# rmax= clamp_r= step=`, `# mark x y z label`이 주석으로 박히고(지도의 출처 = 어떤 앵커로 만들었는지), 본문 컬럼은
`x,y,z,verdict,w,tilt_deg,gap_rad,gap_axis,pos_err_mm,solves,ms,label`.
`verdict`는 `FullDynControllerRT.h`에 새로 생긴 `eIkVerdict`(PASS / NO_SOLUTION / BRANCH / LIMITS / TILT / NO_SEED)를 `VerdictName()`으로 문자열화한 것이고, 나머지 컬럼은 `IkDiag` 구조체(`dW` 승리 가중치, `nSolves` RBDL 호출 수, `dMs` 사다리 전체 벽시계, `dPosErrM`, `dTiltDeg`, `dBranchGap`, `nBranchAxis`) 그대로다.

**반경 처리 두 갈래**: `--clamp-r` 없으면 `r > rmax` 셀은 스윕에서 제외(브리지가 거부할 영역), 주면 rmax 원 위로 투영해 **브리지 동작을 그대로 흉내**낸다.

**종료 리포트**는 판정별 카운트와 `solve time: mean/max ms`를 찍고 `(the 1 kHz budget is 1.00 ms — see merge.md E25)`를 병기한다. 즉 이 도구는 도달성 지도인 동시에 **IK 시간 예산 프로파일러**로도 쓰인다. 마지막 줄은 고정 경고: `no collision model. PASS means the IK accepts the point, not that the arm can safely reach it` — RBDL에 지오메트리가 없어 테이블·카메라 리그·물체·자기 링크가 전부 부재하다는 사실을 소스 헤더·플로터 docstring·표준출력 세 군데에 중복해 못 박아 두었다.

커밋 `a0a2c26` 메시지에 따르면 이 도구의 첫 `--targets` 재생에서 실기 거부 `(0.828, 0.233, 0.303) J5 2.90 rad`를 축·크기까지 재현했고, 그 자리에서 **E28**(polish 단이 하단 브랜치 체크 뒤에 돌아 자세 점수만으로 플립 해를 선호)을 찾아냈다.

### 2. `reachmap_plot.py` / `reachmap_plot3d.py` — 같은 CSV의 2D/3D 뷰

- **2D**: `python3 tools/reachmap_plot.py sweep.csv -o reachmap.png`. 스캔 높이 하나당 패널 하나, 색은 `VERDICTS` OrderedDict(PASS 녹색 → BRANCH 적 → TILT 주황 → NO_SOLUTION 회청 → LIMITS 보라)로 **심각도 순 정렬**. `--metric {verdict,tilt,gap,ms,w}`로 스칼라 필드 맵도 그리는데, 이때 **비-PASS 셀은 회색 처리**해서 거부 셀의 의미 없는 수치가 색 스케일을 오염시키지 않게 한다. 축은 워크스페이스가 아니라 **데이터 범위**에 맞춰(`x.min()-pad ~ x.max()+pad`) 확대 스윕도 읽히게 했고, `rmax` 반원과 base 원점, `--mark` 점은 "주석일 뿐"으로 명시. `--mark`는 z가 가장 가까운 패널에만 그린다(다른 높이에 그리면 그 높이에 대해 무언가 말하는 것처럼 오해되므로).
- **3D**: `python3 tools/reachmap_plot3d.py vol.csv -o reachmap3d.png`, `--haze-every N`(기본 4). **거부 셀은 solid, 통과 셀은 서브샘플 haze(alpha 0.05)** — 2만여 개 녹색 점이 불투명하면 정작 볼 것(브랜치 플립 영역의 형상)을 덮기 때문. 뷰 3종을 고정: `(22,-60) iso`, `(2,-90) side (x–z): the refused region is a CEILING`, `(89,-90) top`. 커밋 `c0fddd4` 메시지 기준 통과율은 z 0.225까지 ~97% 평탄, z 0.40 84.3% → 0.45 66.0% → 0.50 53.9%로 떨어진다.

### 3. `tools/base_shift_fit.py` — E21 베이스 밀림 평면 강체 적합

로봇 베이스가 광학 테이블 위에서 밀렸을 때, **카메라·물체는 그대로이고 베이스 프레임만 이동**했다는 전제로 평면 강체 보정 C(z축 yaw + 2D 병진)를 복원한다.

1. `PAIRS`에 물체마다 `((LOCKED x,y,z), (프로브 TCP x,y,z))`를 손으로 채운다. 캡처 절차가 docstring에 절차서로 박혀 있다 — `'p'`→숫자로 `TARGET LOCKED` 좌표 복사, `'g'` 중력보상에서 물체 상단을 수직에 가깝게 터치 후 `'s'`로 t=[..] 복사.
2. **강체성 사전검사**: 모든 쌍의 물체 간 거리(카메라 프레임 vs 프로브 프레임)를 비교해 `RESID_WARN_M`(0.02 m) 초과 시 "물체가 락과 프로브 사이에 움직였다"로 **`SystemExit(1)` 거부**. 잘못된 데이터로 TF를 만들지 않겠다는 게이트다.
3. **2D Kabsch**: `th = atan2(Σ(cross), Σ(dot))`, `t2 = rc − R2·cc`로 yaw와 병진을 닫힌형으로 구하고 점별 XY 잔차와 dz를 출력(프로브 z는 상단+29 mm 팁이라 dz는 정보용).
4. **launch TF 합성**: 하드코딩된 현재 TF `T_OLD = (0.761822, −0.084713, 0.924974)`, `Q_OLD = (0.72390457, −0.03237801, −0.68876782, 0.02264346)`에 대해 `R_new = Rz(θ)·R_old`, `t_new = Rz(θ)·t_old + [tx,ty,0]`를 계산해 **launch 파일에 그대로 붙일 순서(x y z qx qy qz qw)** 로 인쇄한다.

즉 이 스크립트의 산출물은 숫자가 아니라 **`pick_place_vitis_ai.launch.py`의 static TF 교체값**이고, 잔차가 크면 "16-pose 전체 재캘리브를 고려하라"고 유도한다.

### 4. 캘리브레이션 파이프라인 — `calib_grab.py` → `calib_cpo.py` → `eye_to_hand_calib.py`

이 셋은 **하나의 사슬**이고, 사슬의 한쪽 끝은 RT 앱 안의 `CalibCapture`다.

| 단계 | 도구 | 동작 |
|---|---|---|
| 이미지 수집 | `tools/calib_grab.py` | 파이프라인이 카메라를 점유한 상태(D11)에서 **토픽만으로** 수집: `/camera/camera/color/image_raw/compressed`(BEST_EFFORT, depth 5) 구독 → Enter 시 `cv2.aruco` 36h11 태그가 **실제로 검출될 때만** `image%04d.png` 저장, `/camera/camera/color/camera_info`는 1회만 `camera_info.yaml`로 기록 |
| 로봇 자세 | 앱의 `'s'` 키 | `Indy7Ctrl.cpp` 14행 전역 `CalibCapture s_calibCapture(".../App/CalibUtils/kv260")` → 702~706행 `'s'` 핸들러가 `GetCurrentPose` → `SaveRobotPose()` + `Capture()` |
| 태그 자세 | `tools/calib_cpo.py` | `image*.png` + `camera_info.yaml`의 K/D로 `SOLVEPNP_IPPE_SQUARE` → `pose_cPo_N.yaml` |
| 최종 해 | `App/CalibUtils/kv260/eye_to_hand_calib.py` | `pose_rPe_*` × `pose_cPo_*` → AX=ZB 풀어 `rPc.yaml/.txt` |

세부에서 눈여겨볼 설계:

- **인덱스 락스텝이 이 사슬의 급소**다. `calib_grab.py`는 "먼저 이미지를 확인 저장하고 그 다음에 앱에서 `'s'`"라는 순서를 강제한다(태그가 안 잡히면 저장 자체를 안 하므로 카운터가 어긋나지 않는다). 같은 이유로 `calib_cpo.py`는 코너 리파인을 `CORNER_REFINE_APRILTAG → CORNER_REFINE_SUBPIX → 기본` 3단 폴백으로 돌린다 — 주석에 `image0012`에서 APRILTAG 리파인이 마커를 **떨어뜨린** 사례가 적혀 있고, 인덱스 하나가 비면 `eye_to_hand_calib.py`의 `sorted(glob)` zip 페어링이 **조용히 어긋난다**는 것이 이유다. 검출 실패 시에도 "pose pair N unusable"을 찍고 종료코드 1로 알린다.
- `calib_cpo.py`는 IPPE의 **두 해 모호성 비율**(`alt/best`)을 출력하고 2.0 미만이면 `AMBIGUOUS!`를 붙여, 플립하기 쉬운 프레임을 사람이 골라낼 수 있게 한다. 객체점 순서는 `detectMarkers`의 TL,TR,BR,BL에 맞춰 `[-s/2,+s/2] … ` 로 정의(태그 한 변은 `--tag-mm` 필수 인자, 검은 사각 외곽 기준).
- 출력 포맷은 **ViSP `vpPoseVector::saveYAML`과 바이트 호환**(`rows: 6 / cols: 1 / data:` + tx ty tz, θu). 앱 쪽 `CalibCapture.cpp`도 ViSP 없이 `Eigen::AngleAxisd`로 θu를 만들어 같은 포맷을 쓴다(헤더 주석에 "ViSP가 제공한 유일한 수학은 R→θu였다"고 명시). 덕분에 기존 `eye_to_hand_calib.py`를 **한 줄도 안 고치고** 재사용한다.
- 내부 알고리즘: `solve_eye_to_hand()`가 모든 (i,j) 상대운동 쌍 `A_ij = rMe_i⁻¹rMe_j`, `B_ij = cMo_i⁻¹cMo_j`를 만들고 Park & Martin 방식으로 회전을 SVD(`M_rot += outer(β,α)`), 병진은 `(Ra−I)tx = Rx·tb − ta`의 최소자승으로 풀어 `eMo`를 얻은 뒤 `rMc_i = rMe·eMo·cMo⁻¹`를 측정마다 계산해 **평균(회전은 SVD 프로젝션)**하고, 잔차를 cm/deg로 보고한다.

### 5. `App/CalibUtils/` 두 데이터셋과 **동일한 스크립트 두 벌**

`diff -u App/CalibUtils/eye_to_hand_calib.py App/CalibUtils/kv260/eye_to_hand_calib.py` → **차이 없음(완전 동일)**. 이는 실수 복제가 아니라 구조적 결과다: 스크립트가 `data_dir = os.path.dirname(os.path.abspath(__file__))`로 **자기 파일 위치를 데이터 디렉토리로 삼기** 때문에, 스크립트를 데이터 폴더에 복사하는 것이 곧 데이터셋 선택이다.

| 항목 | `App/CalibUtils/` (원 데이터셋) | `App/CalibUtils/kv260/` (신규 세트) |
|---|---|---|
| 자세 쌍 수 | `pose_rPe_1..12` / `pose_cPo_1..12` (12쌍) | `pose_rPe_1..16` / `pose_cPo_1..16` (16쌍) |
| 내부 파라미터 | `camera.xml` (ViSP XML, 640×480, px 601.064 / u0 320.407) | `camera_info.yaml` (848×480, K fx 601.064 / cx 424.407 — 같은 초점거리, 주점이 (848−640)/2=104 px 이동) |
| 부가 산출 | `eMc.yaml`, `ePo.yaml`, `rPc.yaml/.txt` | `rPc.yaml/.txt`, `robot_poses.csv`(16행, TCP t + 3×3 R), `rMc_visualization.png` |
| rMc 병진 | `rPc.txt` → (−0.8475, 0.1895, 1.0618) | `rPc.txt` → (0.7612, −0.0997, 0.9262) |

kv260 세트의 rMc 병진 (0.7612, −0.0997, 0.9262)은 `base_shift_fit.py`가 현행 launch TF로 하드코딩한 `T_OLD` (0.761822, −0.084713, 0.924974)와 같은 계열의 값이다(완전 일치는 아니며, 코드상 확인되는 것은 두 값이 각각 "이 캘리브 결과"와 "현재 launch에 들어간 값"이라는 사실까지다).

그 밖의 CalibUtils 신규 파일:

- `save_camera_params.cpp` + `Makefile`: ViSP+librealsense로 컬러 스트림을 지정 해상도(`argv[3..4]`, 기본 640×480)로 연 뒤 **실제 초기화된 해상도를 장치에서 되읽어**(`rs.getIntrinsics`) `vpXmlParserCamera::save`로 `camera.xml`을 굽는다. 인자: `save_camera_params [out.xml] [camName] [w] [h]`. Makefile은 `/home/raimlab/visp/build` 등 **개발 PC 절대경로**를 박아둔 독립 빌드로, 상위 `App/Indy7/Makefile`과 연결되지 않는다(보드에서 쓰는 경로는 ROS `camera_info` 쪽 `calib_grab.py`로 갈라졌다).
- `visualize_rPc.py`: rPc 6-벡터를 **소스에 상수로 박아** 베이스/카메라 프레임 축과 base→cam 화살표를 그리는 확인용 스크립트. 저장 경로가 `/home/raimlab/RAON-RT/App/CalibUtils/rPc_visualization.png`로 하드코딩되어 있어 현재 보드(`/home/ubuntu/RAON-RT-Revision`)에서는 그대로 돌지 않는다 — 실질 후속은 `eye_to_hand_calib.py`가 자체적으로 그리는 `rMc_visualization.png`다.

### 6. 브리지·통합 테스트 하네스

**`tools/gate2b_bridge_test.cpp` (Gate 2b 하네스)** — `make gate2b_test`(Makefile 161~168행)가 `ROS2PickBridge.o`만 링크해 `bin/gate2b_bridge_test.out`을 만든다. **EtherCAT도 로봇도 없이 실제 `CROS2PickBridge`를 그대로** 구동한다.

- `setvbuf(stdout, _IOLBF)` — 파이썬 드라이버의 파이프 뒤에서도 브리지 스레드 printf가 즉시 보이게.
- `cBridge.SetWorkspaceBox(-2,2,-2,2,-2,2)` — 합성 피더/플레이스홀더 TF에 대해 **의도적으로 박스를 개방**(앱 기본 박스면 전부 거부됨).
- stdin 한 글자 명령 `p`(메뉴) / `0-9`(선택) / `v`(접근 요청) / `s`(락 여부) / `q`, 그리고 **1 kHz RT 소비자 대역 스레드**가 100 ms마다 `PopGoal()`을 돌려 `[HARNESS] GOAL CONSUMED: class=… xyz=… std_mm=… n=…`을 찍는다.

**`tools/test_gate2b_bridge.py`** — 위 하네스 + **진짜 `pick_logic` 노드**를 띄우고, 합성으로는 `/detections`(apple+banana 15 Hz)와 `/pick_target_base`(apple @ base (0.45,0.10,0.12), σ 1.5 mm 가우시안)만 먹인다. 검사 C1~C5: 메뉴 렌더 → 브리지의 `desired_class='apple' set` ack → **`ros2 param get /pick_logic_node desired_class`로 노드에 실제 반영됐는지 교차확인** → `TARGET LOCKED: apple` → `GOAL CONSUMED`의 z가 `0.12 + Z_MARGIN(0.15) = 0.27`인지 ±0.02로 검증. 위생 처리가 상당하다 — `_kill_stale()`이 `pgrep -f` 후 `/proc/<pid>/comm`까지 확인하고 죽인 뒤 `ros2 daemon stop`, 자식은 `start_new_session=True`로 띄워 `killpg_hard()`로 SIGTERM→SIGKILL 무조건 정리, `ros2` CLI는 5회 재시도.

**`tools/test_phase3_smoke.py`** — 서보 오프(motion 0) **실기 통합** 스모크. P0 프리플라이트에서 `RLIMIT_RTPRIO ≥ 97`과 **`RLIMIT_MEMLOCK == RLIM_INFINITY`** 를 요구하며(주석: 앱이 `mlockall(MCL_CURRENT|MCL_FUTURE)`이라 유한 memlock이면 DDS/ROS2 스레드의 malloc arena가 넘쳐 `std::bad_alloc` → 2026-07-26 보드 프리즈), 부족하면 `sudo prlimit --memlock=unlimited --pid <claude 조상 PID>` 힌트를 계산해 출력한다(`find_claude_ancestor()`가 `/proc`을 거슬러 올라감). 이어 `ethercat slaves` 7개, 바이너리 존재, 카메라/버스 이중 점유(pgrep) 차단. P1 파이프라인 첫 `/detections` 수신, P2 `[PickBridge] up` + 7슬레이브 OP, P3 60 s 유지(`--hold`로 조정) — 여기서 **OP 전이 직후 Lost frames를 재기준선화**하고 "IgH의 Lost frames는 감소할 수 있으므로 **증가만** 실손실"이라고 판정식을 `lost1 <= lost0`으로 둔 점이 정확하다. P4는 앱 stdin에 `'p'`/숫자/`'v'`를 밀어넣어 **라이브 파이프라인 기반 메뉴**를 검증(컨트롤러 비활성이라 GOAL READY가 소비되지 않는 것이 Phase 3의 설계임을 notes로 남김), P5는 축별 `ethercat upload -p<ax> 0x6064` SDO 읽기, P6는 SIGINT → `APPLICATION ENDED`/`(DeInit)`/`[PickBridge] down` + 슬레이브 PREOP 복귀까지 확인. 앱은 `stdbuf -oL`와 `MALLOC_ARENA_MAX=2` 환경으로 띄운다(로그 꼬리 유실 방지 + locked footprint 억제). `--app-only`로 파이프라인/브리지 단계를 건너뛰어 앱+버스 생명주기만 격리 검증할 수 있다.

### 7. 그 밖의 `tools/` 내용물

- `tools/gate0_rtposix_test.c` (+빌드 산출물): `/opt/rt_posix`의 `create_rt_task → set_task_period(1 ms) → wait_next_period` 주기 지터 측정기. 인자 `[cycles] [period_ns] [prio] [cpu|v] [v]`로 **4/5번째 숫자 인자가 CPU 핀**(D10 3+1 격리 A/B용). 주석에 두 가지 사실이 기록돼 있다 — RT-POSIX `wait_next_period()`의 오버런 판정이 tv_sec 동률에서 방향을 잘못 비교하므로 이 테스트는 `NULL`을 넘기고 **측정 dt 통계로만** 판단하고, `set_task_period()`가 첫 데드라인을 셋업 시각에 무장하므로 앞 10주기를 `WARMUP`으로 버린다.
- `tools/patches/rtposix-aarch64-stackmin.patch`: RT-POSIX `src/posix_rt.c::_create_task`에서 `ullStackSize`를 `PTHREAD_STACK_MIN` 이상으로 클램프. aarch64 glibc의 `PTHREAD_STACK_MIN`(128K)이 `DEFAULT_STKSIZE`(64K)보다 커서 기본 요청이 `pthread_attr_setstacksize`에서 실패하던 문제.
- `tools/phase3_logs/{app.log,pipeline.log}`: 위 스모크 실행의 실제 로그 (`.gitignore`에 `tools/phase3_logs/`가 등록돼 있으므로 추적 대상은 아님).

### 8. 사용 시 주의 (코드에서 직접 확인되는 것)

1. **`'s'` 키는 캘리브 세트를 덮어쓴다.** `CalibCapture::CalibCapture`는 `m_count = 1`로 시작하고, `CRobotIndy7::SaveRobotPose()`는 `m_nPoseCapture == 1`에서 `fopen(..., "w")`로 `kv260/robot_poses.csv`를 **truncate** 한다. 앱을 재시작하고 `'s'`를 누르면 `pose_rPe_1.yaml`부터 다시 쓰인다(실제로 kv260 디렉토리의 `pose_rPe_1..3`만 타임스탬프가 7-28로 튀어 있다).
2. **reachmap의 PASS는 안전이 아니다.** 충돌 모델이 전혀 없으므로 자기충돌·테이블 충돌은 여전히 MuJoCo 몫이라고 소스가 명시한다.
3. **reachmap은 앵커에 종속**된다. `~/.indy7_ready_seed`가 다르면 지도가 달라지므로 CSV 헤더의 `# q_ready` 주석과 함께 읽어야 한다(그래서 헤더에 넣어 둔 것).
4. `base_shift_fit.py`, `visualize_rPc.py`는 상수를 **소스에 직접 편집**해서 쓰는 방식(전자는 `PAIRS`/`T_OLD`/`Q_OLD`, 후자는 rPc 6-벡터)이므로 CLI 인자가 없다.

---

## 15.11 ROS2 계층 · 기타 앱 변형 변경점

이 섹션은 ROS2 실행기(`CROS2Executor`), Indy7_ROS2 앱의 빌드 설정, 그리고 PyQt UI 스크립트의 변경을 다룬다. 라인 수로는 `ROS2Executor.cpp`의 **-267줄**이 압도적이지만, 실제로 "동작이 바뀐" 곳은 **종료 시퀀스**와 **ROS 배포판 전환**, **rclpy 이중 스핀 제거** 세 곳이다.

| 파일 | 원본 | 병합본 | 성격 |
|---|---:|---:|---|
| `Global/Comm/ROS2Executor.cpp` | 405 | 138 | 보일러플레이트 제거 + 종료 순서 수정 |
| `Global/Comm/ROS2Executor.h` | 73 | 73 | **완전 동일**(변경 없음) |
| `App/Indy7_ROS2/Makefile` | 171 | 156 | Humble → Jazzy 이식 |
| `App/Indy7_ROS2/Indy7Ctrl.h` | 131 | 133 | 공백 2줄(무의미) |
| `App/Indy7_ROS2/scripts/UiCtrlNG.py` | 602 | 608 | rclpy 이중 스핀 제거 + qdarktheme API |
| `App/Indy7_ROS2/scripts/UICtrl.py` | 341 | 341 | qdarktheme API 1줄 |
| `include/EMasterApp/*.h` | 없음 | 13개 | `make install` 산출물(추적 대상 아님) |

참고: `Global/Comm/` 디렉터리 전체를 `diff -rq`로 훑은 결과 **변경된 파일은 `ROS2Executor.cpp` 하나뿐**이다. `ROS2Node.h`, `ROS2IndyIface.h`, `ROS2Common.h`는 바이트 단위로 동일하다.

---

### 1. `Global/Comm/ROS2Executor.cpp` — 267줄이 사라진 진짜 이유

#### 1-1. `CreateSpinThread()`: 86줄짜리 이중 타입 스위치 → 4줄

원본의 스핀 스레드 람다는 다음 4단계 구조였다.

1. 구체 타입 포인터 13개 선언 (`CROS2IndyStatePub* pPubIndyState;` … `CROS2GetControlModeCli* pCliGetControlMode;`) + `CROS2StrPub*/CROS2StrSub*` + 주석 처리된 선언 10여 개(Imu/PointCloud/JointInfo/AxisInfo).
2. `switch(GetNodeType())` **1번**: 활성 case 13개 + 주석 case 15개. 각 case가 `pX = (구체타입*)apNode; executor.add_node(pX->GetSharedPtr());`.
3. `executor.spin();` 뒤에 `std::this_thread::sleep_for(1ms);`
4. `switch(etype)` **2번**: 위 스위치를 그대로 미러링해 `executor.remove_node(...)` 호출.

병합본은 전부 이것으로 대체됐다.

```cpp
auto node_ptr = apNode->GetSharedPtr();
if (!node_ptr) return;

rclcpp::executors::SingleThreadedExecutor executor;
executor.add_node(node_ptr);
executor.spin();
```

**왜 무손실인가 (코드로 확인한 근거).** `Global/Comm/ROS2IndyIface.h`의 13개 클래스는 전부 `class CROS2IndyStatePub : public CROS2Node`(87행) 형태로 `CROS2Node`를 직접 상속하며, `grep -n "GetSharedPtr" ROS2IndyIface.h` 결과가 **0건** — 즉 자체 `GetSharedPtr()`을 선언하지 않는다. 따라서 13개 case가 각기 다른 타입으로 다운캐스트한 뒤 호출하던 것은 전부 동일한 비가상 기반 멤버 `CROS2Node::GetSharedPtr()`(`ROS2Node.h:49`, 본문은 `return shared_from_this();`)로 귀결된다. 다운캐스트 자체가 아무 효과가 없는 순수 보일러플레이트였다.

#### 1-2. 그래도 동작이 달라진 3가지 (반드시 인지 필요)

| 항목 | 원본 | 병합본 | 의미 |
|---|---|---|---|
| Executor 종류 | `rclcpp::executors::StaticSingleThreadedExecutor` (스택 지역) | `rclcpp::executors::SingleThreadedExecutor` (스택 지역) | Static은 첫 spin 시점에 엔티티 집합을 고정 수집한다. 표준 executor는 매 사이클 재수집하므로 spin 이후 생성된 구독/타이머도 잡힌다 |
| 노드 타입 게이팅 | `default:` / `eUSERINFO_SUB` / `eUSR2CTRL_PUB`, 그리고 주석 처리된 `eSTR_PUB`·`eSTR_SUB`·IMU·PointCloud·AxisInfo·JointInfo는 **`add_node` 없이** 빈 executor를 spin | 노드 타입과 무관하게 **무조건 add_node 후 spin** | `AddNode()`로 등록된 모든 노드가 실제로 돌아간다. 반대로, 스핀시키고 싶지 않은 노드를 타입으로 걸러내던 안전장치는 사라졌다 |
| spin 후처리 | `sleep_for(1ms)` + `remove_node` 미러 스위치 | 없음 | executor가 스택 지역이라 스레드 종료 시 소멸자가 정리한다. 제거해도 누수 없음 |

한 가지 부작용: `CROS2StrPub`(`ROS2Node.h:78`)과 `CROS2StrSub`(`ROS2Node.h:100`)은 기반 클래스의 `GetSharedPtr()`을 **다른 반환 타입**(`SPtrPublisher`/`SPtrSubscriber`)으로 가린다. 그러나 람다가 캡처하는 것은 `CROS2Node*`이므로 이름 가리기가 적용되지 않고 기반 버전(`shared_from_this()`)이 선택된다 → 이 두 타입도 정상적으로 노드로서 스핀된다.

#### 1-3. 삭제된 코드에 있던 fall-through 버그

원본의 두 번째(remove) 스위치에서 `case eSET_ALL_POS_CLI:`는 `remove_node` 호출 후 **`break;`가 없어** 곧바로 `case eSET_CONTROL_MODE_SRV:`로 흘러들어가, 같은 포인터를 `CROS2SetControlModeSrv*`로 재캐스트해 다시 `remove_node`를 부른다. 스위치를 통째로 걷어내면서 이 결함도 함께 없어졌다. (첫 번째 스위치의 동일 위치에는 `break;`가 있었다 — 들여쓰기만 어긋나 있었을 뿐.)

#### 1-4. `DeInit()` — 종료 시 join 데드락 수정 (이번 변경의 핵심 기능 픽스)

```
원본:  m_vecROS2Nodes.clear();  →  Stop();  →  thread->join()  →  clear  →  rclcpp::shutdown();
병합본: rclcpp::shutdown();     →  clear    →  thread->join()  →  clear
```

`executor.spin()`은 컨텍스트가 shutdown될 때까지 반환하지 않는다. 원본은 **join을 먼저 하고 shutdown을 나중에** 했으므로 `join()`에서 무한 대기한다. 병합본은 `/* shutdown rclcpp FIRST so spin() returns, then join */` 주석과 함께 `if (rclcpp::ok()) rclcpp::shutdown();`을 맨 앞으로 옮겼다. 실질적으로 앱 종료 행(hang)을 푸는 변경이다. 아무 일도 하지 않는(`return TRUE;`뿐인) `Stop()` 호출도 함께 제거됐다.

#### 1-5. 생성자/소멸자 — `m_pExecutor` 수명 관리

`ROS2Executor.h`는 **두 트리에서 완전히 동일**하며, 원본에서도 이미 `rclcpp::executors::StaticSingleThreadedExecutor* m_pExecutor;` 멤버를 선언하고 있었다. 그런데 원본 `.cpp`의 두 생성자는 이 포인터를 **초기화하지 않고**, 소멸자도 손대지 않았다 — 미초기화 멤버였다.

| | 원본 | 병합본 |
|---|---|---|
| `CROS2Executor()` / `CROS2Executor(int)` | `m_pExecutor` 미대입 | `m_pExecutor = new rclcpp::executors::StaticSingleThreadedExecutor();` |
| `~CROS2Executor()` | `rclcpp::shutdown();` 무조건 | `if (m_pExecutor) { delete; = nullptr; }` 후 `if (rclcpp::ok()) rclcpp::shutdown();` |

소멸자의 `rclcpp::ok()` 가드는 `DeInit()`이 이미 shutdown한 뒤 소멸자가 또 부르는 이중 shutdown을 막는다. 다만 **솔직히 적어두면**, `m_pExecutor`는 여전히 어디서도 사용되지 않는다 — 실제 스핀은 스레드마다 스택 지역 executor를 새로 만든다. 즉 이 부분은 죽은 멤버에 대한 초기화/해제 정리이지 기능 경로가 아니다.

#### 1-6. 손대지 않은 잔존 결함

`CROS2Executor(int domain_id)` 생성자는 여전히 `rclcpp::InitOptions options; options.set_domain_id(domain_id); rclcpp::init(0, NULL);` 형태로, **`options`를 `init`에 전달하지 않는다**. 도메인 ID 지정이 실효가 없는 상태 그대로다(원본·병합본 동일, 이번 병합에서 건드리지 않음).

또한 스핀 스레드는 `std::thread` 생성 후 스케줄링 정책/우선순위를 설정하는 코드가 없다 — RT 주기 태스크와는 별개의 일반 스레드다(원본·병합본 동일).

---

### 2. `App/Indy7_ROS2/Makefile` — Humble → Jazzy 이식 (171 → 156)

변경은 2개 훅뿐이다.

| 항목 | 원본 | 병합본 |
|---|---|---|
| `ROS_DIR` | `/opt/ros/humble` | `/opt/ros/jazzy` |
| `CFLAGS_ROS` | `-I$(ROS_INCLUDE)` 외 **하드코딩 16줄** (`rclcpp`, `std_msgs`, `rcl`, `rcutils`, `rmw`, `rcl_yaml_param_parser`, `rosidl_runtime_c`, `rosidl_typesupport_interface`, `rcpputils`, `builtin_interfaces`, `rosidl_runtime_cpp`, `tracetools`, `rcl_interfaces`, `libstatistics_collector`, `statistics_msgs`) | `$(shell find $(ROS_INCLUDE) -maxdepth 1 -type d \| sed 's/^/-I/')` **1줄** |

`LDFLAGS_ROS`(indy_iface typesupport 라이브러리들)는 변경 없음.

**하드코딩을 글롭으로 바꾼 이유는 병합본의 빌드 산출물로 실증된다.** `App/Indy7_ROS2/obj/ROS2Executor.d`가 참조하는 Jazzy 인클루드 디렉터리를 뽑아보면 원본 목록에 **없던** 3개가 등장한다.

- `/opt/ros/jazzy/include/service_msgs`
- `/opt/ros/jazzy/include/type_description_interfaces`
- `/opt/ros/jazzy/include/rosidl_dynamic_typesupport`

Jazzy의 `rclcpp` 헤더 체인이 이들을 필수로 끌어오므로, 원본의 고정 16줄 목록으로는 컴파일이 깨진다. 글롭 방식은 배포판이 필요로 하는 패키지가 늘어도 Makefile을 다시 손볼 필요가 없게 만든다.

**환경 관련 확인 사실** (추측 아님, 파일 검사 결과):
- 병합본의 `bin/Indy7Ctrl.out`, `obj/*.o`는 `file` 결과 **x86-64 ELF** → 병합 작업 빌드는 x86-64 데스크톱(Ubuntu 24.04 + Jazzy)에서 수행됐다.
- 현재 이 호스트(Kria, `uname -m` = `aarch64`)에는 `/opt/ros/humble`만 설치돼 있다. 즉 이 Makefile은 **보드에서 그대로 빌드되지 않는다** — 배포판 이름이 상수로 박혀 있어 보드로 되돌릴 때 `ROS_DIR` 수정이 필요하다.

---

### 3. `App/Indy7_ROS2/Indy7Ctrl.h` (131 → 133)

`#include "ROS2Executor.h"` 아래에 **빈 줄 2개**가 삽입된 것이 전부다. 선언·멤버·시그니처 변경 없음. 무언가를 include하려다 되돌린 흔적으로 보이며, 기능적으로는 no-op다.

---

### 4. `App/Indy7_ROS2/scripts/UiCtrlNG.py` (602 → 608, +6)

#### 4-1. rclpy 이중 스핀 제거 (2곳, 각 +3줄)

`ROS2Worker.get_gains()`와 `ROS2Worker.get_control_mode()` 내부의 중첩 함수 `handle_response()`가 대상이다. 두 곳 모두 동일 패턴.

```python
# 원본
rclpy.spin_until_future_complete(self.node, future, timeout_sec=5.0)

# 병합본
import time
timeout = 5.0
start = time.time()
while not future.done() and (time.time() - start) < timeout:
    time.sleep(0.05)
```

**근거:** `handle_response`는 `threading.Thread(target=handle_response, daemon=True).start()`로 별도 스레드에서 돌고, 동시에 `ROS2Worker.run()`(QThread)이 이미 `while self.running and rclpy.ok(): rclpy.spin_once(self.node, timeout_sec=0.1)`로 **같은 노드를 계속 스핀 중**이다. 즉 원본은 한 노드를 두 스레드가 동시에 스핀하는 구조였다. 병합본은 스핀을 QThread 한 곳으로 일원화하고, 보조 스레드는 `future.done()`만 폴링한 뒤 `gains_updated` / `control_mode_updated` 시그널을 emit한다. 대가는 50 ms 폴링 주기로 인한 UI 조회 지연 최대 50 ms뿐이다.

`import time`이 함수 안에 들어간 이유도 확인된다 — 모듈 상단 import는 PyQt6 / `sys` / `qdarktheme` / `rclpy` / `indy_iface` / `threading` / `commons`뿐이고 `time`이 없다.

#### 4-2. qdarktheme API 교체 (`__main__`)

```python
- qdarktheme.setup_theme("light")
+ app.setStyleSheet(qdarktheme.load_stylesheet("light"))
```

`setup_theme()`(PyQtDarkTheme 2.x) → `load_stylesheet()` + 수동 `setStyleSheet`(1.x) 로 되돌린 형태다. **코드상 확인되는 범위**로는 API 호출 형태 변경이며, 대상 환경에 설치 가능한 qdarktheme 버전에 맞춘 것으로 읽힌다(현 호스트에는 `qdarktheme` 모듈 자체가 없어 버전 검증 불가).

---

### 5. `App/Indy7_ROS2/scripts/UICtrl.py` (341 → 341, 1줄)

337행 `__main__` 블록의 **qdarktheme 호출 1줄만** 위 4-2와 동일하게 교체됐다. `JointControl` 클래스, 슬라이더/서비스 호출 로직 등 나머지는 전부 동일하다. (이 파일에는 `spin_until_future_complete` 패턴이 없어 4-1 수정 대상이 아니다.)

---

### 6. `include/EMasterApp/*.h` 13개 — 리뷰 대상 아님 (빌드 산출물)

13개 전부(`EcatCommon.h`, `EcatMasterBase.h`, `EcatSlaveBase.h`, `SlaveBeckhoffCU1124/EK1100/EL2024.h`, `SlaveCIA402Base.h`, `SlaveELMO.h`, `SlaveEPOS4.h`, `SlaveFBGSensor.h`, `SlaveKistarHand.h`, `SlaveKistFT.h`, `SlaveNRMKEndTool.h`)가 `EMasterApp/Device/*.h`와 **`diff -q` 기준 바이트 단위 동일**하며, 두 트리에서 내용이 같은 `EMasterApp/Makefile`의 `install:` 타깃(66~67행 `mkdir -p $(INSTALL_DIR)/include/EMasterApp; cp -rfp $(DEVICE_DIR)/*.h ...`)이 만든 사본이다. `.gitignore:11`에 `/include/`가 등재돼 있어 추적되지 않는다 → **원본에 없는 건 단순히 원본 트리에서 `make install`을 돌리지 않았기 때문**이고, 소스 변경이 아니다.

같은 범주(병합본에만 존재하는 미추적 빌드 산출물): `App/Indy7_ROS2/{bin, obj, build, install, log}`, `App/Indy7_ROS2/scripts/{build, install, log, __pycache__}`, `lib/EMasterApp`.

---

### 7. 학습·통합 관점 정리

- **`ROS2Executor.cpp`의 -267줄은 "기능 삭제"가 아니라 "타입 다운캐스트 보일러플레이트 삭제"다.** 새 ROS2 노드 클래스를 추가할 때 더 이상 `enum eNodeType`에 값을 넣고 `ROS2Executor.cpp`의 두 스위치를 동시에 고칠 필요가 없다 — `CROS2Node`를 상속하고 `AddNode()`만 하면 스핀된다. EtherCAT/비전 쪽 신규 토픽을 붙일 때 수정 지점이 1곳으로 줄었다.
- **진짜 버그 픽스는 `DeInit()`의 shutdown/join 순서 하나다.** 나머지(소멸자 가드, `m_pExecutor` 초기화)는 방어 코드다.
- **`Makefile`의 `ROS_DIR=jazzy` 하드코딩은 이식 시 첫 번째 확인 지점이다.** 보드(humble)와 데스크톱(jazzy)이 갈리므로, 이후 통합에서는 `ROS_DIR ?= /opt/ros/$(ROS_DISTRO)` 같은 형태가 필요해질 수 있다(현 코드에는 없음).
- **PyQt UI 쪽 교훈은 "이미 스핀 중인 노드를 다른 스레드에서 또 스핀하지 말 것"** — `spin_until_future_complete`를 `future.done()` 폴링으로 바꾸는 패턴이 그대로 재사용 가능하다.
- 같은 디렉터리의 `App/Indy7_ROS2/INDY7.cfg`도 변경됐으나(URDF 경로, TASK4→Logger, `AUTO_SERVO_ON`, 홈 오프셋/`POS_BEFORE_EXIT` 등) 이는 설정 섹션 소관이므로 여기서는 다루지 않는다.

---

*문서 끝. 본문(§1~§14)은 `~/RAON-RT` 기준, §15는 `~/RAON-RT` → `~/RAON-RT-Revision` 차이. EtherCAT·HAL·설정 절은 코드 원문 재확인(적대적 검증)을 거쳤습니다. 2026-07-29.*
