# RAON-RT (`RAON-RT-Revision-main`) — 아키텍처 & 통합 레퍼런스 가이드

> **이 문서의 목적**: `~/RAON-RT-Revision-main`의 전체 구조를 다른 세션에서 **재탐색 없이** 파이프라인에 이어붙일 수 있도록 정리한 밀도 높은 레퍼런스. 각 서브시스템의 클래스 계층·핵심 API·PDO 맵·설정 키·상수·**검증된 버그/스텁**·외부 의존성까지 담았다.
>
> **왜 이 코드가 당신 파이프라인과 직결되는가**: RAON-RT는 **IgH EtherLab EtherCAT 마스터(`ecrt.h`, `-lethercat`) + RT 태스크 계층(`rtposix`) + CiA402 서보 드라이브(CST 토크 모드)** 위에 얹힌 설정(`.cfg`)-구동 로봇 제어 프레임워크다. 이는 당신이 Kria KV260에서 진행 중인 **IgH stable-1.6 + PREEMPT_RT** 스택의 상위 응용 계층 그 자체다. → 통합 지침은 [§13](#13-integration)·[§14](#14-appendix) 참조.

---

## 문서 메타데이터

| 항목 | 값 |
|---|---|
| 대상 저장소 | `/home/ubuntu/RAON-RT-Revision-main` |
| 정리일 | 2026-07-23 |
| 저작자(원본) | Raimarius Delgado 외, KIST AIRI / ROBOGRAM LAB (2022~), 일부 파일 RAIMLAB @ Myongji Univ. (2025) |
| 프로젝트 정체 | **RAON-RT** = *Real-time Architecture for Open, Networked robotic systems*. 이기종 로봇의 액추에이터/센서/제어 모듈을 실시간 환경에서 표준화 통합하는 C++ 프레임워크 |
| 대표 산출물 | `App/Indy7/bin/Indy7Ctrl.out` — EtherCAT + PREEMPT_RT 기반 **6축 협동로봇(Indy7) 토크 제어기** |
| 규모 | 366개 파일 · 소스 LOC 약: EMasterApp/Device 4199, EMasterApp/Interface 537, CRobot 8290, Global 902, Global/Comm 3807, App/Indy7 4110, App/Indy7_ROS2 2342, App/Indy7_ROS2_Mujoco 2764, App/CalibUtils 307 |
| 빌드 | 순수 GNU `make` + `g++` (CMake 없음). 루트 `Makefile`은 **EtherCAT 라이브러리만** 빌드; 각 App은 개별 `make` |
| 저장소에 이미 있는 문서 | `summary.md`(App/Indy7만 다룸, 한국어), `arch.puml`/`deployment.puml`(PlantUML), `README.md.txt`. **본 가이드는 이들을 대체·확장한다** — 특히 EtherCAT 마스터 라이브러리 내부와 CRobot HAL은 `summary.md`에 없다 |

## 이 문서 사용법 (다음 세션용)

- **먼저 [§1 개요](#1-overview)와 [§13 통합 지침](#13-integration)만 읽어도** 붙이기 판단이 선다. 세부 API가 필요할 때만 해당 서브시스템 섹션으로 내려가라.
- 섹션 번호는 코드 계층을 따라간다: **빌드/설정(§2) → EtherCAT 마스터(§3) → 슬레이브(§4) → 축 HAL(§5) → 로봇 오케스트레이션(§6) → 센서(§7) → 공용 유틸(§8) → ROS2(§9) → 앱(§10~12) → 통합/부록(§13~14)**.
- ⚠️ 표시된 **버그/스텁**은 워크플로우의 적대적 검증(코드 원문 재확인)을 통과한 실제 결함이다. 하드웨어 구동 전 반드시 확인할 것. `summary.md` 본문의 옛 경로(`/home/raimlab/...`, `/home/jaehyeon/...`)는 원저자 PC 기준이며 stale가 아니라 **의도된 원본**이다 — 붙일 때 당신 경로로 바꿔라.
- 모든 파일 경로는 저장소 루트(`RAON-RT-Revision-main/`) 기준 상대경로다.

---

<a id="1-overview"></a>
#### 1. 개요 & 오리엔테이션 (계층·데이터 흐름·디렉토리 맵)

##### 1.1 5계층 아키텍처 (아래→위 = 하드웨어→응용)

```
┌───────────────────────────────────────────────────────────────────────────┐
│  App/  ── 응용·제어 계층 ("이 로봇만의 로직")                                 │
│     Indy7 (bare RT+ViSP) │ Indy7_ROS2 (+ROS2) │ Indy7_ROS2_Mujoco (+MuJoCo) │
│     CRobotIndy7 · CControllerFullDynamicsRT(RBDL) · VisualServo · CalibUtils │
├───────────────────────────────────────────────────────────────────────────┤
│  CRobot/  ── 로봇 하드웨어 추상화 계층 (HAL)                                  │
│     CRobot(오케스트레이터·RT태스크·마스터 소유)                              │
│     CAxis←CAxisCIA402←CAxisNRMKCore (+시뮬 축 AxisRT/AxisMuJoCo/AxisRTMuJoCo)│
│     CSensor←CSensorFT←CSensorNRMKEndTool · CKistarHand · CConfigRobot · CExtInterface │
├───────────────────────────────────────────────────────────────────────────┤
│  EMasterApp/  ── EtherCAT 마스터 라이브러리  →  libEMasterApp.{a,so}          │
│     CEcatMaster(2도메인) · CEcatSlaveBase · CSlaveCIA402Base(CST) · Slave*   │
├───────────────────────────────────────────────────────────────────────────┤
│  Global/  ── 공용 유틸: ConfigParser(INI) · Defines.h · CRC16 · Socket ·     │
│              Serial · ROS2* 브릿지                                           │
├───────────────────────────────────────────────────────────────────────────┤
│  외부(저장소 밖, 선설치): IgH EtherLab /opt/etherlab · rtposix /opt/rt_posix ·│
│     RBDL · Eigen3 · ViSP+RealSense · MuJoCo · ROS2(jazzy/humble)             │
└───────────────────────────────────────────────────────────────────────────┘
```

핵심 상속(자세히는 각 섹션): `CRobotIndy7 ▹ CRobot` · `CControllerFullDynamicsRT ▹ CController` · `CAxisNRMKCore ▹ CAxisCIA402 ▹ CAxis` · `CSensorNRMKEndTool ▹ CSensorFT ▹ CSensor` · `CSlaveCIA402Base ▹ CEcatSlaveBase`. 축·센서·슬레이브가 모두 동일 추상 인터페이스를 제시하므로 **상위 제어기는 실물/시뮬을 구분하지 못한다**(드롭인 교체).

##### 1.2 1 ms 제어 루프 (심장부 데이터 흐름)

```
                 rtposix RT 태스크 (SCHED_FIFO, PREEMPT_RT)
  proc_ethercat_control (1ms, P95)          proc_main_control (1ms, P97)
  ─────────────────────────────────         ──────────────────────────────
  wait_next_period()                         wait_next_period()
  master->ReadSlaves()  ── ecrt_master_receive→domain_process→각 슬레이브
        ↓ (슬레이브 콜백 OnSlaveUpdateRawParam → 축에 q,q̇,τ 반영)
  [축에서 q, q̇ 읽기]  ───────────────────▶  controller->Update(q,q̇,τ → τ_out)
                                                  (RBDL: 중력보상/CTC/풀다이내믹/IK)
  master->WriteSlaves(appTime)  ◀──────────  각 축 MoveTorque(τ_out)
        └ ecrt_domain_queue→master_send (+DC sync_ref/slave clocks)
```
1 사이클 = **q,q̇ 읽기 → 토크 τ 계산 → 각 축 `MoveTorque(τ)` → 슬레이브로 송신**. EtherCAT은 DC 켜짐 1 ms 주기, 우선순위 97/95. **주의**: 이 마스터는 입력/출력 **2개 도메인**을 써서 사이클당 `receive/send`를 **2회** 수행한다([§3.3](#3-emaster-core)) — KV260 CPU/버스 예산에 반영.

##### 1.3 디렉토리 맵 (소스만; build/obj/log/데이터 제외)

| 경로 | 역할 | 상세 |
|---|---|---|
| `EMasterApp/Device/` | **EtherCAT 마스터·슬레이브 핵심** (IgH 래퍼) | §3, §4 |
| `EMasterApp/Interface/` | `CEcatInterface` — TCP 7421 상태서버(**미빌드·대부분 스텁**) | §3.6 |
| `EMasterApp/Makefile` | `libEMasterApp.{a,so}` 빌드(`-lethercat`,`-lrtposix`) | §2.1 |
| `CRobot/` | 로봇 HAL: 축·센서·핸드·로봇 베이스·설정·외부IF·MuJoCo뷰 | §5, §6, §7 |
| `Global/` | `ConfigParser`(INI)·`Defines.h`(전역 타입/매크로/구조체) | §8 |
| `Global/Comm/` | `CRC16`·`Socket`·`Serial`·`ROS2*`(브릿지) | §8, §9 |
| `App/Indy7/` | **주력 앱** — bare RT 토크제어 + ViSP 비주얼서보 | §10 |
| `App/Indy7_ROS2/` | Indy7 + ROS2(Jazzy) `indy_iface` 미들웨어 | §11 |
| `App/Indy7_ROS2_Mujoco/` | Indy7 + ROS2(Humble) + MuJoCo 시뮬 + GLFW | §11 |
| `App/CalibUtils/` | 눈-손(eye-to-hand) 카메라-로봇 캘리브레이션 | §12 |
| `Config/` | `8_axis_testbed.cfg`(샘플 8축 테스트베드 설정) | §2.2 |
| `include/`, `lib/` | `make install`이 스테이징한 EMasterApp 헤더/라이브러리 사본 | §2.2 |
| `arch.puml`·`deployment.puml`·`summary.md` | 원본 문서(App/Indy7 한정) | — |

##### 1.4 재사용 판단 요약 (자세히는 §13)

- **그대로 재사용 후보**: `EMasterApp`(IgH 래퍼)·`CEcatSlaveBase`/`CSlaveCIA402Base`(CST 서보)·`CRobot`의 설정-구동 RT 태스크 모델·`.cfg` 포맷·`CAxisNRMKCore` 토크 변환.
- **붙이기 전 반드시 손봐야 할 것**: `rtposix` 의존(저장소 밖 KIST 라이브러리 — shim 필요), `-mtune=native`(aarch64 크로스 시 교체), 다수의 하드코딩 `/opt`·`/home/raimlab` 경로, 그리고 검증된 버그들(비-NRMK 드라이브의 항등 토크 변환, unsigned 비교로 죽은 PDO 실패 가드, KistFT/KistarHand 레지스터 맵, `OnRecvAxisCommand` 스텁 등 → §14).

---
#### 2. Build system, configuration format, and external dependencies

All paths below are repo-relative to `/home/ubuntu/RAON-RT-Revision-main` (referred to as `$ROOT`). The build is plain GNU `make` + `g++` (no CMake, no autotools). There are **6 Makefiles**: one root aggregator, one that builds the shared EtherCAT library (`EMasterApp/Makefile`), three that build the Indy7 control executable in three variants (`App/Indy7`, `App/Indy7_ROS2`, `App/Indy7_ROS2_Mujoco`), and one standalone calibration tool (`App/CalibUtils`). **The root Makefile does NOT build the App executables** — it only builds/installs the EtherCAT library. Each App is built separately by `cd`-ing into its directory and running `make`.

##### 2.1 Build graph — what `make` does at each level

`Makefile` (root, 69 LOC) — role: aggregator that builds & installs only the EtherCAT library.

| Target | Action |
|---|---|
| `all` (default) | `= library_ecat` only. (Line 25 `all: library_ecat examples` is commented out; `examples` is never built by default.) |
| `library_ecat` | `cd EMasterApp/ && make install` — builds the `.so`/`.a` and copies headers+libs into `$ROOT/include/EMasterApp` and `$ROOT/lib/EMasterApp`. |
| `install` | depends on `library_ecat`, then creates `/opt/emaster_app`, copies `$ROOT/include/EMasterApp/*` → `/opt/emaster_app/include/` and `$ROOT/lib/EMasterApp/*` → `/opt/emaster_app/lib`. |
| `examples` | `cd Examples/SuperMicroSurgery/ && make install` + copies `Config/*` into `bin/`. **The `Examples/` dir does not exist in this repo — this target and `distclean` will fail.** |
| `clean` | removes `$ROOT/include`, `$ROOT/lib`, `$ROOT/bin`. |
| `distclean` | `clean` + `make clean` in `EMasterApp` and `Examples/SuperMicroSurgery` (**latter path missing → fails**). |
| `re` / `re_hard` | `clean;all` / `distclean;all`. |

Root vars: `DESTDIR ?= /opt`, `INSTALL_DIR = $(DESTDIR)/emaster_app`. `ROBOT_DIR=./CRobot`. Note: `EMasterApp/Makefile` has a stale `ROBOT_DIR=../CIIRobotRT` (unused).

`EMasterApp/Makefile` (109 LOC) — role: builds `libEMasterApp.so` + `libEMasterApp.a` (the IgH EtherCAT device/slave abstraction).

- **Compiled sources (SOURCES)** — only 4 `.cpp`:
  - `EMasterApp/Device/EcatMasterBase.cpp`
  - `EMasterApp/Device/EcatSlaveBase.cpp`
  - `EMasterApp/Device/SlaveCIA402Base.cpp`
  - `EMasterApp/Device/SlaveNRMKEndTool.cpp`
  - **NOT compiled** into the lib (present in tree but absent from SOURCES): `Device/SlaveKistarHand.cpp` and `Interface/EcatInterface.cpp`. Their headers are still shipped (see below).
- **Includes (`CFLAGS`)**: `-I$(DEVICE_DIR)`(=`EMasterApp/Device`) `-I$(GLOBAL_DIR)`(=`Global`) `-I/opt/etherlab/include` `-I/opt/rt_posix/include`.
- **Compiler flags**: `CFLAGS_OPTIONS = -Wall -O3 -mtune=native -flto`; objects compiled with `-MD ... -c -g`; shared object with `-g -shared -fPIC`.
- **Link (`LDFLAGS`)**: `-lm -lrt -lpthread -L/opt/etherlab/lib -lethercat -L/opt/rt_posix/lib -lrtposix`.
- **Outputs**: `EMasterApp/obj/*.o`, `EMasterApp/lib/libEMasterApp.{so,a}` (static via `ar rc` + `ranlib`).
- **`install` target** (invoked by root `library_ecat`): copies **all** `Device/*.h` → `$ROOT/include/EMasterApp` and `EMasterApp/lib/*` → `$ROOT/lib/EMasterApp`. Headers shipped therefore include ones whose `.cpp` isn't compiled: `EcatCommon.h, EcatMasterBase.h, EcatSlaveBase.h, SlaveCIA402Base.h, SlaveNRMKEndTool.h, SlaveELMO.h, SlaveEPOS4.h, SlaveKistFT.h, SlaveFBGSensor.h, SlaveKistarHand.h, SlaveBeckhoffCU1124.h, SlaveBeckhoffEK1100.h, SlaveBeckhoffEL2024.h`.
- Vars: `THIRD_PARTY_DIR=/opt`, `IGH_DIR=/opt/etherlab`, `RT_POSIX_DIR=/opt/rt_posix`, `CC=g++`, `INSTALL_DIR=..` (repo root).

##### 2.2 `/opt` install layout (after `make install` at root)

```
/opt/emaster_app/
├── include/            <- all EMasterApp/Device/*.h
│   ├── EcatCommon.h, EcatMasterBase.h, EcatSlaveBase.h,
│   ├── SlaveCIA402Base.h, SlaveNRMKEndTool.h, SlaveELMO.h, SlaveEPOS4.h,
│   └── SlaveKistFT.h, SlaveFBGSensor.h, SlaveKistarHand.h, SlaveBeckhoff*.h
└── lib/
    ├── libEMasterApp.so
    └── libEMasterApp.a
```
The Apps consume this via `-I/opt/emaster_app/include` and `-L/opt/emaster_app/lib -lEMasterApp`. The two sibling third-party trees the Apps also depend on are `/opt/etherlab` (IgH) and `/opt/rt_posix` (rtposix), each with `include/` and `lib/`.

##### 2.3 App Makefile matrix

All three Indy7 Makefiles share the same skeleton: `PROJ_ROOT_DIR=../..`, `ROBOT_DIR=$ROOT/CRobot`, `GLOBAL_DIR=$ROOT/Global`, `COMM_DIR=$ROOT/Global/Comm`, `CC=g++`, output `bin/Indy7Ctrl.out`, objects in `obj/`, per-file compile `g++ -MD $(CFLAGS) -c -o $@ $<`, final link `g++ -o bin/Indy7Ctrl.out $(OBJECTS) $(LDFLAGS)`. `install` copies `bin/*` → `$ROOT/bin`. Differences:

| Aspect | `App/Indy7/Makefile` (119 LOC) | `App/Indy7_ROS2/Makefile` (157 LOC) | `App/Indy7_ROS2_Mujoco/Makefile` (180 LOC) |
|---|---|---|---|
| Purpose | Bare RT control + ViSP visual servo + RealSense | + ROS2 (Jazzy) indy_iface middleware | + ROS2 (Humble) + MuJoCo sim + GLFW render |
| `CFLAGS_OPTIONS` | `-w -O2 -std=gnu++17 -Dlinux -mtune=native -std=c++17 -shared-libgcc -fexceptions` (**no `-flto`, no `-DNDEBUG`**) | `-w -O3 -std=gnu++17 -DNDEBUG -Dlinux -mtune=native -flto -std=c++17 -shared-libgcc -fexceptions -D_GNU_SOURCE -include cstdio -include cstring -include cstdlib` | same as ROS2 col + `-DMUJOCO_ENABLED` |
| ROS distro | none | `/opt/ros/jazzy` | `/opt/ros/humble` |
| ROS include gen | n/a | `find /opt/ros/jazzy/include -maxdepth 1 -type d \| sed 's/^/-I/'` (dynamic) | explicit `-I` list (rclcpp, std_msgs, rcl, rcutils, rmw, rosidl_*, builtin_interfaces, tracetools, statistics_msgs, …) |
| Extra `-I` | ViSP (`/home/raimlab/visp/build/include`, `.../modules/{detection,sensor,core,io}/include`), `/usr/include/opencv4`, `/usr/include/pcl-1.14` | `-I/usr/include -I/usr/include/c++/11`, indy_iface | + MuJoCo `-I/home/raimlab/dev_env/mujoco-2.3.7/include` |
| Extra libs | `-lrbdl -lrbdl_urdfreader`, ViSP `-lvisp_core -lvisp_io -lvisp_detection -lvisp_sensor`, `-L/usr/local/lib/x86_64-linux-gnu -lrealsense2` | `-lrbdl -lrbdl_urdfreader`, full `LDFLAGS_ROS` (indy_iface rosidl typesupports + rclcpp/rcl/rcutils/rmw/std_msgs/builtin_interfaces/tracetools/statistics) | ROS libs + `-lmujoco`, `-lrbdl -lrbdl_urdfreader -lglfw -lGL -ldl` |
| Common libs | `-lm -lrt -lpthread -L/opt/emaster_app/lib -lEMasterApp -L/opt/rt_posix/lib -lrtposix` (all three) | same | same |

**Source lists (SOURCES) per App** (shared prefix from `Global`/`CRobot` in all three):

| Source | Indy7 | Indy7_ROS2 | Indy7_ROS2_Mujoco |
|---|---|---|---|
| `Global/ConfigParser.cpp`, `Global/Comm/CRC16.cpp`, `Global/Comm/Socket.cpp` | ✓ | ✓ | ✓ |
| `Global/Comm/ROS2Node.cpp`, `ROS2Executor.cpp`, `ROS2IndyIface.cpp` | — | ✓ | ✓ |
| `CRobot/Axis.cpp`, `AxisCIA402.cpp`, `AxisNRMKCore.cpp`, `Sensor.cpp`, `SensorFT.cpp`, `SensorNRMKEndTool.cpp`, `ConfigRobot.cpp`, `ExtInterface.cpp`, `Robot.cpp` | ✓ | ✓ | ✓ |
| `./Controller.cpp`, `./FullDynControllerRT.cpp`, `./Indy7Ctrl.cpp`, `./main.cpp` | ✓ | ✓ | ✓ |
| `./CalibCapture.cpp`, `./VisualServo.cpp` | ✓ | — | — |
| `CRobot/AxisRT.cpp`, `CRobot/AxisRTMuJoCo.cpp`, `CRobot/MuJoCoVisualization.cpp` | — | — | ✓ |

`App/CalibUtils/Makefile` (27 LOC) — role: standalone one-file tool `save_camera_params` (hand-eye/camera-intrinsics helper), **not part of the main build graph**.
- Rule: `g++ $(CFLAGS) -o save_camera_params save_camera_params.cpp $(LDFLAGS)`.
- `CFLAGS = -w -O2 -std=c++17` + ViSP includes (`/home/raimlab/visp/build/include`, `.../modules/{core,sensor,io}/include`) + `-I/usr/local/include` (RealSense) + `-I/usr/include/opencv4` `-I/usr/include/pcl-1.14` `-I/usr/include/eigen3`.
- `LDFLAGS = -L/home/raimlab/visp/build/lib -lvisp_core -lvisp_sensor -lvisp_io -L/usr/local/lib -lrealsense2 -Wl,-rpath,/home/raimlab/visp/build/lib`.

##### 2.4 `.cfg` configuration format — complete reference

Format is **Windows-INI style**, parsed by `Global/ConfigParser.cpp` (a Linux reimplementation of the Win32 profile API) and consumed by `CRobot/ConfigRobot.cpp`. Syntax rules: `[SECTION]` headers; `KEY=VALUE` lines; `;` begins a comment (whole-line or trailing, e.g. `TORQUE_LIMIT_U=2110;` and section-header trailing comments). Whitespace around `=` is tolerated (`VENDOR_ID = 0x...`). Keys are read individually with defaults, so **any key may be omitted** (falls back to the default shown). Sections are addressed positionally: `TASK0..TASKn`, `AXIS0..AXISn`.

**INI parser API (`Global/ConfigParser.h`)** — the only signatures used to read cfg:

| Signature | Semantics |
|---|---|
| `size_t GetPrivateProfileString(const char* section, const char* entry, const char* def, char* buffer, size_t buffer_len, const char* file_name)` | Read string value of `entry` in `section`; writes `def` if missing. Almost all keys use this (then `atoi`/`atof`/`std::stoul`). |
| `int GetPrivateProfileInt(const char* section, const char* entry, int defval, const char* fname)` | Integer read variant (declared; ConfigRobot uses the string form). |
| `BOOL WritePrivateProfileString(const char* section, const char* entry, const char* def, const char* file_name)` | Write value back into the cfg. Used by `CConfigRobot::WriteLastPosition` to persist `POS_BEFORE_EXIT` per axis on shutdown. |
| `BOOL IsExistFile(const char*)`, `BOOL IsExistDir(const char*)` | Path existence checks. |

Parsing quirks (from `ConfigRobot.cpp`): `VENDOR_ID`, `PRODUCT_CODE` are `std::stoul(str, NULL, 16)` (**hex**, fall back to decimal `atoi` on non-hex). `DC_ACTIVATE_WORD` is hex→`UINT16`. Everything else is `atoi` (int) or `atof` (double). `POS_BEFORE_EXIT` is read as int and re-written on exit.

**`[SYSTEM]` section** (read by `ReadSystemConfig`):

| Key | Type/Unit | Default | Meaning |
|---|---|---|---|
| `NAME` | string | `"ROBOT"` | Robot/config display name. |
| `SIMULATION_MODE` | bool 0/1 | 0 | Run without hardware. |
| `AGING_TEST` | bool 0/1 | 0 | Aging/burn-in mode. |
| `AGING_DURATION` | int seconds | 60 | Aging duration (note: source bug — stored into `bAging`, not a duration field). |
| `URDF_PATH` | path string | `TEST.urdf` | RBDL model path (hardcoded absolute in INDY7 cfgs, see §2.7). |
| `MOJUCO_XML_PATH` | path string | `TEST.xml` | MuJoCo model path (key literally spelled `MOJUCO_XML_PATH`). |
| `ROBOT_DOF` | int | 0 | Number of controlled joints; sizes the `KP_/KD_` vectors. |
| `KP_n` / `KD_n` | double | 0.0 | Per-joint P/D gains for `n = 0..ROBOT_DOF-1`. |
| `ENABLE_CONTROLLER_AT_STARTUP` | bool 0/1 | 0 | Auto-enable controller on boot. |
| `DEFAULT_CONTROLLER_MODE` | int | 0 | Initial controller mode. |
| `EXTERNAL_INTERFACE_ENABLED` | bool 0/1 | 0 | Enable external TCP interface. |
| `EXTERNAL_INTERFACE_PORT` | int | 7420 | External interface TCP port. |
| `TELEOPERATION_MODE` | int | 0 | Teleop mode selector. |
| `TELEOPERATION_CONSTANT_SCALING` | double | 0.3 | Teleop scaling ratio. |

**`[RT_TASKS]` + `[TASKn]`** (read by `ReadRTTaskConfig`) — `[RT_TASKS]` has one key `NO_OF_TASKS` (int, default 0). Each `[TASKn]`:

| Key | Type/Unit | Default | Meaning |
|---|---|---|---|
| `ENABLED` | bool 0/1 | 0 | Create the RT thread. |
| `NAME` | string | `"NULL"` | Task label. |
| `PRIORITY` | int 0–99 | 0 | RT priority (0 lowest … 99 highest); maps to POSIX SCHED_FIFO prio. |
| `TASK_PERIOD` | int **nanoseconds** | 0 | Cycle period; `0` = event/aperiodic (e.g. keyboard, logger). |
| `START_DELAY` | int **nanoseconds** | 0 | Delay before first activation. |

**`[ECAT_MASTER]`** (read by `ReadEtherCATConfig`):

| Key | Type/Unit | Default | Meaning |
|---|---|---|---|
| `SLAVENUMBER` | int | 0 | Number of `[AXISn]` sections iterated (0..N-1). |
| `SLAVEHANDNUMBER` | int | 0 | Number of hand slaves (parsed; not present in shipped cfgs). |
| `DC_ENABLED` | bool 0/1 | 0 | Enable EtherCAT Distributed Clock. |
| `CYCLE_TIME` | int **nanoseconds** | 0 | EtherCAT cycle time (comment: TODO tie to main task period). |

**`[AXISn]`** (per-slave; read by `ReadEtherCATConfig`). Full key set (superset — not every cfg uses all):

| Key | Type/Unit | Default | Meaning |
|---|---|---|---|
| `ENABLED` | bool | 0 | Slave active in config. |
| `CONNECTED` | bool | 0 | Slave physically present. |
| `NAME` | string | `"EtherCAT Slave"` | Axis label. |
| `PHYSICAL_POS` | int | 0 | Position in the EtherCAT daisy-chain (ring position). |
| `VENDOR_ID` | **hex** UINT32 | 0 | EtherCAT vendor ID (SDO/slave identity). |
| `PRODUCT_CODE` | **hex** UINT32 | 0 | EtherCAT product code. |
| `DC_SUPPORT` | bool | 0 | Slave supports DC. |
| `DC_ACTIVATE_WORD` | **hex** UINT16 | 0 | DC sync activation word (e.g. 0x0300 style AssignActivate). |
| `DC_SYNC0_SHIFT` | int ns | 0 | SYNC0 shift time. |
| `SLAVE_TYPE` | int | 0 | 0 = CIA402 servo drive; 1 = NRMK end tool (EOAT). |
| `AUTO_SERVO_ON` | bool | 0 | Auto servo-on at startup. |
| `ABSOLUTE_ENCODER` | bool | 0 | 0 = incremental, 1 = absolute. |
| `MOVE_CCW` | bool | 0 | 0 = CW, 1 = CCW direction convention. |
| `JOINT_TYPE` | int | 0 | 0 Revolute, 1 Continuous, 2 Prismatic, 3 Planar, 16 Fixed, 17 Floating, 18 Jointless. |
| `DRIVE_MODE` | int | 1 | CIA402 mode: 1 ProfilePos, 3 ProfileVel, 4 ProfileTorque, 6 Homing, 7 InterpolatedPos, 8 CyclicPos (CSP), 9 CyclicVel (CSV), 10 CyclicTorque (CST). |
| `ENCODER_RESOLUTION` | double counts/rev | 0 | Encoder counts per revolution. |
| `GEAR_RATIO` | double | 0 | Reduction ratio. |
| `TRANSMISSION_RATIO` | double | 0 | Extra transmission ratio (INDY7 = 1.0). |
| `TORQUE_CONSTANT` | double (N·m/A) | 0 | Motor torque constant (INDY7 only). |
| `CURRENT_RATIO` | double | 0 | Current scaling (rated-current mapping; INDY7 = 48 / 96). |
| `ONE_TURN_REF` | double | 0 | Reference per turn — 2·π for revolute (rad), else lead/pitch; INDY7 uses 360.0 (deg). |
| `HOMING_METHOD` | int | 0 | 1 = set start pos as home, 2 = search with reference, 3 = set home manually, 4 = drive built-in homing. |
| `HOME_POSITION_OFFSET` | int (raw counts) | 0 | Home offset (raw encoder counts). |
| `HOME_SEARCH_REFERENCE` | double | 0 | Reference used when `HOMING_METHOD=2`. |
| `OPERATING_VELOCITY` | double **RPM** | 0 | Nominal move velocity. |
| `OPERATING_ACCELERATION` / `OPERATING_DECELERATION` | double | 0 | Nominal accel/decel. |
| `POSITION_LIMIT_U` / `_L` | double **degree** | 0 | Upper/lower position limits. |
| `VELOCITY_LIMIT_U` / `_L` | double **RPM** | 0 | Velocity limits. |
| `ACCELERATION_LIMIT_U`/`_L`, `DECELERATION_LIMIT_U`/`_L` | double | 0 | Accel/decel limits. |
| `TORQUE_LIMIT_U` / `_L` | double | 0 | Torque limits (unit not specified in code/comments; 8-axis uses ‰-of-rated style `2110`, INDY7 uses small values like `117.73/47.5/21.0`). |
| `JERK_LIMIT_U` / `_L` | double | 0 | Jerk limits (all cfgs = 0). |
| `RATED_TORQUE` | double | 0 | Rated torque (parsed; not set in shipped cfgs). |
| `RATED_CURRENT` | double | 0 | Rated current (parsed; not set in shipped cfgs). |
| `POS_BEFORE_EXIT` | int (raw counts) | 0 | Last raw position; **written back** on shutdown by `WriteLastPosition`. |

##### 2.5 `8_axis_testbed.cfg` vs `INDY7.cfg` — concrete comparison

| Item | `Config/8_axis_testbed.cfg` | `App/Indy7*/INDY7.cfg` |
|---|---|---|
| SYSTEM NAME | `8-AXIS TESTBED` | `INDY7` |
| Robot dynamics keys | none (no URDF/DOF/KP/KD) | `URDF_PATH`, `ROBOT_DOF=6`, `KP_0..5`=800/600/400/200/150/100, `KD_0..5`=80/60/40/20/15/10, `TELEOPERATION_MODE=2`, `ENABLE_CONTROLLER_AT_STARTUP=1`, `DEFAULT_CONTROLLER_MODE=0` |
| RT tasks | `NO_OF_TASKS=4`; TASK0 "EtherCAT and Main Control" prio 99 @1 ms; TASK1 keyboard prio 50 aperiodic; TASK2 printer prio 49 @1 s (disabled); TASK3 PI ctrl prio 89 @10 ms (disabled) | `NO_OF_TASKS=5–6`; TASK0 "Main Control" prio 97 @1 ms; TASK1 "EtherCAT Control" prio 95 @1 ms; TASK2 keyboard prio 50; TASK3 printer prio 49 @1 s; TASK4 logger prio 30; (Indy7 non-ROS also TASK5 "Visual Servo" prio 20). **Main & EtherCAT split into two tasks (97/95) vs single task (99).** |
| SLAVENUMBER / DC | 8 slaves, `DC_ENABLED=1`, `CYCLE_TIME=1000000` (1 ms) | 7 slaves, `DC_ENABLED=1`, `CYCLE_TIME=1000000` |
| VENDOR_ID | `0x000000fb` (all axes) | `0x0000089a` (all axes) |
| PRODUCT_CODE | `0x60500000` (AXIS0,2–7), `0x61500000` (AXIS1) | `0x30000000` (AXIS0–5 CIA402 servo), `0x10000007` (AXIS6 EOAT) |
| DRIVE_MODE | `1` (Profile Position) | `10` (Cyclic Synchronous Torque / CST) |
| ENCODER_RESOLUTION | 4096 or 2048 | 65536 |
| GEAR_RATIO | 30/16/100/100/1/1/1/1 | 121 (J0–2), 101 (J3–5) |
| TORQUE_CONSTANT / CURRENT_RATIO / TRANSMISSION_RATIO / SLAVE_TYPE / AUTO_SERVO_ON | absent | present (e.g. J0 `TORQUE_CONSTANT=0.0884`, `CURRENT_RATIO=48.0`, `TRANSMISSION_RATIO=1.0`, `SLAVE_TYPE=0`, `AUTO_SERVO_ON=1`) |
| ONE_TURN_REF | 1.0 (AXIS0) / 2.0 (others) | 360.0 |
| HOMING_METHOD | 1 (all) | 3 (J0–3), 1 (J4–5) |
| POSITION_LIMIT_U/L | ±360 (rev) / ±10800 (spindle axes) | ±35 |
| TORQUE_LIMIT_U | 2110 (all) | 117.73 / 47.5 / 21.0 |
| POS_BEFORE_EXIT | absent | present per axis (persisted home) |
| AXIS6 (EOAT) | n/a | minimal section: only `ENABLED/CONNECTED/NAME=EOAT/PHYSICAL_POS=6/VENDOR_ID/PRODUCT_CODE=0x10000007/SLAVE_TYPE=1` (NRMK end-tool, no motion params) |

`CRobot/ELMO.cfg` (ELMO test bench, 3 slaves declared but only `[AXIS1]`+`[AXIS3]` defined): `DC_ENABLED=0`, `VENDOR_ID=0x0000009a`, `PRODUCT_CODE=0x00100002`, `DRIVE_MODE=1`, `ENCODER_RESOLUTION=8192`, `AXIS3` uses `JOINT_TYPE=2` (prismatic). Uses `TRANSMISSION_RATIO` + `POS_BEFORE_EXIT` but no torque-constant/current keys. The three INDY7 cfgs differ only in `URDF_PATH` (`indy7.urdf` vs `indy7_v2.urdf` for ROS2), task count (Indy7=6 with Visual Servo; ROS2=5; Mujoco=5 with disabled PI task) and per-axis `HOME_POSITION_OFFSET`/`POS_BEFORE_EXIT` calibration values.

##### 2.6 Consolidated external dependencies

| Dependency | Purpose | Expected install path | Link/Include | Needed by |
|---|---|---|---|---|
| IgH EtherLab EtherCAT master | EtherCAT master userspace API (`ecrt.h`) | `/opt/etherlab` (`include/`,`lib/`) | `-lethercat` | EMasterApp lib + all Apps (via include path) |
| rtposix | RT POSIX task/thread abstraction | `/opt/rt_posix` (`include/`,`lib/`) | `-lrtposix` | EMasterApp lib + all Apps |
| EMasterApp (this repo) | EtherCAT device/slave layer | `/opt/emaster_app` (`include/`,`lib/`) | `-lEMasterApp` | all Apps |
| RBDL + urdfreader | Rigid-body dynamics from URDF | system libs (no path in cfg; `-l` only) | `-lrbdl -lrbdl_urdfreader` | all 3 Indy7 Apps |
| Eigen3 | linear algebra (headers only) | `/usr/include/eigen3` | `-I` only | all Indy7 Apps + CalibUtils |
| ViSP | hand-eye calib / visual servoing | `/home/raimlab/visp/build` (+ `/home/raimlab/visp/modules`) | `-lvisp_core -lvisp_io -lvisp_detection -lvisp_sensor` | `App/Indy7` + `App/CalibUtils` |
| librealsense2 | Intel RealSense camera | `/usr/local/lib/x86_64-linux-gnu` (Indy7), `/usr/local/lib` (CalibUtils); hdrs `/usr/local/include` | `-lrealsense2` | `App/Indy7` + `App/CalibUtils` |
| OpenCV 4 | vision (ViSP dep) | `/usr/include/opencv4` | `-I` only | `App/Indy7` + `App/CalibUtils` |
| PCL 1.14 | point cloud (ViSP dep) | `/usr/include/pcl-1.14` | `-I` only | `App/Indy7` + `App/CalibUtils` |
| ROS 2 **Jazzy** | middleware (rclcpp/rcl/rmw/std_msgs/…) | `/opt/ros/jazzy` | full `LDFLAGS_ROS` | `App/Indy7_ROS2` |
| ROS 2 **Humble** | middleware (same set) | `/opt/ros/humble` | full `LDFLAGS_ROS` | `App/Indy7_ROS2_Mujoco` |
| `indy_iface` (custom ROS2 msgs) | Indy interface msg typesupports | `/home/raimlab/ros_ws/install/indy_iface` | `-lindy_iface__rosidl_*` | both ROS2 Apps |
| MuJoCo 2.3.7 | physics simulation | `/home/raimlab/dev_env/mujoco-2.3.7` | `-lmujoco` + `-DMUJOCO_ENABLED` | `App/Indy7_ROS2_Mujoco` |
| GLFW + OpenGL + libdl | MuJoCo rendering window | system | `-lglfw -lGL -ldl` | `App/Indy7_ROS2_Mujoco` |
| pthread / librt / libm | RT threads, timers, math | system | `-lpthread -lrt -lm` | EMasterApp + all Apps |
| system C++ headers | `/usr/include`, `/usr/include/c++/11` | system (gcc 11) | `-I` only | both ROS2 Apps |

##### 2.7 Every hardcoded absolute path found

| Path | File(s) | Note |
|---|---|---|
| `/opt`, `/opt/etherlab`, `/opt/rt_posix`, `/opt/emaster_app` | root + EMasterApp + all App Makefiles | third-party + install roots |
| `/usr/include/eigen3` | Indy7*/CalibUtils Makefiles | Eigen headers |
| `/usr/include/opencv4`, `/usr/include/pcl-1.14` | Indy7 + CalibUtils Makefiles | vision headers |
| `/usr/include`, `/usr/include/c++/11` | Indy7_ROS2 + Mujoco Makefiles | gcc-11 std headers hardcoded |
| `/home/raimlab/visp/build/include`, `/home/raimlab/visp/build/lib`, `/home/raimlab/visp/modules` | Indy7 + CalibUtils Makefiles | ViSP build tree (user home) |
| `/usr/local/lib/x86_64-linux-gnu` | `App/Indy7/Makefile` (realsense) | **x86 triplet path — wrong on Kria ARM (aarch64)** |
| `/usr/local/include`, `/usr/local/lib` | `App/CalibUtils/Makefile` | RealSense install |
| `/opt/ros/jazzy` | `App/Indy7_ROS2/Makefile` | ROS 2 Jazzy |
| `/opt/ros/humble` | `App/Indy7_ROS2_Mujoco/Makefile` | ROS 2 Humble (distro mismatch vs Jazzy) |
| `/home/raimlab/ros_ws/install/indy_iface` | both ROS2 Makefiles | custom msg pkg (user home) |
| `/home/raimlab/dev_env/mujoco-2.3.7` | Mujoco Makefile | MuJoCo (user home; x86 build likely) |
| `/home/raimlab/RAON-RT/App/Indy7/indy7.urdf` | `App/Indy7/INDY7.cfg`, `App/Indy7_ROS2_Mujoco/INDY7.cfg` (`URDF_PATH`) | model path baked into cfg (user home; note dir `RAON-RT`, not this repo dir) |
| `/home/raimlab/RAON-RT/App/Indy7/indy7_v2.urdf` | `App/Indy7_ROS2/INDY7.cfg` (`URDF_PATH`) | v2 model path |

##### 2.8 Integration caveats for the EtherCAT + PREEMPT_RT (Kria KV260 ARM) target

- **Root `make` builds only `libEMasterApp`.** To get a runnable controller you must build an App separately (`cd App/Indy7[...] && make`), and that App expects `/opt/emaster_app`, `/opt/etherlab`, `/opt/rt_posix` already populated (run root `make install` first, and install IgH + rtposix into `/opt`).
- `-mtune=native` (all Makefiles) and `-flto` (EMasterApp + ROS2 Apps) assume compiling **on** the target. Cross-compiling for aarch64 requires removing/overriding `-mtune=native`.
- **x86-specific paths that will break on the KV260 ARM build**: `-L/usr/local/lib/x86_64-linux-gnu` (RealSense, Indy7), MuJoCo 2.3.7 tree under `/home/raimlab/dev_env` (likely x86 binaries), and the `-I/usr/include/c++/11` hardcode (must match the ARM toolchain's gcc version).
- **ROS 2 distro is inconsistent**: `Indy7_ROS2` → Jazzy, `Indy7_ROS2_Mujoco` → Humble. Choose one and align `ROS_DIR` + rebuild `indy_iface` for it.
- **`examples`/`distclean` targets reference a non-existent `Examples/SuperMicroSurgery` dir** and will fail — do not run them.
- The EtherCAT device library links against `libethercat` (IgH userspace lib); the actual `ec_master` kernel module + a NIC EtherCAT driver must be provided at runtime by the IgH install — not built here.
- Two `.cpp` shipped headers (`SlaveKistarHand.cpp`, `Interface/EcatInterface.cpp`) are **not compiled** into `libEMasterApp`; any App needing those slave types must add them to SOURCES.
- Torque-limit units are undocumented in the cfg/code; the two robot families use very different numeric scales (8-axis `2110` vs INDY7 `21–117`). Verify against the actual drive's CIA402 object scaling before enabling torque mode (INDY7 runs `DRIVE_MODE=10`/CST).
- `MOJUCO_XML_PATH` key is misspelled but is the literal key the parser reads; `AGING_DURATION` is parsed into the wrong struct field (`bAging`) — a latent bug, duration is effectively ignored.

---
<a id="3-emaster-core"></a>
#### 3. EtherCAT Master Library — `EMasterApp` core (over IgH EtherLab)

The `EMasterApp/` module is the RAON-RT EtherCAT master. It is a thin, object-oriented C++ wrapper over the **IgH EtherLab** master library (`ecrt.h`, `libethercat`). It provides three cooperating pieces: `CEcatMasterBase` (aliased `CEcatMaster`) — one master, two domains, N slaves; `CEcatSlaveBase` — per-slave configuration + process-data accessors that concrete slaves (CIA402, NRMK end-tool, Beckhoff terminals, Kistar hand, FT sensors) subclass; and `EcatCommon.h` — shared typedefs/enums/CIA402 constants. `CEcatInterface` is a separate TCP command server (see caveat: NOT built into the library, NOT used by `CRobot`). `CRobot`/`App` own a `CEcatMaster*`, register slaves via `AddSlave()`, call `Init(cycleTime, dcEnabled)`, then drive `ReadSlaves()`/`WriteSlaves(appTime)` from an rtposix RT task each cycle.

Author: Raimarius Delgado (KIST AIRI / ROBOGRAM LAB, 2022). All types (`UINT16`, `BOOL`, `BYTEARRAY`, `TSTRING`, `DBG_LOG_*`, `GetCurrTimeInNs()`) come from `Global/Defines.h`.

##### 3.1 Files, LOC, roles

| Path (repo-relative) | LOC | Role |
|---|---|---|
| `EMasterApp/Device/EcatCommon.h` | 253 | Shared EtherCAT typedefs, state-machine/device/domain enums, CIA402 control/status/mode constants, `stEcatMasterDesc`/`stEcatSlaveInfo` descriptors, DC-info struct. Header-only. |
| `EMasterApp/Device/EcatMasterBase.h` | 76 | Declares `CEcatMasterBase`; `typedef CEcatMasterBase CEcatMaster`. |
| `EMasterApp/Device/EcatMasterBase.cpp` | 391 | Master lifecycle + cyclic receive/process/queue/send over `ecrt_*`. |
| `EMasterApp/Device/EcatSlaveBase.h` | 120 | Declares `CEcatSlaveBase`; offset-name macros. |
| `EMasterApp/Device/EcatSlaveBase.cpp` | 374 | Per-slave config (`ecrt_master_slave_config`, PDO regs, DC), typed PDO read/write via `EC_READ_*`/`EC_WRITE_*`. |
| `EMasterApp/Interface/EcatInterface.h` | 177 | TCP command-server class + wire packet structs/enums. |
| `EMasterApp/Interface/EcatInterface.cpp` | 360 | TCP packet parse/build (CRC16-ARC), ECAT-state query handler. Mostly stubbed. |
| `EMasterApp/Makefile` | 108 | Builds `libEMasterApp.a`/`.so`; links `/opt/etherlab -lethercat`, `/opt/rt_posix -lrtposix`. |

##### 3.2 `EcatCommon.h` — types, enums, constants

**IgH type aliases** (all from `ecrt.h`): `ECAT_MASTER`=`ec_master_t`, `ECAT_DOMAIN`=`ec_domain_t`, `ECAT_SLAVE_CONFIG`=`ec_slave_config_t`, `ECAT_DOMAIN_PD`=`uint8_t` (process-data byte buffer), `ECAT_MASTER_STATE`=`ec_master_state_t`, `ECAT_DOMAIN_STATE`=`ec_domain_state_t`, `ECAT_SLAVE_CONFIG_STATE`=`ec_slave_config_state_t`, `ECAT_SYNC_INFO`=`ec_sync_info_t`. Each has a `P*` pointer alias. `ECAT_WC`=`unsigned int`.

**`ECAT_STATE_MACH`** (EtherCAT AL state, bitmask matching IgH): `eNONE=0x00`, `eINIT=0x01` (mailbox✗/PD✗), `ePRE_OP=0x02` (mailbox✓/PD✗), `eSAFE_OP=0x04` (mailbox✓/PD limited), `eOP=0x08` (mailbox✓/PD✓). Powers-of-two so numeric `<` ordering = state ordering; used to compute "lowest" aggregate state.

**`ECAT_WC_STATE`** (domain working-counter state): `eWC_NO_EXCHANGED=0`, `eWC_INCOMPLETE=1`, `eWC_COMPLETE=2`. `eWC_COMPLETE` ⇒ domain OP.

**`ECAT_DEVICE_TYPE`**: `eUNKNOWN=0, eDIGITAL_IN, eDIGITAL_OUT, eDIGITAL_IN_OUT, eANALOG_IN, eANALOG_OUT, eANALOG_IN_OUT, eTERMINAL, eJUNCTION, eCIA402, eFTSensor, eKistarHand`. Note: `eTERMINAL`/`eJUNCTION` (e.g. EK1100 coupler) are **skipped** in the Read/Write PDO loops.

**`ECAT_SLAVE_TYPE`**: `eNO_IO=0, eIN_ONLY, eOUT_ONLY, eIN_OUT` — derived from device type in `SetDeviceType()` (see 3.4 for the exact mapping — several device types fall through to `eNO_IO`).

**`ECAT_COMM_DIR`**: `eInput=0, eOutput=1` — selects input vs output domain everywhere.

**Constants / magic numbers**: `MAX_SYNC_PDO=100`, `MAX_ECAT_SLAVES=65536`, `DEFAULT_VENDORID=-1`, `DEFAULT_PRODUCTCODE=-1`. Error codes: `EMSCONF=1` (master-slave config), `EPDCONF=2` (PDO config), `EDCONF=3` (DC config). (The error codes are declared but not thrown/returned anywhere in these files.)

**CIA402 control words** (all macros are `CIA402_`-prefixed, `(UINT16)`): `CIA402_SHUTDOWN=0x0006`, `CIA402_SWITCH_ON=0x0007`, `CIA402_SWITCH_ON_EN_OP=0x000F`, `CIA402_DISABLE_VOLTAGE=0x0000`, `CIA402_QUICK_STOP=0x0002`, `CIA402_DISABLE_OPERATION=0x0007`, `CIA402_ENABLE_OPERATION=0x000F`, `CIA402_FAULT_RESET=0x0080`.
**CIA402 status words** (all `CIA402_`-prefixed, `(UINT16)`): `CIA402_NOT_READY_TO_SWITCH_ON=0x0000`, `CIA402_SWITCH_ON_DISABLED=0x0040`, `CIA402_READY_TO_SWITCH_ON=0x0021`, `CIA402_SWITCH_ON_ENABLED=0x0023`, `CIA402_OPERATION_ENABLED=0x0027`, `CIA402_QUICK_STOP_ACTIVE=0x0007`, `CIA402_FAULT_REACTION_ACTIVE=0x000F`, `CIA402_FAULT=0x0008`.
**CIA402 drive modes** (all `CIA402_`-prefixed, `(INT8)`, = object 0x6060 values): `CIA402_PROFILE_POSITION=0x01`, `CIA402_PROFILE_VELOCITY=0x03`, `CIA402_PROFILE_TORQUE=0x04`, `CIA402_HOMING=0x06`, `CIA402_INTERPOLATED_POSITION=0x07`, `CIA402_CYCLIC_POSITION` (CSP)=0x08, `CIA402_CYCLIC_VELOCITY` (CSV)=0x09, `CIA402_CYCLIC_TORQUE` (CST)=0x0A. Helpers `GetCIA402DriveMode(int)` (→ label string, "" for unknown) and `ValidateCIA402DriveMode(int)` (→ mode byte; default falls back to `CIA402_PROFILE_POSITION`).

**`stEcatMasterDesc`** — the master/domain/process-data model (all pointers, zero-init in ctor):
| Field | Type | Meaning |
|---|---|---|
| `pEcatMaster` | `PECAT_MASTER` | IgH master handle (`ecrt_request_master`). |
| `pEcatDomainIn` | `PECAT_DOMAIN` | **Input** (slave→master, TxPDO) domain. |
| `pEcatDomainOut` | `PECAT_DOMAIN` | **Output** (master→slave, RxPDO) domain. |
| `pEcatDomainPdIn` | `PECAT_DOMAIN_PD` (`uint8_t*`) | Input domain process-data base pointer (`ecrt_domain_data`). |
| `pEcatDomainPdOut` | `PECAT_DOMAIN_PD` | Output domain process-data base pointer. |

Design note: **two separate domains** (input and output) rather than one. Consequently each control cycle performs **two** `ecrt_master_receive`+`ecrt_master_send` pairs (one in `ReadSlaves`, one in `WriteSlaves`).

**`stEcatSlaveInfo`**: `unVendorID`, `unProdCode` (UINT32), `usAlias`, `usPosition` (UINT16), nested `DC_INFO{ BOOL bIsSupported; UINT16 usActivateWord; UINT32 unCycleTime; INT32 nShiftTime; }` (instance member `stEcatDCInfo`; note the source comment mislabels `unCycleTime` as "DC Shift Time"), `ECAT_SLAVE_TYPE eSlaveType`, `PECAT_SYNC_INFO pEcatSyncInfo` (pointer to the slave's `ec_sync_info_t[]` sync-manager/PDO table). Ctor zero-inits.

##### 3.3 `CEcatMasterBase` (`CEcatMaster`) — lifecycle & cyclic exchange

Members: `m_bInit`, `m_unCycleTime` (ns), `m_bIsDCEnabled`, `m_stMasterState`, `m_stDomainInState`, `m_stDomainOutState`, `m_stEcatMasterDesc`, `std::vector<CEcatSlaveBase*> m_vEcatSlaves`.

**Init sequence — `Init(UINT32 cycleTimeNs, BOOL dcEnabled=FALSE)`** maps to `ecrt_*` in this exact order:
1. Guard: already-init → return TRUE; empty slave vector → error, return FALSE.
2. `ecrt_request_master(0)` — **master index hardcoded to 0** → `pEcatMaster`.
3. `ecrt_master_create_domain(master)` → `pEcatDomainIn`.
4. `ecrt_master_create_domain(master)` → `pEcatDomainOut`.
5. `ecrt_master_state` + `ecrt_domain_state`×2 snapshot (via `UpdateMasterStateSt`/`UpdateDomainStateSt`).
6. Store `m_bIsDCEnabled`, `m_unCycleTime`.
7. `InitSlaves()` — per slave `InitSlave(alias=0,pos=cnt,masterDesc)` then, if DC enabled, `EnableDC(m_unCycleTime)` (called on every slave regardless of that slave's InitSlave result; EnableDC internally no-ops when the slave doesn't support DC). Requires **count of initialized slaves == `GetRespSlaveNo()`** (responding slaves on the bus) or it fails.
8. `ecrt_master_activate(master)` (nonzero → fail). PDO layout is now frozen — no more `ecrt_slave_config_reg_pdo_entry` after this.
9. `ecrt_domain_data(pEcatDomainIn)` → `pEcatDomainPdIn`; `ecrt_domain_data(pEcatDomainOut)` → `pEcatDomainPdOut`.
10. Per slave `ActivateDomainPD(masterDesc)` — copies the two live PD base pointers into each slave.
11. `m_bInit=TRUE`. On any failure calls `DeInit()`.

State-machine transition to OP (INIT→PREOP→SAFEOP→OP) is driven by the IgH master itself after `ecrt_master_activate` + cyclic exchange; this class does not command AL states — it only *observes* them (`GetMasterState`, `GetSlaveState`, `IsMasterOp`, `IsAllSlavesOp`) and the app spins `ReadSlaves`/`WriteSlaves` until OP.

**`ReadSlaves()`** (input path), guarded by `m_bInit`:
`ecrt_master_receive(master)` → `ecrt_domain_process(domainIn)` → `UpdateMasterStateSt()` (`ecrt_master_state`) → `UpdateDomainStateSt(eInput)` (`ecrt_domain_state`) → for each slave: `UpdateSlaveConfigState()` (`ecrt_slave_config_state`, called for **all** slaves incl. terminals), and if device is not `eTERMINAL`/`eJUNCTION` and `IsDomainOp()` then `slave->ReadFromSlave()` → `ecrt_domain_queue(domainIn)` → `ecrt_master_send(master)`.

**`WriteSlaves(UINT64 appTimeNs)`** (output path), guarded by `m_bInit`:
`ecrt_master_receive(master)` → `ecrt_domain_process(domainOut)` → `UpdateDomainStateSt(eOutput)` (only the output domain state; master state is NOT re-snapshotted here) → for each non-terminal/junction slave, if `IsDomainOp(eOutput)` then `slave->WriteToSlave()` → `UpdateAppTime(appTimeNs)` → `ecrt_domain_queue(domainOut)` → `ecrt_master_send(master)`.

**`UpdateAppTime(UINT64 t)`**: `ecrt_master_application_time(master, t)`; **if DC enabled**: `ecrt_master_sync_reference_clock(master)` + `ecrt_master_sync_slave_clocks(master)`. The app time `t` is supplied by the caller each cycle (in `App/Indy7`, `tmSend = read_timer()` from rtposix — a monotonic-ns timestamp).

**`DeInit()`**: `ReadSlaves()` → `DeInitSlaves()` (calls each `slave->DeInit()`) → `WriteSlaves(GetCurrTimeInNs())` (clean final frame) → (if `pEcatMaster != NULL`) `ecrt_release_master(master)`; clears slave vector, `m_bInit=FALSE`. (The internal `ReadSlaves`/`WriteSlaves` no-op when `m_bInit` is already FALSE, e.g. after a failed Init.)

**`AddSlave(CEcatSlaveBase*)`**: pushes to vector, sets `alias=0`, `position = vector size captured *before* push` (= 0-based insertion index) — i.e. **slaves must be registered in physical bus order** (position = ring index).

State observers (used by `App` RT loop and `CEcatInterface`): `GetMasterState()`=`m_stMasterState.al_states`; `GetSlaveState()` = min AL-state over all slaves (`eNONE` if none); `IsMasterOp()` (== `eOP`); `IsAllSlavesOp()` (all `slave->IsSlaveOp()`); `IsLinkUp()` (`master_state.link_up`); `GetRespSlaveNo()` (`master_state.slaves_responding`); `GetWorkingCounter(dir)` (`domain_state.working_counter`); `GetDomainState(dir)` (`domain_state.wc_state`); `IsDomainOp(dir)` (== `eWC_COMPLETE`); `GetSlaveCnt()` (vector size).

###### CEcatMaster API table
| Signature | Vis | Semantics |
|---|---|---|
| `CEcatMasterBase()` / `~CEcatMasterBase()` | pub | Ctor zero-inits flags/cycle; dtor empty (call `DeInit()` explicitly). |
| `BOOL Init(UINT32 cycleTimeNs, BOOL dcEnabled=FALSE)` | pub virt | Full master+slave bring-up (steps above). Returns TRUE on OP-ready. |
| `void DeInit()` | pub virt | Final read/write, release master, clear slaves. |
| `void DeInitSlaves()` | pub virt | Calls `DeInit()` on each slave. |
| `void AddSlave(CEcatSlaveBase*)` | pub virt | Register slave (alias 0, position=index). |
| `void ReadSlaves()` | pub virt | Cyclic input exchange (receive→process→read→queue→send). |
| `void WriteSlaves(UINT64 appTimeNs)` | pub virt | Cyclic output exchange + DC app-time/sync. |
| `UINT32 GetCycleTime()` | pub | Returns stored cycle time (ns). |
| `BOOL IsDCEnabled()` | pub | DC flag. |
| `ECAT_STATE_MACH GetMasterState()` | pub | Master AL state. |
| `ECAT_STATE_MACH GetSlaveState()` | pub | Lowest AL state among slaves. |
| `BOOL IsMasterOp()` / `IsAllSlavesOp()` | pub | OP checks. |
| `ECAT_WC GetWorkingCounter(dir=eInput)` | pub | Domain working counter. |
| `ECAT_WC_STATE GetDomainState(dir=eInput)` | pub | Domain wc_state. |
| `BOOL IsDomainOp(dir=eInput)` | pub | `wc_state==eWC_COMPLETE`. |
| `unsigned GetSlaveCnt()` | pub | # registered slaves. |
| `unsigned GetRespSlaveNo()` | pub | # bus-responding slaves. |
| `BOOL IsLinkUp()` | pub | Ethernet link status. |
| `BOOL InitSlaves()` | prot virt | Per-slave `InitSlave`+optional `EnableDC`; requires initialized==responding. |
| `void UpdateAppTime(UINT64)` | prot | `ecrt_master_application_time` + DC sync when enabled. |
| `Get/UpdateMasterStateSt`, `Get/UpdateDomainStateSt(dir)` | priv | Cache `ec_master_state_t`/`ec_domain_state_t`. |

##### 3.4 `CEcatSlaveBase` — per-slave config & process data

Base class every concrete slave subclasses. Private state: `m_bIsInitialized`, `m_bIsDCEnabled`, `m_stEcatMasterDesc` (its own copy of master/domain/PD pointers), `m_pEcatSlaveConfig` (`ec_slave_config_t*`), `m_eDeviceType`. Protected: `m_stEcatSlaveInfo`, `m_stSlaveState` (`ec_slave_config_state_t`).

**`Init(stEcatMasterDesc)`** (called via public `InitSlave(alias,pos,desc)`):
1. `ecrt_master_slave_config(master, alias, position, vendorID, productCode)` → `m_pEcatSlaveConfig` (NULL → fail). Sets `m_bIsInitialized=TRUE`.
2. If `GetSlaveType()!=eNO_IO`: call virtual `InitSyncs()` (subclass fills `m_stEcatSlaveInfo.pEcatSyncInfo` = its static `ec_sync_info_t[]` table); require non-NULL sync info; `ecrt_slave_config_pdos(config, EC_END, pEcatSyncInfo)` (0 → ok); then virtual `RegisterPDO()` (subclass registers each PDO entry offset). **An `eNO_IO` slave skips this entire step** (no InitSyncs, no PDO config).

**`SetDeviceType(ECAT_DEVICE_TYPE)`** stores the device type and derives the `ECAT_SLAVE_TYPE`: `eDIGITAL_IN`/`eANALOG_IN`→`eIN_ONLY`; `eDIGITAL_OUT`/`eANALOG_OUT`→`eOUT_ONLY`; `eDIGITAL_IN_OUT`/`eANALOG_IN_OUT`/`eFTSensor`/`eCIA402`→`eIN_OUT`; **everything else — `eTERMINAL`, `eJUNCTION`, `eKistarHand`, `eUNKNOWN`, and any unlisted value — falls through to `eNO_IO`** (and thus skips PDO config in `Init`). Concrete slaves therefore call `SetDeviceType` with an I/O-mapped type (e.g. `SlaveCIA402Base`→`eCIA402`, `SlaveNRMKEndTool`→`eFTSensor`); a slave that needs PDOs must not rely on a device-type value that maps to `eNO_IO`.

**`RegisterPDOEntry(UINT16 index, UINT8 subindex, UINT32* bitPos, ECAT_COMM_DIR dir=eInput)`** → wraps `ecrt_slave_config_reg_pdo_entry(config, index, subindex, domain, bitPos)`; picks `domainIn` for `eInput` else `domainOut`; returns byte **offset** of the entry in the domain PD (≥0), or the error path (also errors if called before `Init`). This offset is the key each concrete slave stores and later feeds to `ReadPdo*/WritePdo*`. (See caveat: the declared return type is `UINT32`, so the source's internal `-1` sentinel / `unRet < 0` check is a no-op — treat the return as a valid offset only when init succeeded.)

**DC — `EnableDC(UINT32 cycleTimeNs)`**: if DC supported → `ecrt_slave_config_dc(config, assignActivateWord, cycleTimeNs /*SYNC0 cycle*/, shiftTimeNs /*SYNC0 shift*/, 0 /*SYNC1 cycle*/, 0 /*SYNC1 shift*/)` and sets `m_bIsDCEnabled=TRUE`; else `ecrt_slave_config_dc(config,0,0,0,0,0)` (DC off). Always stores cycle time (`SetDCCycleTime`, outside the if/else). AssignActivate word and shift time come from `SetDCInfo(supported, activateWord, shiftTime)` — **vendor-specific, from the slave's ESI/XML `Device→Dc→AssignActivate`**. **`SetAsDCRef()`**: `ecrt_master_select_reference_clock(master, config)` — makes this slave the DC reference; requires DC already enabled (`IsDCEnabled()`) and Init done. NOTE: `Init()` does **not** auto-select a reference clock; if a specific slave must be the DC master, the integrator must call `SetAsDCRef()` explicitly (otherwise IgH's default reference applies).

**Process-data accessors** (operate on `pEcatDomainPdIn/Out + offset`):
- `WritePdoU(offset, UINT64 val, int bits=64)` / `WritePdoS(offset, INT64 val, int bits=64)` → `EC_WRITE_U8/16/32/64` / `EC_WRITE_S8/16/32/64` on **output** PD (unsupported `bits` → FALSE).
- `ReadPdoU8/U16/U32/U64`, `ReadPdoS8/S16/S32/S64(offset, BOOL bIsOut=FALSE)` → `EC_READ_U*/S*`; `bIsOut=TRUE` reads output PD else input PD.
- `ReadPdoDouble(offset, bIsOut=FALSE)` → `EC_READ_LREAL` (IEEE-754 double PDO).

**Virtuals for subclasses**: `RegisterPDO()` (default returns TRUE/no-op), `InitSyncs()` (default no-op; TODO "make this smart"), `WriteToSlave()` / `ReadFromSlave()` (default empty; called by master each cycle), `DeInit()` (default empty).

Offset-name helper macros in `EcatSlaveBase.h` (used by concrete slaves to declare parallel offset/bit fields): `SET_OFFSET(N)`→`UINT32 offN`, `GET_OFFSET(N)`→`offN`, `SET_BITPOS(N)`→`UINT32 bitN`, `GET_BITPOS(N)`→`bitN` (built on `SET_PREFIX_VAR`/`GET_PREFIX_VAR` `__typeof__` token-paste).

###### CEcatSlaveBase API table (selected)
| Signature | Vis | Semantics |
|---|---|---|
| `void SetVendorInfo(UINT32 vid, UINT32 pcode)` | pub | Set vendor ID + product code before init. |
| `void SetDCInfo(BOOL supported, UINT16 activateWord, INT32 shiftTime)` | pub | DC parameters from ESI. |
| `BOOL InitSlave(UINT16 alias, UINT16 pos, stEcatMasterDesc)` | pub | Set alias/pos → `Init()`. |
| `void ActivateDomainPD(stEcatMasterDesc)` | pub | Copy live `pEcatDomainPdIn/Out` post-activate. |
| `BOOL EnableDC(UINT32 cycleNs)` | pub | `ecrt_slave_config_dc` (SYNC0). |
| `BOOL SetAsDCRef()` | pub | `ecrt_master_select_reference_clock`. |
| `ECAT_STATE_MACH GetSlaveState()` | pub | `slave_config_state.al_state`. |
| `BOOL IsSlaveOp()` / `IsSlaveOnline()` | pub | `al_state==eOP` / `.online`. |
| `void UpdateSlaveConfigState()` | pub | `ecrt_slave_config_state` snapshot. |
| `BOOL WritePdoU/S(offset,val,bits=64)` | pub | Write to output PD. |
| `T ReadPdoU8..S64 / ReadPdoDouble(offset,bIsOut=FALSE)` | pub | Typed PD read (in/out). |
| `virtual void ReadFromSlave()/WriteToSlave()` | pub | Subclass cyclic I/O (called by master). |
| `Get/SetAlias, Get/SetPosition, GetVendorID, GetProductCode, GetDeviceType, GetDCActivateWord/ShiftTime/CycleTime, GetEcatPdoSync` | pub | Accessors. |
| `UINT32 RegisterPDOEntry(UINT16 idx, UINT8 sub, UINT32* bitPos, dir=eInput)` | prot | `ecrt_slave_config_reg_pdo_entry`→byte offset. |
| `BOOL Init(stEcatMasterDesc)` | prot | slave_config + pdos + RegisterPDO. |
| `void SetDeviceType(ECAT_DEVICE_TYPE)` | prot | Sets device+derived slave type. |
| `void SetEcatPdoSync(PECAT_SYNC_INFO)` | prot | Install `ec_sync_info_t[]` table. |
| `virtual BOOL RegisterPDO()` / `virtual void InitSyncs()` | prot | Subclass PDO wiring hooks. |

##### 3.5 Complete `ecrt_*` (IgH) call inventory used by this subsystem
| `ecrt_*` call | Where | Purpose |
|---|---|---|
| `ecrt_request_master(0)` | Master::Init | Acquire master index 0. |
| `ecrt_master_create_domain` | Master::Init (×2) | Create input & output domains. |
| `ecrt_master_slave_config(m,alias,pos,vid,pc)` | Slave::Init | Bind slave config by position+identity. |
| `ecrt_slave_config_pdos(sc, EC_END, syncInfo)` | Slave::Init | Apply full SM/PDO layout. |
| `ecrt_slave_config_reg_pdo_entry(sc,idx,sub,dom,&bit)` | Slave::RegisterPDOEntry | Register entry → byte offset. |
| `ecrt_slave_config_dc(sc,aw,c0,s0,c1,s1)` | Slave::EnableDC | Configure DC SYNC0 (SYNC1=0). |
| `ecrt_master_select_reference_clock(m,sc)` | Slave::SetAsDCRef | Pick DC reference slave. |
| `ecrt_master_activate(m)` | Master::Init | Freeze config, go operational. |
| `ecrt_domain_data(dom)` | Master::Init (×2) | Get PD base pointers. |
| `ecrt_master_receive(m)` | Read/Write/DeInit | Fetch received datagrams. |
| `ecrt_domain_process(dom)` | Read(in)/Write(out) | Update PD image + wc. |
| `ecrt_domain_queue(dom)` | Read/Write | Queue domain datagrams. |
| `ecrt_master_send(m)` | Read/Write | Send queued frames. |
| `ecrt_master_state / ecrt_domain_state / ecrt_slave_config_state` | state updaters | Cache master/domain/slave state. |
| `ecrt_master_application_time(m,t)` | UpdateAppTime | Set DC app time. |
| `ecrt_master_sync_reference_clock(m)` / `ecrt_master_sync_slave_clocks(m)` | UpdateAppTime (DC only) | DC drift compensation. |
| `ecrt_release_master(m)` | DeInit | Free master. |
| `EC_READ_U8..U64/S8..S64/LREAL`, `EC_WRITE_U8..U64/S8..S64` | Slave PD accessors | Endian-correct PD field access. |

No `ecrt_slave_config_sdo*` (SDO) calls appear in the base classes (verified: zero `sdo` references in `EcatMasterBase.cpp`/`EcatSlaveBase.cpp`) — SDO/mailbox config, if any, lives in the concrete slave subclasses (`SlaveCIA402Base.cpp`, etc.), not documented here. Vendor/product IDs and PDO indices are **not** hardcoded in the base; they are supplied per-slave via `SetVendorInfo`/`RegisterPDO`.

##### 3.6 `CEcatInterface` — TCP command/telemetry server (auxiliary)
Standalone TCP server (`CTcpServer` from `Global/Comm/Socket.h`) on **`DEFAULT_PORT=7421`**, framed binary protocol with CRC16-ARC (`Global/Comm/CRC16.h`, class `CRC16_ARC` = poly 0x8005, init 0x0000, refin/refout, xorout 0x0000). Wire frame: `Head(0x02 0x5B) | SPIN(1) | Length(2, BE) | CMD1(1) | CMD2(1) | Data(0..245) | CRC16(2) | Tail(0x5D 0x03)`; `PACKET_MIN_LENGTH=11`; the Length **field** encodes `dataLen + 2` (CMD1+CMD2), while the total on-wire frame length = `Length + (PACKET_MIN_LENGTH-1)` = `Length + 10`. (Note: a `static const pbTail = {0x3E,0x5D}` exists but is dead — build/parse actually use tail bytes `0x5D 0x03`.)

Command headers: `HEAD_COMMON=0x43('C')`, `HEAD_ECAT=0x45('E')`. **The single implemented subcommand, `HEAD_GET_ECAT_STATE=0x01`, is dispatched under the `HEAD_COMMON` ('C') branch — NOT under `HEAD_ECAT` ('E'), whose switch body is completely empty.** So to query state a client sends CMD1=`HEAD_COMMON`(0x43), CMD2=`HEAD_GET_ECAT_STATE`(0x01); the handler replies (via `SendPacket(HEAD_GET_ECAT_STATE, feedback)`, default cmd-type `HEAD_COMMON`) with `ST_CUR_ECAT_STATE{ UINT8 uMaster, UINT8 uSlave, UINT8 uDomain, UINT16 usNoOfSlaves }` serialized as 3 single bytes + a 2-byte big-endian slave count. `UpdateEcatState(...)` is the setter *intended* to be fed `GetMasterState`/`GetSlaveState`/`GetDomainState`/`GetRespSlaveNo`, but note nothing actually calls it (see stub status). Responses `RESP_ACK_OK=0x06/RESP_NACK=0x07/RESP_TIMEOUT=0x08`. Structs `ST_CUR_STATE`, `ST_CUR_CMD{nAlias,nPosition,eCmd,nData}` exist with `#pragma pack(1)`.

**Stub status (explicit):** the `HEAD_ECAT` command switch is empty; nearly all motion subcommands (`MOVE_ABS`, `HOMING`, `SERVO_POWER_*`, `FAULT_RESET`, …) are commented-out enumerators; `SendAck()` body is commented out; CRC on receive is computed but result is discarded (`(void)crc_recv/crc_calc`); `GetCmdData()` returns `m_stCurCommand` which is never populated with a real command. It stores a `CEcatMasterBase*` (`m_pcEcatMaster`) at `Init()` but **never dereferences it afterward** — the served state comes entirely from external `UpdateEcatState()` calls, and it does not itself drive `ReadSlaves`/`WriteSlaves`.

##### 3.7 Makefile — build & link
Output artifacts (in `EMasterApp/lib/`): **`libEMasterApp.a`** (static, via `ar rc` + `ranlib`) and **`libEMasterApp.so`** (shared, `g++ -g -shared -fPIC`). Compiler `g++`, objects → `EMasterApp/obj/`.
**Sources compiled into the library (exactly four):** `Device/EcatMasterBase.cpp`, `Device/EcatSlaveBase.cpp`, `Device/SlaveCIA402Base.cpp`, `Device/SlaveNRMKEndTool.cpp`. (`Interface/EcatInterface.cpp` is **NOT** in `SOURCES` — see caveats; other slave headers `SlaveELMO/EPOS4/BeckhoffEK1100/EL2024/CU1124/KistFT/FBGSensor.h` are header-only, `SlaveKistarHand.cpp` is present in the tree but NOT compiled by this Makefile.)
**CFLAGS** = `-Wall -O3 -mtune=native -flto` + includes: `Device`, `Global`, `/opt/etherlab/include`, `/opt/rt_posix/include`.
**LDFLAGS** (`.so` only; the `.a` archives objects unresolved) = `-lm -lrt -lpthread` + **`-L/opt/etherlab/lib -lethercat`** + **`-L/opt/rt_posix/lib -lrtposix`**.
`make install` copies `Device/*.h` → `../include/EMasterApp/` and `lib/*` → `../lib/EMasterApp/`. `make re` = `make clean` + `make` (default `all` = shared+static) + `make install`. Dep files `*.d` via `-MD`.

##### 3.8 Integration model for a future EtherCAT + PREEMPT_RT (KV260) pipeline
- Ownership: `CRobot` (`CRobot/Robot.h`) holds `CEcatMaster* m_pcEcatMaster`. Concrete device wrappers (`CAxisCIA402`, `CSensorNRMKEndTool`, `CKistarHand`) each own a `CEcatSlaveBase` subclass member (`CSlaveCIA402 m_cEcSlave`, `m_cNrmkSlave`, `m_cEcSlave`) and register it via `m_pEcMaster->AddSlave(&slave)` inside their own `Init(CEcatMaster&, …)`. In the Indy7 app the axis class is actually **`CAxisNRMKCore`** (subclass of `CAxisCIA402`, so it inherits the `CSlaveCIA402`+`AddSlave` path); sensors are `CSensorNRMKEndTool`.
- Bring-up order (from `App/Indy7/Indy7Ctrl.cpp::InitEtherCAT`): `new CEcatMaster()` → for each configured slave, construct axis/sensor and call `axis->Init(*master, (INT8)nDriveMode)` / `sensor->Init(*master)` (which `AddSlave`s and sets vendor/DC info) → read master conf → `master->Init(stEcatMaster.nCycleTime, stEcatMaster.bDCEnabled)`.
- RT cycle (rtposix task `proc_ethercat_control`, registered via `AddTaskFunction`): `wait_next_period(NULL)` → `tmCurrent=read_timer()` → `master->ReadSlaves()` → `pRobot->UpdateExtInterfaceData()` → set `m_bEcatOP` from `IsAllSlavesOp() && IsMasterOp()` → `tmSend = read_timer()` → `master->WriteSlaves(tmSend)`. The RT **period, priority, and CPU affinity live in the rtposix task layer, not here** — this subsystem contains no `create_rt_task`/scheduling code; it only consumes `read_timer()`/`GetCurrTimeInNs()` timestamps.
- Config keys consumed (via robot config `ST_CONFIG_ECAT_MASTER`/`ST_CONFIG_ECAT_SLAVE`, parsed in `CRobot`, not here): master `nCycleTime` (ns) and `bDCEnabled`; per-slave `nDriveMode` (CIA402), vendor/product via `SetVendorInfo(uVendorID,uProductCode)`, and DC via `SetDCInfo(bDCSupported, usDCActivateWord, nDCSyncShift)`.

##### 3.9 Gotchas, stubs, caveats (do not overlook)
- **`ecrt_request_master(0)` — master index hardcoded to 0.** Multi-master or non-zero master index needs a source change.
- **CIA402 macro names carry a `CIA402_` prefix** for control words, status words, AND drive modes (e.g. `CIA402_OPERATION_ENABLED`, `CIA402_CYCLIC_POSITION`); grep for the prefixed symbol.
- **`HEAD_GET_ECAT_STATE` (0x01) is handled under `HEAD_COMMON` ('C'=0x43), not `HEAD_ECAT` ('E'=0x45).** The `HEAD_ECAT` switch is empty; a client sending 'E',0x01 gets nothing back.
- **`EcatInterface.cpp` is not built into the library and not referenced by any Makefile**, and `CRobot`/`App` never instantiate `CEcatInterface`. It is an unused/experimental TCP server. Do not assume it provides live control; most of it is stubbed (empty `HEAD_ECAT` handler, discarded CRC, no-op `SendAck`, unpopulated `GetCmdData`, and `m_pcEcatMaster` is stored but never used).
- **Two-domain design ⇒ two receive/send round-trips per control cycle** (once in `ReadSlaves`, once in `WriteSlaves`) — higher bus/CPU cost than a single-domain master; budget accordingly on KV260.
- **DC reference clock is not auto-selected** in `Init()`; call `slave->SetAsDCRef()` (after DC enabled) if a specific reference is required. DC sync (`sync_reference_clock`/`sync_slave_clocks`) only runs when `dcEnabled=TRUE`, and only SYNC0 is configured (SYNC1 cycle/shift forced to 0 in `EnableDC`).
- **`AddSlave` assigns `position = insertion index` and `alias = 0`** — slaves must be added strictly in bus/ring order; alias-based addressing is not supported through this path.
- **`InitSlaves` hard-requires `#initialized == GetRespSlaveNo()`** (number of bus-responding slaves). A miscount (e.g. an unexpected coupler, or a slave that fails PDO config) aborts the whole master init.
- **`SetDeviceType` maps several device types to `eNO_IO`** — `eTERMINAL`, `eJUNCTION`, `eKistarHand`, `eUNKNOWN` (and any unlisted value) become `eNO_IO`, and `eNO_IO` slaves skip `InitSyncs()`/PDO config in `Init()` **and** are skipped in the Read/Write PDO loops (the loop skip itself keys on `eTERMINAL`/`eJUNCTION`). A concrete I/O slave must register a device type that maps to a non-`eNO_IO` slave type.
- **Hardcoded absolute paths (Makefile):** `THIRD_PARTY_DIR=/opt`, IgH at **`/opt/etherlab`** (`include/`,`lib/`,`-lethercat`), rtposix at **`/opt/rt_posix`** (`include/`,`lib/`,`-lrtposix`). A commented alt `RT_POSIX_DIR=$(GLOBAL_DIR)/ThirdParty/rt_posix` exists. These must exist on the KV260 target (or the cross-sysroot) at those exact prefixes.
- **`-mtune=native`** in CFLAGS: fine when building natively on the KV260 Cortex-A53, but if cross-compiling from x86 this tunes for the wrong CPU — override for cross builds.
- `RegisterPDOEntry` returns `UINT32` but the source signals error as `-1`/`<0`; the caller comparison `unRet < 0` on an unsigned type is always false. Treat the return strictly as an offset, valid only when init succeeded.
- `GetWorkingCounter` casts `working_counter` through `ECAT_WC_STATE` before returning `ECAT_WC` — cosmetic, but the value is the raw working counter, not a `wc_state` enum.
- The `cycleTime` argument to `CEcatMaster::Init()` is in **nanoseconds** and is reused verbatim as the DC SYNC0 cycle time in each slave's `EnableDC()`. `DeInit()` emits a final `ReadSlaves`/`WriteSlaves(GetCurrTimeInNs())` before `ecrt_release_master`.
- SDO configuration, PDO entry indices/subindices, vendor/product IDs, and sync-manager tables are **not** in these base files — they live in the concrete slave classes (e.g. `SlaveCIA402Base`, `SlaveNRMKEndTool`, Beckhoff/ELMO/EPOS4 headers). Document those separately before wiring real hardware.

---
#### 4. EtherCAT Slave Device Drivers (`EMasterApp/Device/Slave*`)

All slave drivers derive from `CEcatSlaveBase` (`EMasterApp/Device/EcatSlaveBase.h`) and use the IgH EtherLab master API via `ecrt.h`. Constants (CiA402 words, device-type enum, EtherCAT state-machine enum, slave-info/DC structs) live in `EMasterApp/Device/EcatCommon.h`, which `#include`s `Defines.h` and `ecrt.h`. Each driver supplies three things the framework consumes cyclically or at config time: an `ec_pdo_entry_info_t`/`ec_pdo_info_t`/`ec_sync_info_t` descriptor triple, a `RegisterPDO()` override (maps each entry to a byte-offset/bit-position in the process image via `RegisterPDOEntry`), and `WriteToSlave()`/`ReadFromSlave()` overrides (called every RT cycle to marshal the PDO byte-offsets to/from typed member fields using `WritePdoU/WritePdoS` and `ReadPdo{U,S}{8,16,32,64}`).

##### 4.0 Shared base plumbing (`EcatSlaveBase.h`, `EcatCommon.h`)

- `CEcatSlaveBase` key members used by every driver:
  - `UINT32 RegisterPDOEntry(UINT16 index, UINT8 subindex, UINT32* pBitPos, ECAT_COMM_DIR dir=eInput)` — wraps `ecrt_slave_config_reg_pdo_entry()`; returns the byte offset of the entry in the domain process image, and writes the bit offset into `*pBitPos`. **Return type is UINT32 (unsigned).** The underlying ecrt call returns `<0` on error, but it is stored in `UINT32 unRet = -1` and returned as `0xFFFFFFFF`.
  - **CRITICAL (silent PDO-registration failure):** because the return is UINT32 and every driver stores it into a `UINT32 off*` variable, *both* the internal guard `if(unRet < 0)` in `EcatSlaveBase.cpp:107` *and* every override's guard `if (0 > (m_stSlaveParams.GET_OFFSET(X) = RegisterPDOEntry(...)))` are **dead code (unsigned compare, always false)**. A failed entry registration therefore logs nothing, `RegisterPDO()` still returns TRUE, and the offset is left at `0xFFFFFFFF`; the next `WriteToSlave()`/`ReadFromSlave()` dereferences `domain_pd + 0xFFFFFFFF` → out-of-bounds access/crash. Do not trust `RegisterPDO()`'s return value — validate every PDO index/subindex against the slave ESI before running.
  - `virtual BOOL RegisterPDO()` (default TRUE), `virtual void InitSyncs()` (default no-op), `virtual void WriteToSlave()`, `virtual void ReadFromSlave()`, `virtual void DeInit()` — the override points.
  - Ctor setters: `SetVendorID/SetProductCode`, `SetVendorInfo(vendor,product)`, `SetDeviceType(ECAT_DEVICE_TYPE)`, `SetDCSupported/SetDCActivateWord/SetDCShiftTime/SetDCCycleTime`, `SetDCInfo(BOOL supported,UINT16 activateWord,INT32 shiftTime)`, `SetEcatPdoSync(PECAT_SYNC_INFO)`, `SetAlias/SetPosition`.
  - State queries: `IsSlaveOp()` (state==eOP), `IsSlaveOnline()` (reads `ecrt_slave_config_state().online`), `IsDCEnabled()`, `IsDCSupported()`, `IsInitialized()`, `GetSlaveState()` returns `ECAT_STATE_MACH` (from `al_state`). Note: `IsSlaveOnline()` reflects the cached `m_stSlaveState`; call `UpdateSlaveConfigState()` to refresh.
  - PDO IO wrappers: `WritePdoU(offset,val,bits=64)`, `WritePdoS(offset,val,bits=64)`, `ReadPdoU8/16/32/64`, `ReadPdoS8/16/32/64`, `ReadPdoDouble` (byte offset, optional `bIsOut`). All read from `pEcatDomainPdIn` unless `bIsOut`, then `pEcatDomainPdOut`.
- Offset/bitpos macros (expand via `__typeof__`): `SET_OFFSET(N)`→`UINT32 offN;`, `GET_OFFSET(N)`→`offN`; `SET_BITPOS(N)`→`UINT32 bitN;`, `GET_BITPOS(N)`→`bitN`. Each driver's `..._SLAVE_PARAMS` struct is a `stOutPDOs`/`stInPDOs` pair (output-only slaves like EL2024 carry only `stOutPDOs`) plus one `SET_OFFSET`/`SET_BITPOS` per PDO field. Only NRMK's ctor `memset`s its params — the others leave unregistered `off*`/`bit*` members indeterminate.
- `ECAT_DEVICE_TYPE`: `eUNKNOWN, eDIGITAL_IN, eDIGITAL_OUT, eDIGITAL_IN_OUT, eANALOG_IN, eANALOG_OUT, eANALOG_IN_OUT, eTERMINAL, eJUNCTION, eCIA402, eFTSensor, eKistarHand`. `SetDeviceType()` maps to `ECAT_SLAVE_TYPE {eNO_IO,eIN_ONLY,eOUT_ONLY,eIN_OUT}`; `eFTSensor`/`eCIA402`→`eIN_OUT`, `eTERMINAL`/`eUNKNOWN`→`eNO_IO` (so `eTERMINAL`/`eJUNCTION` slaves skip PDO config entirely in `Init()`).
- `ECAT_STATE_MACH` (EtherCAT AL states): `eNONE=0x00, eINIT=0x01, ePRE_OP=0x02, eSAFE_OP=0x04, eOP=0x08`.
- `ECAT_COMM_DIR`: `eInput=0, eOutput=1`. `MAX_SYNC_PDO=100`, `MAX_ECAT_SLAVES=65536`. `DEFAULT_VENDORID=-1`, `DEFAULT_PRODUCTCODE=-1`.
- `stEcatSlaveInfo`: `unVendorID, unProdCode, usAlias, usPosition`, nested `DC_INFO{bIsSupported, usActivateWord, unCycleTime, nShiftTime}`, `eSlaveType`, `pEcatSyncInfo`.
- **DC activate word `0x300`** appears in every DC-capable driver (bit 8 `0x100` = enable cyclic/AssignActivate, bit 9 `0x200` = SYNC0 generation). Sync-manager convention: `SM0`=mailbox out, `SM1`=mailbox in, `SM2`=RxPDO (master→slave, `EC_WD_ENABLE`), `SM3`=TxPDO (slave→master, `EC_WD_DISABLE`); mailbox-less slaves (EL2024, FBG) put process data on `SM0`/`SM1`. RxPDO mapping objects are `0x1600` (…`0x1603`), TxPDO mapping object is `0x1a00`.

##### 4.1 `CSlaveCIA402Base` — base servo drive (COMPILED)

- Files: `EMasterApp/Device/SlaveCIA402Base.h` (~365 LOC), `SlaveCIA402Base.cpp` (~636 LOC). Role: generic CiA402 (DS402) servo-drive slave; base class for ELMO/EPOS4 and any CSP/CSV/CST/PP/PV/HM axis. `typedef CSlaveCIA402Base CSlaveCIA402;`. Ctor sets `SetDeviceType(eCIA402)` and initial servo status `eServoDisconnected`. **One of only two device-driver `.cpp` files compiled into `libEMasterApp`** (see §4.12).

CiA402 constants (from `EcatCommon.h`):

| Control word (`0x6040`) | val | Status-word masked state (`0x6041`) | val | Drive mode (`0x6060/0x6061`) | val |
|---|---|---|---|---|---|
| `CIA402_SHUTDOWN` | 0x0006 | `CIA402_NOT_READY_TO_SWITCH_ON` | 0x0000 | `CIA402_PROFILE_POSITION` (PP) | 0x01 |
| `CIA402_SWITCH_ON` | 0x0007 | `CIA402_SWITCH_ON_DISABLED` | 0x0040 | `CIA402_PROFILE_VELOCITY` (PV) | 0x03 |
| `CIA402_SWITCH_ON_EN_OP` | 0x000F | `CIA402_READY_TO_SWITCH_ON` | 0x0021 | `CIA402_PROFILE_TORQUE` (PT) | 0x04 |
| `CIA402_DISABLE_VOLTAGE` | 0x0000 | `CIA402_SWITCH_ON_ENABLED` (=DS402 "Switched On") | 0x0023 | `CIA402_HOMING` (HM) | 0x06 |
| `CIA402_QUICK_STOP` | 0x0002 | `CIA402_OPERATION_ENABLED` | 0x0027 | `CIA402_INTERPOLATED_POSITION` (IP) | 0x07 |
| `CIA402_DISABLE_OPERATION` | 0x0007 | `CIA402_QUICK_STOP_ACTIVE` | 0x0007 | `CIA402_CYCLIC_POSITION` (CSP) | 0x08 |
| `CIA402_ENABLE_OPERATION` | 0x000F | `CIA402_FAULT_REACTION_ACTIVE` | 0x000F | `CIA402_CYCLIC_VELOCITY` (CSV) | 0x09 |
| `CIA402_FAULT_RESET` | 0x0080 | `CIA402_FAULT` | 0x0008 | `CIA402_CYCLIC_TORQUE` (CST) | 0x0A |

`ValidateCIA402DriveMode(int)`/`GetCIA402DriveMode(int)` (inline, `EcatCommon.h`) map/validate these; an unknown mode defaults to PP.

**Live PDO map** (declared `cia402_pdo_entries[11]` but only 10 entries initialized; profile/error/additional-pos entries are **commented out**, so the live map is 10 entries / 5 Rx + 5 Tx):

| Dir | Mapping obj | index:sub:bits | Meaning |
|---|---|---|---|
| Rx `0x1600` (SM2) | | `0x6040:00:16` | Control Word |
| | | `0x607A:00:32` | Target Position |
| | | `0x60FF:00:32` | Target Velocity |
| | | `0x6071:00:16` | Target Torque |
| | | `0x6060:00:8` | Modes of Operation |
| Tx `0x1a00` (SM3) | | `0x6041:00:16` | Status Word |
| | | `0x6064:00:32` | Position Actual Value |
| | | `0x606C:00:32` | Velocity Actual Value |
| | | `0x6077:00:16` | Torque Actual Value |
| | | `0x6061:00:8` | Modes of Operation Display |

- `cia402_pdos[2] = {{0x1600,5,entries+0},{0x1a00,5,entries+5}}`. `RegisterPDO()` registers exactly those 10 entries (its `0 > offset` guards are dead per §4.0). Commented-out (NOT registered/read): profile velocity `0x6081`, profile accel `0x6083`, profile decel `0x6084`, quick-stop decel `0x6085`, max-profile-vel `0x607F`, max-profile-acc `0x60C5`, error code `0x603F`, additional/absolute pos `0x2fe4:02` (64-bit), motor rated current `0x6075`, and an unlabeled `0x60f4:32`. The `CIA402_OUT`/`CIA402_IN` structs still carry these fields with `Set*/Get*` accessors, but they are dead until re-enabled (`GetErrorCode()` always 0; error code even in the FAULT log prints the stale `usErrorCode`). Header comment `/* todo: make this configurable */` — map is not runtime-configurable.
- `InitSyncs()`: `syncs[0]={0,EC_DIR_OUTPUT,0,NULL,EC_WD_DISABLE}` (SM0 mbx out), `[1]={1,EC_DIR_INPUT,0,NULL,EC_WD_DISABLE}` (SM1 mbx in), `[2]={2,EC_DIR_OUTPUT,1,cia402_pdos+0,EC_WD_ENABLE}` (SM2 RxPDO), `[3]={3,EC_DIR_INPUT,1,cia402_pdos+1,EC_WD_DISABLE}` (SM3 TxPDO), `[4]={0xff}`.

Servo-status FSM: `eSERVO_STATUS { eServoOff=0x00, eServoIdle, eServoStopped, eServoHoming, eServoRunning, eServoFault=0x80, eServoDisconnected }`. `SetServoStatus()` fires `m_pStateChange` on change; only `eServoDisconnected` logs an error (`eServoFault` log line commented out).

`AnalyzeStatusWord(UINT16 raw, BOOL abExtend=TRUE)`:
- Extended (per drive-mode-display): **bit15 `0x8000`=home set** (`m_bIsHomeSet`), **bit13 `0x2000`=following error**. PP (halt-checked first→eServoStopped): **bit12 `0x1000`=set-point ack**→eServoRunning, **bit10 `0x0400`=target reached**→eServoIdle. HM: **bit12=homing attained** (→eServoIdle + auto-switch back to PP), **bit10=homing aborted**→eServoStopped, else (servo on)→eServoHoming. PV (halt-checked first): bit10=target reached→eServoIdle else eServoRunning, **bit11 `0x0800`=speed zero**, bit12=speed saturated. CSP/CSV/CST: **bit12=drive follows target**→eServoRunning else eServoIdle.
- State decode (order-sensitive): `(raw&0x4F)==0x00`→NOT_READY; `==0x08`→FAULT; `==0x40`→SWITCH_ON_DISABLED; `(raw&0x6F)==0x27`→OPERATION_ENABLED; `==0x23`→SWITCH_ON_ENABLED; `==0x21`→READY_TO_SWITCH_ON; `==0x07`→QUICK_STOP_ACTIVE; `(raw&0x4F)==0x0F`→FAULT_REACTION_ACTIVE; else `0xFFFF`.
- **Quirk: `case CIA402_PROFILE_VELOCITY:` has no `break;` and falls through into the CSV/CSP/CST cases**, so in PV mode the cyclic bit12 logic runs *after* the PV logic and overrides the servo status.

`WriteToSlave()` drives the servo-on state machine only while `m_bIsSetServoOnOff && !m_bIsServoOn`: SWITCH_ON_DISABLED→`eServoOff`+`SHUTDOWN`; READY_TO_SWITCH_ON→`SWITCH_ON`; SWITCH_ON_ENABLED→latch start pos/vel/tor, set target pos=start, vel=0, tor=0, write `ENABLE_OPERATION`; FAULT→`eServoFault`+`FAULT_RESET`; OPERATION_ENABLED→`eServoIdle`; QUICK_STOP_ACTIVE→`DISABLE_VOLTAGE`. When `!m_bIsSetServoOnOff`→`SHUTDOWN`+`eServoOff`. When servo on: handles homing (halt toggle + new-set-point) and clears CW bits 4+5 (`&= ~0x30`) in PP after set-point ack. Then always writes CW(16)/TargetPos(32)/TargetVel(32)/TargetTor(16)/DriveMode(8). Note `IsSlaveOp()` is called but its early-return is commented out, so writes proceed even when not OP.

`ReadFromSlave()` reads raw status word, calls `AnalyzeStatusWord`, sets `m_bIsServoOn=(state==OPERATION_ENABLED)`, reads actual pos/vel/tor + drive-mode-display, updates `ST_RAW_DATA` and fires `m_pUpdateParam`. If not `IsSlaveOnline()`, forces `eServoDisconnected` and skips extended analysis (ErrorCode/AdditionalPos/MotorRatedCurrent reads are commented out).

Control-word bit helpers (mutate `stOutPDOs.usControlWord`): `SetNewSetPoint(forced)`→bit4 `0x10` always + bit5 `0x20` only in PP when forced; `SetHalt(bool)`→bit8 `0x100`; `SetRelativePosMode(bool)`→bit6 `0x40` (PP only); `SetEndlessMovement(bool)`→bit15 `0x8000` (PP only); `SetEmgStop()`→`CIA402_QUICK_STOP`. `SetTargetPos` guarded to CSP/PP; `SetTargetVel` guarded to CSV/PV. `SetServoOn(mode=CIA402_PROFILE_POSITION)`; `GoHome()` switches to HM and sets `m_bTriggerGoHome`. `DeInit()`=`SetServoOff()`+`SetEmgStop()`. Callbacks: `RegisterCallbackStateChange/ParamUpdate(CALLBACK_FN)` where `CALLBACK_FN=std::function<void(PVOID,PVOID,PVOID,PVOID)>` (moved in; state-change callback fires once immediately on registration).

`ST_RAW_DATA` (callback payload): `usControlWord, nTargetPos, nTargetVel, nTargetTor, btDriveMode, usStatusWord, nActualPos, nActualVel, nActualTor, btActualDriveMode` (note `usStatusWord` here is loaded from the *raw* status word).

##### 4.2 `CSlaveELMO` — ELMO Gold/Platinum servo drive (header-only)

- File: `EMasterApp/Device/SlaveELMO.h` (37 LOC). `class CSlaveELMO : public CSlaveCIA402Base`; ctor-only, inherits the CiA402 PDO map/FSM from §4.1.
- Vendor `ELMO_VENDOR_ID = 0x0000009a`; product `ELMO_MODULE_PLATINUM = 0x00100002` (alt `0x00030924` commented). `SetDCInfo(TRUE, 0x300, 0)` → DC/SYNC0 enabled, zero shift.
- Physical device: ELMO Platinum (Gold-family) EtherCAT servo drive. Include guard `_ECAT_SLAVE_ELMO_` (plus `#pragma once`), but banner (`Name: SlaveEPOS4.h`), trailing `#endif // _ECAT_SLAVE_EPOS4_`, and `};//SlaveEPOS4` are all copy-pasted from EPOS4.

##### 4.3 `CSlaveEPOS4` — (mislabeled) Maxon EPOS4 servo drive (header-only)

- File: `EMasterApp/Device/SlaveEPOS4.h` (38 LOC). `class CSlaveEPOS4 : public CSlaveCIA402Base`; ctor-only. Vendor `EPOS4_VENDOR_ID = 0x0000009a`, product `EPOS4_MODULE24_1_5 = 0x00100002`, `SetDCInfo(TRUE, 0x300, 0)`. Include guard `_ECAT_SLAVE_MECAPIONL7N_` (plus `#pragma once`).
- **Integration caveat: despite the name, this is configured identically to `CSlaveELMO` (ELMO vendor `0x9a`, product `0x00100002`), NOT for a real Maxon EPOS4.** An explicit `/* this is for ELMO */` comment sits above the active vendor `#define`; Maxon's true vendor ID `0x000000fb` and the alt product `0x00030924` ("1층"/1st-floor) appear only as commented `#define`s. Set correct vendor/product before using a real EPOS4.

##### 4.4 `CSlaveBeckhoffEK1100` — EtherCAT bus coupler (header-only)

- File: `EMasterApp/Device/SlaveBeckhoffEK1100.h` (31 LOC). `class CSlaveBeckhoffEK1100 : public CEcatSlaveBase`; ctor-only, no PDOs (infrastructure coupler / power feed).
- Vendor `BECKHOFF_VENDOR_ID = 0x00000002`; product `BECKHOFF_EK1100 = 0x044c2c52`. `SetDeviceType(eTERMINAL)`→`eNO_IO`, `SetDCSupported(FALSE)`. No IO overrides.

##### 4.5 `CSlaveBeckhoffEL2024` — 4-ch digital output terminal (header-only)

- File: `EMasterApp/Device/SlaveBeckhoffEL2024.h` (85 LOC). `class CSlaveBeckhoffEL2024 : public CEcatSlaveBase`. Physical device: Beckhoff EL2024 4-channel 24 V / 2 A digital-output terminal (drives LEDs here).
- Vendor `0x00000002`; product `BECKHOFF_EL2024 = 0x07e83052`. `SetDeviceType(eDIGITAL_OUT)`→`eOUT_ONLY`, `SetDCSupported(FALSE)`. Sets sync in ctor via `SetEcatPdoSync` (no `InitSyncs` override).
- PDO map (outputs only): entries `{0x7000:01:1},{0x7010:01:1},{0x7020:01:1},{0x7030:01:1}`; mapping objects `0x1600..0x1603` (one entry each = channels 1–4); sync `{0,EC_DIR_OUTPUT,4,pdos+0,EC_WD_ENABLE},{0xff}` (single output SM, no mailbox).
- **`RegisterPDO()` registers only channel 1 (`0x7000:01`→`LedValue`)**; `WriteToSlave()` writes 8 bits via `SetLedValue(UINT8)` even though the entry is 1 bit wide. Channels 2–4 are declared but not wired. `..._SLAVE_PARAMS` has only `stOutPDOs`.
- **ODR hazard: descriptor arrays (`beckhoff_el2024_pdo_entries/_pdos/_syncs`) are non-`static` header globals** → multiple-definition link errors if included in >1 TU (same in §4.7/§4.8).

##### 4.6 `CSlaveBeckhoffCU1124` — EtherCAT junction/hub (header-only)

- File: `EMasterApp/Device/SlaveBeckhoffCU1124.h` (32 LOC). `class CSlaveBeckhoffCU1124 : public CEcatSlaveBase`; ctor-only, no PDOs. Physical device: Beckhoff CU1124 EtherCAT junction (topology splitter; real part is 3-port — code carries no port count).
- Vendor `0x00000002`; product `BECKHOFF_CU1124 = 0x04645432` (alt `0x04685432` "1층"/1st-floor commented). `SetDeviceType(eTERMINAL)` (not `eJUNCTION`, though that enum exists), `SetDCSupported(FALSE)`. Banner copied from EK1100.

##### 4.7 `CSlaveKistFT` — KIST 6-axis F/T sensor (header-only)

- File: `EMasterApp/Device/SlaveKistFT.h` (201 LOC). `class CSlaveKistFT : public CEcatSlaveBase`, all inline. Physical device: KIST "IFBOX4NEWIF" 6-axis force/torque sensor.
- Vendor `KIST_VENDOR_ID = 0x00828845`; product `KIST_FT_SENSOR = 0x00009252`; revision (comment) `0x00000001`. `SetDeviceType(eFTSensor)`, `SetDCSupported(FALSE)` (DC activate `0x0300`/shift `125000` ns `#define`d but the `SetDCActivateWord/ShiftTime` ctor calls are commented out). Sync set in ctor via `SetEcatPdoSync` (no `InitSyncs` override).
- PDO map: Rx `0x1600` (2: `0x7000:01:16` value1 = op-mode command, `0x7000:02:16` value2); Tx `0x1a00` (7: `0x6000:01..07:32` = Fx,Fy,Fz,Tx,Ty,Tz,count). 4-SM sync (mailbox SM0/SM1 `EC_WD_DISABLE`, PDOs SM2/SM3).
- `FT_OP_MODE { DEFAULT_OP=0, ADC_VALUE=8, BIAS_FLASH_SAVE=9, BIAS_NO_SAVE=6 }`; `SetOperationMode(INT)`→`value1`. Getters `GetFx/Fy/Fz/Tx/Ty/Tz/GetCount` (raw INT32). `WriteToSlave()` writes value1/value2 (16b each); `ReadFromSlave()` reads all 7 inputs unconditionally (no online guard).
- **Bugs in `RegisterPDO()` — the entire F/T read map is broken:** the Tx/Ty/Tz registrations mistakenly assign into `GET_OFFSET(Fx/Fy/Fz)` (with the correct `GET_BITPOS(Tx/Ty/Tz)`), so `offFx/offFy/offFz` are **overwritten by the Tx/Ty/Tz byte offsets** → `GetFx/GetFy/GetFz` actually return the *torque* channels. `offTx/offTy/offTz` are never assigned → indeterminate (KistFT's params are not `memset`) → `GetTx/GetTy/GetTz` read garbage/out-of-bounds offsets. `Count` is registered at `0x6000:06` (dup of Tz) instead of `0x6000:07`, so `GetCount` aliases Tz. Net: only the force channels' data survives, mislabeled as Fx/Fy/Fz; Tx/Ty/Tz/Count are unusable.

##### 4.8 `CSlaveFBGSensor` — FBG optical force sensor on LAN9252 (header-only)

- File: `EMasterApp/Device/SlaveFBGSensor.h` (250 LOC). `class CSlaveFBGSensor : public CEcatSlaveBase`, all inline. Physical device: FBG (Fiber-Bragg-Grating) optical force/temperature sensor on a Microchip LAN9252 EtherCAT slave controller ("LAN9252_t"). Include guard is FBG-specific `_ECAT_SLAVE_LAN9252_FBG_`, but the banner (`Name: SlaveKistFT.h`), trailing `#endif // _ECAT_SLAVE_KIST_FT_`, and `};//CSlaveKistFT` are copy-pasted from KistFT.
- Vendor `LAN9252_VENDOR_ID = 0xe00004d8`; product `LAN9252_FBG_SENSOR = 0x00009252`. `SetDeviceType(eFTSensor)`, `SetDCSupported(FALSE)` (DC defines commented out). Note: re-`#define`s `KIST_FT_ACTIVATE_WORD`/`KIST_FT_SYNC0_SHIFT` (unguarded) → macro-redefinition warnings if co-included with KistFT/KistarHand.
- PDO map: Rx `0x1600` (2: `0x0005:01:32` Theta, `0x0005:02:8` Biasing); Tx `0x1a00` (14, all `0x0006:01..0e:32`): LeftFx, LeftFy, LeftFz, LeftTemp, RightFx, RightFy, RightFz, RightTemp, Fx, Fy, Fz, Fg, Tz, Temp. Sync `{0,OUTPUT,1,pdos+0,WD_ENABLE},{1,INPUT,1,pdos+1,WD_DISABLE},{0xff}` (process data on SM0/SM1, no mailbox SMs). `RegisterPDO()` here is correct (each field→own subindex). Setters `SetBiasing(BOOL)`/`SetTheta(INT32)`; 14 typed INT32 getters. `ReadFromSlave()` has no online guard.

##### 4.9 `CSlaveKistarHand` — KISTAR multi-finger robot hand (header + .cpp, NOT compiled into lib)

- Files: `EMasterApp/Device/SlaveKistarHand.h` (463 LOC), `SlaveKistarHand.cpp` (367 LOC). `class CSlaveKistarHand : public CEcatSlaveBase`. Physical device: KISTAR dexterous hand — 16 actuated joints w/ per-joint position + current feedback, 12 kinesthetic channels, 4 tactile channels, plus status/add-info words.
- **Broken include guard:** `#ifndef _ECAT_SLAVE_KIST_HAND_` has **no matching `#define`** (and the trailing comment reads `_ECAT_SLAVE_KIST_FT_`), so double-inclusion is not actually prevented.
- Vendor `KISTAR_HAND_VENDOR_ID = 0x00000000`; product `KISTAR_HAND_PRODUCT_CODE = 0x00000004`. `SetDeviceType(eKistarHand)`, `SetDCSupported(FALSE)` in ctor (defined in `.cpp`). `KIST_FT_ACTIVATE_WORD 0x0300`/`KIST_FT_SYNC0_SHIFT 125000` `#define`d but DC left off. Public `SetVendorInfo()`/`SetDCInfo()` allow later override.
- PDO layout via packed unions: `KISTAR_HAND_PDO_IN` = 128 B (`usStatusIn1, usStatusIn2, INT16 nPosition[16], nCurrent[16], nKinesthetic[12], nTactile[4], nAddInfoIn[14]` = 64 words); `KISTAR_HAND_PDO_OUT` = 64 B (`usStatusOut1, usStatusOut2, INT16 nTargetPos[16], UINT16 usAddInfoOut[14]` = 32 words). Also a `#pragma pack(1)` `ST_AddInfo` config struct (WRMode, Pos gains P/D, per-finger tactile thresholds, 12-byte reserved, init-origin).
- Descriptor: `slave_kistar_hand_pdo_entries[100]` (32 outputs `0x0007:0x01..0x20` @16b; 64 inputs `0x0006:0x01..0x40` @16b); `slave_kistar_hand_pdos = {{0x1600,32,+0},{0x1a00,64,+32}}`; `InitSyncs()` (in .cpp): `{0,OUTPUT,1,pdos+0,WD_ENABLE},{1,INPUT,1,pdos+1,WD_ENABLE},{0xff}` (note: input SM uses `WD_ENABLE`, unlike the usual `WD_DISABLE`).
- Accessors: `SetServoStatus(UINT16)`→`usStatusOut1`, `SetControlMode(UINT16)`→`usStatusOut2`, `SetTargetPos(axis,INT16)`; `GetServoStatus/GetControlMode/GetPosition(axis)/GetCurrent(axis)/GetKinesthetic(n)/GetTactile(n)/GetAddInfoIn(n)`, etc.
- **Bug in `RegisterPDO()`:** after Tactile1–4 (`0x06:2F..32`) it re-registers `StatusIn1/StatusIn2` at `0x06:33/0x34` (overwriting their earlier `0x01/0x02` offsets → `GetServoStatus/GetControlMode` read the wrong slots), then maps `AddInfoIn1..14` to `0x06:35..0x42`. But the descriptor labels `0x33..0x40` as ADD1..ADD14 and has **no `0x41/0x42`** — a +2 subindex mismatch, and the final two registrations (`0x41`,`0x42`) fail; per §4.0 the dead guard swallows that failure, leaving `offAddInfoIn13/14 = 0xFFFFFFFF` → OOB reads in `ReadFromSlave()`.
- **Compilation caveat: `SlaveKistarHand.cpp` is NOT in `EMasterApp/Makefile` SOURCES** — the ctor/RegisterPDO/InitSyncs/WriteToSlave/ReadFromSlave are not built into `libEMasterApp.{a,so}`. A future build must add the `.cpp`.

##### 4.10 `CSlaveNrmkEndtool` — Neuromeka EOAT (FT sensor + gripper + LED/button) (COMPILED)

- Files: `EMasterApp/Device/SlaveNRMKEndTool.h` (258 LOC), `SlaveNRMKEndTool.cpp` (234 LOC). `class CSlaveNrmkEndtool : public CEcatSlaveBase`. Newest driver (RAIMLAB @ Myongji University, 2025). Physical device: Neuromeka (NRMK) end-of-arm tool — integrated 6-axis F/T sensor, gripper output, RGB status LED, button input. Ctor `memset`s its params (only driver that does).
- Vendor `NRMK_VENDOR_ID = 0x0000089a`; product `NRMK_ENDTOOL = 0x10000007`. `SetVendorInfo/SetDCInfo(TRUE, 0x0300, 0)`, `SetDeviceType(eFTSensor)`. **Second (newest) device driver `.cpp` compiled into `libEMasterApp`.**
- PDO map:

| Dir | Mapping obj | index:sub:bits | Field |
|---|---|---|---|
| Rx `0x1600` (SM2) | | `0x7000:01:8` | ILed |
| | | `0x7000:02:8` | IGripper |
| | | `0x7000:03:32` | FTConfigParam |
| | | `0x7000:04:8` | LEDMode |
| | | `0x7000:05:8` | LEDG |
| | | `0x7000:06:8` | LEDR |
| | | `0x7000:07:8` | LEDB |
| Tx `0x1a00` (SM3) | | `0x6000:01:8` | IStatus |
| | | `0x6000:02:8` | IButton |
| | | `0x6000:03..08:16` | FTRawFx, Fy, Fz, Tx, Ty, Tz |
| | | `0x6000:09:8` | FTOverloadStatus |
| | | `0x6000:0a:8` | FTErrorFlag |

- `InitSyncs()` (override): `{0,OUTPUT,0,NULL,WD_DISABLE},{1,INPUT,0,NULL,WD_DISABLE},{2,OUTPUT,1,pdos+0,WD_ENABLE},{3,INPUT,1,pdos+1,WD_DISABLE},{0xff}`.
- `ReadFromSlave()` (early-returns if `!IsSlaveOnline()`): converts raw counts to float via `Fx/Fy/Fz = raw / FT_FORCE_DIVIDER(=50.0)`, `Tx/Ty/Tz = raw / FT_TORQUE_DIVIDER(=2000.0)`; on `FTErrorFlag != 0` logs `DBG_LOG_WARN` and sets `m_eFTState=FT_FAULT`.
- `WriteToSlave()` (early-returns if `!IsSlaveOnline()`) runs the FT config state machine into `FTConfigParam` (only when `m_bFTOn`, else writes `FT_STOP_DATA_OUTPUT`), then writes ILed/IGripper/FTConfigParam/LEDMode/LEDG/LEDR/LEDB. FT command bases: `FT_START_DATA_OUTPUT=0x0B`, `FT_STOP_DATA_OUTPUT=0x0C`, `FT_BIAS_COMMAND=0x11`, `FT_DATARATE_COMMAND=0x0F`, `FT_FILTER_COMMAND=0x118`. Builders: datarate=`0x0F+(GetFTDataRate(code)<<8)`, filter=`0x118+(GetFTLPFCof(code)<<16)`, bias=`0x11+(enabled?1<<8:0)`.
- `FT_STATE_MACHINE { FT_NONE, FT_READY, FT_SET_DATARATE, FT_SET_FILTER, FT_SET_START, FT_SET_BIAS, FT_FAULT }` (enum order); the actual `FTSensorOn` run sequence is NONE→READY→SET_FILTER→SET_DATARATE→SET_START→SET_BIAS (FAULT→READY). `LED_MODE { NO_COLOR, BLINK_RED, STEADY_RED, BLINK_GREEN, STEADY_GREEN, BLINK_BLUE, STEADY_BLUE, BLINK_YELLOW, STEADY_YELLOW }` with `LED_OFF/RED/GREEN/BLUE/YELLOW(int blink)` helpers (`BLINK=1`,`STEADY=0`). `FT_ERROR_CODE { NO_ERROR=0x00, UNSUPPORTED_COMMAND=0x01, OUT_OF_RANGE=0x02, FAILED_PARAMETER=0x03 }`.
- Data-rate map `GetFTDataRate(Hz)`: 1000→0x08, 500→0x07, 333→0x06, 200→0x05, 100→0x04, 50→0x03, 20→0x02, 10→0x01, else 0x00. LPF map `GetFTLPFCof(Hz)`: 500→0x01, 300→0x02, 200→0x03, 150→0x04, 100→0x05, 50→0x06, 40→0x07, 30→0x08, 20→0x09, 10→0x0A, 5→0x0B, 3→0x0C, 2→0x0D, 1→0x0E, 0→0x00. `FTSensorOn(bool biasing=true, int output_rate=1000, int lpf_cof=100)`, `FTSensorOff()`, `IsFTSensorOn()`.

##### 4.11 Key API / signature reference (base servo + representative sensors)

| Signature | Class | One-line semantics |
|---|---|---|
| `virtual BOOL RegisterPDO()` | all | Map each PDO entry to a domain byte-offset/bit-pos; **returns TRUE in practice — the per-entry `0 > offset` failure check is dead (unsigned), see §4.0** |
| `virtual void InitSyncs()` | CIA402/KistarHand/NRMK | Fill `ec_sync_info_t[]` and call `SetEcatPdoSync()` (EL2024/KistFT/FBG set sync in ctor instead) |
| `virtual void WriteToSlave()` | all | Marshal `stOutPDOs`→process image each RT cycle (+FSM logic) |
| `virtual void ReadFromSlave()` | all | Marshal process image→`stInPDOs` each RT cycle |
| `BOOL SetServoOn(INT8 mode=CIA402_PROFILE_POSITION)` | CIA402 | Request CiA402 transition to OPERATION_ENABLED in `mode` |
| `BOOL SetServoOff()` | CIA402 | Request drop out of OPERATION_ENABLED |
| `BOOL SetTargetPos(INT32,BOOL forced=TRUE,BOOL rel=FALSE)` | CIA402 | Set target pos (CSP/PP only); toggles new-set-point/halt |
| `BOOL SetTargetVel(INT32,BOOL forced=FALSE)` | CIA402 | Set target vel (CSV/PV only) |
| `void SetTargetTor(INT16)` / `void SetDriveMode(INT8)` | CIA402 | Set target torque / validated mode-of-operation |
| `void GoHome()` | CIA402 | Switch to HM mode and trigger homing |
| `UINT16 GetStatusWord()/GetRawStatusWord()` | CIA402 | Decoded state / raw `0x6041` word |
| `INT32 GetActualPos()/GetActualVel()`, `INT16 GetActualTor()` | CIA402 | Feedback |
| `void RegisterCallbackStateChange/ParamUpdate(CALLBACK_FN)` | CIA402 | Register `std::function<void(PVOID,PVOID,PVOID,PVOID)>` hooks |
| `void SetLedValue(UINT8)` | EL2024 | Set DO channel-1 byte |
| `void SetOperationMode(INT)` | KistFT | Select ADC/bias mode word |
| `void SetBiasing(BOOL)/SetTheta(INT32)` | FBG | Command bias/angle |
| `void SetTargetPos(int axis,INT16)`, `INT16 GetPosition(int axis)` | KistarHand | Per-joint command/feedback (16 axes) |
| `void FTSensorOn(bool,int,int)/FTSensorOff()` | NRMK | Configure & start/stop FT stream |
| `float GetFx()/GetTx()` | NRMK | Engineering-unit F/T (raw/50, raw/2000) |

##### 4.12 Compiled-vs-header + device summary table

Per `EMasterApp/Makefile`, `SOURCES` = `EcatMasterBase.cpp`, `EcatSlaveBase.cpp`, `SlaveCIA402Base.cpp`, `SlaveNRMKEndTool.cpp` only. Output: `EMasterApp/lib/libEMasterApp.{a,so}`; `make install` copies `Device/*.h`→`../include/EMasterApp/` and libs→`../lib/EMasterApp/`. Build is hardcoded to `/opt` (IgH at `/opt/etherlab`, rt_posix at `/opt/rt_posix`) with `-O3 -mtune=native -flto` — retarget `-mtune` for the Kria KV260 aarch64 cross build.

| Slave class | Physical device | Vendor:Product | DC (activate/shift) | Compiled into lib? | Key PDOs (Rx→slave / Tx→master) |
|---|---|---|---|---|---|
| `CSlaveCIA402Base` | Generic CiA402 servo | (set by subclass) | via subclass | **Yes** (`.cpp`) | Rx `0x1600`: 6040,607A,60FF,6071,6060 · Tx `0x1a00`: 6041,6064,606C,6077,6061 |
| `CSlaveELMO` | ELMO Platinum drive | `0x9a:0x00100002` | Yes / 0x300 / 0 | Header-only (uses base `.cpp`) | inherits CIA402 map |
| `CSlaveEPOS4` | labeled Maxon EPOS4; actually ELMO cfg | `0x9a:0x00100002` | Yes / 0x300 / 0 | Header-only (uses base `.cpp`) | inherits CIA402 map |
| `CSlaveBeckhoffEK1100` | EtherCAT bus coupler | `0x2:0x044c2c52` | No | Header-only | none (infrastructure) |
| `CSlaveBeckhoffEL2024` | 4-ch digital output | `0x2:0x07e83052` | No | Header-only | Rx `0x1600..0x1603`: 7000/7010/7020/7030:01 (only ch1 wired) |
| `CSlaveBeckhoffCU1124` | EtherCAT junction | `0x2:0x04645432` | No | Header-only | none (infrastructure) |
| `CSlaveKistFT` | KIST 6-axis F/T sensor | `0x00828845:0x00009252` | No | Header-only | Rx `0x1600`: 7000:01/02 · Tx `0x1a00`: 6000:01..07 (Fx…Tz,count) — **read map buggy, §4.7** |
| `CSlaveFBGSensor` | FBG optical F/T sensor (LAN9252) | `0xe00004d8:0x00009252` | No | Header-only | Rx `0x1600`: 0005:01/02 (Theta,Bias) · Tx `0x1a00`: 0006:01..0e (14×) |
| `CSlaveKistarHand` | KISTAR 16-DOF hand | `0x0:0x00000004` | No | **No** (`.cpp` absent from Makefile) | Rx `0x1600`: 0007:01..20 (32) · Tx `0x1a00`: 0006:01..40 (64) — **register map buggy, §4.9** |
| `CSlaveNrmkEndtool` | Neuromeka EOAT (FT+gripper+LED) | `0x0000089a:0x10000007` | Yes / 0x300 / 0 | **Yes** (`.cpp`) | Rx `0x1600`: 7000:01..07 · Tx `0x1a00`: 6000:01..0a |

---
#### 5. Robot HAL — Axis hierarchy (`CRobot/Axis*`)

This subsystem is the motor/axis Hardware Abstraction Layer. A single abstract base (`CAxis`) defines the command/state/units contract; concrete subclasses bind that contract either to a **real EtherCAT CiA402 servo drive** (via a composed `CSlaveCIA402` slave object) or to a **simulated actuator** (pure-RT integrator, or MuJoCo physics). Because every subclass presents the identical `CAxis` interface, the upstream trajectory/robot controller (`CRobot`) runs unchanged against real hardware or simulation — the sim axes are drop-in substitutes for an EtherCAT axis.

All files live under `CRobot/`. Real-EtherCAT axes depend on `include/EMasterApp/` (`EcatMasterBase.h`, `SlaveCIA402Base.h`, `EcatCommon.h`); simulation axes depend only on `Axis.h` (+ MuJoCo for the MuJoCo variants).

##### 5.0 File inventory

| File | LOC | Role |
|---|---|---|
| `CRobot/Axis.h` | 349 | `CAxis` abstract base: enums, param/limit structs, full virtual command+state+units API |
| `CRobot/Axis.cpp` | 722 | `CAxis` implementation: unit conversions, limit checks, param bookkeeping, default (mostly `FALSE`) command stubs |
| `CRobot/AxisCIA402.h` | 83 | `CAxisCIA402 : CAxis` — generic CiA402-over-EtherCAT axis; composes `CSlaveCIA402 m_cEcSlave` + `CEcatMaster*` |
| `CRobot/AxisCIA402.cpp` | 563 | CiA402 impl: master registration, servo on/off, drive-mode gating of Move*, two slave callbacks, axis state machine |
| `CRobot/AxisNRMKCore.h` | 31 | `CAxisNRMKCore : CAxisCIA402` — Neuromeka CORE drive; overrides torque↔count math |
| `CRobot/AxisNRMKCore.cpp` | 125 | Torque→motor-current→raw-count conversion using gear/Kt/current-ratio; status callback |
| `CRobot/AxisELMO.h` | 35 | `CAxisELMO : CAxisCIA402` — ELMO drive (banner text mislabels it "AxisEPOS4"; include guard `__AXIS__ELMO__`) |
| `CRobot/AxisELMO.cpp` | 122 | ELMO torque path in mNm, additional-pos scaling, `GetCurrentTor` mNm→Nm (file banner mislabels "AxisEPOS4.cpp") |
| `CRobot/AxisEPOS4.h` | 26 | `CAxisEPOS4 : CAxisCIA402` — header-only, empty body (uses all CiA402 defaults); guard `__AXIS__EPOS4__` |
| `CRobot/AxisRT.h` | 157 | `CAxisRT : CAxis` — pure real-time simulated axis (no EtherCAT, no MuJoCo); PID + 1-DOF motor ODE |
| `CRobot/AxisRT.cpp` | 434 | RT-sim impl: `StepSimulation(dt)`, motor dynamics integrator, encoder emulation |
| `CRobot/AxisMuJoCo.h` | 127 | `CAxisMuJoCo : CAxis` — MuJoCo-physics-backed axis, one axis ↔ one `mjModel` joint id |
| `CRobot/AxisMuJoCo.cpp` | 463 | Reads state from `mjData`, applies torque to `mjData->ctrl[]`, PID position/velocity |
| `CRobot/AxisRTMuJoCo.h` | 113 | `CAxisRTMuJoCo : CAxisRT` + `CRobotRTMuJoCo` multi-axis controller; RT↔viz lock-free bridge |
| `CRobot/AxisRTMuJoCo.cpp` | 359 | Hybrid: RT thread runs `CAxisRT` sim, publishes atomically to a non-RT MuJoCo visualization thread |

##### 5.1 Inheritance diagram (ASCII)

```
                              CAxis  (abstract HAL base, Axis.h/.cpp)
                                │
        ┌───────────────────┬──┴───────────────┬──────────────────┐
        │                   │                   │                  │
   CAxisCIA402          CAxisRT            CAxisMuJoCo        (CAxis used directly
  (EtherCAT/CiA402)   (pure-RT sim)      (MuJoCo-backed sim)   as sensor axes)
        │                   │
   ┌────┼────────┐     CAxisRTMuJoCo
   │    │        │    (RT sim + MuJoCo viz)
CAxisNRMKCore  CAxisELMO  CAxisEPOS4
(Neuromeka)   (ELMO)     (empty)

Composition (real axes): CAxisCIA402  ──has-a──►  CSlaveCIA402  m_cEcSlave   (EtherCAT PDO/SDO endpoint)
                         CAxisCIA402  ──ptr────►  CEcatMaster*  m_pEcMaster  (IgH/EtherLab master wrapper)
Composition (sim):       CAxisMuJoCo  ──ptr────►  mjModel* / mjData*         (one joint id per axis)
                         CAxisRTMuJoCo──owns────►  RTVisualizationData x2 (lock-free RT↔viz double buffer)
Aggregation:             CRobotRTMuJoCo owns std::vector<unique_ptr<CAxisRTMuJoCo>>
```
Note: `CSlaveCIA402` is **not a distinct class** — it is `typedef CSlaveCIA402Base CSlaveCIA402;` (`SlaveCIA402Base.h:363`). ALL four CiA402 axis variants (generic, NRMKCore, ELMO, EPOS4) embed this same generic base slave; the device-specific `CSlaveELMO`/`CSlaveEPOS4` headers exist under `include/EMasterApp/` but are **not** composed by the Axis layer.

Command flow substitution: `CRobot`/controller calls `MoveTorque(Nm)`, `MoveAxis(rad)`, `GetCurrentPos()` etc. on a `CAxis*`. For a real axis this becomes an EtherCAT PDO write via `m_cEcSlave`; for a sim axis it updates internal state that a `StepSimulation`/`UpdateFromMuJoCo` call later integrates. The controller cannot tell them apart.

##### 5.2 Enums and structs (`Axis.h`)

`eHomingMethod`: `eAxisHomingNotSet=0, eAxisHomeStartPos, eAxisHomeSearch, eAxisHomeManual, eAxisHomeBuiltin`.

`eCommType`: `eAxisRS232=0, eAxisRS485, eAxisEthernet, eAxisEtherCAT, eAxisMuJoCo=0x20, eAxisUnknownCommType=0x30`. **Both `CAxisRT` and `CAxisMuJoCo` construct with `(eCommType)0x20` = `eAxisMuJoCo`** — the RT sim axis reports MuJoCo comm type despite not using MuJoCo.

`eAxisType`: `eAxisRevolute=0, eAxisContinuous, eAxisPrismatic, eAxisPlanar, eAxisFixed, eAxisFloating, eAxisJointless, eAxisSensor`. `IsActuator()` returns FALSE when `type >= eAxisSensor`. `m_dOneTurnRef` is auto-set to `TWO_M_PI` (6.283185307179586) for revolute, else `1.0`; non-revolute joints must call `SetOneTurnRef(lead)` (screw lead for prismatic) — note `SetOneTurnRef` returns FALSE and does nothing on a revolute axis.

`eAxisState` (ordered — comparisons rely on ordering): `eAxisEmergency=0x00, eAxisError, eAxisUnknownState, eAxisDeinit, eAxisDisconnected, eAxisInit, eAxisIdle, eAxisHoming, eAxisRunning, eAxisStopped`. `IsMovable()` = `(state > eAxisInit) && IsLimitConfigured() && IsEnabled()` — i.e. state must be ≥ `eAxisIdle`.

Structs:
- `ST_AXIS_INFO {eAxisState eState; eAxisType eJoint; eCommType eComm; eHomingMethod eHoming;}` — defaults eState=Unknown, eJoint=Revolute, eComm=EtherCAT, eHoming=NotSet.
- `ST_AXIS_PARAMS {double dPos,dVel,dTor;}` — engineering units (rad or mm; rad/s; Nm or mNm depending on subclass).
- `ST_AXIS_RAW_PARAMS {INT32 nPos,nVel,nTor;}` — raw encoder counts / drive units.
- `ST_LIMITS {BOOL bIsSet; double dUpper,dLower;}`.
- `ST_AXIS_LIMITS {BOOL bIsSet; ST_LIMITS stPos,stVel,stAcc,stDec,stJerk,stTorque;}` — six independent limit pairs; `IsLimitConfigured()` requires all six `bIsSet==TRUE`. (Its loop bound is `sizeof(bLimits)` over a `BOOL[6]`; this happens to be safe only because `BOOL` is `typedef bool` in `Defines.h`, so `sizeof(bLimits)==6`.)

##### 5.3 `CAxis` — abstract base (units, limits, state, bookkeeping)

Constructor `CAxis(eCommType, eAxisType, BOOL abAbsoluteEncoder=TRUE, BOOL abCCW=TRUE, BOOL abEnabled=TRUE)`. Sets `m_dResolution=m_dGearRatio=m_dEncoderRatio=m_dTorqueConstant=m_dCurrentRatio=1.0`; **`m_dTransRatio` is NOT initialized in the ctor** — it is only ever assigned via `SetResolution`, so a bare `CAxis` (or any axis constructed without calling `SetResolution`) has an indeterminate `m_dTransRatio` in the position formulas. `m_nDirection = +1` if `abCCW`, else `-1` (CW = inverse polarity). Allocates 5 heap structs (info/limits/params/rawParams/startRawParams), freed in dtor.

**Unit-conversion math (the load-bearing equations):**
```
ConvertRadMM2Res(pos)  = (INT32)( (pos / m_dOneTurnRef) * m_dTransRatio * m_dGearRatio * m_dResolution * m_nDirection )
ConvertRes2RadMM(res)  = m_dOneTurnRef * ( res / m_dResolution / m_dGearRatio / m_dTransRatio ) * m_nDirection
ConvertCur2Tor(cur,useTC=T) = useTC ? cur*Kt : cur*RatedTorque/RatedCurrent      (guards RatedCurrent==0)
ConvertTor2Cur(tor,useTC=T) = useTC ? tor/Kt : tor*RatedCurrent/RatedTorque      (guards RatedTorque==0)
```
where `Kt=m_dTorqueConstant`, and `SetResolution(adRes, adGearRatio=1, adTransRatio=1)` assigns `m_dResolution=adRes, m_dGearRatio=adGearRatio, m_dTransRatio=adTransRatio`. Note the header param is named `adEncRatio` but the impl stores it into `m_dTransRatio` (naming discrepancy; `m_dEncoderRatio` exists but is unused in conversions). `adEncRes` is expected to already fold in the encoder decode multiplier (X1/X2/X4).

**BUG / STUB — base torque↔count converters are effectively identity casts.** `CAxis::ConvertTor2Res(adTor)` computes `res = (int)(m_nDirection*ConvertTor2Cur(adTor)*1000.0/RatedCurrent)` **but then `return (INT32)adTor;`** — the computed `res` is dead code. Likewise `CAxis::ConvertRes2Tor(adRes)` computes `torque = m_nDirection*adRes*RatedTorque/1000.0` then **`return (double)adRes;`**. So for any subclass that does not override these (plain `CAxisCIA402`, `CAxisEPOS4`, `CAxisELMO`), torque↔count is a raw numeric passthrough, not a physical conversion. Only `CAxisNRMKCore` overrides them correctly.

**Position/velocity/torque limits & checks:** private `SetLimits(ST_LIMITS&,lo,hi)` sets bounds+bIsSet; `CheckLimits(ST_LIMITS&,x)` returns `lo<=x<=hi`. Public `IsAllowablePosition/Velocity/Acceleration/Deceleration/Jerk/Torque(x)` wrap `CheckLimits`. `SetPositionLimits(lo,hi,abIsRad=FALSE)` converts deg→rad (via `ConvertDeg2Rad`) only for revolute axes; single-arg `SetPositionLimits(v)` sets `±v` (and also deg→rad for revolute). Vel/acc/dec/jerk/torque have the same ±-symmetric single-arg overload but do **no** unit conversion. `GetMaxPos()/GetMinPos()` return the position upper/lower bound.

**Param bookkeeping / home offset:** `UpdateCurrentParams(INT32 pos,vel,tor)` stores raw, then computes displayed position relative to home: `nCurrentPos = rawPos - GetHomePosition()` if `IsHomeSet()`, else `rawPos - GetStartRawPos()`; converts pos+vel via `ConvertRes2RadMM` and tor via `ConvertRes2Tor` and stores engineering-unit params. (A large limit-enforcement block is present but fully commented out.) `GetCurrentPos()` (rad/mm), `GetCurrentPosD()` (deg via `ConvertRad2Deg`), `GetCurrentVel()`, `GetCurrentTor()`, and raw variants `GetCurrentRawPos/Vel/Tor()` read back these fields. `IsMoving()` = `fabs(GetCurrentVel())>0`.

**Default command implementations are inert:** `ServoOn/ServoOff/DoHoming/MoveAxis/StopAxis/EmgStopAxis/MoveVelocity/MoveTorque/SetVelocity/SetAcceleration/SetDeceleration/SetJerk/SetTorque/IsServoOn/ChangeDriveMode` all `return FALSE` in the base. `Init()` sets state `eAxisInit` and returns TRUE; `DeInit()` sets `eAxisDeinit`. `MoveHome(forced)` = `MoveAxis(m_nHomePosition, forced)`; `MovePosLimit/MoveNegLimit` move to the pos-limit upper/lower. Subclasses override the real behavior. The `virtual INT32 Get*Raw*/GetVelocity/GetMaxVel/...` EtherCAT getters all return `0` in the base.

##### 5.4 `CAxisCIA402` — real EtherCAT CiA402 axis (`AxisCIA402.h/.cpp`)

Ctor `CAxisCIA402(eAxisType, double adEncRes, double adGearRatio, double adTransRatio, absEnc=T, CCW=T, enabled=T, connected=T)` → base `CAxis(eAxisEtherCAT,…)`, calls `SetResolution(adEncRes,adGearRatio,adTransRatio)`; if `!connected` forces disabled. Members: `CSlaveCIA402 m_cEcSlave` (**`CSlaveCIA402` is a typedef alias of `CSlaveCIA402Base`**, `SlaveCIA402Base.h:363` — the value-composed slave that owns the PDO image), `CEcatMaster* m_pEcMaster`, `BOOL m_bConnected`, `INT32 m_nPosBeforeDisconnect`.

**`Init(CEcatMaster& master, INT8 driveMode=CIA402_PROFILE_POSITION)`** (overload of base Init) is the integration entry point:
1. Returns TRUE if already `>= eAxisInit`.
2. Fails (DeInit) if `!IsLimitConfigured()`.
3. Validates homing method: `eAxisHomeSearch` requires `IsHomeReferenceSet()`, `eAxisHomeManual` requires `IsHomeSet()`; `eAxisHomeBuiltin`/`eAxisHomingNotSet`/default → error+DeInit; `eAxisHomeStartPos` OK.
4. If connected: stores master ptr, `m_pEcMaster->AddSlave(&m_cEcSlave)`, reads `GetAlias()/GetPosition()` → `SetAliasPos()`.
5. If enabled: registers two `std::bind` callbacks on the slave — `RegisterCallbackStateChange(→OnSlaveStatusChanged)` and `RegisterCallbackParamUpdate(→OnSlaveUpdateRawParam)` — then either `ServoOn(driveMode)` (if `IsAutoServoOn()`) or `m_cEcSlave.SetDriveMode(driveMode)`. On success → `CAxis::Init()` (state=Init). (Note: `IsAutoServoOn()` defaults to FALSE.)

**Drive-mode gating** (constants from `EcatCommon.h`): `CIA402_PROFILE_POSITION=0x01`, `CIA402_PROFILE_VELOCITY=0x03`, `CIA402_PROFILE_TORQUE=0x04`, `CIA402_CYCLIC_POSITION=0x08`, `CIA402_CYCLIC_VELOCITY=0x09`, `CIA402_CYCLIC_TORQUE=0x0A`. Each Move* checks `m_cEcSlave.GetActualDriveMode()` and refuses if not in a compatible mode:
- `MoveAxis(rad,force=T,abs=T)`: requires CYCLIC_POSITION or PROFILE_POSITION. Absolute target (only when `abAbs && IsHomeSet()`) uses `nRef=GetHomePosition()` with `IsAllowablePosition(target)` check; otherwise relative uses `nRef=GetCurrentRawPos()` (with an `IsAllowablePosition(cur+target)` guard when HomeSet). Writes `m_cEcSlave.SetTargetPos(nRef + ConvertRadMM2Res(target))`.
- `MoveVelocity(rad/s)`: requires CYCLIC/PROFILE_VELOCITY + `IsAllowableVelocity`; `SetTargetVel(ConvertRadMM2Res(vel))`.
- `MoveTorque(Nm)`: requires CYCLIC/PROFILE_TORQUE; `SetTargetTor((INT16)ConvertTor2Res(tor))` — with the base identity converter this passes the numeric torque through unscaled (subclasses fix this).
- `MoveHome(force)`: requires movable + position mode; `SetTargetPos(GetHomePosition(),force)`.
- `StopAxis()`: `IsMovable()` guard, then `m_cEcSlave.SetHalt(TRUE)`. `EmgStopAxis()`: `m_cEcSlave.SetEmgStop()`.

Servo/mode: `ServoOn(driveMode=PROFILE_POSITION)` → guard `!(IsConnected() AND IsEnabled)` then `m_cEcSlave.SetServoOn(driveMode)`; `ServoOff()` → `SetServoOff()`; `ChangeDriveMode(mode)` → `SetDriveMode(mode)`; `IsServoOn()` → `m_cEcSlave.IsServoOn()`. Profile setters: `SetVelocity(rpm)` sets both `SetProfileVel` and `SetMaxProfileVel`; `SetAcceleration/SetDeceleration` set `SetProfileAcc/Dec` (all gated on limit-allowable). Getters forward to slave: `GetTargetRawPos/Vel/Tor`, `GetVelocity`(actual profile vel), `GetMaxVel/GetMaxAcc/GetQuickStopDec`, `GetDriveMode`, `GetStatusWord`(raw), `GetControlWord`, `GetAcceleration/GetDeceleration`, `GetAdditionalPos`. Inline `SetTargetTorq(int16)`/`SetTargetPos(int32)` write the slave PDO directly.

**Vendor/DC config forwarders (EtherCAT identity):** `SetVendorInfo(UINT32 vendorID, UINT32 productCode)` → `m_cEcSlave.SetVendorInfo(...)`; `SetDCInfo(BOOL dcSupported, UINT16 activateWord, INT32 shiftTime)` → `m_cEcSlave.SetDCInfo(...)`. **The actual PDO map lives entirely in `CSlaveCIA402Base` (the Axis layer only forwards vendor/product/DC and reads/writes the CiA402 fields the slave exposes).** For reference, the base slave's fixed default mapping is RxPDO `0x1600` (5 entries: control word `0x6040`:16, target position `0x607A`:32, target velocity `0x60FF`:32, target torque `0x6071`:16, mode-of-operation `0x6060`:8) and TxPDO `0x1a00` (5 entries: status word `0x6041`:16, actual position `0x6064`:32, actual velocity `0x606C`:32, actual torque `0x6077`:16, mode-of-operation-display `0x6061`:8) — the profile-vel/acc/dec, quick-stop, max-profile, additional-pos, rated-current and error-code entries are present but commented out. ESI vendor/product IDs and DC-sync register values are also defined in the slave subsystem — verify there.

**Axis state machine — `SetState(eAxisState)`** (override): computes a transition label but never prints (its `bPrintState` guard is hardcoded FALSE); if previous state was `eAxisDisconnected`, it discards the transition when `GetCurrentRawPos() != m_nPosBeforeDisconnect` (position moved during power loss); on entering `eAxisDisconnected` it captures `m_nPosBeforeDisconnect = GetCurrentRawPos()`. `SetHomingFlag(flag=T)` sets `m_bIsHoming` and forces state `eAxisHoming`.

**Callback `OnSlaveStatusChanged(slave,status,…)`** maps drive servo status → axis state: `eServoOff→(no-op)`, `eServoIdle→` (first-time: capture start pos → if `eAxisHomeStartPos` set home `= startPos - GetPositionBeforeExit()`, seed current+start raw params; then `eAxisIdle` if HomeSet else `eAxisInit`), `eServoHoming→eAxisHoming`, `eServoRunning→eAxisRunning`, `eServoStopped→eAxisStopped`, `eServoFault→eAxisError`, `eServoDisconnected→eAxisDisconnected`. `eSERVO_STATUS` (from `SlaveCIA402Base.h`): `eServoOff=0x00, eServoIdle, eServoStopped, eServoHoming, eServoRunning, eServoFault=0x80, eServoDisconnected`. **Callback `OnSlaveUpdateRawParam(slave,params,…)`** runs every parsed EtherCAT frame: it copies `*(CSlaveCIA402Base*)apSlave` and `*(ST_RAW_DATA*)apParams` by value, then `UpdateCurrentParams(stRawParams.nActualPos, nActualVel, nActualTor)` (note `ST_RAW_DATA.nActualTor` is INT16). The low-level CiA402 INIT/PREOP/SAFEOP/OP transition and 402 control/status-word handshake live in the slave/master layer; this class consumes only the derived `eSERVO_STATUS`.

##### 5.5 `CAxisNRMKCore` — Neuromeka CORE drive (`AxisNRMKCore.h/.cpp`)

`CAxisNRMKCore : CAxisCIA402`. **Ctor quirk:** forwards to base as `CAxisCIA402(aeAxisType, adEncRes, adGearRatio, adGearRatio, …)` — passes `adGearRatio` in the `adTransRatio` slot — but then immediately calls `SetResolution(adEncRes, adGearRatio, adTransRatio)` which overwrites with the correct trans ratio. Net effect correct, but the base ctor line is misleading.

Overrides the torque↔count math (this is the correct torque→current→count chain, gated to torque mode):
```
MoveTorque(adTor):   dmotorcurrent = adTor / m_dGearRatio / m_dTorqueConstant
                     m_cEcSlave.SetTargetTor( (INT16)( dmotorcurrent * m_dCurrentRatio * m_nDirection ) )
ConvertTor2Res(tor): (INT32)( (tor/gear/Kt) * currentRatio * dir )
ConvertRes2Tor(res): (res / currentRatio) * gear * Kt * dir
```
i.e. joint-torque → motor-torque (÷gear) → motor-current (÷Kt) → raw drive counts (×currentRatio), sign via `m_nDirection`. `OnSlaveStatusChanged` is a copy of the CIA402 version (same mapping).

##### 5.6 `CAxisELMO` — ELMO drive (`AxisELMO.h/.cpp`)

`CAxisELMO : CAxisCIA402` (file banners erroneously say "AxisEPOS4"; include guard `__AXIS__ELMO__`; commented-out macros hint ELMO example values `RatedCurrent=14710 mA`, `RatedTorque=1323 mNm`). Ctor forwards straight to base. Torque handling is in **mNm**:
- `MoveTorque(adTor /*Nm*/)`: requires torque mode; sets `m_dTargetTorq=adTor`; `dTor = adTor*1000.0` (Nm→mNm); warns if `!IsAllowableTorque(dTor)`; if `IsAllowablePosition(GetCurrentPos())` → `SetTargetTor((INT16)ConvertTor2Res(dTor))` (ELMO does NOT override `ConvertTor2Res`, so this is the base identity → sends mNm as raw), else `SetTargetTor(0)` and returns FALSE (position-limit guard).
- `GetAdditionalPos()` = `m_cEcSlave.GetAdditionalPos() * m_dOneTurnRef / m_dResolution`.
- `GetCurrentTor()` = `m_pstAxisParams->dTor / 1000.0` (mNm→Nm).

**BUG:** `OnSlaveStatusChanged` sets `m_bFirstHome = FALSE;` immediately *before* the `if (TRUE == m_bFirstHome)` start-position-capture block, so that block is dead code and start-pos/home is never captured here.

##### 5.7 `CAxisEPOS4` — Maxon EPOS4 (`AxisEPOS4.h`)

Header-only, empty body: `CAxisEPOS4 : CAxisCIA402`, ctor just forwards all args. Inherits every CiA402 default including the base (identity) torque converter — no EPOS4-specific scaling implemented. Effectively a plain CiA402 axis. (Uses the generic `CSlaveCIA402` slave, not the separate `SlaveEPOS4.h`.)

##### 5.8 SIMULATION variant — `CAxisRT` (pure real-time, no EtherCAT) (`AxisRT.h/.cpp`)

`CAxisRT : CAxis`, ctor uses comm type `(eCommType)0x20`. This substitutes for an EtherCAT axis by running a **1-DOF motor ODE + PID** in software; there is no slave, no master, no PDO. The controller drives it with the same `MoveTorque/MoveVelocity/MoveAxis` and reads `GetCurrentPos/Vel/Tor` — but the state only advances when `StepSimulation(dt)` is called from the RT loop.

Internal state: `enum eControlMode {CONTROL_POSITION, CONTROL_VELOCITY, CONTROL_TORQUE}` (default `CONTROL_POSITION`); two `PIDController` structs (RT-safe `compute(error,dt)` with anti-windup via `integral_limit` and output clamp via `output_limit`); `MotorDynamics {inertia, damping, friction, position, velocity, acceleration}`. Sim scalars: `m_bServoOn, m_dSimTime, m_dExternalTorque, m_dMotorTorque, m_dMotorCurrent, m_dProfileVel/Acc/Dec`.

Constructor defaults (from INDY7 tuning): profile vel `130.0` deg/s, acc/dec `10000.0`; position PID `kp=800, ki=0.1, kd=80, out_limit=100 Nm, integral_limit=10`; velocity PID `kp=50, ki=0.05, kd=5, out=100, integral=10`; motor dynamics `inertia=0.001 kg·m², damping=0.01, friction=0.001`.

Key methods:
- `Init()` — verbose printf debug; fails (state=Error) if `!IsLimitConfigured()`; seeds `m_motorDynamics.position=ConvertRes2RadMM(GetCurrentRawPos())` and `m_dSimulatedEncoderPos=GetCurrentRawPos()`; if `eAxisHomeStartPos`, `SetHomePosition(m_dSimulatedEncoderPos)`; state=Init.
- `ServoOn()` — requires enabled; resets both PIDs; state=Idle. `ServoOff()` — zero torque/current, state=Init. `IsServoOn()`.
- `StepSimulation(double dt)` — **the RT tick.** Returns early if `!IsServoOn()||dt<=0`. Computes `controlTorque` per mode (POSITION: PID on `m_dTargetPos - position`; VELOCITY: PID on `m_dTargetVel - velocity`; TORQUE: `controlTorque = m_dTargetTorq`), `ApplyTorqueLimits`, then `UpdateMotorDynamics(dt)`, `UpdateSimulatedEncoder()`, `m_dMotorCurrent=ConvertTor2Cur(torque)`, and `UpdateCurrentParams(ConvertRadMM2Res(pos), ConvertRadMM2Res(vel), ConvertTor2Res(torque))`. Sets Idle/Running by velocity threshold `1e-6`.
- `UpdateMotorDynamics(dt)` — Euler integration of `J·a = T_motor + T_external − B·v − T_friction`: `acceleration=totalTorque/inertia; velocity += a·dt; position += v·dt;` then hard-clamps to position limits (zeroes velocity at the stop).
- `ApplyTorqueLimits(&t)` clamps to `stTorque` limits. `SetExternalTorque(t)`, `SetMotorParameters(inertia,damping,friction)`, `SetPosition/Velocity/TorqueControl()` mode setters, `GetSimulationTime()`, `GetMotorCurrent()`.

**How MoveTorque maps torque→current→counts (sim path):** `MoveTorque(Nm)` merely stores `m_dTargetTorq` and sets state Running (the limit-check/mode-set lines are commented out — it does NOT switch to CONTROL_TORQUE). The actual mapping happens in `StepSimulation`, but only if the mode was set to CONTROL_TORQUE separately (via `SetTorqueControl()`): target Nm → `controlTorque` → `m_dMotorCurrent = ConvertTor2Cur(torque)` (Nm÷Kt) → `rawTor = ConvertTor2Res(torque)` (base identity) stored as raw encoder torque.

**BUGS/STUBS to flag:** `MoveAxis()` is **broken/incomplete** — `m_dTargetPos` is never assigned on any code path (only a discarded local `targetPos` is computed). Because of missing braces after `else if (!abAbs)`, that branch's single controlled statement is `SetState(eAxisEmergency);`, so a **relative** command (`abAbs==FALSE`) forces the axis into `eAxisEmergency`, while an **absolute** command (the default `abAbs==TRUE`) returns TRUE with **no state change and no target update**. Either way the position command is silently dropped; `return TRUE;` is unconditional. `MoveHome/StopAxis/EmgStopAxis` are explicit stubs returning FALSE ("Linker error fix" comment).

##### 5.9 SIMULATION variant — `CAxisMuJoCo` (physics-backed) (`AxisMuJoCo.h/.cpp`)

`CAxisMuJoCo : CAxis`, comm type `(eCommType)0x20`, ctor `CAxisMuJoCo(eAxisType, int mjJointId, adEncRes=65536, …)`. Substitutes for an EtherCAT axis by binding to **one MuJoCo joint** (`int m_nMjJointId`) inside a shared `mjModel*`/`mjData*`. State comes from `mjData->qpos/qvel/qfrc_actuator[jointId]`; commands go to `mjData->ctrl[jointId]`. MuJoCo types forward-declared in the header (`struct mjModel_/mjData_`); real include only in a `.cpp`/consumer.

- `Init(mjModel*, mjData*)` — null/`njnt`-range/limit checks (state=Error on failure); binds model+data; `m_dSimulatedEncoderPos=ConvertRadMM2Res(qpos[id])`; start-pos home if `eAxisHomeStartPos`; state=Init.
- `UpdateFromMuJoCo()` (RT-safe read): `dt = data->time - lastTime`; reads `qpos,qvel,qfrc_actuator[id]`, converts via `ConvertRadMM2Res`/`ConvertTor2Res`, `UpdateCurrentParams(...)`; Idle/Running by `1e-6` velocity threshold.
- `ApplyToMuJoCo()` (RT-safe write): early-returns if `dt<=0`; per mode computes PID (`ComputePIDPosition/Velocity`, which store output in `pid.integral`) or passes `m_dTargetTorq`; `ApplyTorqueLimits`; writes `mjData->ctrl[id]=outputTorque`.
- `ComputePIDPosition/Velocity(dt)` — textbook P+I+D with output clamp; the MuJoCo `PIDController` has **no `integral_limit` field** (unlike `CAxisRT`), and **the clamped output is stashed back into `pid.integral`** (not a true integral accumulator) for `ApplyToMuJoCo` to read.
- `MoveAxis(target,force,abs)` sets `m_dTargetPos` + CONTROL_POSITION + Running (abs/rel handled, limit-checked) — unlike `CAxisRT`, this one works. `MoveVelocity` similar. `MoveTorque(Nm)` **just stores `m_dTargetTorq`** (mode-set + servo check commented out). `MoveHome`, `StopAxis` (sets target=current, state=Stopped), `EmgStopAxis` (zeroes `ctrl[id]`, state=Emergency), `DoHoming` (per method). `ServoOn` requires bound model+data+enabled. `GetMuJoCoJointId()`, `GetMuJoCoTime()`.

**Torque→current→counts (MuJoCo path):** `MoveTorque` target Nm → `ApplyToMuJoCo` writes it (limited) to `mjData->ctrl[id]` (MuJoCo actuator drives the joint) → `UpdateFromMuJoCo` reads `qfrc_actuator[id]` and stores `ConvertTor2Res(torque)` as raw. No explicit motor-current step here (that exists in `CAxisRT`).

##### 5.10 SIMULATION variant — `CAxisRTMuJoCo` + `CRobotRTMuJoCo` (`AxisRTMuJoCo.h/.cpp`)

`CAxisRTMuJoCo : CAxisRT`. Purpose: run the deterministic `CAxisRT` motor sim in the **RT thread** while a separate **non-RT visualization thread** renders/steps MuJoCo, connected by a **lock-free double buffer** (no mutex in the RT path). The header includes `<mujoco/mujoco.h>` unconditionally plus `MuJoCoVisualization.h`.

- `StepSimulation(dt)` (override, RT thread): `UpdateExternalForcesFromVisualization()` → `CAxisRT::StepSimulation(dt)` (runs the ODE) → if `m_bVisualizationEnabled`, `PublishStateToVisualization()`.
- `PublishStateToVisualization()` (RT-safe, atomic stores): writes `m_motorDynamics.position/velocity`, `m_dMotorTorque`, `m_dSimTime` into `m_rtToVizState.joint_positions[0]/velocities[0]/torques[0]/timestamp` and sets `data_updated=true`.
- `UpdateMuJoCoVisualization()` (viz thread, `#ifdef MUJOCO_ENABLED`): if RT posted new data, copies it into `mjData->qpos/qvel/ctrl[jointId]` for display, clears flag.
- `StepMuJoCoPhysics()` (viz thread): `mj_step(model,data)`, reads `qfrc_applied[jointId]` as external torque, `SetExternalForcesFromMuJoCo(...)`.
- `RTVisualizationData` (`MuJoCoVisualization.h`): `std::atomic<double> joint_positions[8], joint_velocities[8], joint_torques[8], timestamp; std::atomic<bool> data_updated;` (+ `num_joints`) — supports up to 8 joints; each axis uses index `[0]` only. Two instances: `m_rtToVizState` (RT→viz), `m_vizToRTState` (viz→RT).

**STUBS:** `RTVisualizationData` has no external-force fields, so `SetExternalForcesFromMuJoCo()` and `UpdateExternalForcesFromVisualization()` only toggle `data_updated` — the external-force feedback path is a **no-op** (comment: "skip or implement as needed"). MuJoCo-visualization bodies are compiled only under `MUJOCO_ENABLED`.

`CRobotRTMuJoCo` — multi-axis owner holding `std::vector<std::unique_ptr<CAxisRTMuJoCo>>`:
- `SetAxes(&&)` injects config-driven axes (ownership moved, sets `m_nNumAxes`). `InitRT()` **hardcodes a 6-axis INDY7 gear table** (see constants below), applies per-axis `SetTorqueConstant/SetCurrentRatio/SetTorqueLimits`, `SetPositionLimits(-35,35 deg)`, `SetVelocityLimits(150)`, `SetVelocity(130)`, `SetAcceleration(10000)`, `SetHomingMethod(eAxisHomeStartPos)`, then `Init()` + `ServoOn()`.
- `StepRTSimulation(dt)` — call at **1 kHz** from the RT loop; iterates `axis->StepSimulation(dt)`.
- `UpdateVisualization()` — call at **~60 Hz** (viz rate `m_dVizUpdateRate=60.0`). `SetJointCommand/SetJointVelocityCommand/SetJointTorqueCommand(id,val)` route to axis `MoveAxis/MoveVelocity/MoveTorque`. `GetJointPosition/Velocity(id)`; **`GetJointTorque(id)` returns the axis's `GetTargetTorq()` (commanded target, not measured)**. `IsJointReady(id)` (=`IsServoOn`). `InitMuJoCo(model,data)`, `UpdateMuJoCoFromRT()` (called from `proc_ethercat_control`; publishes each axis's RT state to viz), `Shutdown()` (ServoOff+DeInit all). `ConfigureFromFile(string)` is declared but **not defined** in this file.

##### 5.11 Consolidated API / signature table (representative)

| Method (class) | Signature | Semantics |
|---|---|---|
| CAxis ctor | `CAxis(eCommType,eAxisType,absEnc=T,CCW=T,en=T)` | dir=+1(CCW)/−1(CW); oneTurnRef=2π(revolute)/1 |
| CAxis::ConvertRadMM2Res | `INT32(double pos)` | pos/oneTurnRef·trans·gear·res·dir |
| CAxis::ConvertRes2RadMM | `double(INT32)` | inverse of above |
| CAxis::ConvertCur2Tor | `double(double cur,BOOL useTC=T)` | cur·Kt or cur·Trated/Irated |
| CAxis::ConvertTor2Cur | `double(double tor,BOOL useTC=T)` | tor/Kt or tor·Irated/Trated |
| CAxis::ConvertTor2Res | `INT32(double)` | **identity cast (base bug)** |
| CAxis::UpdateCurrentParams | `void(INT32 p,v,t)` | store raw, subtract home/start, store eng units |
| CAxis::IsMovable | `BOOL()` | state>Init && limitsSet && enabled |
| CAxis::IsAllowable* | `BOOL(double)` | pos/vel/acc/dec/jerk/torque bound check |
| CAxisCIA402::Init | `BOOL(CEcatMaster&,INT8 mode=0x01)` | AddSlave, alias/pos, register callbacks, ServoOn |
| CAxisCIA402::MoveAxis | `BOOL(double rad,force=T,abs=T)` | pos-mode; `SetTargetPos(ref+ConvertRadMM2Res)` |
| CAxisCIA402::MoveVelocity | `BOOL(double rad/s)` | vel-mode; `SetTargetVel(ConvertRadMM2Res)` |
| CAxisCIA402::MoveTorque | `BOOL(double Nm)` | tor-mode; `SetTargetTor((INT16)ConvertTor2Res)` |
| CAxisCIA402::ServoOn | `BOOL(INT8 mode=0x01)` | `m_cEcSlave.SetServoOn(mode)` |
| CAxisCIA402::SetVendorInfo | `void(UINT32 vid,UINT32 pcode)` | forward to slave (ESI identity) |
| CAxisCIA402::SetDCInfo | `void(BOOL,UINT16 actWord,INT32 shift)` | forward DC-sync params to slave |
| CAxisCIA402::OnSlaveUpdateRawParam | `void(PVOID…)` | per-frame `UpdateCurrentParams(nActual*)` |
| CAxisNRMKCore::MoveTorque | `BOOL(double Nm)` | `SetTargetTor((INT16)(tor/gear/Kt·currentRatio·dir))` |
| CAxisNRMKCore::ConvertTor2Res | `INT32(double)` | (tor/gear/Kt)·currentRatio·dir |
| CAxisELMO::MoveTorque | `BOOL(double Nm)` | Nm→mNm, pos-guarded `SetTargetTor` (else 0) |
| CAxisELMO::GetCurrentTor | `double()` | dTor/1000 (mNm→Nm) |
| CAxisRT::StepSimulation | `void(double dt)` | PID→torque→ODE integrate→update params |
| CAxisRT::MoveTorque | `BOOL(double Nm)` | store target only (mode-set commented out) |
| CAxisRT::MoveAxis | `BOOL(double,…)` | **broken: m_dTargetPos never set; rel→Emergency, abs→no-op** |
| CAxisMuJoCo ctor | `(eAxisType,int mjJointId,adEncRes=65536,…)` | binds one joint id |
| CAxisMuJoCo::Init | `BOOL(mjModel*,mjData*)` | bind joint id, validate njnt/limits |
| CAxisMuJoCo::ApplyToMuJoCo | `void()` | PID/torque → `mjData->ctrl[id]` |
| CAxisMuJoCo::UpdateFromMuJoCo | `void()` | qpos/qvel/qfrc_actuator[id] → params |
| CAxisRTMuJoCo::StepSimulation | `void(double dt)` | RT sim + lock-free publish to viz |
| CRobotRTMuJoCo::StepRTSimulation | `void(double dt)` | **1 kHz** step all axes |
| CRobotRTMuJoCo::UpdateVisualization | `void()` | **~60 Hz** MuJoCo refresh |

##### 5.12 Constants / magic numbers

- Angle: `M_PI=3.141592653589793`, `TWO_M_PI=6.283185307179586` (`Global/Defines.h`); `ConvertDeg2Rad(d)=d·π/180`, `ConvertRad2Deg(r)=r·180/π`, `ConvertRpm2Rad(rpm)=rpm·π/30`.
- CiA402 drive modes (`EcatCommon.h`): PP=0x01, PV=0x03, PT=0x04, HOMING=0x06, INTERPOLATED=0x07, CSP=0x08, CSV=0x09, CST=0x0A.
- `eSERVO_STATUS`: Off=0x00, Idle, Stopped, Homing, Running, Fault=0x80, Disconnected.
- Default sim ctor: encRes `65536`, gear `1.0`, trans `1.0`; velocity threshold `1e-6` rad/s.
- `CAxisRT` PID: pos(kp800,ki0.1,kd80,lim100Nm,iLim10), vel(kp50,ki0.05,kd5,lim100,iLim10); motor(J0.001,B0.01,μ0.001); profile(130 deg/s, 10000 deg/s²).
- `CAxisMuJoCo` PID: pos(kp1000,ki0,kd50,lim1000), vel(kp100,ki0,kd10,lim1000) — no integral_limit member.
- `CAxisRTMuJoCo` viz rate `60.0` Hz; `RTVisualizationData` arrays size `8`.
- **Hardcoded INDY7 6-axis table in `CRobotRTMuJoCo::InitRT` {gear, Kt, currentRatio, torqueLimit}:** J0/J1 `{121.0, 0.0884, 48.0, 117.73}`, J2 `{121.0, 0.087, 96.0, 47.5}`, J3/J4/J5 `{101.0, 0.058, 96.0, 21.0}`; plus pos limit ±35°, vel limit 150 deg/s, profile vel 130 deg/s, accel 10000.

##### 5.13 RT / EtherCAT integration facts for the future EtherCAT+PREEMPT_RT port

- Real axes bind to the IgH/EtherLab master through `CEcatMaster`/`CSlaveCIA402` (headers under `include/EMasterApp/`; `CSlaveCIA402` is a typedef of `CSlaveCIA402Base`). The Axis layer never touches `ecrt.h` directly — all PDO/SDO/DC/402-state-machine work is delegated to the slave/master classes; verify those in the EtherCAT-slave subsystem. **All four CiA402 axis variants share the identical generic `CSlaveCIA402Base` slave with its fixed 5-entry RxPDO `0x1600` / 5-entry TxPDO `0x1a00` map** (§5.4); the device-specific `SlaveELMO.h`/`SlaveEPOS4.h` classes are NOT wired in. `CAxisCIA402::Init` requires a `CEcatMaster&` and must be called after all six axis limits are configured and a valid homing method is set.
- Cyclic data path: the master calls the registered `OnSlaveUpdateRawParam` each cycle → `UpdateCurrentParams`. For a real 1 kHz DC-synced loop, that callback is the read side; the command side is `SetTargetPos/Vel/Tor` invoked by `MoveAxis/MoveVelocity/MoveTorque`.
- Torque commanding on real drives only works correctly for `CAxisNRMKCore` (full gear/Kt/currentRatio math) and, in mNm, `CAxisELMO`. Plain `CAxisCIA402`/`CAxisEPOS4` inherit the identity torque converter and will send unscaled counts — the future integration must supply a real `ConvertTor2Res`/`ConvertRes2Tor` (or `SetTorqueConstant`/rated values) per drive.
- Simulation substitution: the same controller code drives `CAxisRT`/`CAxisMuJoCo`/`CAxisRTMuJoCo`. For hardware-in-the-loop or offline test on the KV260 without EtherCAT, use `CAxisRT` (no external deps) or `CRobotRTMuJoCo` (RT sim + optional MuJoCo viz). Sim axes advance only when `StepSimulation`/`UpdateFromMuJoCo` is ticked from the RT loop. Note `CAxisRT::MoveAxis` is non-functional (§5.8), so position control of the pure-RT sim axis is not usable as-shipped.

##### 5.14 Header/comment defects (do not "fix" as stale)

- `AxisELMO.h` and `AxisELMO.cpp` banners say "AxisEPOS4" (copy-paste); class/guard are correctly `CAxisELMO`/`__AXIS__ELMO__`. (`AxisEPOS4.h` correctly uses guard `__AXIS__EPOS4__`, so there is no guard collision.)
- `AxisCIA402.cpp` banner reproduces the header banner verbatim ("Name: AxisCIA402.h / Description: Header for …") even though it is the implementation file. `AxisNRMKCore.cpp`'s banner "Name" field likewise says "AxisNRMKCore.h", but its "Description" correctly reads "Implementation of the CAxisNRMKCore child class" (only the filename field is wrong, not the description).

---
#### 6. Robot HAL — Orchestration: `CRobot`, `CConfigRobot`, `CExtInterface`

Three cooperating classes under `CRobot/` form the top-level Hardware-Abstraction-Layer orchestrator: `CRobot` (lifecycle + RT-task owner + EtherCAT-master owner), `CConfigRobot` (INI config loader/writer), and `CExtInterface` (TCP :7420 binary telemetry/command server). All authored by Raimarius Delgado, KIST AIRI / ROBOGRAM LAB (2022).

| File | LOC | Role |
|------|-----|------|
| `CRobot/Robot.h` | 115 | `CRobot` base-class declaration: lifecycle, RT-task/axis/hand registries, state machine |
| `CRobot/Robot.cpp` | 257 | `CRobot` implementation: `Init(sim)`/`DeInit`, `InitRTTasks`, `AddAxis`/`AddTaskFunction`/`AddHand`, ext-iface glue |
| `CRobot/ConfigRobot.h` | 299 | `CConfigRobot` + all config structs (task/master/slave/hand/ext-iface/system) |
| `CRobot/ConfigRobot.cpp` | 482 | INI parsing of System/RT-Task/EtherCAT sections; `WriteLastPosition` |
| `CRobot/ExtInterface.h` | 130 | `CExtInterface` decl: packet constants, `eCommand`/`eSubCommand` enums, socket callbacks |
| `CRobot/ExtInterface.cpp` | 659 | TCP server, packet framing (STX/ETX/CRC16-ARC), parse/interpret, metadata/ack senders |

Design pattern: `CRobot` is an **abstract orchestrator**. `InitEtherCAT()` is a **protected** virtual returning `FALSE` by default — a concrete robot (e.g. `App/Indy7/Indy7Ctrl.cpp` `CRobotIndy7`) overrides it to `new CEcatMaster()`, build/`AddAxis` slaves, and `m_pcEcatMaster->Init(cycletime_ns, bDC)`. The derived class also `new`s the `CConfigRobot`, calls `ReadConfiguration()`, and registers task functions in its constructor. `CRobot::Init()` then drives the fixed sequence below.

---

##### 6.1 `CRobot` — base lifecycle, RT-task model, ownership

**Robot state machine** (`eRobotStateMach`, Robot.h:30-40): `eRobotInit=0x00, eRobotIdle, eRobotOperation, eRobotStopped, eRobotEmg=0x80, eRobotError, eRobotDeInit, eRobotUnknown`. Stored in private `m_eRobotState`; accessed via `GetState()/SetState()`. NOTE: `GetState()` return type is declared `BOOL` (Robot.h:67) though it returns an `eRobotStateMach` — a type mismatch.

**Type aliases**: `typedef POSIX_TASK PTASK;` (from `posix_rt.h`). `PTASKFCN` (also from `posix_rt.h`) is the task-function pointer; from usage it is effectively `void(*)(void*)` — App task fns are declared `void proc_xxx(void*)` and registered via `AddTaskFunction(&proc_xxx)`.

**Key members** (all `protected` unless noted):
| Member | Type | Meaning |
|--------|------|---------|
| `m_pcEcatMaster` | `CEcatMaster*` | EtherCAT master (owned; created in derived `InitEtherCAT`, `DeInit`'d but NOT `delete`d by base) |
| `m_pcConfigRobot` | `CConfigRobot*` | Config loader (created in derived ctor; `delete`d in base `DeInit`) |
| `m_pcExtInterface` | `CExtInterface*` | TCP server (created in `InitExtInterface`; **never deleted** — leak) |
| `m_vAxis` | `std::vector<CAxis*>` | Registered axes (not owned) |
| `m_vTask` | `std::vector<PTASK>` | RT task handles created by `InitRTTasks` |
| `m_vTaskFunctions` | `std::vector<PTASKFCN>` | Task entry-point fn pointers (registered pre-Init) |
| `m_vKistarHand` | `std::vector<CKistarHand*>` | Hand end-effectors (not owned) |
| `m_nTotalRTTasks` | `INT` | (init 0; **never actually incremented** — `GetTotalRTTasks()` returns 0) |
| `m_bStopTask` | `BOOL` | Cooperative stop flag polled by task loops via `CheckStopTask()` |
| `m_bAging,m_nAgingDur,m_dAgingFreq` | | Sine-wave aging-test params (ctor defaults 60 s, 1 Hz) |
| `m_bIsSim` | `BOOL` | Simulation mode |
| `m_strName` | `TSTRING` | Robot name; base never sets it. **Populated by the derived class** — `CRobotIndy7::Init` assigns it `GetSystemConf().strURDFPath` (a quirk: `GetName()`, and the robot-name sent over the wire by `SendMetadataRobot`, is actually the URDF path in the Indy7 build), NOT `strName` |
| `m_vstAxisCmds` | `VEC_AXIS_CMD` | Declared axis-command buffer, **currently unused** (`OnRecvAxisCommand` copies into a local, not this) |

`friend class CExtInterface;` — the ext-iface directly reads `m_pcEcatMaster` (see `SendMetadataEcatMaster`).

**Public API**:
| Signature | Semantics |
|-----------|-----------|
| `CRobot()` | Clears `m_vAxis`+`m_vKistarHand`; nulls the 3 owned pointers; `m_nTotalRTTasks=0`; aging defaults (60 s, 1 Hz) |
| `virtual BOOL Init(BOOL abSim)` | Master lifecycle entry (see below) |
| `virtual BOOL InitExtInterface()` | If `GetSystemConf().stExternalIface.bEnabled`, `new CExtInterface`, `RegisterCallbackAxisCmd(bind(OnRecvAxisCommand))`, `->Init(this)`; else return `FALSE` |
| `virtual BOOL DeInit()` | Stop tasks, EtherCAT deinit, save POS_BEFORE_EXIT, free config |
| `virtual BOOL IsEcatEnabled()` | `TRUE` iff `m_pcEcatMaster != NULL` |
| `virtual INT GetTotalEcatSlaves()` | `m_pcEcatMaster->GetSlaveCnt()` or 0 |
| `virtual INT GetTotalRTTasks()` | returns `m_nTotalRTTasks` (always 0 — see note) |
| `virtual BOOL CheckStopTask()` | returns `m_bStopTask` (poll target for RT loops) |
| `virtual void StopTasks(BOOL=TRUE)` | sets `m_bStopTask` |
| `virtual void SetAgingParams(INT dur,double freq=1.)` / `EnableAgingTest(BOOL)` | aging config |
| `BOOL AddAxis(CAxis*)` | append axis; if ext-iface present, `RegisterAxis` |
| `BOOL AddTaskFunction(PTASKFCN)` | append task fn (unconditional, no dedup) |
| `BOOL AddHand(CKistarHand*)` | append hand |
| `BOOL IsSim()` / `TSTRING GetName()` / `INT GetTotalAxis()` / `INT GetTotalHands()` | accessors |
| `BOOL GetState()` / `void SetState(eRobotStateMach)` | robot state |

**Protected virtuals** (overridable by the concrete robot — these are NOT public):
| Signature | Semantics |
|-----------|-----------|
| `virtual BOOL InitEtherCAT()` **=inline stub `return FALSE`** | **must be overridden** by concrete robot |
| `virtual BOOL InitRTTasks()` | RT task creation (see below) |
| `virtual BOOL IsAgingTest()` | returns `m_bAging` |
| `virtual void UpdateExtInterfaceData()` | push EtherCAT metadata to ext-iface |
| `virtual void OnRecvAxisCommand(PVOID,PVOID,PVOID,PVOID)` | axis-cmd callback (STUB — see below) |
| `virtual void DoAgingTest()` **=inline stub `return`** | override for aging motion |

**`Init(BOOL abSim)` sequence** (Robot.cpp:27-56): sets `m_bIsSim`. **Only if `abSim==FALSE`**: (1) `InitExtInterface()` — failure is logged WARN, non-fatal; (2) `InitEtherCAT()` — failure returns `FALSE` (fatal); (3) `InitRTTasks()` — failure returns `FALSE` (fatal). In **sim mode all three are skipped** (no ext-iface, no EtherCAT, no RT tasks are created). Logs name and returns `TRUE`. The derived `CRobotIndy7::Init` does its own controller/visual-servo init first, then calls `CRobot::Init(abSim)` last.

**RT TASK CREATION MODEL — `InitRTTasks()`** (Robot.cpp:118-156). This is the core RT integration point:
1. `VEC_TASK_CONF vTaskConf = m_pcConfigRobot->GetTaskList();` → one `ST_CONFIG_TASK` per `[TASKn]`.
2. `nTotalRtTasks = vTaskConf.size()`. **Guard**: if `m_vTaskFunctions.size() != nTotalRtTasks` → return `FALSE`. ⇒ the number of `AddTaskFunction()` calls MUST equal `[RT_TASKS] NO_OF_TASKS`. (Integration caveat: `CRobotIndy7` registers 6 fns; the sample `Config/8_axis_testbed.cfg` sets `NO_OF_TASKS=4` — a mismatch that would fail here. The **deployed `App/Indy7/INDY7.cfg` correctly sets `NO_OF_TASKS=6`** to match.)
3. **Phase 1 — create (all tasks, enabled or not)**: for each task
   - `create_rt_task(&taskTemp, (const PCHAR)strName.c_str(), 2*1024*1024, nPriority);` — stack = **2 MiB**, priority = config `PRIORITY` (0 lowest … 99 highest; per cfg comment SCHED_FIFO under PREEMPT_RT).
   - if `nPeriod != 0`: compute start time — `nStartDelay==0` → `tmStartDelay = SET_TM_NOW`; else `tmStartDelay = read_timer() + nStartDelay` (both in ns; `read_timer()` returns current `RTTIME`). Then `set_task_period(&taskTemp, tmStartDelay, nPeriod);` (period in ns). Period-0 tasks (e.g. keyboard) get NO period → run free/event-driven.
   - `m_vTask.push_back(taskTemp);`
4. **Phase 2 — start (only `bEnabled` tasks)**: `start_task(&m_vTask[n], m_vTaskFunctions[n], this);` — the task entry fn receives `this` (the `CRobot*`) as its `void*` argument. Disabled tasks are created+periodized but never started.

**Task-loop pattern (in the App entry fns, not in CRobot)** — the canonical body a future integrator must write for each `proc_xxx(void* apRobot)`:
```
CRobot* pRobot = (CRobot*)apRobot;
RTTIME t = read_timer();
while (!pRobot->CheckStopTask()) {
    wait_next_period(NULL);   // blocks until next period edge (set by set_task_period)
    ... do I/O: m_pcEcatMaster->ReadSlaves(); control; WriteSlaves(tmSend); ...
}
```
`wait_next_period(nullptr)` is the rtposix sleep-to-next-period primitive; `CheckStopTask()` is the cooperative exit set by `DeInit`.

**EtherCAT master ownership/wiring**: base `CRobot` holds `m_pcEcatMaster` but never constructs it. The derived `InitEtherCAT()` does `m_pcEcatMaster = new CEcatMaster();`, builds each slave (`new CAxisNRMKCore(...)`, `SetVendorInfo`, `SetDCInfo`, limits, `->Init(*m_pcEcatMaster, (INT8)nDriveMode)`, `AddAxis(...)`), then `m_pcEcatMaster->Init(nCycleTime, bDCEnabled)` (confirmed in `Indy7Ctrl.cpp` `InitEtherCAT`). Base helpers `IsEcatEnabled()`, `GetTotalEcatSlaves()`, and `UpdateExtInterfaceData()` read master state via `GetSlaveCnt()/GetMasterState()/GetSlaveState()/GetDomainState()`.

**`OnRecvAxisCommand(PVOID apAxisCmd,...)`** (Robot.cpp:184-189): bound via `std::bind` into the ext-iface. **STUB**: it copies `*(VEC_AXIS_CMD*)apAxisCmd` into a local and does nothing else (the intended `m_qAxisCmd.push(...)` is commented out). ⇒ TCP `SET_POS` commands are ACK'd but produce **no motion** in the current code.

**`DeInit()`** (Robot.cpp:75-109): (1) `StopTasks()` (sets stop flag); (2) `usleep(2000000)` — **hardcoded 2 s** delay so RT tasks exit before EtherCAT teardown; (3) if `m_pcEcatMaster` `->DeInit()` (not `delete`d); (4) **for each axis**: read `GetCurrentRawPos()`, log vs `GetHomePosition()`, and `m_pcConfigRobot->WriteLastPosition(axisIdx, rawPos)` → persists `POS_BEFORE_EXIT` back to the INI (used next boot to seed incremental-encoder position); (5) `delete m_pcConfigRobot`; (6) clear all vectors; (7) `SetState(eRobotDeInit)`. NOTE: `m_pcExtInterface` and `m_pcEcatMaster` are not freed here (ext-iface leaks; master freed elsewhere/leaks).

`UpdateExtInterfaceData()` (Robot.cpp:172-182): if both ext-iface and master exist, calls `m_pcExtInterface->UpdateEcatMetadata(slaveCnt, masterState, slaveState, domainState)` — this is the RT→telemetry bridge; the ext-iface then answers `CMD_ECAT_MASTER` queries from cached RT-context values.

---

##### 6.2 `CConfigRobot` — INI config loader

Uses Windows-style INI API re-implemented in `Global/ConfigParser.h`: `GetPrivateProfileString(section,key,default,buf,buflen,file)`, `WritePrivateProfileString(section,key,val,file)`, `IsExistFile(path)`. `TOSTRING(n)` stringifies; `ZeroMemory(buf)`; `__MAX_PATH__` (=1024) sized scratch buffer. Numeric fields go through `atoi`/`atof`; hex fields (vendor/product/DC word) through `std::stoul(str,NULL,16)` with `atoi` fallback on `std::invalid_argument`.

`#define DEFAULT_CONFIGURATION_FULLPATH ("ELMO.cfg")` (relative path).

**Config structs produced (full field reference):**

`ST_CONFIG_TASK` (per `[TASKn]`): `BOOL bEnabled`; `TSTRING strName`; `INT32 nPriority`; `INT32 nStartDelay` (ns); `INT32 nPeriod` (ns). Defaults all 0/FALSE/"".

`ST_CONFIG_ECAT_MASTER` (`[ECAT_MASTER]`): `BOOL bDCEnabled`; `INT32 nNoOfSlaves`; `INT32 nNoOfHands`; `INT32 nCycleTime` (ns). (ctor leaves `nNoOfHands` uninitialized.)

`ST_CONFIG_ECAT_SLAVE` (per `[AXISn]`) — full field list; **Default = struct-ctor default** (note: several read calls in `ReadEtherCATConfig` pass INI default "0", so a *missing* key yields 0 even where the ctor default is 1.0 — e.g. ENCODER_RESOLUTION/GEAR_RATIO/…):
| Field | Type | Default | INI key |
|-------|------|---------|---------|
| `bEnabled` | BOOL | F | ENABLED |
| `bConnected` | BOOL | F | CONNECTED |
| `strName` | TSTRING | "EtherCAT Slave" | NAME |
| `nPhyPos` | INT32 | 0 | PHYSICAL_POS |
| `uVendorID` | UINT32 | 0 | VENDOR_ID (hex) |
| `uProductCode` | UINT32 | 0 | PRODUCT_CODE (hex) |
| `bDCSupported` | BOOL | F | DC_SUPPORT |
| `usDCActivateWord` | UINT16 | 0x300 | DC_ACTIVATE_WORD (hex) |
| `nDCSyncShift` | INT32 | 0 | DC_SYNC0_SHIFT |
| `nSlaveType` | INT32 | 0 | SLAVE_TYPE (0=Axis,1=Sensor,3=Terminal,4=JunctionBox,5=Hand) |
| `bAutoServoOn` | BOOL | F | AUTO_SERVO_ON |
| `bAbsEnc` | BOOL | F | ABSOLUTE_ENCODER |
| `bCCW` | BOOL | T (read default 0) | MOVE_CCW |
| `nJointType` | INT32 | 0 | JOINT_TYPE |
| `nDriveMode` | INT32 | 1 | DRIVE_MODE (CiA-402 mode; 1=PP,3=PV,4=PT,6=HM,7=IP,8=CSP,9=CSV,10=CST — per `EcatCommon.h` `ValidateCIA402DriveMode`) |
| `dEncResolution` | double | 1 (read default 0) | ENCODER_RESOLUTION |
| `dGearRatio` | double | 1 (read default 0) | GEAR_RATIO |
| `dTransRatio` | double | 1 (read default 0) | TRANSMISSION_RATIO |
| `dTorqueConstant` | double | 1 (read default 0) | TORQUE_CONSTANT |
| `dCurrentRatio` | double | 1 (read default 0) | CURRENT_RATIO |
| `dOneTurnRef` | double | 1 (read default 0) | ONE_TURN_REF |
| `nHomingMethod` | INT32 | 0 | HOMING_METHOD (0=NotSet,1=StartPos,2=Search,3=Manual,4=Builtin) |
| `dHomeSearchRef` | double | 1 (read default 0) | HOME_SEARCH_REFERENCE |
| `nHomePositionOffset` | INT32 | 0 | HOME_POSITION_OFFSET |
| `dOperatingVel/Acc/Dec` | double | 0 | OPERATING_VELOCITY/ACCELERATION/DECELERATION |
| `dPosLimitU/L` | double | 0 | POSITION_LIMIT_U/L (deg for revolute) |
| `dVelLimitU/L` | double | 0 | VELOCITY_LIMIT_U/L |
| `dAccLimitU/L` | double | 0 | ACCELERATION_LIMIT_U/L |
| `dDecLimitU/L` | double | 0 | DECELERATION_LIMIT_U/L |
| `dTorLimitU/L` | double | 0 | TORQUE_LIMIT_U/L |
| `dJerkLimitU/L` | double | 0 | JERK_LIMIT_U/L |
| `dRatedTorque` | double | 0 | RATED_TORQUE |
| `dRatedCurrent` | double | 0 | RATED_CURRENT |
| `nPosBeforeExit` | INT32 | 0 | POS_BEFORE_EXIT (persisted by `WriteLastPosition`) |

`ST_HAND_CONFIG_ECAT_SLAVE`: `bEnabled,bConnected,strName("EtherCAT Hand"),nPhyPos,uVendorID,uProductCode,bDCSupported,usDCActivateWord(0x300),nDCSyncShift,nNoAxes`, plus `double dPosLimitU[16]`, `double dPosLimitL[16]`. **CAVEAT: never populated** — no `Read*` method fills `m_vstHandEcatSlaveList`; `GetHandEcatSlaveList()` always returns empty despite `SLAVEHANDNUMBER` being read into `nNoOfHands`.

`ST_CONFIG_EXT_IFACE`: `BOOL bEnabled(F)`; `INT32 nPort(7420)`.

`ST_CONFIG_SYSTEM` (`[SYSTEM]`): `TSTRING strName("ROBOT")`; `BOOL bSim(F)`; `BOOL bAging(F)`; `INT32 nAgingDur(**uninit — never read from cfg**)`; `INT32 nTeleMode(0)`; `double dTeleScalingRatio(0)`; `TSTRING strURDFPath("TEST.urdf")`; `TSTRING strMojucoXmlPath("TEST.xml")`; `BOOL bEnableControllerAtStartup(T)`; `INT32 nDefaultControllerMode(0)` (0=GravityComp,1=CTC,2=FullDynamics); `INT32 nRobotAxis`; `std::vector<double> vKp`, `vKd` (ctor default resize 6, then re-resized to `nRobotAxis`); embedded `ST_CONFIG_EXT_IFACE stExternalIface`. (A separate unused `m_stExtIface` member also exists; `GetExtIfaceConf()` returns `m_stSystem.stExternalIface`.)

**Getter API** (all return by value/copy):
| Method | Returns |
|--------|---------|
| `GetTaskList()` | `VEC_TASK_CONF` (`m_vstTaskList`) |
| `GetEcatSlaveList()` | `VEC_ECAT_SLAVE_CONF` |
| `GetHandEcatSlaveList()` | `VEC_HAND_ECAT_SLAVE_CONF` (empty) |
| `GetEcatMasterConf()` | `ST_CONFIG_ECAT_MASTER` |
| `GetSystemConf()` | `ST_CONFIG_SYSTEM` |
| `GetExtIfaceConf()` | `m_stSystem.stExternalIface` |
| `SetConfigPath/GetConfigPath` | path |
| `WriteLastPosition(INT32 axis,INT32 rawPos)` | writes `[AXISn] POS_BEFORE_EXIT` |

**`ReadConfiguration(path="DEFAULT")`** (public): clears lists; resolves path (uses `m_strConfigPath` if "DEFAULT"); `IsExistFile` check; `SetConfigPath`; then calls in order `ReadSystemConfig()` → `ReadRTTaskConfig()` → `ReadEtherCATConfig()`, each fatal-on-FALSE; try/catch wraps all.

`ReadRTTaskConfig()` — `[RT_TASKS] NO_OF_TASKS`, then loops `[TASK0..N-1]` keys ENABLED/NAME/PRIORITY/TASK_PERIOD/START_DELAY.
`ReadEtherCATConfig()` — `[ECAT_MASTER]` SLAVENUMBER/SLAVEHANDNUMBER/DC_ENABLED/CYCLE_TIME, then loops `[AXIS0..nNoOfSlaves-1]` reading all slave keys above (all slaves parsed under `[AXISn]` regardless of type).
`ReadSystemConfig()` — `[SYSTEM]` keys: SIMULATION_MODE, AGING_TEST, AGING_DURATION (**BUG: written into `bAging` not `nAgingDur`**, ConfigRobot.cpp:384), NAME, URDF_PATH, MOJUCO_XML_PATH, ROBOT_DOF→`nRobotAxis`, per-axis `KP_i`/`KD_i`, ENABLE_CONTROLLER_AT_STARTUP, DEFAULT_CONTROLLER_MODE, EXTERNAL_INTERFACE_ENABLED, EXTERNAL_INTERFACE_PORT(7420), TELEOPERATION_MODE, TELEOPERATION_CONSTANT_SCALING(0.3).

**Stub/unimplemented**: `LoadDefaultConfig()` is a no-op `return;`. `UpdateConfiguration()` and `CreateDefaultConfig()` are **declared but have NO definition** in ConfigRobot.cpp (link error if referenced).

---

##### 6.3 `CExtInterface` — TCP :7420 binary protocol

TCP server (`Global/Comm/Socket.h::CTcpServer`) that streams robot/axis/EtherCAT telemetry and receives axis commands. `#define EXT_IFACE_PORT 7420`; `Init(CRobot*, INT32 anPort=7420)`. Uses `CRC16_ARC` (poly `0x8005`, init 0, reflect-in, reflect-out, xor-out 0 — i.e. standard CRC-16/ARC) from `Global/Comm/CRC16.h`.

**Packet frame (wire layout, big-endian multibyte)** — built by `MakePacket` (ExtInterface.cpp:156):
```
[0] STX_H = 0x02
[1] STX_L = 0x5B
[2] SpinId          (rolling seq 0x00..0xFF, ++ per send AND per interpret)
[3] Len_H           Len = (Cmd+SubCmd+payload) length = payload.size()+2
[4] Len_L
[5] Cmd             (eCommand)
[6] SubCmd          (eSubCommand)
[7..7+payload-1] payload bytes
[..] CRC_H          CRC16-ARC over bytes [2 .. end-of-payload] (STX & ETX excluded)
[..] CRC_L
[..] ETX_H = 0x5D
[..] ETX_L = 0x03
```
Constants: `PACKET_STX_H 0x02`, `PACKET_STX_L 0x5B`, `PACKET_ETX_H 0x5D`, `PACKET_ETX_L 0x03`, `MIN_PACKET_LENGTH 11` (empty-payload frame = 2 STX +1 SpinId +2 Len +1 Cmd +1 SubCmd +2 CRC +2 ETX). `PRECISION_FACTOR 1000` (fixed-point scale for pos/vel/acc/limits over the wire). `ALL_AXIS = (INT)(-1)` (broadcast/select-all sentinel; sent as signed byte 0xFF).

**`eCommand`** (ExtInterface.h:38): `CMD_NOTHING=0x00`, `CMD_ROBOT=0x82`, `CMD_AXIS=0x65`, `CMD_ECAT_MASTER=0x77`, `CMD_ECAT_SLAVE=0x83`, `CMD_BINARY_RESPONSE=0x66`. (The `// 'R' / 'A' / 'M' / 'S' / 'B'` source comments are **misleading** — they do NOT match the ASCII codes; the numeric values are authoritative.)

**`eSubCommand`** (ExtInterface.h:48): `SUBCMD_NOTHING=0x00`, `SUBCMD_GET_METADATA=0x01`, `SUBCMD_GET_STATE=0x02`, `SUBCMD_SET_POS=0x50`, `SUBCMD_GET_POS=0x51`, `SUBCMD_SET_VEL=0x52`, `SUBCMD_GET_VEL=0x53`, `SUBCMD_SET_ACC=0x54`, `SUBCMD_GET_ACC=0x55`, `SUBCMD_SET_TOR=0x56`, `SUBCMD_GET_TOR=0x57`, `SUB_CMD_ACK=0xFE`, `SUB_CMD_NACK=0xFF`.

**Receive/parse flow**:
- `OnSocketReceive(...)` (ExtInterface.cpp:244): if error==0, appends `nLength` bytes into `m_pRecvBuffer` (flushes if ≥ `MAX_RECV_BUFF_LEN`=8192, from `Socket.h`), then `ParseRecvPacket()`.
- `ParseRecvPacket()` (ExtInterface.cpp:279): `std::search` for header `{0x02,0x5B}`; at each hit `idx`, if enough bytes: `nPacketLength = buf[idx+3]*256 + buf[idx+4] + (MIN_PACKET_LENGTH-2)` (i.e. Len field + 9 = full frame size). If full frame present AND trailing bytes == ETX (`0x5D,0x03`), slice `[idx, idx+nPacketLength)` and `InterpretPacket(packet)`; advance remainder index. Leftover bytes are retained for reassembly. **CAVEAT: the CRC is NEVER verified on receive** — only the ETX terminator is checked.
- `InterpretPacket(const BYTEARRAY)` (ExtInterface.cpp:318): `btCmd=aPacket[5]`, `btSubCmd=aPacket[6]`, `vData = [begin+7, end-4]` (strips 7-byte header + 4-byte CRC/ETX trailer). Dispatch by Cmd → `InterpretCmdRobot/Axis/EcatMaster/EcatSlave`. Increments SpinId.

**Command handlers**:
| Cmd | SubCmd handled | Action |
|-----|----------------|--------|
| `InterpretCmdRobot` | GET_METADATA | `SendMetadataRobot()`; GET_STATE = no-op |
| `InterpretCmdAxis` | GET_METADATA | `SendMetadataAxis(nAxisNo)` where `nAxisNo=apData[0]` |
| | GET_STATE | **empty; falls through (no `break`)** into SET_POS |
| | SET_POS | if `nAxisNo!=ALL_AXIS`: payload[1..] → `ConvertByteArrayToIntBE` (signed BE int) → `dValue=ConvertDeg2Rad(nValue/1000.0)`; build `ST_AXIS_CMD{nAxisNo,nCmd=SUBCMD_SET_POS,dValue}`, push to `VEC_AXIS_CMD`, invoke `m_pCallbackAxisCommand(&vAxisCmd,NULL,NULL,NULL)` (→ `CRobot::OnRecvAxisCommand`, a stub), then `SendAck()` |
| `InterpretCmdEcatMaster` | GET_METADATA | `SendMetadataEcatMaster()`; GET_STATE = no-op |
| `InterpretCmdEcatSlave` | (all) | **empty stub** — every case body is empty |

**Send/telemetry paths**:
- `SendMetadataRobot()` → `CMD_ROBOT/GET_METADATA`, payload `[IsSim(1), TotalAxis(U16 BE), IsEcatEnabled(1), nameLen(1), name...]`.
- `SendMetadataAxis(INT anAxis)` → `CMD_AXIS/GET_METADATA`. If `ALL_AXIS`: leading byte 0xFF then per-axis block `[idx(1), axisType(1), commType(1), posU/posL/velU/velL/accU/accL (each S32 BE), nameLen(1), name...]`. If single: `[axisIdx(1), axisType, commType, limits(6×S32 BE), nameLen, name...]`. (Torque/deceleration limits are TODO/omitted.)
- `SendMetadataEcatMaster()` → `CMD_ECAT_MASTER/GET_METADATA`, payload `[masterState(1), slaveState(1), domainState(1), slaveNo(U16 BE)]`. Uses cached `m_stEcatMetadata` when `m_bInRTContext` (set by `UpdateEcatMetadata`), else live `m_pRobot->m_pcEcatMaster->Get*State()` (direct friend access; returns FALSE if master null). State bytes are IgH-derived `ECAT_STATE_MACH` (from `include/EMasterApp/EcatCommon.h`): `eNONE=0x00,eINIT=0x01,ePRE_OP=0x02,eSAFE_OP=0x04,eOP=0x08`; domain = `ECAT_WC_STATE` (`eWC_NO_EXCHANGED=0,eWC_INCOMPLETE=1,eWC_COMPLETE=2`).
- `SendAck()` → `CMD_BINARY_RESPONSE/SUB_CMD_ACK`; `SendNack()` → `.../SUB_CMD_NACK` (**declared+defined but never called**).
- `OnSocketAccept()` (client connect): eagerly pushes `SendMetadataRobot()`, `SendMetadataEcatMaster()`, `SendMetadataAxis(ALL_AXIS)`.
- `SendPacket(cmd,subcmd[,data])` → `MakePacket` then `m_pSocket->SendToClients(&packet[0], size)`; increments SpinId.

**Registration/update API**:
| Method | Semantics |
|--------|-----------|
| `RegisterAxis(CAxis*)` | build `ST_AXIS_METADATA` from axis (revolute pos limits rad→deg then ×1000; others ×1000; vel/acc ×1000); push metadata + an initial `ST_AXIS_STATE` (cur pos/vel/acc/tor all seeded 1.0) |
| `UpdateAxisState(INT id, CAxis*)` | refresh cached state. **BUGGY**: bound-check `id > size()` (off-by-one, should be `>=`); `dCurPos`, `dCurVel` AND `dCurAcc` are ALL assigned `(BYTE)GetCurrentPos()` (lossy cast + all three sourced from position); `dCurTor` left stale |
| `UpdateEcatMetadata(UINT16 slaveNo, UINT8 master, UINT8 slave, UINT8 domain)` | cache RT states, set `m_bInRTContext=TRUE` |
| `RegisterCallbackAxisCmd(CALLBACK_FN)` | store axis-cmd callback (only if currently null) |
| `Init(CRobot*, INT32 port=7420)` | `DeInit()`; store robot; `new CTcpServer`; bind 6 socket callbacks; `->Start(port)` |
| `DeInit()` | stop+delete socket; clear metadata |

Socket callbacks `OnSocketOpen/Send/Close/ClientDisconnect` are **empty stubs**; only `OnSocketReceive` and `OnSocketAccept` carry logic.

**Wire struct field reference** (`Global/Defines.h`, all `#pragma pack(push,1)`; note: serialization is manual byte-push, so packing is informational):
- `ST_AXIS_CMD { int nAxisNo; int nCmd; double dValue; }`; `VEC_AXIS_CMD = std::vector<ST_AXIS_CMD>`.
- `ST_AXIS_STATE { BYTE btDriveMode; BYTE btStatus; double dCurPos,dCurVel,dCurAcc,dCurTor; }`.
- `ST_ECAT_STATES { UINT8 btMaster,btSlave,btDomain; }`; `ST_ECAT_METADATA { ST_ECAT_STATES stEcatStates; UINT16 usSlaveNo; }`.
- `ST_AXIS_METADATA { TSTRING strName; UINT8 btAxisType; UINT8 btCommType; INT32 nPosLimitU,nPosLimitL,nVelLimitU,nVelLimitL,nAccLimitU,nAccLimitL; }`.
- Enums referenced — **defined in `CRobot/Axis.h`, NOT Defines.h**: `eAxisType {eAxisRevolute=0,eAxisContinuous,eAxisPrismatic,eAxisPlanar,eAxisFixed,eAxisFloating,eAxisJointless,eAxisSensor}`; `eCommType {eAxisRS232=0,eAxisRS485,eAxisEthernet,eAxisEtherCAT,eAxisMuJoCo=0x20,eAxisUnknownCommType=0x30}` (also `eHomingMethod`, `eAxisState` live in Axis.h).
- Byte helpers (Defines.h): `ConvertU16ToByteArrayBE`, `ConvertS32ToByteArrayBE`, `ConvertS8ToByte`, `ConvertByteArrayToIntBE`, `ExtendByteArray(dst,src)`; angle: `ConvertRad2Deg`, `ConvertDeg2Rad`.

---

##### 6.4 EtherCAT / RT integration summary for the KV260 target

- **RT primitives (rtposix, `-lrtposix`, headers in `/opt/rt_posix/include/posix_rt.h`, NOT in this repo)**: `create_rt_task(&task, name, stack=2MiB, prio)`, `set_task_period(&task, start, period_ns)`, `start_task(&task, fn, arg)`, `wait_next_period(NULL)`, `read_timer()→RTTIME(ns)`, `SET_TM_NOW`. Priorities 0–99 (per cfg comment SCHED_FIFO under PREEMPT_RT). Sample cfg TASK0 = 1 ms period @ prio 99 (deployed `INDY7.cfg` TASK0/TASK1 = 1 ms @ 97/95); matches EtherCAT `CYCLE_TIME=1000000` ns — the ~1 ms RT/EtherCAT ceiling.
- **EtherCAT master** is IgH EtherLab (`ecrt.h`) behind `CEcatMaster`/`libEMasterApp`; `CRobot` only holds the pointer and reads state — the concrete robot builds the bus. Per-slave identity/DC come from `[AXISn]`: VENDOR_ID/PRODUCT_CODE (hex; sample `8_axis_testbed.cfg` vendor `0x000000fb`, products `0x60500000`/`0x61500000`; deployed `INDY7.cfg` vendor `0x0000089a`, products `0x30000000`/`0x10000007`), DC_SUPPORT, DC_ACTIVATE_WORD (default `0x300`), DC_SYNC0_SHIFT, plus master DC_ENABLED + CYCLE_TIME. State bytes on the wire are IgH INIT/PREOP/SAFEOP/OP (`0x01/0x02/0x04/0x08`).
- **Build/paths — CORRECTED ATTRIBUTION** (two distinct Makefiles):
  - **Repo-root `Makefile`** (`make install` stages the prebuilt EtherCAT lib): `DESTDIR ?= /opt`, `INSTALL_DIR = $(DESTDIR)/emaster_app` → copies `include/EMasterApp/*` → `/opt/emaster_app/include/` and `lib/EMasterApp/*` → `/opt/emaster_app/lib/`. (`EMasterApp/Makefile` is what links IgH: `LDFLAG_IGH = -L$(IGH_DIR)/lib -lethercat` into `libEMasterApp.so`.) The `-lethercat` dependency lives **inside** `libEMasterApp`, not in the App link line.
  - **`App/Indy7/Makefile`** (the concrete robot — has NO `DESTDIR`; its `INSTALL_DIR := $(PROJ_ROOT_DIR)` = repo root, where `install` copies the built `bin`): includes `ECAT_INCLUDE=/opt/emaster_app/include`, `IGH_INCLUDE=/opt/etherlab/include` (`IGH_DIR=/opt/etherlab`), `RT_POSIX_DIR=/opt/rt_posix` (`+/include,/lib`), `EIGEN3_INCLUDE=/usr/include/eigen3`, `VISP_INCLUDE=/home/raimlab/visp/build/include` (developer-specific), `/usr/include/opencv4`, `/usr/include/pcl-1.14`. Links `-L/opt/emaster_app/lib -lEMasterApp`, `-L/opt/rt_posix/lib -lrtposix`, `-lrbdl -lrbdl_urdfreader`, ViSP (`-lvisp_core/io/detection/sensor`), `-L/usr/local/lib/x86_64-linux-gnu -lrealsense2`, `-lm -lrt -lpthread`. In-code relative defaults: config `"ELMO.cfg"`, `"TEST.urdf"`, `"TEST.xml"`.

**Integration caveats / stubs (do not assume behavior):**
- `InitEtherCAT()` and `DoAgingTest()` are **protected** base stubs — a KV260 robot MUST override `InitEtherCAT()`.
- `OnRecvAxisCommand()` is a stub → incoming TCP `SET_POS` is ACK'd but never applied (the queue push is commented out); `m_vstAxisCmds` is declared but never written.
- `InterpretCmdEcatSlave` bodies are all empty; `GET_STATE` and all `GET_*`/`SET_VEL/ACC/TOR` subcommands are unimplemented; `InterpretCmdAxis` `GET_STATE` **falls through** (missing `break`) into `SET_POS`.
- Received packets are **not CRC-validated** (only STX/ETX framing).
- `m_pcExtInterface` is never freed; `m_pcEcatMaster` is `DeInit`'d but not `delete`d by the base.
- `InitRTTasks` requires `#AddTaskFunction == [RT_TASKS] NO_OF_TASKS` exactly, else returns FALSE (sample `8_axis_testbed.cfg`'s `NO_OF_TASKS=4` vs Indy7's 6 fns would fail — the **deployed `INDY7.cfg` correctly uses `NO_OF_TASKS=6`**).
- Config bugs: `AGING_DURATION` overwrites `bAging` (so `nAgingDur` never loaded); hand-slave config (`GetHandEcatSlaveList`) is never populated; `GetTotalRTTasks()` always returns 0; `UpdateAxisState` has an off-by-one bound check and lossy `(BYTE)` casts.
- `GetName()` / wire robot-name is the **URDF path** in the Indy7 build (`CRobotIndy7::Init` assigns `m_strName = strURDFPath`), not the `[SYSTEM] NAME`.
- Sim mode (`Init(TRUE)`) skips ext-iface, EtherCAT, and RT-task creation entirely.
- `UpdateConfiguration()`/`CreateDefaultConfig()` declared but unimplemented (link error if called); `LoadDefaultConfig()` is a no-op.

---
#### 7. Robot HAL — Sensors, Hand, MuJoCo visualization (`CRobot/Sensor*`, `KistarHand`, `MuJoCo*`)

This section covers the sensor abstraction layer (`CSensor` → `CSensorFT` → `CSensorNRMKEndTool`), the standalone KISTAR gripper/hand wrapper (`CKistarHand`), and the MuJoCo visualization + soft-real-time physics subsystem (`CMuJoCoVisualizationManager`) plus a non-built example (`MuJoCoAxisExample.cpp`). All F/T and gripper classes are thin EtherCAT device wrappers that own an `CEcatSlaveBase`-derived slave; the MuJoCo pieces are simulation-only and gated behind `-DMUJOCO_ENABLED`.

| File | LOC | Role |
|------|-----|------|
| `CRobot/Sensor.h` | 231 | Abstract `CSensor` base: enums, info/limits/status structs, lifecycle + limit/overload/calibration framework declarations |
| `CRobot/Sensor.cpp` | 245 | `CSensor` implementation: state machine, `CheckLimits`/`CheckOverload`, string helpers |
| `CRobot/SensorFT.h` | 142 | `CSensorFT` (6-axis F/T): `ST_FT_DATA`, `ST_FT_CALIBRATION`, processing/calibration API |
| `CRobot/SensorFT.cpp` | 358 | F/T pipeline: raw INT16→physical via dividers, bias/scale, magnitude, overload, file I/O |
| `CRobot/SensorNRMKEndTool.h` | 87 | `CSensorNRMKEndTool` (NRMK EOAT): binds `CSlaveNrmkEndtool`, LED/gripper/button/FT-flag API |
| `CRobot/SensorNRMKEndTool.cpp` | 364 | NRMK EOAT impl: slave read/write, LED status mapping, FT error handling |
| `CRobot/KistarHand.h` | 60 | `CKistarHand` multi-DoF gripper wrapper over `CSlaveKistarHand` (NOT a `CSensor`) |
| `CRobot/KistarHand.cpp` | 51 | Hand impl: rad↔user-unit conversion, target position, limits |
| `CRobot/MuJoCoVisualization.h` | 326 | Singleton viz manager, lock-free RT↔physics command queue + state exchange |
| `CRobot/MuJoCoVisualization.cpp` | 481 | GLFW/MuJoCo dual-rate (1 kHz physics / 60 Hz render) loop on a non-RT POSIX task |
| `CRobot/MuJoCoAxisExample.cpp` | 295 | **Not compiled, no `main()`** — example `MuJoCoRobotController` (6× `CAxisMuJoCo`, INDY7 cfg) + commented ROS2 node |

##### 7.1 `CSensor` abstract base (`Sensor.h` / `Sensor.cpp`)

Abstract polymorphic base for every sensor. Constructor `CSensor(eSensorCommType aeComm, eSensorType aeType, BOOL abEnabled = TRUE)` heap-allocates `m_pstSensorInfo` (`new ST_SENSOR_INFO`) and `m_pstSensorLimits` (`new ST_SENSOR_LIMITS`); destructor deletes both. Defaults: sample rate `1000`, filter cutoff `100`, comm `eSensorEtherCAT`, state `eSensorUnknownState`, not calibrated.

**Enums (all in `Sensor.h`):**
- `eSensorType`: `eSensorForceTorque=0, eSensorVision, eSensorProximity, eSensorTemperature, eSensorPressure, eSensorAccelerometer, eSensorGyroscope, eSensorIMU, eSensorLidar, eSensorEncoder, eSensorTouch, eSensorUnknown=0xFF`.
- `eSensorCommType`: `eSensorRS232=0, eSensorRS485, eSensorEthernet, eSensorEtherCAT, eSensorCAN, eSensorI2C, eSensorSPI, eSensorAnalog, eSensorUnknownCommType=0x10`.
- `eSensorState`: `eSensorEmergency=0x00, eSensorError, eSensorUnknownState, eSensorDeinit, eSensorDisconnected, eSensorInit, eSensorIdle, eSensorCalibrating, eSensorRunning, eSensorStopped, eSensorFault`.
- `eSensorCalibration`: `eSensorCalibrationNone=0, eSensorCalibrationZero, eSensorCalibrationBias, eSensorCalibrationScale, eSensorCalibrationFull`.

**Structs:** `ST_SENSOR_INFO`{`eState,eType,eComm,eCalibration, UINT32 uSampleRate, UINT32 uFilterCutoff, BOOL bIsCalibrated`}; `ST_SENSOR_LIMITS`{`BOOL bIsSet, double dMaxValue,dMinValue,dOverloadThreshold,dWarningThreshold`}; `ST_SENSOR_STATUS`{`BOOL bOnline,bOverload,bWarning,bCalibrating, UINT8 uErrorCode, UINT32 uDataCount,uLastUpdateTime`}. All have zero/default-initializing constructors.

**Pure-virtual contract (must be implemented downstream):** `Init()`, `DeInit()`, `Start()`, `Stop()`, `Reset()`, `Calibrate(eSensorCalibration=eSensorCalibrationZero)`, `ReadData()`, `IsDataReady()`, `SetSampleRate(UINT32)`, `SetFilterCutoff(UINT32)`, `SetCalibrationData(void*,UINT32)`, `LoadCalibrationFromFile(const TSTRING&)`, `SaveCalibrationToFile(const TSTRING&)`.

**Base-implemented behavior:**

| Method | Semantics |
|--------|-----------|
| `SetLimits(min,max,overload=0,warning=0)` | Validates `min<max` (`ValidateRange`), stores limits, sets `bIsSet=TRUE`; returns FALSE on invalid range |
| `SetState(eSensorState)` | Logs transition; side-effects: `Running`→`bOnline=TRUE`; `Error/Fault/Disconnected`→`bOnline=FALSE`; `Calibrating`→`bCalibrating=TRUE`; `Idle`→`bCalibrating=FALSE` |
| `CheckLimits(double v)` | If `bIsSet`: `fabs(v) > dOverloadThreshold` (when >0) → `bOverload=TRUE`, return FALSE; `fabs(v) > dWarningThreshold` (when >0) → `bWarning=TRUE`; then returns `IsValueInRange(v)` |
| `IsValueInRange(double v)` | `v ∈ [dMinValue, dMaxValue]` (TRUE if no limits set) |
| `UpdateStatus()` | `uLastUpdateTime = read_timer()`; calls `CheckOverload()`; logs if warning active |
| `CheckOverload()` | If `bOverload` → `SetState(eSensorError)` + `SetErrorCode(0x01)` (generic overload). Meant to be overridden |
| `GetSensorTypeString()/GetSensorStateString([state])` | Enum → `TSTRING` |
| Protected `InitHW/InitSW/DeInitHW/DeInitSW` | Default no-op stubs; `InitSW`→`SetState(eSensorInit)`, `DeInitSW`→`SetState(eSensorDeinit)`+`bOnline=FALSE` |

Inline accessors: `IsEnabled/SetEnabled`, `IsOnline`, `IsCalibrated`, `IsOverloaded`, `HasWarning`, `GetErrorCode`, `GetDataCount`, `GetSampleRate`, `GetFilterCutoff`, `GetState`, `IsRunning/IsStopped/IsInError`, `SetID/GetID`, `SetName/GetName`, `SetAliasPos(alias,pos)`, `GetSensorType/SetSensorType`, `GetCommType/SetCommType`, `GetSensorLimits/GetSensorStatus`. Virtual no-op hooks for derived EtherCAT sensors: `SetVendorInfo(vendorID,productCode)`, `SetDCInfo(dcSupported,activateWord,shiftTime)`, `PrintSensorInfo()`.

**Error codes seen:** `0x01` generic overload (`CheckOverload`), `0x02` calibration error (`CSensorFT::Calibrate`).

##### 7.2 `CSensorFT` — 6-axis F/T processing (`SensorFT.h` / `SensorFT.cpp`)

`class CSensorFT : public CSensor`. Constructor `CSensorFT(eSensorCommType aeComm, BOOL abEnabled=TRUE)` → base with type `eSensorForceTorque`; `memset`s FT data; sets dividers to NRMK defaults and calls `SetLimits(-1000.0, 1000.0, 800.0, 600.0)` (min, max, overload, warning — in Newtons per comment). **Still abstract** — does not override `Init/DeInit/Start/Stop/Reset/SetSampleRate/SetFilterCutoff`, so it cannot be instantiated directly.

**`ST_FT_DATA`** (`SensorFT.h`): raw `INT16 nRawFx,nRawFy,nRawFz,nRawTx,nRawTy,nRawTz`; calibrated `float fFx..fTz`; `float fForcemagnitude, fTorqueMagnitude`; `BOOL bDataValid`; `UINT32 uTimestamp`.

**`ST_FT_CALIBRATION`**: `float fBiasFx..fBiasTz` (0); `float fScaleFx..fScaleTz` (1.0); `float fForceDivider = 50.0f`; `float fTorqueDivider = 2000.0f`; `BOOL bIsValid = FALSE`. **These are the scale constants** — 50 raw-units/N and 2000 raw-units/Nm (NRMK convention; also defined in `SlaveNRMKEndTool.h` as `FT_FORCE_DIVIDER 50.` / `FT_TORQUE_DIVIDER 2000.`).

**Processing pipeline (`ProcessRawData()`), exact order:**
1. Physical = raw / divider: `fFx = nRawFx / fForceDivider` (×3), `fTx = nRawTx / fTorqueDivider` (×3).
2. If `fCalibration.bIsValid`: `ApplyCalibration()` — **subtract bias then multiply by scale**, per axis.
3. `CalculateMagnitudes()` — `fForcemagnitude = sqrt(fFx²+fFy²+fFz²)`, `fTorqueMagnitude = sqrt(fTx²+fTy²+fTz²)`.
4. `m_bForceOverload = !CheckForceLimits(fFx,fFy,fFz)`; `m_bTorqueOverload = !CheckTorqueLimits(...)` — each computes the vector magnitude and calls base `CheckLimits`.
5. `uTimestamp = read_timer()`; `bDataValid = TRUE`.

**`ZeroBias()`**: takes `BIAS_SAMPLES = 100` samples (each iteration re-calls `ProcessRawData()`), averages `fFx..fTz`, stores as bias, sets `bIsValid=TRUE`. NOTE: loop re-processes the *same* latched raw data (no fresh acquisition inside the base loop — derived class must feed data).

**`Calibrate(type)`**: requires `IsOnline()`. `Zero`/`Bias` → `ZeroBias()`; `Scale` → **not implemented** (logs warning, returns FALSE); `Full` → falls back to `ZeroBias()` (full cal not implemented). On success sets `bIsCalibrated=TRUE`, `eCalibration=type`, `SetState(eSensorIdle)`; on failure `SetState(eSensorError)`+`SetErrorCode(0x02)`.

**Other:** `SetBias(fx..tz)`, `SetScale(fx..tz)`, `SetDividers(force,torque)` (rejects ≤0). `SetCalibrationData(void*,size)` requires `size==sizeof(ST_FT_CALIBRATION)` (`memcpy`). `LoadCalibrationFromFile/SaveCalibrationToFile` do **raw binary `std::ifstream/ofstream` (`std::ios::binary`) of the whole `ST_FT_CALIBRATION` struct** — not portable across ABIs; load validates `bIsValid`. Getters: `GetFTData`, `GetForce(&,&,&)`, `GetTorque`, `GetRawForce`, `GetRawTorque`, individual `GetFx..GetTz`, `GetRawFx..GetRawTz`, `GetForceMagnitude`, `GetTorqueMagnitude`, `GetCalibration`, `IsForceOverload`, `IsTorqueOverload`. `ReadData()` base impl just re-runs `ProcessRawData()`+`IncrementDataCount()`+`UpdateStatus()` (expected to be overridden). `UpdateRawData(fx..tz)` latches the 6 raw INT16s.

##### 7.3 `CSensorNRMKEndTool` — NRMK EOAT integration (`SensorNRMKEndTool.h` / `SensorNRMKEndTool.cpp`)

`class CSensorNRMKEndTool : public CSensorFT`. Owns a **`CSlaveNrmkEndtool m_cNrmkSlave`** (by value) and `CEcatMaster* m_pEcMaster`. Constructor `CSensorNRMKEndTool(BOOL abEnabled=TRUE)` → `CSensorFT(eSensorEtherCAT)`; sets name `"NRMK_EndTool"`, `SetDividers(50.0f, 2000.0f)`, sample rate `1000`, filter cutoff `100`.

**Lifecycle:**

| Method | Behavior |
|--------|----------|
| `Init()` (no-arg) | Stub — returns TRUE (hides base pure-virtual) |
| `Init(CEcatMaster& m)` | `InitSW()` → `SetState(eSensorIdle)` → `InitSlave(m)`. (`m_bSlaveInitialized` guard is commented out.) `/* TODO: Implement Enabled and Connected logic */` |
| `InitSlave(CEcatMaster& m)` | `m_pEcMaster=&m; m_pEcMaster->AddSlave(&m_cNrmkSlave)`. **Bug/caveat: never sets `m_bSlaveInitialized=TRUE`** (only DeInit sets it FALSE), so the early-return-if-initialized check is dead |
| `DeInit()` | Stops if running, `m_cNrmkSlave.DeInit()`, `m_bSlaveInitialized=FALSE`, `DeInitSW()` |
| `Start()` | Requires `IsOnline()`; `m_cNrmkSlave.FTSensorOn(true, uSampleRate, uFilterCutoff)`; `SetState(eSensorRunning)` |
| `Stop()` | `m_cNrmkSlave.FTSensorOff()`; `SetState(eSensorStopped)` |
| `Reset()` | Stop → `ClearError()` → clear overload/warning → `LED_OFF()` → `SetState(eSensorIdle)` |
| `Calibrate(type)` | **STUB** — body fully commented out; only checks `IsOnline()` then returns TRUE. Does NOT call `CSensorFT::Calibrate` |
| `ReadData()` | `ReadFromSlave()` → `UpdateRawData(GetFTRawFx..GetFTRawTz())` → `ProcessRawData()` → `HandleFTErrors()` → `UpdateLEDStatus()` → `IncrementDataCount()` → `UpdateStatus()` |
| `IsDataReady()` | `IsOnline() && m_cNrmkSlave.IsFTSensorOn()` |
| `SetSampleRate(r)` / `SetFilterCutoff(c)` | Store value; if running, `Stop()`+`Start()` to re-arm sensor |

**LED control** — `SetLED(LED_MODE)` sets `m_eLEDMode` and calls `m_cNrmkSlave.SetLEDMode((UINT8)mode)`. Convenience: `LED_OFF()`, `LED_RED(blink=FALSE)`, `LED_GREEN(blink)`, `LED_BLUE(blink)`, `LED_YELLOW(blink)` map to the slave's `CSlaveNrmkEndtool::LED_MODE` enum: `NO_COLOR=0, BLINK_RED, STEADY_RED, BLINK_GREEN, STEADY_GREEN, BLINK_BLUE, STEADY_BLUE, BLINK_YELLOW, STEADY_YELLOW`.

**`UpdateLEDStatus()` mapping (priority order):** `IsInError()` → RED blink; else `IsOverloaded()` → YELLOW blink; else `IsRunning()` → GREEN steady; else → OFF.

**Gripper / button / status:** `SetGripper(UINT8)` → `m_cNrmkSlave.SetIGripper(value)` (writes 8-bit `IGripper` output PDO 0x7000:02); `GetGripper()` → `m_cNrmkSlave.GetIStatus()` (**caveat: comment says "Assuming gripper status is in IStatus"** — reads `IStatus` input PDO, not a dedicated gripper feedback). `IsButtonPressed()` → `GetIButton()!=0`; `GetStatus()` → `GetIStatus()`.

**FT flags:** `IsFTSensorOn()`, `GetFTErrorFlag()` (8-bit), `GetFTOverloadStatus()` (8-bit). `HandleFTErrors()`: if error flag ≠0 → `SetErrorCode(flag)`+`SetState(eSensorError)`; if overload ≠0 → `bOverload=TRUE`.

**Overrides:** `ProcessRawData()` = base + `m_uLastDataTime=read_timer()`. `UpdateRawData(...)` = base latch + `m_cNrmkSlave.WriteToSlave()`. `SetVendorInfo`/`SetDCInfo` forward to the slave. `GetSlave()` returns `CSlaveNrmkEndtool*`.

**EtherCAT specifics of the bound slave (`EMasterApp/Device/SlaveNRMKEndTool.h`) — needed to wire this device:**
- Vendor ID `NRMK_VENDOR_ID = 0x0000089a`; product code `NRMK_ENDTOOL = 0x10000007`; `NRMK_ENDTOOL_ACTIVATE_WORD = 0x0300`; `NRMK_ENDTOOL_SYNC0_SHIFT = 0`.
- **Output PDOs (RxPDO 0x1600, 7 entries), index 0x7000:** `:01` ILed(8), `:02` IGripper(8), `:03` FTConfigParam(32), `:04` LEDMode(8), `:05` LEDG(8), `:06` LEDR(8), `:07` LEDB(8).
- **Input PDOs (TxPDO 0x1a00, 10 entries), index 0x6000:** `:01` IStatus(8), `:02` IButton(8), `:03` FTRawFx(16), `:04` FTRawFy(16), `:05` FTRawFz(16), `:06` FTRawTx(16), `:07` FTRawTy(16), `:08` FTRawTz(16), `:09` FTOverloadStatus(8), `:0a` FTErrorFlag(8).
- **Sync managers:** SM0 `EC_DIR_OUTPUT` WD_DISABLE (mailbox), SM1 `EC_DIR_INPUT` WD_DISABLE, SM2 `EC_DIR_OUTPUT` → 0x1600 `EC_WD_ENABLE`, SM3 `EC_DIR_INPUT` → 0x1a00 `EC_WD_DISABLE`, terminator `{0xff}`.
- **FT config command words (`FTConfigParam`):** `FT_START_DATA_OUTPUT=0x0B`, `FT_STOP_DATA_OUTPUT=0x0C`, `FT_BIAS_COMMAND=0x11`, `FT_DATARATE_COMMAND=0x0F`, `FT_FILTER_COMMAND=0x118`. `BLINK=1`, `STEADY=0`. `FT_ERROR_CODE`{`NO_ERROR=0x00, UNSUPPORTED_COMMAND=0x01, OUT_OF_RANGE=0x02, FAILED_PARAMETER=0x03`}; `FT_STATE_MACHINE`{`FT_NONE=0x00, FT_READY, FT_SET_DATARATE, FT_SET_FILTER, FT_SET_START, FT_SET_BIAS, FT_FAULT`}. `FTSensorOn(bool biasing=true, int output_rate=1000, int lpf_cof=100)` / `FTSensorOff()`.

##### 7.4 `CKistarHand` — KISTAR multi-DoF gripper (`KistarHand.h` / `KistarHand.cpp`)

Standalone gripper wrapper (**not** derived from `CSensor`; conceptually parallel to an `CAxis` group). Owns `CSlaveKistarHand m_cEcSlave` and `CEcatMaster* m_pEcMaster`.

- **Unit conversion macros:** `RAD2USR(X) = X*8192.0/M_PI`, `USR2RAD(X) = X*M_PI/8192.0` → **8192 user-units per π radians** (13-bit-per-half-rev encoder convention).
- **`enum eControlMode { PWM_MODE=0x0000, POSITION_MODE=0xFFFF }`** — written via `SetControlMode(usMode)` into the slave's `usStatusOut2`.
- Constructor `CKistarHand(INT32 nNoAxes, BOOL abEnabled, BOOL abConnected)`: allocates `ST_AXIS_LIMITS[nNoAxes]`; if `!abConnected` forces `SetEnabled(FALSE)`. Destructor `delete[]`s the limits array.

| Method | Semantics |
|--------|-----------|
| `Init(CEcatMaster&)` | `m_pEcMaster->AddSlave(&m_cEcSlave)`; returns TRUE |
| `SetServoOn(usFlag=0xFFFF)` / `SetServoOff(usFlag=0x0000)` | `m_cEcSlave.SetServoStatus(flag)` (`usStatusOut1`) |
| `SetControlMode(usMode)` | `usStatusOut2` |
| `SetTargetPos(int nAxis, double dTarget)` | `m_cEcSlave.SetTargetPos(nAxis, RAD2USR(dTarget))` — rad in, user-units to wire |
| `GetTargetPos(int nAxis)` | `USR2RAD(m_cEcSlave.GetTargetPosition(nAxis))` |
| `SetPositionLimits(nAxis, lowerDeg, upperDeg, abSet=TRUE)` | Converts deg→rad via `ConvertDeg2Rad` (from `Axis.h`), stores in `m_pstAxisLimits[nAxis].stPos` |
| `GetPositionLimits(nAxis)` | Returns `ST_LIMITS` (`stPos`) |
| `SetVendorInfo`/`SetDCInfo`/`SetEnabled`/`SetName`/`GetName`/`isConnected` | Forwarders / trivial accessors |

**Bound slave (`EMasterApp/Device/SlaveKistarHand.h`) EtherCAT map:** default `KISTAR_HAND_VENDOR_ID=0x00000000`, `KISTAR_HAND_PRODUCT_CODE=0x00000004`, `KIST_FT_ACTIVATE_WORD=0x0300`, `KIST_FT_SYNC0_SHIFT=125000` (ns). RxPDO `0x1600` = 32 entries at index `0x0007` (StatusOut1/2 + 16× TargetPos + 14× AddInfoOut, all 16-bit); TxPDO `0x1a00` = 64 entries at index `0x0006` (StatusIn1/2 + 16× Position + 16× Current + 12× Kinesthetic + 4× Tactile + 14× AddInfoIn, all 16-bit). Header carries a reference comment for an alternate device "IFBOX4NEWIF" (Vendor `0x00828845`, Product `0x00009252`, Rev `0x00000001`) — **comment only, not active config**. `ST_AddInfo` config struct (packed): `usWRMode, nPosGainP, nPosGainD, 4× tactile thresholds (thumb/index/middle/ring), reserved[12], nInitOrgin`.

##### 7.5 MuJoCo visualization + physics (`MuJoCoVisualization.h` / `.cpp`)

Simulation-only. Entire functional body is inside `#ifdef MUJOCO_ENABLED` (else stubs return false/log error). **Compiled only in `App/Indy7_ROS2_Mujoco`** (`SOURCES += $(ROBOT_DIR)/MuJoCoVisualization.cpp`), which passes `-DMUJOCO_ENABLED`.

**`PhysicsCommand`** (lock-free command, all fields `std::atomic`): `Type type` (`SET_JOINT_TORQUE=0, SET_JOINT_POSITION, SET_JOINT_VELOCITY, STEP_PHYSICS`), `int joint_index`, `double value`, `double timestamp`, `bool valid`. Hand-written copy-ctor/assignment do `.load()/.store()` on each atomic. Helpers `Set(...)`, `SetStepCommand(time)`, `IsValid()`, `Consume()`, `GetType/GetJointIndex/GetValue/GetTimestamp`.

**`LockFreePhysicsQueue<SIZE>`**: SPSC ring buffer, `std::array<PhysicsCommand,SIZE>` + atomic read/write indices. `Push(type,idx,val,ts)` / `PushStepCommand(ts)` (producer = RT control thread; returns false when full = `nextWrite==readIndex`), `Pop(PhysicsCommand&)` (consumer = physics thread; checks `IsValid()` then `Consume()`), `IsEmpty()`, `Size()`. Instantiated as `LockFreePhysicsQueue<1000>`.

**`RTVisualizationData`**: `std::atomic<double> joint_positions[8]/joint_velocities[8]/joint_torques[8]`, `timestamp`, `data_updated`, `num_joints`. `UpdateFromRT(n,pos*,vel*,tor*,time)` (RT producer, sets `data_updated=true`), `ReadForVisualization(...)` (consumer, gated on `data_updated`, clears flag). **Fixed 8-joint capacity.**

**`CMuJoCoVisualizationManager`** — Meyers singleton (`GetInstance()`), non-copyable. Holds `mjModel* m_pMjModel`, `mjData* m_pMjData`, atomic feedback arrays `[8]`, `m_numJoints`, `POSIX_TASK m_visualizationTask`, atomics `m_bStopVisualization/m_bVisualizationActive/m_bInitialized`, `RTVisualizationData m_visualizationData`, `LockFreePhysicsQueue<1000> m_physicsQueue`, `m_physicsTime`, `m_physicsStepCount`, and a `VisualizationSettings` struct.

| Method | Semantics |
|--------|-----------|
| `Initialize(const char* modelFile)` | `mj_loadXML(modelFile,0,error,1000)` → `mj_makeData` → `mj_resetData`; sets `m_bInitialized`. Without `MUJOCO_ENABLED` returns false |
| `StartVisualization()` | Requires initialized; spawns **non-RT** task: `spawn_nrt_task(&m_visualizationTask, "MuJoCoViz", DEFAULT_STKSIZE, VisualizationTaskFunc, this)`; `usleep(10000)` (10 ms) settle |
| `StopVisualization()` | `m_bStopVisualization=true`; `delete_task(&m_visualizationTask)`; clears active flag |
| `Shutdown()` | Stop + `mj_deleteData`/`mj_deleteModel` |
| `UpdateRobotState(n,pos*,vel*,tor*,ts)` | RT-safe; no-op unless active; forwards to `m_visualizationData.UpdateFromRT` |
| `SendJointTorque/Position/VelocityCommand(idx,val,ts)` | Push typed command (returns false if not active) |
| `SendPhysicsStepCommand(ts)` | Push `STEP_PHYSICS` |
| `GetJointFeedback(idx,&pos,&vel,&tor)` | Atomic read of feedback arrays; bounds-checked on `m_numJoints` |
| `IsVisualizationActive()` | atomic read |

**`RunVisualization()` (task body):** `glfwInit` → `glfwCreateWindow(1200,900,"RAON-RT MuJoCo Simulation (1kHz Physics)")` → `glfwMakeContextCurrent` → `glfwSwapInterval(1)` (vsync). Builds `mjvCamera/mjvOption/mjvScene(maxgeom=2000)/mjrContext(mjFONTSCALE_150)`. Camera: azimuth `90.0`, elevation `-20.0`, distance `2.0`, lookat `{0,0,1}`. `m_numJoints = min(m_pMjModel->njnt, 8)`.
Dual-rate wall-clock loop (`std::chrono::high_resolution_clock`), runs while `!m_bStopVisualization && !glfwWindowShouldClose`:
- **Physics @ 1 kHz** (`physics_dt = 1/physics_hz = 1 ms`): `ProcessPhysicsCommands()` → `StepMuJoCoPhysics(physics_dt)` → `UpdateVisualizationFromPhysics()`.
- **Render @ 60 Hz** (`vis_dt = 1/60`): framebuffer size, `mjv_updateScene(...,mjCAT_ALL,...)`, `mjr_render`, `glfwSwapBuffers`, `glfwPollEvents`; perf `DBG_LOG_INFO` every 5 s (`vis_frames % (fps*5)==0`).
- `usleep(100)` (0.1 ms) each iteration to cap CPU. Cleanup: `mjr_freeContext`, `mjv_freeScene`, `glfwDestroyWindow`, `glfwTerminate`.

**`ProcessPhysicsCommands()`**: drains up to `max_commands_per_cycle = 50` per cycle. `SET_JOINT_TORQUE`→`m_pMjData->ctrl[idx]=val` (idx bounded by `nu`); `SET_JOINT_POSITION`→`qpos[idx]` (bounded by `njnt`); `SET_JOINT_VELOCITY`→`qvel[idx]` (bounded by `njnt`); `STEP_PHYSICS`→no-op. **`StepMuJoCoPhysics(ts)`**: `mj_step` **then** `m_pMjData->time += timestep` (note: increments sim time on top of mj_step's own advance). **`UpdateVisualizationFromPhysics()`**: copies `qpos[i]/qvel[i]` → atomic pos/vel and `qfrc_applied[i]` → atomic torque, for `i < m_numJoints` (bounded by `njnt`/`nu`).

**`VisualizationSettings`** defaults: `window_width=1200, window_height=900`, title as above, `camera_azimuth=90, camera_elevation=-20, camera_distance=2.0, camera_lookat={0,0,1}, visualization_fps=60, physics_hz=1000`.

**`namespace MuJoCoViz`** free functions (`Initialize/Start/Stop/Shutdown/UpdateRobotState/SendJointTorqueCommand/SendJointPositionCommand/SendJointVelocityCommand/SendPhysicsStepCommand/GetJointFeedback/IsActive`) are thin forwarders to the singleton — the intended API for RT control threads.

##### 7.6 `MuJoCoAxisExample.cpp` — non-built example

**No `main()`, not referenced by any Makefile → dead/example code only.** Defines `struct MuJoCoAxisConfig` (mjJointId, enabled, connected, name, encoderResolution, gearRatio, transmissionRatio, torqueConstant, currentRatio, operatingVelocity/Acceleration, position/velocity/torque limits) and class `MuJoCoRobotController` which builds 6× `std::unique_ptr<CAxisMuJoCo>` (see Axis section) for an INDY7. Per-axis: `Init(mjModel*,mjData*)`, `UpdateFromMuJoCo()`+`ApplyToMuJoCo()` in `Update()`, `MoveJoint/MoveJointVelocity/MoveJointTorque(jointId,val)`, `GetJointPosition/Velocity/Torque`, `IsJointReady` (`IsServoOn`), `Shutdown` (`ServoOff`+`DeInit`). Axes created as `eAxisRevolute`, absolute encoder + CCW, homing `eAxisHomeStartPos`.

**Hardcoded INDY7 config table (values a future integrator can reuse for the real robot):**

| Joint | mjId | encRes | gearRatio | Kt | currentRatio | opVel | opAcc | posLim (±deg) | velLim | torLim |
|-------|------|--------|-----------|------|------|------|-------|------|------|------|
| 0 | 0 | 65536 | 121 | 0.0884 | 48.0 | 130 | 10000 | ±35 | 150 | 117.73 |
| 1 | 1 | 65536 | 121 | 0.0884 | 48.0 | 130 | 10000 | ±35 | 150 | 117.73 |
| 2 | 2 | 65536 | 121 | 0.087 | 96.0 | 125 | 10000 | ±35 | 150 | 47.5 |
| 3 | 3 | 65536 | 101 | 0.058 | 96.0 | 155 | 10000 | ±35 | 178 | 21.0 |
| 4 | 4 | 65536 | 101 | 0.058 | 96.0 | 155 | 10000 | ±35 | 178 | 21.0 |
| 5 | 5 | 65536 | 101 | 0.058 | 96.0 | 155 | 10000 | ±35 | 178 | 21.0 |

(transmissionRatio = 1.0 all joints.) Bottom half of the file is a **commented-out** `MuJoCoROS2Node : rclcpp::Node` sketch (joint_states publisher, joint_commands subscriber, 1 ms `create_wall_timer` calling `mj_step`).

##### 7.7 RT/timing, dependencies, integration caveats

**RT-POSIX (rtposix) usage** — external lib `-lrtposix` at `RT_POSIX_DIR=/opt/rt_posix` (`include/`, `lib/`), header `posix_rt.h` (not in repo): `read_timer()` (Sensor/SensorFT/SensorNRMKEndTool timestamps), `spawn_nrt_task(POSIX_TASK*, name, DEFAULT_STKSIZE, func, arg)`, `delete_task(POSIX_TASK*)`, `POSIX_TASK`, `DEFAULT_STKSIZE`. **The MuJoCo viz thread is explicitly a NON-RT task** (`spawn_nrt_task`) — not scheduled at RT priority; physics timing is wall-clock, not deadline-driven.

**External dependencies:** `posix_rt.h`/librtposix (`/opt/rt_posix`); IgH EtherLab (`ecrt.h` types `ec_pdo_entry_info_t`, `ec_pdo_info_t`, `ec_sync_info_t`, `EC_DIR_*`, `EC_WD_*`) transitively via `EcatSlaveBase.h`/`EcatMasterBase.h`; MuJoCo 2.3.7 (`mujoco/mujoco.h`) at `MUJOCO_DIR=/home/raimlab/dev_env/mujoco-2.3.7`; GLFW3 (`GLFW/glfw3.h`) and OpenGL (`GL/gl.h`, `GL/glu.h`); C++ stdlib `<atomic>`, `<chrono>`, `<array>`, `<vector>`, `<fstream>`, `<cmath>`, `<unistd.h>`. `Axis.h` (for `CKistarHand`: `ST_LIMITS`, `ST_AXIS_LIMITS`, `ConvertDeg2Rad`) and `AxisMuJoCo.h` (example only). No RBDL/Eigen/ViSP used directly in this subsystem (Eigen pulled transitively at app level).

**Caveats / stubs / hazards for EtherCAT+PREEMPT_RT integration:**
- **`CSensorNRMKEndTool::Start()`/`ReadData()`/`Calibrate()` all gate on `IsOnline()`, but `bOnline` is only set TRUE by `SetState(eSensorRunning)`.** After `Init()` the state is `eSensorIdle` (offline), so `Start()` returns FALSE. A future integrator must force the sensor online (e.g. `SetState(eSensorRunning)` once the EtherCAT slave reaches OP) before these calls work — the code has no path that sets online from the EtherCAT link/AL state.
- `CSensorNRMKEndTool::Calibrate()` is a **no-op stub** (body commented out) — despite `CSensorFT` implementing `ZeroBias`, the derived override never invokes it. F/T zeroing must be driven manually.
- `m_bSlaveInitialized` is **never set TRUE**; the guard in `InitSlave()` is effectively dead.
- `GetGripper()` returns `IStatus`, not a real gripper feedback field (self-documented assumption).
- `ZeroBias()` re-processes latched raw data 100× without fresh acquisition in the base class — the derived class's `ReadData` must be interleaved for a meaningful bias, but the stubbed `Calibrate` never does this.
- F/T calibration file format is **raw binary struct dump** (`ST_FT_CALIBRATION`) — endian/ABI/padding-fragile across the Kria ARM target vs. authoring host.
- Sensor state machine has no explicit INIT/PREOP/SAFEOP/OP mapping — the EtherCAT AL state machine lives in the `CEcatSlaveBase`/`CEcatMaster` layer (other sections); DC sync/activate-word/shift are forwarded verbatim via `SetVendorInfo`/`SetDCInfo` (NRMK activate word `0x0300` shift `0`; KISTAR activate `0x0300` shift `125000` ns).
- MuJoCo subsystem is entirely opt-in (`-DMUJOCO_ENABLED`) and simulation-only; feedback arrays are hard-capped at 8 joints; `StepMuJoCoPhysics` double-advances `mjData->time`. Not part of the EtherCAT hardware path.

**Hardcoded absolute paths (from `App/Indy7_ROS2_Mujoco/Makefile`):** `RT_POSIX_DIR=/opt/rt_posix`; `MUJOCO_DIR=/home/raimlab/dev_env/mujoco-2.3.7` (headers `-I.../include`, lib `-L.../lib -lmujoco`). No hardcoded paths inside the `.cpp/.h` sources themselves — MuJoCo model file is passed at runtime to `Initialize(const char* modelFile)`.

---
#### 8. Global utilities — INI parser, defines, comm primitives (`Global/`)

Non-ROS shared C++ utility layer used across the RAON-RT framework. Pure POSIX/libc/STL + `std::thread` (needs `-lpthread`). **No IgH `ecrt.h`, no RBDL, no Eigen, no ViSP, no `rtposix`/`create_rt_task` anywhere in this layer.** All files authored by Raimarius Delgado, "ROBOGRAM LAB (2022)", KIST AIRI. The only EtherCAT presence here is passive data structs (`ST_ECAT_STATES`, `ST_ECAT_METADATA`) — no bus I/O, no PDO/SDO calls, no DC sync. The only RT-relevant primitive is `GetCurrTimeInNs()` (`CLOCK_MONOTONIC`).

| File | LOC | Role |
|---|---|---|
| `Global/ConfigParser.h` | 25 | Declares Win32-style `GetPrivateProfile*` INI API + file/dir existence checks |
| `Global/ConfigParser.cpp` | 242 | INI (.cfg) read/write, atomic write via `mkstemp`+`rename` |
| `Global/Defines.h` | 635 | Header-only: typedefs, logging macros, time, endian/angle conversions, comm structs |
| `Global/Comm/CRC16.h` | 84 | `CRC16` configurable table-driven checksum + `CRC16_ARC` |
| `Global/Comm/CRC16.cpp` | 128 | CRC16 LUT generation and calculation |
| `Global/Comm/Socket.h` | 258 | `CSocket`, `CTcpClient`, `CTcpServer` declarations |
| `Global/Comm/Socket.cpp` | 613 | BSD-socket TCP server/client, multi-client accept + reaper threads |
| `Global/Comm/Serial.h` | 171 | `CSerialComm` termios serial wrapper declarations |
| `Global/Comm/Serial.cpp` | 333 | termios serial config + async send/recv threads (file header mislabeled "Socket.cpp") |

##### 8.1 `ConfigParser` — Win32-compatible INI (.cfg) reader/writer

Reimplements Windows `GetPrivateProfileString/Int` and `WritePrivateProfileString` on POSIX. Section header format is `[section]`; entries are `key=value`, one per line. Line buffer is `__MAX_PATH__` (1024) — **lines longer than 1023 chars are truncated**.

| Signature | Semantics |
|---|---|
| `BOOL IsExistFile(const char* strName)` | `stat()`==0 → TRUE. Returns TRUE for **any** existing path (also directories). |
| `BOOL IsExistDir(const char* strName)` | `stat()`==0 AND `st_mode & S_IFDIR` → TRUE. |
| `size_t GetPrivateProfileString(section, entry, def, char* buffer, size_t buffer_len, file_name)` | Reads string value; on any failure (file missing, section/entry not found, no `=`) copies `def` into `buffer` and returns its length. Trims leading/trailing whitespace and `\n`. |
| `int GetPrivateProfileInt(section, entry, int defval, fname)` | Reads integer; parses leading digits after `=` via `atoi`. |
| `BOOL WritePrivateProfileString(section, entry, def, file_name)` | Writes/updates `key=value`; creates file+section if absent. Atomic replace. |

Behavioral details and caveats to know before reuse:
- **Section match asymmetry:** `GetPrivateProfileString` matches the section with `strncasecmp` (case-**in**sensitive) and the entry with `strncasecmp`. `GetPrivateProfileInt` matches the section with `strcmp` against `"[section]"` (case-sensitive **and** requires the line to equal the bracketed name including trailing newline; a `[section]\n` from `fgets` will contain the `\n`, so `strcmp` typically never matches → returns `defval`). Treat `GetPrivateProfileInt` as fragile; prefer `GetPrivateProfileString` + manual `atoi`.
- **`GetPrivateProfileInt` fopen-fail returns `0`, not `defval`** (line 121) — inconsistent with its own "not found" path which returns `defval`.
- **Buffer overflow (off-by-one):** `GetPrivateProfileString` does `buffer[buffer_len] = '\0'` (line 105) — writes one byte past a `buffer_len`-sized buffer. Callers must over-allocate by 1 or expect a 1-byte overwrite.
- **Atomic write mechanism:** `WritePrivateProfileString` calls `mkstemp("PRIVPROFXXXXXX")` → creates the temp file **in the current working directory** (relative name, NOT alongside `file_name`), copies/edits into it, then `unlink(file_name); rename(tname, file_name)`. **Caveat: `rename()` fails with `EXDEV` if CWD and `file_name` are on different filesystems** — safe only when `file_name` lives on the same FS as CWD. Also not thread-safe (fixed temp template pattern).
- Value read into `char value[12]` in `GetPrivateProfileInt` — max 10 decimal digits + sign assumption.

##### 8.2 `Defines.h` — global typedefs, macros, logging, time, conversions, comm structs (exhaustive)

**Constants / magic numbers**
- `M_PI = 3.141592653589793`, `TWO_M_PI = 6.283185307179586`
- `TRUE = 1`, `FALSE = 0`
- `__MAX_PATH__ = 1024` (line/path buffer), `__MAX_MESSAGE__ = 2048` (log message buffer)
- `X_AXIS = 0`, `Y_AXIS = 1`, `Z_AXIS = 2`
- ANSI color codes: `LOG_RST`, `LOG_BLACK/RED/GREEN/YELLOW/BLUE/MAGENTA/CYAN/WHITE` and `LOG_BOLD*` variants (`\033[...m`).

**Function-like macros**
- `TOSTRING` → `std::to_string`
- `ZeroMemory(x)` → `memset(x,0,sizeof(x))` (only valid for arrays, not pointers)
- `ZeroMemoryE(x,y)` → `memset(x,0,y)`
- `__FILENAME__` → basename of `__FILE__` (strips path)
- `DBG_LOG_TRACE/ERROR/WARN/INFO/NOTHING(fmt, ...)` → `OutputString(__FILENAME__, __LINE__, eLog*, fmt, ...)`

**Typedefs**

| Alias | Underlying |
|---|---|
| `PVOID` | `void*` |
| `STD_THREAD`, `PSTD_THREAD` | `std::thread`, `std::thread*` |
| `GLOBAL_CALLBACK_FN` | `std::function<void(PVOID,PVOID,PVOID,PVOID)>` |
| `TSTRING` | `std::string` |
| `TCHAR` | `char` |
| `UINT8/16/64`, `UINT`/`UINT32` | `uint8/16/64_t`, `uint32_t` |
| `INT8/16/64`, `INT`/`INT32` | `int8/16/64_t`, `int32_t` |
| `BOOL` | `bool` |
| `BYTE` | `unsigned char` |
| `BYTEARRAY` | `std::vector<BYTE>` |
| `eLOG_TYPE` (enum) | `eLogTrace=0, eLogWarning=1, eLogError=2, eLogInfo=3, eLogNothing=4` |

**Logging / assert internals (all `inline`/`static inline`, header-only)**
- `OutputDebugString(const char* s, BOOL abIsError=FALSE)` — `fprintf` to `stdout` (info) or `stderr` (error) with `\n`.
- `OutputString(file, line, eLOG_TYPE, fmt, ...)` — `vsnprintf` into 2048 buf, wraps in color + `<timestamp>[LEVEL] msg [file:line]`; ERROR routes to stderr. Catches `CThrowAssert<>` and `...`.
- `AssertOutputString(file, line, BOOL abUseExtend, BOOL abSave, BOOL abShowTime, fmt, ...)` — assert-style formatter, always to stderr. `abSave`/`abShowTime` params are accepted but **unused** (no file saving implemented).
- `AssertReport(const char*)` — **empty stub** (TODO at top of file: "AssertReport to save Logfile").
- `template<class A=int> class CThrowAssert` — holds `m_pFileName`,`m_nLine`; `Report()` prints assert location. Used only as an exception type in the log catch blocks.

**Time functions**
- `char* GetOSTime()` — wall-clock string `YYYY-MM-DD_HH:MM:SS.mmm` via **deprecated `ftime()`** + `localtime_r`. **Leaks: `malloc(200)` returned, never freed by callers** (called once per log line). A `clock_gettime(CLOCK_REALTIME)` alternative is present but commented out.
- `UINT64 GetCurrTimeInNs()` — **`clock_gettime(CLOCK_MONOTONIC)`**, returns `tv_sec*1e9 + tv_nsec`. On failure returns `-1` (i.e. `0xFFFFFFFFFFFFFFFF` as UINT64). **This is the RT-relevant monotonic timestamp** used for loop timing/jitter measurement elsewhere.

**Angle / unit conversions** (`inline double`)
- `ConvertRad2Deg(rad)` = `rad*180/π`
- `ConvertDeg2Rad(deg)` = `deg*π/180`
- `ConvertRpm2Rad(rpm)` = `rpm*π/30`

**Terminal / error helpers**
- `int getch()` — raw single char (`~(ICANON|ECHO)`, restores termios).
- `int getche()` — raw with echo (`~ICANON` only).
- `int GetLastError()` → `(int)errno`.
- `TSTRING TranslateError(int)` → `strerror`.

**Endian / byte-array conversions** (all **big-endian**, `inline`)
- `static INT64 CalcTwosComplement(INT64)` → `~(-v)+1`.
- `ConvertS64/S32/S16/S8ToByteArrayBE(...)` and `ConvertU64/U32/U16/U8ToByteArrayBE(...)` → `BYTEARRAY` MSB-first; signed variants clamp to type range and apply two's-complement for negatives.
- `ConvertU8ToByte(UINT8)`, `ConvertS8ToByte(INT8)` → single `BYTE` (clamped).
- `ConvertByteArrayToUintBE(BYTEARRAY)` → `UINT` (MSB-first accumulate; caps at 32-bit).
- `ConvertByteArrayToIntBE(BYTEARRAY)` → signed `INT` from BE bytes (uses `pow` for range → floating-point, size-dependent).
- `ExtendByteArray(BYTEARRAY& origin, BYTEARRAY extend)` → appends `extend` to `origin`.

**Comm / metadata structs** — all wrapped in `#pragma pack(push,1)`/`pop`. **Field-by-field:**

| Struct (typedef) | Fields (type name) | Packed size / note |
|---|---|---|
| `_ST_AXIS_CMD` → `ST_AXIS_CMD` | `int nAxisNo`, `int nCmd`, `double dValue` | 16 B, POD-safe to serialize. `VEC_AXIS_CMD = std::vector<ST_AXIS_CMD>` |
| `_ST_AXIS_STATE` → `ST_AXIS_STATE` | `BYTE btDriveMode`, `BYTE btStatus`, `double dCurPos`, `double dCurVel`, `double dCurAcc`, `double dCurTor` | 34 B packed, POD-safe |
| `stRobotMetadata` → `ST_ROBOT_METADATA` | `BOOL bIsSim`, `BOOL bWithEcat`, `TSTRING strName`, `INT32 nAxisNo` | **Contains `std::string` — NOT POD; `pack(1)` here is meaningless / must NOT be memcpy'd or wire-serialized** |
| `stEcatStates` → `ST_ECAT_STATES` | `UINT8 btMaster`, `UINT8 btSlave`, `UINT8 btDomain` (ctor zeroes all) | 3 B. Holds coarse EtherCAT master/slave/domain state codes (values not enumerated here) |
| `stEcatMetadata` → `ST_ECAT_METADATA` | `ST_ECAT_STATES stEcatStates`, `UINT16 usSlaveNo` (ctor sets `usSlaveNo=0`) | Comment: "This includes EtherCAT state machine" — but INIT/PREOP/SAFEOP/OP are only implied UINT8s; no enum/logic here |
| `stAxisMetadata` → `ST_AXIS_METADATA` | `TSTRING strName`, `UINT8 btAxisType`, `UINT8 btCommType`, `INT32 nPosLimitU`, `nPosLimitL`, `nVelLimitU`, `nVelLimitL`, `nAccLimitU`, `nAccLimitL` | **Contains `std::string` — NOT POD-serializable** |

Integration note: `ST_ECAT_STATES`/`ST_ECAT_METADATA` are the hooks a future EtherCAT integration would populate from the IgH master state (`ec_master_state_t`, `ec_slave_config_state_t`) and domain state — but the mapping is not implemented in this layer.

##### 8.3 `CRC16` / `CRC16_ARC` — configurable table-driven CRC-16

Table-driven CRC-16. `REFLECT_BIT_ORDER_TABLE[256]` (static const in header) is a precomputed bit-reversal LUT used for input reflection.

| Member | Signature | Semantics |
|---|---|---|
| ctor | `CRC16(uint16_t apolynomial, uint16_t init_value=0, bool areflect_input=true, bool areflect_output=true, uint16_t axor_output=0)` | Stores config, builds `lut_crc[256]` (MSB-first, `create_lookup_table`). |
| calc | `uint16_t calculate(const char* string)` | CRC of null-terminated string (length via `strlen`). Wrapped in try/catch → returns 0 on exception. |
| calc | `uint16_t calculate(const uint8_t* data_in, const int length)` | CRC of raw buffer. |
| calc | `uint16_t calculate(std::vector<uint8_t> data)` | Core: per byte optionally reflect via `REFLECT_BIT_ORDER_TABLE`, `crc=(crc<<8)^lut_crc[(crc>>8)^byte]`, optional output reflect, `^xor_output`. |
| priv | `uint16_t reflect(uint16_t)`, `void create_lookup_table()`, `inline void display_table()` | Helpers (`display_table` dumps LUT to stdout). |

`class CRC16_ARC : public CRC16` — CRC-16/ARC preset: **polynomial `0x8005`, init `0x0000`, reflect_input `true`, reflect_output `true`, xor_output `0x0000`**.

**Caveat (bug):** The ctor parameter is named `init_value`, identical to the member `init_value`, and the ctor body **never assigns the member** (assigns `polynomial`, `reflect_input`, `reflect_output`, `xor_output` only). The member `init_value` has no in-class initializer → **`init_value` is used uninitialized in `calculate()`**. For `CRC16_ARC` the intended init is `0x0000`, so results are only correct if the uninitialized member happens to be 0 (not guaranteed). A future integration relying on CRC16 should fix the ctor to set `this->init_value = init_value;`.

##### 8.4 Socket layer — `CSocket`, `CTcpClient`, `CTcpServer`

BSD-socket (AF_INET) TCP (and UDP-capable base) wrapper. Callback-driven via `GLOBAL_CALLBACK_FN` (4× `void*`). Errors in `CSocket` are signalled by **throwing `std::runtime_error`** (caught by `CTcpServer::Start`).

**Constants / types**
- `MAX_RECV_BUFF_LEN = 8192` (constexpr), `SOCK_BUFF_LEN = 4096` (recv/send buffers actually used).
- `SOCKADDR_IN = struct sockaddr_in`, `SOCK_IPADDR = char*`.
- `enum SOCKET_TYPE { eTCP=0, eUDP }`.
- `SOCKET_INFO`/`stSocketInfo`: `SOCKET_TYPE eSocketType`, `char pcIpAddr[NI_MAXHOST]`, `int nPort`, `BOOL bIsNonBlocking`; **ctor default port `7421`**, `eTCP`, non-blocking `FALSE`.
- `SOCKCLIENT_INFO`/`stSocketClientInfo`: `int nClientFd`, `SOCKADDR_IN stClientAdd`, `socklen_t nClientSockLen`, `BOOL bIsInitialized`, `char pcIpAddr[NI_MAXHOST]`, `int nPort`.
- `struct stSendData { char* buffer; UINT32 length; }` (buffer NULL/len 0 in ctor). **Note: identical struct also defined in `Serial.h` — ODR collision risk if both headers land in one TU.**

**`CSocket` (base)**

| Method | Semantics |
|---|---|
| `BOOL InitSocket(SOCKET_TYPE)` | `socket(AF_INET, SOCK_STREAM/SOCK_DGRAM, 0)`, sets `SO_REUSEADDR`. Throws on fail. |
| `BOOL BindAddress(SOCK_IPADDR, int port)` | `INADDR_ANY` if IP NULL else `inet_addr`; `htons(port)`; `bind()`. Logs resolved host/port. Throws if not init or bind fails. |
| `BOOL SetNonBlocking()` | `fcntl(fd, F_SETFL, O_NONBLOCK)`. Throws on fail. |
| `BOOL ListenToClients(int backlog)` | `listen()`. Throws on fail. |
| `SOCKCLIENT_INFO AcceptClient()` | **Blocking** `accept()`; fills client IP (`inet_ntop`) + port. Throws on fail. |
| `void Close()` | `close(fd)`; fires close callback. |
| getters | `GetFileDesc/GetIpAddr/GetPort/GetSocketType/IsNonBlocking/IsSocketInit/IsConnected`. |
| callbacks | `RegisterCallbackOpen/Accept/Receive/Send/Close`. |

**`CTcpClient`** — one per accepted connection; spawns two `std::thread`s.

| Method | Semantics |
|---|---|
| `CTcpClient(SOCKCLIENT_INFO)` | Stores client info, connected=FALSE. |
| `void StartListening()` | Sets connected, starts `proc_thread_recv` + `proc_thread_send`, fires connect callback. |
| `int Send(const void*, UINT32)` | **Async**: `new char[len]` copy → pushes `stSendData` to `m_queue_send`; returns 0 immediately. |
| `void Close()` | Joins/deletes recv+send threads, fires close callback, `close(fd)`. |
| `proc_thread_send()` | Pops queue, `send()` loop; on error fires send callback + breaks. |
| `proc_thread_recv()` | `recv()` into `SOCK_BUFF_LEN` buffer; if `<1` byte → receive callback + `SetConnected(FALSE)` (marks dead). |
| accessors | `SetConnected/IsConnected/GetIPAddress/GetPortNo`; `RegisterCallbackConnect/Receive/Send/Close`. |

**`CTcpServer`** — multi-client TCP server: accept thread + dead-client reaper thread.

| Method | Semantics |
|---|---|
| `BOOL Start(int port, int backlog=1, BOOL nonBlocking=FALSE)` | Init/Bind(ANY)/Listen[/SetNonBlocking]; on throw → `Stop()`+return FALSE. Spawns `proc_thread_accept` + `proc_thread_dead_client_remover`. |
| `BOOL Stop()` | Terminates reaper + accept threads, `Close()` all clients, clears vector, closes listen socket. |
| `BOOL IsConnected()` | TRUE iff `m_vTcpClient` non-empty. |
| `int SendToClients(const void*, UINT32)` | **Broadcast**: iterates clients, calls each `client->Send()`. Returns 0. |
| `proc_thread_accept()` | Loop: blocking `AcceptClient()` → `new CTcpClient` → binds `OnClient*` handlers as its callbacks → `StartListening()` → `push_back`. |
| `proc_thread_dead_client_remover()` | Every **1 s**: `find_if(!IsConnected)` → `Close()`+`delete`+`erase`. |
| `OnClientConnect/Receive/Send/Close` | Protected virtuals forwarding to registered server callbacks. **`OnClientClose` forwards to `m_pCallbackClientDisconnect`.** |
| callbacks | `RegisterCallbackStart/Accept/Receive/Send/Stop/ClientDisconnect`. |

`m_vTcpClient` is `reserve(10)`'d.

**Socket-layer caveats:**
- **No mutex on `m_vTcpClient`.** Accept thread `push_back`, reaper thread `erase`, and `SendToClients` iteration run concurrently → **data race / iterator invalidation** under real load. Must add locking before RT/production use.
- **Memory leak:** `CTcpClient::Send` (and the queued `stSendData.buffer` from `new char[len]`) is **never `delete[]`d** in `proc_thread_send`. Long-running send traffic leaks.
- `proc_thread_send` loop `nIndex += nBytesToSend; nBytesToSend -= nBytesToSend;` assumes a single full `send()` (partial-send handling is effectively broken; the inner loop always terminates after one iteration).
- `Send`/socket ops are **not RT-safe** (heap alloc, `std::queue`, 1 ms polling sleep in send thread). Do **not** call from an RT/EtherCAT cyclic task; use only from non-RT/config/telemetry paths.
- `Socket.cpp` uses `#include <Socket.h>` (angle brackets) → build must add `-IGlobal/Comm` to the include path.

##### 8.5 `CSerialComm` — termios serial-port wrapper

RS-232/USB-serial wrapper with async send/recv threads. File header comment erroneously says "Socket.cpp". Handle stored type-erased in `PVOID m_pSerialHandler` (a heap `new int()` holding the fd).

**Constants / enums**
- `MAX_RECV_BUFF_LEN = 4095` (constexpr) — **conflicts with `Socket.h`'s `MAX_RECV_BUFF_LEN = 8192`; never include both headers in one TU.**
- `SERIAL_PORT_MAX = 15`.
- `enum eRS232_FLOW { NONE=0, DTRDSR=1, RTSCTS=2, XONXOFF=4 }`
- `enum eRS232_DATASIZE { BIT7=7, BIT8=8 }`
- `enum eRS232_BAUDRATE { 1200,2400,4800,9600,14400,19200,38400,56000,57600,115200 }` (values are the numeric baud)
- `enum eRS232_STOPBIT { ONESTOPBIT=0, ONE5STOPBITS=1, TWOSTOPBITS=2 }`
- `enum eRS232_PARITY { NOPARITY=0, ODDPARITY=1, EVENPARITY=2, MARKPARITY=3, SPACEPARITY=4 }`
- `enum eRS232_ASCII_DEF { BEL=0x07, BS=0x08, LF=0x0A, CR=0x0D, XON=0x11, XOFF=0x13, STX=0x02, ETX=0xFE }`
- `struct TTYSTRUCT` (`__attribute__((packed))`, alias `LPTTYSTRUCT`): `TSTRING strComPort`, `UINT8 btXonXoff`, `UINT8 btByteSize`, `UINT8 btFlowCtrl`, `UINT8 btParity`, `UINT8 btStopBits`, `UINT32 uBaudRate`, `UINT32 uReadTimeout`, `UINT32 uWriteTimeout`. (Contains `std::string` → not truly POD despite `packed`.)
- `struct stSendData { char* buffer; UINT32 length; }` (duplicate of Socket's).

**API**

| Method | Semantics |
|---|---|
| `CSerialComm()` | Defaults: port `ttyACM0`, flow NONE, BIT8, ONESTOPBIT, NOPARITY, baud 9600, read/write timeout 1000 (ms, unused). |
| `BOOL Init(TSTRING astrPort, INT anBaudRate=9600)` | Opens `"/dev/"+astrPort` with `O_RDWR|O_NOCTTY`; configures termios; starts threads; fires connect callback. Returns FALSE on open/thread failure. |
| `BOOL DeInit()` | Sets disconnected, `usleep(100)`, `close(fd)`, deletes handle. |
| `BOOL IsConnected()` | Returns `m_bConnected`. |
| `BOOL Send(const PVOID, const UINT32)` | **Async**: `new char[len]` copy → push to `m_qSend`; returns TRUE. |
| `void SetParams(LPTTYSTRUCT)` | **STUB — empty body.** Serial params cannot be changed via this API; only `Init`'s baud arg + ctor defaults take effect. |
| `proc_thread_recv()` | `read(fd, buf, 4095)`; on `<0` → recv callback + disconnect. `VMIN=1` (blocks until ≥1 byte). |
| `proc_thread_send()` | Pops queue, `write()`, 1 ms sleep per chunk; same single-write assumption bug as socket. |
| callbacks | `RegisterCallbackConnect/Disconnect/Send/Recv`. |

**termios configuration applied in `Init` (raw mode):**
- `c_iflag = IGNPAR` (ignore parity errors); `c_oflag = 0`; `c_lflag = 0` (non-canonical, no echo).
- `c_cflag = CLOCAL | CREAD` + baud (`B9600/B19200/B38400/B57600/B115200`, **default `B115200`**) + data bits (`CS7`/`CS8`, default `CS8`) + parity (`PARODD`/`PARENB`; **switch default is EVEN=PARENB**, but ctor sets member to NOPARITY so no parity in practice) + stop bits (`CSTOPB` for 2).
- `c_cc[VTIME]=0`, `c_cc[VMIN]=1`; `tcflush(TCIFLUSH)`; `tcsetattr(TCSANOW)`.

**Serial caveats:**
- **Bug:** RTS/CTS flow control does `stTermios.c_iflag |= CRTSCTS` — `CRTSCTS` belongs in **`c_cflag`**, so hardware flow control is effectively not enabled. Moot anyway since default flow is NONE and `SetParams` is a stub.
- Same **send-buffer memory leak** and **single-`write` partial-send bug** as the socket layer.
- Not RT-safe (heap alloc + `std::queue` + 1 ms polling). Keep off the EtherCAT cyclic path.

##### 8.6 Integration summary for a future EtherCAT + PREEMPT_RT session
- Reusable and RT-friendly from this layer: `GetCurrTimeInNs()` (`CLOCK_MONOTONIC`, ns) for cycle timing/jitter; the endian `Convert*ByteArray*` helpers for building PDO byte payloads; `CRC16`/`CRC16_ARC` for serial-protocol framing (after fixing the `init_value` ctor bug).
- **Not RT-safe / keep in non-RT threads:** all of `CSocket`/`CTcpClient`/`CTcpServer`/`CSerialComm` (heap allocation, `std::queue`, `std::thread`, 1 ms polling sleeps), and all logging macros (`DBG_LOG_*` → `GetOSTime()` `malloc` + `fprintf`).
- The EtherCAT integration point in this layer is data-only: fill `ST_ECAT_STATES`/`ST_ECAT_METADATA` from the IgH master/slave/domain state; there is **no `ecrt.h` usage, no PDO/SDO indices, no DC-sync, no INIT/PREOP/SAFEOP/OP logic** here — those live elsewhere in the framework, not in `Global/`.

---
#### 9. ROS2 integration layer (`Global/Comm/ROS2*`)

The `Global/Comm/ROS2*` files are a thin C++ wrapper library that bridges the RT control code (which uses raw types from `Global/Defines.h` and the rtposix RT loop) to ROS2/DDS. Each ROS2 entity (publisher / subscriber / service server / service client) is wrapped in a class that **inherits `rclcpp::Node`**, and a `CROS2Executor` owns a set of these nodes and spins each one in its **own dedicated non-RT `std::thread`**. The RT control loop and the ROS2 side exchange data through **plain shared members of the owning `CRobotIndy7` object with no mutex/lock** (see §9.7 caveats).

Two applications consume this layer: **`App/Indy7_ROS2`** (real EtherCAT hardware, built against **ROS 2 Jazzy**) and **`App/Indy7_ROS2_Mujoco`** (MuJoCo simulation, built against **ROS 2 Humble**). Both instantiate the identical node set through `CRobotIndy7::InitROS2Interface()`.

Important scope fact: of the eight source files in this task, **only three are compiled** into the Indy7 apps — `ROS2Node.cpp`, `ROS2Executor.cpp`, `ROS2IndyIface.cpp` (see each app's `Makefile` `SOURCES`). `ROS2AxisInfo.cpp`, `ROS2Imu.cpp`, `ROS2PointCloud.cpp`, and `ROS2PrismIface.cpp` are **dormant/legacy** code (from an earlier "SuperMicroSurgery / PRISM" robot and a perception pipeline) — not built by either Indy7 app, and `ROS2Imu.h` does not even exist in the repo (only `ROS2Imu.cpp`, which `#include "ROS2Imu.h"`). Treat those four files as reference-only; they will not link as-is.

##### 9.1 File inventory

| File | LOC | Compiled by Indy7 apps? | Role |
|------|-----|--------------------------|------|
| `Global/Comm/ROS2Common.h` | 200 | yes (header) | Common includes, `HISTORY_DEPTH`, `eNodeType` enum, all `typedef`s for pub/sub/srv/cli shared-ptrs, `vectorToArray`/`arrayToVector` helpers |
| `Global/Comm/ROS2Node.h` | 113 | yes | Base `CROS2Node : public rclcpp::Node` + `std_msgs/String` pub/sub wrappers |
| `Global/Comm/ROS2Node.cpp` | 108 | yes | Impl of base node + String pub/sub |
| `Global/Comm/ROS2Executor.h` | 72 | yes | `CROS2Executor` declaration (owns nodes + spin threads) |
| `Global/Comm/ROS2Executor.cpp` | 138 | yes | `rclcpp::init/shutdown`, per-node spin-thread creation/join |
| `Global/Comm/ROS2IndyIface.h` | 280 | yes | Indy7 robot interface: state publisher, 6 service servers, 6 service clients, `IndyRobotState`/`IndyControlGains` structs |
| `Global/Comm/ROS2IndyIface.cpp` | 467 | yes | Impl of Indy state pub + all gain/pos/control-mode services & clients |
| `Global/Comm/ROS2AxisInfo.h` | 151 | **no** (legacy) | `sensor_msgs/JointState` + `axis_info` cmd/state pub/sub, zstd-compressed state |
| `Global/Comm/ROS2AxisInfo.cpp` | 274 | **no** | Impl; ZSTD compression of serialized `axis_info/AxisState` into `std_msgs/ByteMultiArray` |
| `Global/Comm/ROS2PrismIface.h` | 105 | **no** (legacy) | `prism_iface` Usr2Ctrl sub, JointInfo/UserInfo pub (SuperMicroSurgery robot) |
| `Global/Comm/ROS2PrismIface.cpp` | 79 | **no** | Impl of prism_iface wrappers |
| `Global/Comm/ROS2Imu.cpp` | 88 | **no** (header missing) | `sensor_msgs/Imu` pub/sub |
| `Global/Comm/ROS2PointCloud.h` | 57 | **no** (legacy) | `sensor_msgs/PointCloud2` pub/sub |
| `Global/Comm/ROS2PointCloud.cpp` | 88 | **no** | Impl (raw publish; lz4/zstd headers included but unused) |

##### 9.2 Base node & String wrappers (`ROS2Node.*`)

`CROS2Node : public rclcpp::Node` is the base of every wrapper.

- Constructor `CROS2Node(TSTRING nodeName, TSTRING topicName, INT histDepth)` forwards `nodeName` to `rclcpp::Node(nodeName)`; stores topic name and history depth.
- Getters: `GetTopicName()`, `GetNodeName()`, `GetHistDepth()`, `IsPublisher()`, `IsPeriodic()`, `GetNodeType() -> eNodeType`.
- `std::shared_ptr<rclcpp::Node> GetSharedPtr()` returns `shared_from_this()` — **this is what `CROS2Executor` uses to add the node to an executor**, so every wrapper MUST be owned by a `std::shared_ptr` (the apps use `std::make_shared<...>`).
- `virtual void SetPeriod(INT64 periodInMs)` sets `m_nPeriod` and marks the node periodic; String/JointInfo/Imu/PointCloud publishers override it to create a `rclcpp::WallTimer` (`create_wall_timer`) whose callback republishes the last cached message. `HISTORY_DEPTH` = **1** (`ROS2Common.h`).
- Protected `m_eNodeType` (an `eNodeType`) tags each node's kind.

`CROS2StrPub` / `CROS2StrSub` wrap `std_msgs::msg::String` on `topicName`. `SetMessage(TSTRING, BOOL force=FALSE)` publishes immediately if not periodic (or `force`). Subscriber uses the generic callback typedef `GLOBAL_CALLBACK_FN = std::function<void(PVOID,PVOID,PVOID,PVOID)>` (from `Defines.h`); on receipt it invokes `m_pCallbackSub(&msg->data, NULL, NULL, NULL)`. These String wrappers are generic scaffolding and are **not** used by the Indy7 control path.

##### 9.3 Executor & threading model (`ROS2Executor.*`)

`CROS2Executor` is the glue that starts ROS2.

- Default ctor calls `rclcpp::init(0, NULL)` if `!rclcpp::ok()`, then allocates a `rclcpp::executors::StaticSingleThreadedExecutor* m_pExecutor`. **`m_pExecutor` is allocated but never actually used to spin** (see below).
- `CROS2Executor(int domain_id)` builds `rclcpp::InitOptions` with `set_domain_id(domain_id)` **but then calls `rclcpp::init(0, NULL)` WITHOUT passing the options** — so the domain id is effectively **ignored** (bug/caveat). The apps use the default ctor, i.e. default `ROS_DOMAIN_ID`.
- `BOOL AddNode(CROS2Node*)` — de-dups and appends to `m_vecROS2Nodes`.
- `BOOL Init()` — for every registered node calls `CreateSpinThread(node)` and stores the returned `std::shared_ptr<std::thread>`. Fails if node list is empty or already initialized.
- `CreateSpinThread(CROS2Node*, BOOL abMulti=TRUE)` — **creates one `std::thread` per node**; inside the thread it does `node_ptr = apNode->GetSharedPtr()` (= `shared_from_this()`), then constructs a **local `rclcpp::executors::SingleThreadedExecutor`**, `add_node(node_ptr)`, `spin()`. So the effective model is **one OS thread + one SingleThreadedExecutor per node** — NOT the StaticSingleThreadedExecutor member, and the `abMulti` argument is unused.
- `BOOL DeInit()` — calls `rclcpp::shutdown()` first (so every `spin()` returns), clears the node list, then `join()`s each spin thread.
- `Stop()` is a no-op stub returning TRUE. Destructor deletes `m_pExecutor` and calls `rclcpp::shutdown()` if still ok.

**RT ↔ non-RT data exchange:** there is no lock-free ring buffer or mutex. The spin threads run the ROS2 callbacks (service handlers) at non-RT priority; the RT control task (`proc_main_control`, an rtposix task) both reads state and calls `PublishRobotState()` **inline from the RT loop**. Service callbacks mutate the same `CRobotIndy7`/`CControllerFullDynamicsRT` objects the RT loop reads — unsynchronized (see §9.7).

##### 9.4 Indy7 robot interface (`ROS2IndyIface.*`) — the only robot bridge actually used

Data structures (`ROS2IndyIface.h`):

- `struct IndyRobotState { std::vector<double> positions, velocities, torques; std::vector<uint8_t> faults; uint64_t timestamp; }` — all vectors default-sized to **6** (hardcoded 6-DOF for Indy7), timestamp in ns.
- `struct IndyControlGains { std::vector<double> kp, kd; }` — both size 6.

Message/service type aliases map onto the **external `indy_iface` package**: msg `JointInfo`; srvs `GetGains`, `SetGains`, `SetPos`, `SetAllPos`, `SetControlMode`, `GetControlMode`.

Node classes (all `: public CROS2Node`):

- **`CROS2IndyStatePub`** — publisher of `indy_iface::msg::JointInfo` on topic `indy_state`, QoS depth = `GetHistDepth()` = 1 (default reliable, KeepLast(1)). `PublishState(const IndyRobotState&)` copies the state into the message via `vectorToArray(...)` into fixed `std::array` fields **`is_fault`, `actual_pos`, `actual_vel`, `actual_tor`** and publishes. `SetMessage(INDY_IFACE_STATE)` publishes a pre-built message.
- **Service servers** (each owns a `rclcpp::Service<...>` and a `std::function` callback set via `SetCallback`):
  - `CROS2GetGainsSrv` (`get_gains`) → callback `IndyControlGains()`; fills `response->kp`, `response->kd` (arrays), `response->success`.
  - `CROS2SetGainsSrv` (`set_gains`) → callback `bool(const IndyControlGains&)`; **validates `request->kp.size()==6 && request->kd.size()==6`** else fail.
  - `CROS2SetPosSrv` (`set_pos`) → callback `bool(uint32_t, double)`; **validates `request->joint_index < 6`**. Fields `joint_index` (uint32), `position` (double).
  - `CROS2SetAllPosSrv` (`set_all_pos`) → callback `bool(const std::vector<double>&)`; **validates `request->positions.size()==6`**.
  - `CROS2SetControlModeSrv` (`set_control_mode`) → callback `bool(uint8_t)`; **validates `request->control_mode <= 3`** (0=GravComp,1=FullDyn,2=CTC,3=Adaptive). Field `control_mode` (uint8), `response->success`.
  - `CROS2GetControlModeSrv` (`get_control_mode`) → callback `uint8_t()`; sets `response->control_mode` (uint8) and `response->success`.
  - All handlers wrap the callback in try/catch and set `response->success=false` on any exception or missing callback.
- **Service clients** (mirror servers; each `wait_for_service(1s)` then `async_send_request` with a **5 s** `future.wait_for` timeout):
  - `CROS2GetGainsCli::CallGetGains(IndyControlGains&) -> bool`
  - `CROS2SetGainsCli::CallSetGains(const IndyControlGains&) -> bool`
  - `CROS2SetPosCli::CallSetPos(uint32_t, double) -> bool`
  - `CROS2SetAllPosCli::CallSetAllPos(const std::vector<double>&) -> bool`
  - `CROS2SetControlModeCli::CallSetControlMode(uint8_t) -> bool`
  - `CROS2GetControlModeCli::CallGetControlMode(uint8_t&) -> bool`

`eNodeType` values assigned: `eINDY_STATE_PUB, eGET_GAINS_SRV, eSET_GAINS_SRV, eSET_POS_SRV, eSET_ALL_POS_SRV, eGET_GAINS_CLI, eSET_POS_CLI, eSET_ALL_POS_CLI, eSET_CONTROL_MODE_SRV, eGET_CONTROL_MODE_SRV, eSET_CONTROL_MODE_CLI, eGET_CONTROL_MODE_CLI` (full enum in `ROS2Common.h`).

##### 9.5 How the app wires it up (`App/Indy7_ROS2/Indy7Ctrl.cpp`, identical in Mujoco)

`CRobotIndy7::InitROS2Interface()` (called from `CRobotIndy7::Init()`):
1. `m_pROS2Executor = new CROS2Executor();`
2. Creates nodes with fixed **(nodeName, topic/serviceName)** pairs:
   - `CROS2IndyStatePub("indy_state_pub", "indy_state")`
   - `CROS2GetGainsSrv("get_gains_srv", "get_gains")`
   - `CROS2SetGainsSrv("set_gains_srv", "set_gains")`
   - `CROS2SetPosSrv("set_pos_srv", "set_pos")`
   - `CROS2SetAllPosSrv("set_all_pos_srv", "set_all_pos")`
   - `CROS2SetControlModeSrv("set_control_mode_srv", "set_control_mode")`
   - `CROS2GetControlModeSrv("get_control_mode_srv", "get_control_mode")`
3. Binds each service callback to a `CRobotIndy7` method via a `[this]` lambda:
   - `get_gains` → `GetCurrentControlGains()`
   - `set_gains` → `SetControlGains(gains)` (requires kp.size()==kd.size()==6)
   - `set_pos` → `SetJointPosition(idx, position)` — **input is in DEGREES**, converted `ConvertDeg2Rad`, forwarded to `m_pController->SetReferencePos`.
   - `set_all_pos` → `SetAllJointPositions(positions)` — 6 values, DEGREES→rad.
   - `set_control_mode` → `SetControlMode(uint8)` which maps 0..3 to `CControllerFullDynamicsRT::{eGravityCompensation,eFullDynamics,eComputedTorque,eAdaptiveControl}` and first re-seeds reference positions from `m_pEcatAxis[i]->GetCurrentPos()`.
   - `get_control_mode` → `GetControlMode()` (reverse mapping).
4. `AddNode(...)` for all 7 nodes, then `m_pROS2Executor->Init()` (spawns 7 spin threads).

**State publishing:** the RT loop `proc_main_control` calls `pRobot->PublishRobotState()` every cycle. `GetCurrentRobotState()` fills the message from the pre-allocated RT vectors `m_vCurrentPos/Vel/Tor` (updated each cycle from `CAxisNRMKCore::GetCurrentPos/Vel/Tor`). **Positions are converted rad→deg (`ConvertRad2Deg`) before publishing.** `timestamp = read_timer()` (rtposix). Per-joint `faults`: `1` normal, `2` if `axis state < eAxisInit`, `0` if axis pointer null. `Update()` on the controller produces `m_vOutputTorque`, applied via `CAxisNRMKCore::MoveTorque` (CST). Notably `GetGains` uses the controller DOF but `SetControlGains`/`SetControllerGains` require the vector size to equal `GetTotalAxis()`.

##### 9.6 Topic / message / service table (as instantiated by the Indy7 apps)

| Name | ROS2 kind | Type | Direction (board perspective) | QoS | Fields used |
|------|-----------|------|-------------------------------|-----|-------------|
| `indy_state` | topic (pub) | `indy_iface/msg/JointInfo` | board → host (publish state) | KeepLast(1), default reliable (depth=`HISTORY_DEPTH`=1) | `is_fault[6]` u8, `actual_pos[6]` f64 (deg), `actual_vel[6]` f64, `actual_tor[6]` f64 |
| `get_gains` | service (server) | `indy_iface/srv/GetGains` | host → board | default services QoS | resp: `kp[6]`,`kd[6]` f64, `success` bool |
| `set_gains` | service (server) | `indy_iface/srv/SetGains` | host → board | default | req: `kp[6]`,`kd[6]` f64 (size-6 required); resp: `success` |
| `set_pos` | service (server) | `indy_iface/srv/SetPos` | host → board | default | req: `joint_index` u32 (<6), `position` f64 (DEG); resp: `success` |
| `set_all_pos` | service (server) | `indy_iface/srv/SetAllPos` | host → board | default | req: `positions[6]` f64 (DEG); resp: `success` |
| `set_control_mode` | service (server) | `indy_iface/srv/SetControlMode` | host → board | default | req: `control_mode` u8 (0..3); resp: `success` |
| `get_control_mode` | service (server) | `indy_iface/srv/GetControlMode` | host → board | default | resp: `control_mode` u8, `success` bool |

Client variants (`CROS2*Cli`) exist in code but are **not instantiated by the Indy7 apps** (they are for a host/UI-side process; the Python UI in `App/Indy7_ROS2/scripts/` plays the client role over these same service/topic names).

##### 9.7 Legacy/dormant wrappers (reference only — not built by Indy7 apps)

- **`ROS2AxisInfo.*`**: `CROS2JointInfoPub/Sub` on `sensor_msgs/msg/JointState` (QoS `KeepLast(1).best_effort()`); `CROS2AxisInfoCmdPub` publishes `axis_info/msg/AxisCmd`, `CROS2AxisInfoCmdSub` subscribes to `std_msgs/msg/ByteMultiArray`; `CROS2AxisInfoStatePub` **serializes `axis_info/msg/AxisState` then ZSTD-compresses (`ZSTD_compress`, level 5) into a `std_msgs/msg/ByteMultiArray`** before publishing (requires `-lzstd`, `<zstd.h>`, `<zlib.h>`); `CROS2AxisInfoStateSub` subscribes to raw `axis_info/msg/AxisState`. Depends on an external `axis_info` package (no headers on disk).
- **`ROS2PrismIface.*`**: `CROS2Usr2CtrlSub` (`prism_iface/msg/Usr2Ctrl`, sub), `CROS2JointInfoPub` (`prism_iface/msg/JointInfo`, pub), `CROS2UserInfoPub` (`prism_iface/msg/UserInfo`, pub) — for the SuperMicroSurgery/PRISM robot. External `prism_iface` package. NOTE: header/impl banners mislabel the file as "ConfigParser.h/.cpp".
- **`ROS2Imu.cpp`**: `CROS2ImuPub/Sub` on `sensor_msgs/msg/Imu` (QoS `QoS(1).best_effort()`). **`ROS2Imu.h` is absent from the repo**, so this file cannot compile as-is.
- **`ROS2PointCloud.*`**: `CROS2PointCloudPub/Sub` on `sensor_msgs/msg/PointCloud2` (QoS `QoS(1).best_effort().durability_volatile()`). Includes `<lz4.h>`/`<zstd.h>` but publishes uncompressed; the publish path has a leftover `printf` and an unused `compressed_msg`.

`ROS2Common.h` and `ROS2Common.h`'s `eNodeType` enum still declare types/enums for all of the above (`ePOINTCLOUD_*`, `eIMU_*`, `eAXISINFO_*`, `eJOINTINFO_*`, `eUSR2CTRL_*`, `eUSERINFO_*`), but the corresponding `typedef`s/`#include`s for `sensor_msgs`, `axis_info` are commented out in `ROS2Common.h` — meaning `ROS2AxisInfo.*`/`ROS2Imu.*`/`ROS2PointCloud.*` will not compile against `ROS2Common.h` alone without re-enabling those includes.

##### 9.8 Build / dependency facts (from `App/Indy7_ROS2/Makefile` and `App/Indy7_ROS2_Mujoco/Makefile`)

- **ROS 2 distro is different per app**: `Indy7_ROS2` → `/opt/ros/jazzy`; `Indy7_ROS2_Mujoco` → `/opt/ros/humble`. Include flags are auto-generated via `find $(ROS_INCLUDE) -maxdepth 1 -type d`.
- **External `indy_iface` package** (custom msgs/srvs) at hardcoded **`/home/raimlab/ros_ws/install/indy_iface`** (include + lib). Linked libs include `-lindy_iface__rosidl_generator_c` and all `rosidl_typesupport_{c,cpp,fastrtps_c,fastrtps_cpp,introspection_*}` variants, plus `rclcpp, rcl, rcutils, rmw, rosidl_runtime_c, std_msgs__*, builtin_interfaces__*, tracetools, statistics_msgs__*, libstatistics_collector`. **Fast-RTPS/Fast-DDS is the DDS backend** (fastrtps typesupport linked).
- Other hardcoded roots: rtposix `/opt/rt_posix` (`-lrtposix`, provides `read_timer`, `wait_next_period`, `mlockall`-style RT loop), IgH EtherLab `/opt/etherlab` (include only here), EtherCAT master lib `/opt/emaster_app` (`-lEMasterApp`), Eigen `/usr/include/eigen3`, RBDL (`-lrbdl -lrbdl_urdfreader`). Mujoco app additionally hardcodes `/home/raimlab/dev_env/mujoco-2.3.7` (`-lmujoco -lglfw -lGL -ldl`).
- Compiled ROS2 sources per app: **`ROS2Node.cpp`, `ROS2Executor.cpp`, `ROS2IndyIface.cpp` only**.
- `main.cpp` calls `mlockall(MCL_CURRENT|MCL_FUTURE)` and installs SIGTERM/SIGINT handlers that call `g_cRobot->DeInit()` (which triggers `DeInitROS2Interface()` → `rclcpp::shutdown()` + thread joins).

##### 9.9 Integration guidance & caveats for the EtherCAT + PREEMPT_RT target

- **No RT/non-RT synchronization.** The RT loop reads `m_vCurrentPos/Vel/Tor`, `m_pController`, `m_pEcatAxis[]`; ROS2 service spin threads write the same objects (gains, reference positions, control mode) with **no mutex/atomic**. On the KV260 this is a real data race; a future integrator should add a lock-free command queue or double-buffer between the spin threads and the RT task. `PublishRobotState()` currently publishes **inline from the RT thread** (DDS send inside the RT cycle) — consider moving to a non-RT publisher thread fed by a lock-free buffer to protect the RT deadline.
- **6-DOF is hardcoded** throughout `IndyRobotState`/`IndyControlGains` (size 6) and every service validation (`==6`, `<6`, `<=3`). Non-6-DOF robots need edits.
- **Units mismatch to watch:** `indy_state.actual_pos` is published in **degrees**; `set_pos`/`set_all_pos` inputs are **degrees** (converted to rad internally). `actual_vel`/`actual_tor` are passed through unconverted (raw controller units).
- **`CROS2Executor(int domain_id)` does not apply the domain id** (calls `rclcpp::init(0,NULL)` ignoring the built `InitOptions`). To isolate DDS domains, fix this or set `ROS_DOMAIN_ID` in the environment.
- **Threading cost:** one OS thread per node (7 threads for the Indy7 set), each with its own `SingleThreadedExecutor`; the `StaticSingleThreadedExecutor` member `m_pExecutor` is dead code. Pin/priority these threads below the RT control task on the KV260.
- **Distro drift:** hardware app targets Jazzy, sim app targets Humble — the wrapper compiles against both, but a single deployment must pick one ABI; `indy_iface` must be rebuilt for that distro.
- **Missing/half-wired files:** `ROS2Imu.h` is absent; `ROS2Common.h` has the `sensor_msgs`/`axis_info` typedefs commented out. Re-enabling IMU/PointCloud/AxisInfo/Prism requires restoring those includes/typedefs and adding `-lzstd`/`-llz4` and the `axis_info`/`prism_iface` packages.
- The `ROS2PrismIface.h/.cpp` file banners incorrectly say "ConfigParser" — cosmetic, but do not confuse with the real `Global/ConfigParser.*`.

---
#### 10. Application — `App/Indy7` (bare-metal EtherCAT torque controller)

Flagship real-time torque-control application for a 6-DOF Neuromeka Indy7 driven over EtherCAT (CiA-402 CST / opmode 10) with an RBDL full-dynamics controller at 1 kHz. Entry point spins up `CRobotIndy7` (subclass of `CRobot`) which registers **6 RT/non-RT tasks** and an `CControllerFullDynamicsRT` (subclass of `CController`). All computation is torque-based; positions/velocities are read from the **NRMK CORE-class drives (`CAxisNRMKCore`, vendor `0x0000089a`)** — not EPOS4/ELMO — and torques written back every 1 ms.

##### 10.0 File inventory (path · LOC · role)

| File | LOC | Role |
|---|---|---|
| `App/Indy7/main.cpp` | 102 | Process entry; loads cfg, `mlockall`, builds `CRobotIndy7`, installs SIGINT/SIGTERM handlers, idle-polls `CheckStopTask()`. |
| `App/Indy7/Indy7Ctrl.h` | 159 | `CRobotIndy7` class decl; `ST_DATALOG` struct; keyboard/ISO/rectangle/visual-servo state; declares 6 `friend proc_*` task fns. |
| `App/Indy7/Indy7Ctrl.cpp` | 1359 | `CRobotIndy7` impl + all 6 task functions + keyboard command dispatch + ISO/rectangle state machines + CSV writers. |
| `App/Indy7/Controller.h` | 159 | `CController` abstract base (enums, stats, saturation, validation). |
| `App/Indy7/Controller.cpp` | 165 | `CController` impl (limits, saturate, validate, stats, clamp, debug log). |
| `App/Indy7/FullDynControllerRT.h` | 251 | `CControllerFullDynamicsRT` decl; `eControlMode`, `Pose`, `RTPerformance`, RBDL member vectors, IK/Jacobian buffers, constants. |
| `App/Indy7/FullDynControllerRT.cpp` | 1464 | Control-law impl: grav-comp, full-dyn, CTC, Jacobian-IK/DLS, RBDL-6DOF-IK, quintic trajectory, RT memory/CPU opt, deadline monitor, ISO validation. |
| `App/Indy7/DataRecorder.h` | 47 | `ST_LOG_ENTRY` log record + lock-free SPSC `RingBuffer<T,N>`; `LogRingBuffer = RingBuffer<ST_LOG_ENTRY,65536>`. |
| `App/Indy7/VisualServo.h` | 50 | `VisualServo` class (PIMPL) for AprilTag visual servoing; `State` enum. |
| `App/Indy7/VisualServo.cpp` | 234 | ViSP + librealsense2 impl: RealSense color stream, TAG_36h11 detect, EMA-filtered goal pose, double-buffered output. |
| `App/Indy7/CalibCapture.h` | 26 | `CalibCapture` — saves TCP poses as `pose_rPe_<N>.yaml` for hand-eye calibration. |
| `App/Indy7/CalibCapture.cpp` | 44 | Impl: `Pose`→`vpHomogeneousMatrix`→`vpPoseVector`→YAML. |
| `App/Indy7/INDY7.cfg` | 328 | Runtime config: SYSTEM, RT_TASKS (6), ECAT_MASTER, AXIS0–5 (motors), AXIS6 (EOAT sensor). |
| `App/Indy7/Makefile` | 119 | Build to `bin/Indy7Ctrl.out`. |

##### 10.1 `main.cpp` startup sequence
1. Parse `-f <file>` (getopt); default config path is `DEFAULT_CONFIGURATION_FULLPATH` = **`"ELMO.cfg"`** (from `CRobot/ConfigRobot.h:14`), **NOT** `INDY7.cfg` — must pass `-f INDY7.cfg`.
2. `IsExistFile()` check → `g_cConfigRobot->ReadConfiguration(myFile)`; `bSimMode = GetSystemConf().bSim` (cfg `SIMULATION_MODE`).
3. `g_cRobot = new CRobotIndy7(g_cConfigRobot)`.
4. `signal(SIGTERM/SIGINT, signal_handler)`; handler calls `g_cRobot->DeInit()`.
5. `mlockall(MCL_CURRENT | MCL_FUTURE)` — lock all pages (RT).
6. `g_cRobot->Init(bSimMode)` → on fail returns `RET_FAIL`.
7. Main thread busy-idle: `while(!CheckStopTask()){ cpu_relax(); usleep(1000); }`.
Globals: `CConfigRobot* g_cConfigRobot`, `CRobotIndy7* g_cRobot`, `CExtInterface* g_cExtInterface` (last never instantiated here).

##### 10.2 `CRobotIndy7 : public CRobot`

Constructor registers task functions **in this exact order** (index = TASKn in cfg):

| idx | `AddTaskFunction` | cfg section | PRIORITY | TASK_PERIOD (ns) | What it does |
|---|---|---|---|---|---|
| 0 | `proc_main_control` | `[TASK0]` Main Control | 97 | 1000000 (1 ms) | Reads joint state, calls `pRTController->Update(...)`, writes `MoveTorque` per axis; runs keyboard `DoInput()`, VS goal injection, TCP logging push, ISO-HW & rectangle state machines, LED per mode. |
| 1 | `proc_ethercat_control` | `[TASK1]` EtherCAT | 95 | 1000000 (1 ms) | `ReadSlaves()` → `UpdateExtInterfaceData()` → sets `m_bEcatOP` if all-slaves-OP && master-OP → `WriteSlaves(tmSend)`; on stop, ServoOff all axes (≤1000 cleanup cycles). |
| 2 | `proc_keyboard_control` | `[TASK2]` Keyboard | 50 | 0 (free-run) | Blocking `getche()`; `'q'`→`StopTasks()`; `'z'`→`RunISOCubeIKValidation()`; ignores arrow-key escape seqs; else stores `m_cKeyPress`. |
| 3 | `proc_terminal_output` | `[TASK3]` Terminal | 49 | 1000000000 (1 s) | Mostly commented-out debug prints; `wait_next_period` loop. |
| 4 | `proc_logger` | `[TASK4]` Logger | 30 | 0 (free-run) | Waits on `m_bLogTrigger`; flushes buffer, `sleep(24)` collecting 24 s, then drains `m_logBuffer` to timestamped CSV. |
| 5 | `proc_visual_servo` | `[TASK5]` Visual Servo | 20 | 0 (free-run) | **Self-demotes to `SCHED_OTHER`** (non-RT) at entry; when `m_bVSTrigger`, calls `m_visualServo.Loop()` (blocking camera I/O). |

Tasks are created generically by `CRobot::InitRTTasks()` (`CRobot/Robot.cpp:118`): `create_rt_task(&t, name, 2*1024*1024 /*2 MB stack*/, priority)`; if `nPeriod!=0` → `set_task_period(&t, SET_TM_NOW-or-read_timer()+delay, nPeriod)`; then `start_task(&t, fn, this)` for enabled tasks. START_DELAY = 0 for all.

**`CRobotIndy7` public API**

| Signature | Semantics |
|---|---|
| `CRobotIndy7(CConfigRobot* =NULL)` | If cfg NULL → new+`LoadDefaultConfig`; else `ReadConfiguration()`. Sets `m_strName` from `SYSTEM.NAME`. Registers 6 task fns. |
| `virtual BOOL Init(BOOL abSim)` | `InitController(URDF_PATH)` → `m_visualServo.Init()` (warn-only on fail) → `CRobot::Init(abSim)`. **Note bug:** `m_strName = GetSystemConf().strURDFPath` overwrites robot name with URDF path. |
| `virtual BOOL DeInit()` | `CRobot::DeInit()` then `delete[]` axis/sensor arrays. |
| `BOOL InitController(const TSTRING& URDFPath)` | Builds `CControllerFullDynamicsRT(URDF, dof)`; `EnableRTMode(TRUE)`; `SetDeadline(500000)` (500 µs); sets mode from cfg `DEFAULT_CONTROLLER_MODE`; `Init()`; loads Kp/Kd (dof==6 from cfg; else hard-coded scaled defaults); pre-allocs 4 state vectors; auto-enables if `ENABLE_CONTROLLER_AT_STARTUP`. |
| `BOOL EnableController(BOOL)` / `BOOL SetControllerMode(eControlMode)` / `BOOL SetControllerGains(vKp,vKd)` | Thin wrappers over controller; gain setter validates `size()==GetTotalAxis()`. |
| `CControllerFullDynamicsRT* GetController()` | Accessor. |
| `BOOL IsMoving()` | True if any `m_pEcatAxis[i]->IsMoving()`. |
| `void WriteDataLog()` | Legacy: writes `DataLog_Axis{0..7}.csv` from `m_stDataLog[32]` lists (largely unused). |
| `enum eISOHWState{eISO_HW_IDLE,_TO_TARGET,_TO_CLEARANCE,_DONE}` / `enum eRectState{eRECT_IDLE,_TO_CORNER}` | ISO-cube-test / rectangle-motion FSM states. |

**Protected/private (integration-relevant):** `InitEtherCAT()`, `InitConfig()` (returns TRUE, stub), `DoAgingTest()` (empty stub), `DoInput()` (keyboard dispatch), `DoHoming(){}` (empty). Members: `CAxisNRMKCore** m_pEcatAxis`, `CSensorNRMKEndTool** m_pEcatSensor`, `BOOL m_bEcatOP`, `UINT32 m_nEcatCycle`, control vectors `m_vCurrentPos/Vel/Tor`, `m_vOutputTorque`, `LogRingBuffer m_logBuffer`, `VisualServo m_visualServo`, ISO `m_isoHWRecords[5][10][3]`, `m_isoTargets[5]`, rectangle `m_rectCorners[4]` + `m_rectJointTargets[4]`. Global `extern CalibCapture s_calibCapture;` (defined `Indy7Ctrl.cpp:14` with dir `/home/raimlab/RAON-RT/App/CalibUtils`).

**`InitEtherCAT()` specifics:** allocates `CAxisNRMKCore*[nTotalSlaves]` and `CSensorNRMKEndTool*[nTotalSlaves]`; per slave: `SLAVE_TYPE==0`→ axis (revolute default), sets enc-res/gear/trans ratio/torque-const/current-ratio; `SetVendorInfo(uVendorID,uProductCode)`; `SetDCInfo(bDCSupported, usDCActivateWord, nDCSyncShift)`; vel/acc/dec/jerk/torque/pos limits; homing method; `Init(*m_pcEcatMaster,(INT8)nDriveMode)`; `AddAxis`. `SLAVE_TYPE==1`→ sensor created **in reverse order** (`nPos = nTotalSlaves-1-nCnt`), `CSensorNRMKEndTool`. Finally `m_pcEcatMaster->Init(CYCLE_TIME, DC_ENABLED)`. **PDO entry indices/subindices, SDOs and the actual CiA-402 state machine (INIT/PREOP/SAFEOP/OP) are NOT in this app** — they live in `CRobot/AxisNRMKCore`, `CRobot/AxisCIA402`, `EMasterApp`. This app only supplies vendor/product IDs and DC parameters from cfg.

**Keyboard command map (`DoInput()`):**

| Key | Action |
|---|---|
| `y/u/o` | EOAT sensor LED green / red / off. |
| `e` / `x` | `EmgStopAxis()` all / `StopAxis()` all. |
| `t` | `ChangeDriveMode(CIA402_CYCLIC_TORQUE)` all (→ CST). |
| `r` | Toggle controller enable. |
| `g` / `f` / `c` | Set mode GravComp / FullDynamics / ComputedTorque. |
| `l` | `m_bLogTrigger=TRUE` (start 24 s TCP logging). |
| `i` | Mode `eInverseKinematics` (Jacobian IK), `m_bIkTrigger=TRUE`. |
| `m` | `SetTargetPose(m_Pose)` (RBDL 6-DOF IK) → mode `eInverseKinematics_6dof` + log; needs `s` first. |
| `n` | Toggle rectangle motion: grav-comp, capture center, build 4 corners at ±0.25 m in Y/Z, pre-solve position-only IK for each, start 2.0 s quintic to corner 0. |
| `q` (in `DoInput`) | Build ISO cube (center = TCP+2 cm X, `a=0.100`), start ISO-HW test FSM. **Note:** `'q'` is also intercepted in `proc_keyboard_control` as global stop — so ISO-HW `q` path is effectively shadowed by StopTasks. |
| `d` | `LogDistanceError(m_Pose)`. |
| `s` | `GetCurrentPose(m_Pose)` → `SaveRobotPose()` (CSV) + `s_calibCapture.Capture()` + print. |
| `v` | Toggle visual servoing: `m_visualServo.Start()` + mode `eInverseKinematics`; off→grav-comp. |
| `a` | Hard-coded target pose (pos `[-0.1806,-0.1808,0.9307]`, rpy `[0.0872,-0.0860,1.5670]`) → `SetTargetPose` → 6-DOF IK. |
| `z` (in keyboard task) | `RunISOCubeIKValidation()` (software-only, non-RT). |

`proc_main_control` VS-injection singularity guard: joint vel > **0.45 rad/s** → `NotifySingularity()` + grav-comp. Rectangle FSM: 2000 counts (2.0 s @1 ms) per corner, logging trigger at count 1230. ISO-HW: 5 points × 10 cycles, records TCP each settle (`m_bVerifyDone`), computes AP/RP per ISO 9283 → CSV.

##### 10.3 `CController` (abstract base)

Enums: `eControllerType` (15 values incl. `eControllerGravityComp`, `eControllerFullDynamics`, `eControllerComputedTorque`); `eControllerStatus` (Idle/Running/Error/Stopped/Initializing). Ctor defaults: `m_dSampleTime=0.001`, gains=1.0, output limits ±1000 Nm.

| Method | Notes |
|---|---|
| `pure virtual BOOL Init()` | Derived must implement. |
| `pure virtual BOOL Update(pos,vel,tor,&outTorque)` | Core control step. |
| `pure virtual BOOL Reset()` / `void SetGains(vGains)` | — |
| `void Enable(BOOL)` / `BOOL IsEnabled()` | Runtime enable flag. |
| `void SetOutputLimits(lo,hi)` / `GetOutputLimits` / `void SaturateOutput(&out)` | Per-DOF clamp; only active if limits set & size matches. |
| `BOOL ValidateInputs(...)` | Size + NaN/Inf check (protected). |
| `double Clamp(v,min,max)` | Protected helper. |
| `struct ControllerStats{ulUpdateCount,ulErrorCount,dLast/Avg/Max/MinUpdateTime}` | Running-avg timing. |
| `SetSampleTime/GetSampleTime`, `SetDebugMode`, `GetType/GetDOF/GetStatus`, `GetLastError/ClearError` | Accessors. |

Note: `CControllerFullDynamicsRT` does **not** call base `SaturateOutput()` — there is **no torque saturation in the RT torque path**; safety is only via velocity/accel reference clamps (see 10.4).

##### 10.4 `CControllerFullDynamicsRT : public CController` — the RT control core

Constructed as `CController(eControllerFullDynamics, dof)`. Pre-allocates all RBDL `VectorNd`/`MatrixNd` in ctor (RT-safe, no runtime alloc). `#define _ALL_AXIS 0xFFFFFFFF`.

**`enum eControlMode`:** `eGravityCompensation=0, eFullDynamics, eComputedTorque, eAdaptiveControl, eInverseKinematics ('i' Jacobian), eInverseKinematics_6dof ('m' RBDL IK + CTC playback)`.

`CTRL_MODE_*` cfg mapping (in `Indy7Ctrl.cpp`): `0=GRAV_COMP → eGravityCompensation`, `1=FULL_DYN → eFullDynamics`, `2=CTC → eComputedTorque`, `3=ADAPTIVE` (unmapped → defaults to grav-comp).

**`Update()` dispatch** (per 1 ms): copies `m_Q/m_Qd` from input, calls `SetTcpReferencePose()`, switches on mode, then RT perf accounting + `CheckRTViolation`. `eInverseKinematics_6dof` case = `UpdateTrajectory()` then `ComputeComputedTorque()`. Returns FALSE (zero torque) if not initialized/enabled.

**Exact torque laws (RBDL calls in `RigidBodyDynamics::`):**

- **Gravity compensation** (`ComputeGravityCompensation`): `τ = g(q)` via `InverseDynamics(model, Q, 0⃗, 0⃗, g)` → `out[i]=g[i]`.
- **Full dynamics** (`ComputeFullDynamics`): 
  - `M = CompositeRigidBodyAlgorithm(model, Q)`; `h = NonlinearEffects(model, Q, Qd)`; `g = InverseDynamics(model, Q, 0⃗, 0⃗)`; `c = h − g`.
  - `e_pos = Q_ref − Q`, `e_vel = Qd_ref − Qd`; feedforward `τ_M = M·Qdd_ref`; feedback `τ_fb[i] = Kp[i]·e_pos[i] + Kd[i]·e_vel[i]`.
  - **`τ = M·Qdd_ref + h + (Kp·e_pos + Kd·e_vel)`**.
- **Computed torque** (`ComputeComputedTorque`): 
  - `M = CompositeRigidBodyAlgorithm(...)`; `h = NonlinearEffects(...)`.
  - `Qdd_des[i] = Qdd_ref[i] + Kp[i]·e_pos[i] + Kd[i]·e_vel[i]`.
  - **`τ = M·Qdd_des + h`**.
- **Jacobian IK / DLS** (`ComputeJacobianBasedInverseKinematics`, mode `eInverseKinematics`):
  - On `m_bIkTrigger`: snapshot start pose, `goal.m_rotation = current.m_rotation` (hold orientation), goal position pre-set elsewhere.
  - `J(6×dof) = CalcPointJacobian6D(model, Q, body_id, tcp_local_point)` (order `[angular(0..2); linear(3..5)]`).
  - `e_task[3..5] = (goal.pos − tcp.pos)·m_Kp_task_pos`; `e_task[0..2] = m_Kp_task_rot·0.5·vee(R_err)`, `R_err = R_goal·R_curᵀ`.
  - DLS: `λ = 0.0005 if pos_err<0.01 else m_lambda(0.01)`; `JJᵀ += λ²I`; `J⁺ = Jᵀ(JJᵀ)⁻¹`.
  - `Qd_ref = J⁺·e_task`, clamp **MAX_JOINT_VEL = 0.5 rad/s**; `Q_ref = Q + Qd_ref·dt`; lead clamp **MAX_REF_LEAD = 0.10 rad**; `Qdd_ref=0`; then `ComputeComputedTorque()` + `CheckIKConvergence()`.
- **Visual-servo Jacobian** (`SetTargetPose_Jacobian`, called from `proc_main_control` when tracking):
  - Same 6D J; rotation error only engaged when `pos_err_raw < 0.08` (z-axis alignment `e_rot = curZ × goalZ`, roll ignored).
  - **Angular clamp MAX_ROT_VEL = 0.30 rad/s**.
  - **Adaptive damping** via manipulability `w = √det(JJᵀ)`: `λ = lambda_high(0.05) if w<w_threshold(0.01); lambda_low(0.0005) if pos_err<0.01; else m_lambda(0.01)`.
  - **Accel clamp MAX_JOINT_ACC = 2.0 rad/s²** (`max_delta_vel = 2.0·dt`); **MAX_JOINT_VEL = 0.6 rad/s**; `Q_ref = Q + Qd_ref·dt`; **MAX_REF_LEAD = 0.10 rad**; `Qdd_ref=0`. Callers then switch mode to `eComputedTorque` for actual tracking.
- **6-DOF RBDL IK** (mode `eInverseKinematics_6dof`): IK solved at trigger time in `SetTargetPose()` (non-RT keyboard thread), then quintic playback via `UpdateTrajectory`+`ComputeComputedTorque`. The legacy `ComputeInverseKinematics_6dof()` exists but **is NOT reached from `Update()`** (dead code — annotated "Lagacy function").

**Task-space gains / constants** (`FullDynControllerRT.h`): `m_Kp_task_pos = 1.0`, `m_Kp_task_rot = 0.2`, `static constexpr m_dt = 0.001`, `static constexpr m_lambda = 0.01`. `tcp_local_point = {0,0,0}` (a commented alt is `{0,0,0.07}`).

**RBDL IK constraint set** (`SetTargetPose`, `SetTargetPosePositionOnly`, `RunISOCubeIKValidation`, legacy 6DOF): `InverseKinematicsConstraintSet CS; CS.num_steps=1000; CS.step_tol=1e-10; CS.constraint_tol=1e-8;` then `AddFullConstraint(body_id, tcp_local_point, pos, rot.transpose())` (full) or `AddPointConstraint(body_id, tcp_local_point, pos)` (position-only) → `InverseKinematics(model, Q_seed, CS, q_sol)`.

**FK** (`ComputeTcpFK`, `GetCurrentPose`): position = `CalcBodyToBaseCoordinates(model, Q, body_id, tcp_local_point)`; orientation = `CalcBodyWorldOrientation(model, Q, body_id).transpose()`. `body_id = model.GetBodyId("tcp")` (URDF link must be named **`tcp`**).

**Quintic trajectory** (`UpdateTrajectory`, `TrajState{q_start,q_goal,T,t_elapsed,active}`, default `m_traj_duration=3.0` s):
- `s = t/T` (clamped ≤1); `p = 10s³ − 15s⁴ + 6s⁵`; `pd = (30s² − 60s³ + 30s⁴)/T`; `pdd = (60s − 180s² + 120s³)/T²`.
- `Q_ref = q_start + Δq·p`, `Qd_ref = Δq·pd`, `Qdd_ref = Δq·pdd`; `t_elapsed += dt`.
- Settling after `T`: `Q_ref=q_goal, Qd/Qdd_ref=0`, lead-clamped to **MAX_REF_LEAD = 0.15 rad**; deactivates when all joints settled.
`StartJointTrajectory(q_goal, T)` seeds from current `m_Q`.

**IK convergence** (`CheckIKConvergence`): motion "started" when a joint vel > 0.02 rad/s; then requires `IsJointSettled(0.01)` for **5000 consecutive cycles (5 s)** → `ComputeTcpFK`, record final pose, `PrintTcpVerificationResult()` (also appends to `rt_ik_error_log/ik_accuracy_log.csv`), set `m_bVerifyDone`. `IsJointStopped()` threshold 0.04 rad/s (used only in commented alt path).

**RPY convention** — `RPYToRot(r,p,y)` = ZYX (`Rz·Ry·Rx`); `RotToRPY` inverse. `pitch=atan2(−R20,√(R21²+R22²))`, `roll=atan2(R21,R22)`, `yaw=atan2(R10,R00)`.

**RT optimizations:**
- `InitRTMemoryOptimizations()`: prefaults every RBDL vector/matrix element; runs one dummy `CompositeRigidBodyAlgorithm`+`InverseDynamics`+`NonlinearEffects` to fault in RBDL internals. (Relies on `main`'s `mlockall`.)
- `InitRTProcessorOptimizations()`: `Eigen::internal::set_is_malloc_allowed(false)` (guarded by `EIGEN_RUNTIME_NO_MALLOC` && Eigen≥3.4); `_MM_SET_FLUSH_ZERO_MODE(ON)` + `_MM_SET_DENORMALS_ZERO_MODE(ON)` (guarded `__SSE__` — **x86-only; no effect on ARM/KV260**). Uses `<xmmintrin.h>`,`<pmmintrin.h>`.
- Destructor: `munlockall()` if RT-optimized.

**Deadline monitoring:** `RTPerformance{max/avg/total_compute_time_ns, cycle_count, rt_violations, deadline_ns}`. Ctor sets `deadline_ns=500000` (500 µs); `SetDeadline(500000)` re-affirms. `Update()` measures `read_timer()` delta; `CheckRTViolation()` increments `rt_violations` when compute > deadline, logs every 100th violation. `SetGravity` sets `model.gravity = (0,0,−9.81)`.

**Key public method table**

| Signature | Semantics |
|---|---|
| `CControllerFullDynamicsRT(TSTRING urdf, uint dof)` | Pre-allocates all RBDL buffers; default `m_Kp=100, m_Kd=10`. |
| `BOOL Init()` | `LoadURDF` (`URDFReadFromFile(path,&model,false,true)`), set gravity, verify `model.qdot_size==dof`, RT opts, `body_id=GetBodyId("tcp")`, default safe goal pos `(−0.01193,−0.18843,1.32671)`. |
| `BOOL Update(pos,vel,tor,&out)` | Mode dispatch + perf/deadline accounting. |
| `void SetControlMode(eControlMode)` / `eControlMode GetControlMode()` | Mode set/get (no lock — plain enum). |
| `void SetControlGains(vKp,vKd)` / `SetControlGain(axis,Kp,Kd)` / `GetControlGain(axis,*Kp,*Kd)` | `_ALL_AXIS` broadcasts. |
| `void SetReferenceTrajectory(Q_ref,Qd_ref,Qdd_ref)` / `SetReferencePos(axis,pos)` | Direct reference injection. |
| `BOOL StartJointTrajectory(q_goal,T)` / `SetTrajectoryDuration(T)` / `IsTrajectoryDone()` / `GetTrajGoal()` | Quintic control. |
| `BOOL SetTargetPose(Pose)` / `SetTargetPosePositionOnly(Pose)` | RBDL IK → seed quintic trajectory. |
| `BOOL SetTargetPose_Jacobian()` | Per-cycle VS Jacobian tracking (fills `Qd_ref/Q_ref`). |
| `BOOL GetCurrentPose(Pose&)` / `ComputeTcpFK()` / `const Pose& GetTcpPose()` | FK access. |
| `BOOL LogDistanceError(Pose)` / `RunISOCubeIKValidation()` | Diagnostics/CSV (non-RT). |
| `static Matrix3d RPYToRot(r,p,y)` | ZYX RPY → R. |
| `RTPerformance GetPerformance()` / `ResetPerformance()` / `SetDeadline(ns)` | Perf/deadline. |
| public flags | `std::atomic<bool> m_bIkTrigger, m_bSetRefPoseTrigger`; `Pose goal_tcpPose, tcpPose`; `BOOL m_bIkReady/m_bVerifyDone/m_bIkMotionStarted`. |

**`struct Pose`:** `Vector3d m_position`, `Vector3d m_rotation_rpy`, `Matrix3d m_rotation` (ctor: position/rpy zero, rotation identity).

##### 10.5 `DataRecorder.h` — lock-free logging

`struct ST_LOG_ENTRY`: `uint64_t timestamp_ns; double q[6]; double q_ref[6]; double qd[6]; double tau[6]; double tcp_x,tcp_y,tcp_z; double tcp_roll,tcp_pitch,tcp_yaw; double goal_x,goal_y,goal_z; double goal_roll,goal_pitch,goal_yaw; uint8_t ctrl_mode;` (RPY = ZYX, rad; positions m).

`template<typename T,size_t N> class RingBuffer`: SPSC lock-free, `atomic<size_t> head,tail`. `push()` (RT producer): drops when full (`next==tail`), no blocking, `memory_order_relaxed`/`acquire`/`release`. `pop()` (logger consumer): FALSE when empty. `using LogRingBuffer = RingBuffer<ST_LOG_ENTRY, 65536>` (N=65536 ≈ 65 s @1 kHz; comment claims 10 min but that is inaccurate). Logger writes 37-column CSV (`timestamp_ns,q0..5,q_ref0..5,qd0..5,tau0..5,tcp_x/y/z,tcp_roll/pitch/yaw,goal_x/y/z,goal_roll/pitch/yaw,ctrl_mode`).

##### 10.6 `VisualServo` (AprilTag pipeline, PIMPL)

`using Pose = CControllerFullDynamicsRT::Pose;` `enum class State{IDLE,TRACKING,TAG_LOST,SINGULARITY}`. Ctor default calib dir `"/home/raimlab/RAON-RT/App/CalibUtils"`. `struct Impl{vpCameraParameters cam; vpHomogeneousMatrix rMc;}` (ViSP/RealSense types hidden from header).

| Method | Semantics |
|---|---|
| `bool Init()` | Load `<dir>/camera.xml` (`vpXmlParserCamera`, view `"RealSense_color"`, `perspectiveProjWithDistortion`); load `<dir>/rPc.yaml` (`vpPoseVector`→`rMc`); query RealSense device (no stream open). Sets `m_initialized`. |
| `void Start()/Stop()` | Set `m_running`/`m_state`; clear valid/lostCount. |
| `void Loop()` | **Opens the RealSense pipeline here** (non-RT thread): `cfg.enable_stream(RS2_STREAM_COLOR,640,480,RS2_FORMAT_RGBA8,30)`, `pipe.start(cfg)`. Detector: `vpDetectorAprilTag(TAG_36h11)`, `setAprilTagQuadDecimate(1.0)`, `HOMOGRAPHY_VIRTUAL_VS`, `NbThreads(1)`, `tagSize=0.09` m. Loop: `try_wait_for_frames(&frames,200ms)`; RGBA→gray (`0.299R+0.587G+0.114B`); `detector.detect`; `goal = rMc · cMo · s_Toffset`; EMA filter **α=0.15**; publish to double buffer (`m_buf[2]`, `m_latest`, `m_valid`). |
| `bool GetGoalPose(Pose&)` | Returns latest buffer unless SINGULARITY or invalid. |
| `void NotifySingularity()` | TRACKING/TAG_LOST → SINGULARITY. |
| `State GetState()/IsRunning()` | Accessors. `int lostFrameThreshold=10` (public; TAG_LOST actually set immediately on first empty frame). |

`s_Toffset` = `vpTranslationVector(-0.15,0,0)` × `vpRotationMatrix(vpRxyzVector(π/2,0,-π/2))` (tag→TCP offset, 15 cm along robot +x). `toRBDLPose()` copies `vpHomogeneousMatrix`→`Pose`.

##### 10.7 `CalibCapture`

`explicit CalibCapture(outDir="calib_data")` — `mkdir(outDir,0777)`, `m_count=1`. `Capture(const Pose&)`: `Pose→vpHomogeneousMatrix (ToMatrix)→vpPoseVector→saveYAML("<outDir>/pose_rPe_<count>.yaml")`, increments count. `Reset()` sets count=0. `GetCount()`. Used by `s`-key to accumulate robot poses for hand-eye calibration (paired with `robot_poses.csv` from `SaveRobotPose`).

##### 10.8 `INDY7.cfg` — full key reference

**`[SYSTEM]`**: `NAME=INDY7`; `SIMULATION_MODE=0`; `EXTERNAL_INTERFACE_ENABLED=1`; `EXTERNAL_INTERFACE_PORT=7420`; `TELEOPERATION_MODE=2`; `TELEOPERATION_CONSTANT_SCALING=0.3`; `URDF_PATH=/home/raimlab/RAON-RT/App/Indy7/indy7.urdf`; `ENABLE_CONTROLLER_AT_STARTUP=1`; `DEFAULT_CONTROLLER_MODE=0` (grav-comp); `ROBOT_DOF=6`; per-joint gains `KP_0..KP_5 = 800/600/400/200/150/100`, `KD_0..KD_5 = 80/60/40/20/15/10`.

**`[RT_TASKS]`**: `NO_OF_TASKS=6`. Per `[TASKn]`: `ENABLED`, `NAME`, `PRIORITY` (0–99), `TASK_PERIOD` (ns; 0 = free-run), `START_DELAY` (ns). Values: TASK0 Main prio97/1 ms; TASK1 EtherCAT prio95/1 ms; TASK2 Keyboard prio50/0; TASK3 Terminal prio49/1 s; TASK4 Logger prio30/0; TASK5 Visual Servo prio20/0 (all START_DELAY=0, ENABLED=1).

**`[ECAT_MASTER]`**: `SLAVENUMBER=7`; `DC_ENABLED=1`; `CYCLE_TIME=1000000` (1 ms).

**`[AXIS0]`–`[AXIS5]` (motors, `SLAVE_TYPE=0`)** keys: `ENABLED, CONNECTED, NAME, PHYSICAL_POS, VENDOR_ID=0x0000089a, PRODUCT_CODE=0x30000000, SLAVE_TYPE, AUTO_SERVO_ON, ABSOLUTE_ENCODER, MOVE_CCW, JOINT_TYPE(0=revolute), DRIVE_MODE=10 (CiA-402 CST), ENCODER_RESOLUTION=65536, GEAR_RATIO, TRANSMISSION_RATIO, TORQUE_CONSTANT, CURRENT_RATIO, ONE_TURN_REF=360.0, HOMING_METHOD, HOME_POSITION_OFFSET, HOME_SEARCH_REFERENCE, OPERATING_VELOCITY/ACCELERATION/DECELERATION, POSITION_LIMIT_U/L(±35.0), VELOCITY_LIMIT_U/L, ACCELERATION_LIMIT_U/L, DECELERATION_LIMIT_U/L, TORQUE_LIMIT_U/L, JERK_LIMIT_U/L, POS_BEFORE_EXIT`.

Per-axis distinctive values:

| AXIS | GEAR_RATIO | TORQUE_CONSTANT | CURRENT_RATIO | MOVE_CCW | HOMING_METHOD | VEL_LIMIT_U | TORQUE_LIMIT_U | HOME_POSITION_OFFSET | POS_BEFORE_EXIT |
|---|---|---|---|---|---|---|---|---|---|
| 0 | 121 | 0.0884 | 48.0 | 0 | 3 | 150 | 117.73 | 15755196 | -204427 |
| 1 | 121 | 0.0884 | 48.0 | 0 | 3 | 150 | 117.73 | 28218 | 41252 |
| 2 | 121 | 0.087 | 96.0 | 1 | 3 | 150 | 47.5 | 15841818 | 15840317 |
| 3 | 101 | 0.058 | 96.0 | 0 | 3 | 178 | 21.0 | -20393022 | -13730912 |
| 4 | 101 | 0.058 | 96.0 | 0 | 1 | 178 | 21.0 | 33130756 | 33120174 |
| 5 | 101 | 0.058 | 96.0 | 1 | 1 | 178 | 21.0 | -6573591 | -6619243 |

(All: OPERATING_ACC/DEC=10000, ACC/DEC_LIMIT_U=10000, JERK_LIMIT=0, POS_LIMIT ±35.0, VEL_LIMIT_L=0. OPERATING_VELOCITY: axes0/1=130, axis2=125, axes3–5=155.)

**`[AXIS6]` (EOAT sensor, `SLAVE_TYPE=1`)**: `ENABLED=1, CONNECTED=1, NAME=EOAT, PHYSICAL_POS=6, VENDOR_ID=0x0000089a, PRODUCT_CODE=0x10000007, SLAVE_TYPE=1` → maps to `CSensorNRMKEndTool` (LED/end-tool). Vendor ID `0x089a` = Neuromeka; motors product `0x30000000`, end-tool product `0x10000007`.

##### 10.9 `Makefile` — build spec

- **Compiler:** `g++`, output `bin/Indy7Ctrl.out`, objects in `obj/`.
- **Flags:** `CFLAGS_OPTIONS = -w -O2 -std=gnu++17 -Dlinux -mtune=native -std=c++17 -shared-libgcc -fexceptions` (commented stricter variant uses `-O3 -flto -DNDEBUG`). `-mtune=native` and `-w` (warnings suppressed).
- **Include paths:** `Global`, `CRobot`, `/opt/emaster_app/include`, `Global/Comm`, `/opt/rt_posix/include`, `/opt/etherlab/include`, `/usr/include/eigen3`, `EMasterApp/Device`; ViSP `/home/raimlab/visp/build/include` + `/home/raimlab/visp/modules/{detection,sensor,core,io}/include`; `/usr/include/opencv4`; `/usr/include/pcl-1.14`.
- **Linked libs (`LDFLAGS`):** `-lm -lrt -lpthread`; `-L/opt/emaster_app/lib -lEMasterApp`; `-L/opt/rt_posix/lib -lrtposix`; `-lrbdl -lrbdl_urdfreader`; `-L/home/raimlab/visp/build/lib -lvisp_core -lvisp_io -lvisp_detection -lvisp_sensor`; `-L/usr/local/lib/x86_64-linux-gnu -lrealsense2`.
- **Compiled sources (13):** `Global/ConfigParser.cpp`, `Global/Comm/CRC16.cpp`, `Global/Comm/Socket.cpp`, `CRobot/{Axis,AxisCIA402,AxisNRMKCore,Sensor,SensorFT,SensorNRMKEndTool,ConfigRobot,ExtInterface,Robot}.cpp`, `Controller.cpp`, `FullDynControllerRT.cpp`, `CalibCapture.cpp`, `VisualServo.cpp`, `Indy7Ctrl.cpp`, `main.cpp`.
- Targets: `all`/`executable`, `install` (copies to `../../bin`), `objects`, `clean`. Auto-dep via `-MD`.

##### 10.10 rtposix primitives used (from `posix_rt.h`, lib `-lrtposix`)
`create_rt_task(&t,name,stack,prio)`, `set_task_period(&t,start,period)`, `start_task(&t,fn,arg)`, `wait_next_period(NULL)`, `read_timer()` (→`RTTIME`, ns), `cpu_relax()`, `getche()`, `SET_TM_NOW`. `RTTIME` is nanoseconds. Task fns are `void proc_*(void* apRobot)` cast to `CRobotIndy7*`.

##### 10.11 EtherCAT / RT integration summary for a future port
- Master lifecycle & DC handled by `CEcatMaster` (EMasterApp, IgH under `/opt/etherlab`); this app supplies only per-slave vendor/product IDs, DC-supported flag, DC activate word, DC sync-shift, and cycle time (1 ms). The **CiA-402 state machine, PDO map, SDOs live in `CRobot/AxisNRMKCore`/`AxisCIA402`** — read those for INIT/PREOP/SAFEOP/OP details.
- Control loop is torque-only (opmode 10 CST). Torque command path: `Update()`→`m_vOutputTorque[i]`→`CAxisNRMKCore::MoveTorque(τ)`. **No torque saturation** in this app — motor `TORQUE_LIMIT_U` (cfg) is enforced downstream in the axis class, not here.
- 1 kHz (`m_dt=0.001`), 500 µs compute deadline. Two hard-RT tasks (Main prio 97, EtherCAT prio 95). Camera task deliberately non-RT (`SCHED_OTHER`) to protect the EtherCAT Sync-Manager watchdog.

##### 10.12 Stubs / dead code / unimplemented
- `InitConfig()` returns TRUE (empty). `DoAgingTest()` empty. `DoHoming(){}` empty. `EnableAgingTest` call commented out in `main`.
- `ComputeInverseKinematics_6dof()` is fully implemented but **unreachable** from `Update()` (marked "Lagacy"/"trash code"); the live 6-DOF path uses `SetTargetPose` (RBDL IK at trigger) + quintic + CTC.
- `eAdaptiveControl` mode has no implementation (falls through to grav-comp default).
- `WriteDataLog()` legacy list-based CSV largely superseded by `RingBuffer`/`proc_logger`.
- `proc_terminal_output` body is almost entirely commented out.

For high-level narrative see the repo's `summary.md`; this section is the exact API/constant complement.

---
#### 11. Application variants — `App/Indy7_ROS2` and `App/Indy7_ROS2_Mujoco`

Both directories are copy-forks of the baseline `App/Indy7` application (same `CRobotIndy7 : public CRobot` shell, same 5–6 RT-task model, same `main.cpp` bootstrap). They diverge from the baseline in exactly three axes: (a) a **ROS2 control/telemetry bridge** wired into `CRobotIndy7` (both variants); (b) a **MuJoCo physics+GL simulation harness** that swaps EtherCAT for a simulated actuator stack at runtime (Mujoco variant only); (c) **stripped-down controller/UI** (no ViSP visual-servo, no RBDL IK/pose/trajectory, PyQt6+rclpy GUI instead of terminal). This section documents ONLY the deltas versus `App/Indy7`; anything not called out is byte-identical to the baseline described in the Indy7 section.

Everything shared is genuinely shared: `Controller.h`/`Controller.cpp` are **byte-identical across all three** variants; `FullDynControllerRT.h`/`.cpp` are **byte-identical between `Indy7_ROS2` and `Indy7_ROS2_Mujoco`** but are the *older/simpler* controller — the baseline `App/Indy7` version has extra "jieun" IK/Pose/trajectory code that both ROS2 variants **lack** (see §11.4). `main.cpp` is byte-identical between the two ROS2 variants and differs from baseline only in one dropped comment.

##### 11.1 File inventory (variant-local files only)

| File (variant-relative) | LOC | Role / delta vs `App/Indy7` |
|---|---|---|
| `Indy7_ROS2/main.cpp` | 101 | Bootstrap; identical to baseline minus one comment. Reads cfg, `mlockall`, `CRobotIndy7::Init(bSim)`, spin on `CheckStopTask()`. |
| `Indy7_ROS2/Indy7Ctrl.h` | 134 | `CRobotIndy7` decl **+ ROS2 members & 8 ROS2 methods**; **drops** ViSP/Calib/IK/logging members present in baseline. |
| `Indy7_ROS2/Indy7Ctrl.cpp` | 1109 | Adds `InitROS2Interface`/`DeInitROS2Interface`/`PublishRobotState`/service callbacks; `proc_main_control` calls `PublishRobotState()`; `proc_logger` is a **no-op stub**; `DoInput` keyset reduced (no i/m/n/q/s/v/l IK keys). |
| `Indy7_ROS2/Controller.{h,cpp}` | 159 / — | **Identical to baseline.** |
| `Indy7_ROS2/FullDynControllerRT.{h,cpp}` | — | Simpler/older controller (no IK/Pose/trajectory — see §11.4). |
| `Indy7_ROS2/INDY7.cfg` | 329 | 5 RT tasks (baseline 6); `URDF_PATH=.../indy7_v2.urdf` (baseline `indy7.urdf`). Otherwise same slaves/gains. |
| `Indy7_ROS2/Makefile` | 157 | Adds ROS2 (jazzy) include/link + `ROS2Node/ROS2Executor/ROS2IndyIface.cpp`; drops CalibCapture/VisualServo + ViSP/RealSense/OpenCV/PCL. |
| `Indy7_ROS2/scripts/{UICtrl,UiCtrlNG}.py` | 342 / 609 | PyQt6 + rclpy GUIs (§11.6). |
| `Indy7_ROS2/scripts/{commons.py,config.json}` | 35 / 36 | Shared helpers + 6-joint ±180° UI config. |
| `Indy7_ROS2_Mujoco/main.cpp` | 101 | Identical to `Indy7_ROS2/main.cpp`. |
| `Indy7_ROS2_Mujoco/Indy7Ctrl.h` | 154 | ROS2 members **+ MuJoCo members**; `m_pEcatAxis` retyped `CAxis**` (base) not `CAxisNRMKCore**`; adds `m_pSimRobot`, `m_pCurrentAxes`, `m_bSimulationMode`, `mjModel*/mjData*`, `InitSimulation()`. |
| `Indy7_ROS2_Mujoco/Indy7Ctrl.cpp` | 1413 | Runtime HW/SIM branch in `Init`/`DeInit`/`InitEtherCAT`/`proc_main_control`/`proc_ethercat_control`/`IsMoving`/`GetCurrentRobotState`. |
| `Indy7_ROS2_Mujoco/Controller.{h,cpp}` | — | Identical to baseline/ROS2. |
| `Indy7_ROS2_Mujoco/FullDynControllerRT.{h,cpp}` | — | Identical to `Indy7_ROS2` version. |
| `Indy7_ROS2_Mujoco/test_simulation.cpp` | 98 | **Orphan/stale** standalone test (NOT in Makefile SOURCES); uses APIs that don't exist in the header — see §11.5. |
| `Indy7_ROS2_Mujoco/INDY7.cfg` | 329 | 5 tasks, TASK4 `ENABLED=0`; `URDF_PATH=.../Indy7/indy7.urdf`; **no `MOJUCO_XML_PATH` key** (caveat). |
| `Indy7_ROS2_Mujoco/Makefile` | 180 | ROS2 (**humble**, not jazzy) + MuJoCo 2.3.7 + GLFW/GL; adds `AxisRT.cpp AxisRTMuJoCo.cpp MuJoCoVisualization.cpp`, `-DMUJOCO_ENABLED`. |
| `Indy7_ROS2_Mujoco/models/indy7.xml` | 87 | MuJoCo MJCF (§11.5). |
| `Indy7_ROS2_Mujoco/models/indy7.urdf`, `Indy7_v_*.stl`, `Indy7_c_*.stl` | — | URDF + visual/collision meshes for MJCF + RBDL. |
| `Indy7_ROS2_Mujoco/scripts/*` | — | Same as ROS2 scripts except theme call + RViz `/joint_states` publish (§11.6). |

Shared library classes (in `Global/Comm/`, compiled INTO each variant, not variant-local): `ROS2Node.{h,cpp}` (108/113), `ROS2Executor.{h,cpp}` (72/138), `ROS2IndyIface.{h,cpp}` (280/467), `ROS2Common.h` (200). MuJoCo axis stack (in `CRobot/`): `AxisRT.{h,cpp}` (157/—), `AxisRTMuJoCo.{h,cpp}` (113/—), `MuJoCoVisualization.{h,cpp}` (326/—). (`CRobot/AxisMuJoCo.{h,cpp}` and `CRobot/MuJoCoAxisExample.cpp` exist but are **NOT compiled** by the Mujoco Makefile — the RT variant `CAxisRTMuJoCo` is used instead.)

##### 11.2 ROS2 bridge wiring (both ROS2 variants, identical)

`CRobotIndy7::Init()` calls `InitROS2Interface()` (after `InitController()`, before `CRobot::Init`). It constructs one `CROS2Executor` and **7 ROS2 nodes**, wires C++ lambdas as service callbacks, `AddNode()`s all seven, then `m_pROS2Executor->Init()`. Node names, topic/service names, and message types:

| Member | Class | ROS node name | Topic/Service name | Type | Direction |
|---|---|---|---|---|---|
| `m_pROS2StatePub` | `CROS2IndyStatePub` | `indy_state_pub` | **`indy_state`** (topic) | `indy_iface/msg/JointInfo` | publish (QoS depth `HISTORY_DEPTH=1`) |
| `m_pROS2GetGainsSrv` | `CROS2GetGainsSrv` | `get_gains_srv` | `get_gains` | `indy_iface/srv/GetGains` | service server |
| `m_pROS2SetGainsSrv` | `CROS2SetGainsSrv` | `set_gains_srv` | `set_gains` | `indy_iface/srv/SetGains` | service server |
| `m_pROS2SetPosSrv` | `CROS2SetPosSrv` | `set_pos_srv` | `set_pos` | `indy_iface/srv/SetPos` | service server |
| `m_pROS2SetAllPosSrv` | `CROS2SetAllPosSrv` | `set_all_pos_srv` | `set_all_pos` | `indy_iface/srv/SetAllPos` | service server |
| `m_pROS2SetControlModeSrv` | `CROS2SetControlModeSrv` | `set_control_mode_srv` | `set_control_mode` | `indy_iface/srv/SetControlMode` | service server |
| `m_pROS2GetControlModeSrv` | `CROS2GetControlModeSrv` | `get_control_mode_srv` | `get_control_mode` | `indy_iface/srv/GetControlMode` | service server |

Service callback → `CRobotIndy7` method mapping (all in `Indy7Ctrl.cpp`):

| Service | Bound method | Semantics |
|---|---|---|
| `get_gains` | `GetCurrentControlGains() → IndyControlGains` | Reads `m_pController->GetControlGain(i,&kp,&kd)` for 6 joints. |
| `set_gains` | `SetControlGains(const IndyControlGains&) → BOOL` | Validates `kp.size()==6 && kd.size()==6`, forwards to `SetControllerGains`. |
| `set_pos` | `SetJointPosition(uint32_t idx, double deg) → BOOL` | `m_pController->SetReferencePos(idx, ConvertDeg2Rad(deg))`. |
| `set_all_pos` | `SetAllJointPositions(vector<double> deg) → BOOL` | 6 deg→rad `SetReferencePos`. |
| `set_control_mode` | `SetControlMode(uint8_t) → BOOL` | 0=Grav,1=FullDyn,2=CTC,3=Adaptive; **first seeds `SetReferencePos(i, m_pEcatAxis[i]->GetCurrentPos())` for all axes** then `SetControllerMode`. |
| `get_control_mode` | `GetControlMode() → uint8_t` | Maps `eControlMode`→0..3. |

**State publish path (RT):** `proc_main_control` calls `pRobot->PublishRobotState()` every cycle (after torque write). `PublishRobotState()` → `GetCurrentRobotState()` fills `IndyRobotState{ positions[6] (rad→**deg** via ConvertRad2Deg), velocities[6], torques[6], faults[6], timestamp=read_timer() }`; `PublishState()` copies via `vectorToArray` into `JointInfo{ is_fault, actual_pos, actual_vel, actual_tor }` and publishes. Fault byte: `1`=ok, `2` if `axstatus < eAxisInit`, `0` if axis missing (Mujoco sim mode: always `1`).

**Executor threading:** `CROS2Executor::Init()` spawns **one `std::thread` per node**, each running its own `rclcpp::executors::SingleThreadedExecutor::spin()` (the stored `StaticSingleThreadedExecutor* m_pExecutor` is allocated but **unused** — dead code). `rclcpp::init(0,NULL)` is called lazily in the ctor if `!rclcpp::ok()`. `DeInit()` calls `rclcpp::shutdown()` then joins all spin threads. These ROS2 threads are **plain `SCHED_OTHER` std::threads, not rtposix RT tasks** — they run outside the RT scheduler.

`IndyRobotState`/`IndyControlGains` structs (in `ROS2IndyIface.h`) both default to size-6 zero vectors. `HISTORY_DEPTH=1` (`ROS2Common.h`). `eNodeType` enum tags each node (`eINDY_STATE_PUB`, `eGET_GAINS_SRV`, …). Service clients (`CROS2*Cli`) also exist in `ROS2IndyIface` but are **not instantiated by the app** (only the Python UI acts as client).

##### 11.3 MuJoCo simulation harness (Mujoco variant only)

The Mujoco variant makes `CRobotIndy7` **dual-mode** via `BOOL m_bSimulationMode` (set from `Init(abSim)`, which is fed by cfg `SIMULATION_MODE`). Structural changes vs ROS2 variant:

- **Axis array retyped:** `CAxis** m_pEcatAxis` (base pointer) instead of `CAxisNRMKCore**`, so it can hold either `CAxisNRMKCore` (HW) or `CAxisRTMuJoCo` (SIM). Adds `CAxis** m_pCurrentAxes`, `CRobotRTMuJoCo* m_pSimRobot`, and `#ifdef MUJOCO_ENABLED mjModel* m_pMjModel; mjData* m_pMjData;`.
- **`InitEtherCAT()` branches on `m_bSimulationMode`:**
  - **SIM path** (`#ifdef MUJOCO_ENABLED`): `mj_loadXML(strMojucoXmlPath)` → `mj_makeData`; builds one `CAxisRTMuJoCo` per `SLAVE_TYPE==0` slave via `std::make_unique<CAxisRTMuJoCo>(jointType, mjJointId=nCnt, encRes, gear, trans, absEnc, ccw, enabled)` + limit setters + `Init()`; sensors (`SLAVE_TYPE==1`) become `CSensorNRMKEndTool` (reverse-indexed) with `Init()` (no master). Creates `CRobotRTMuJoCo`, `SetAxes(move(mujocoAxes))`, `InitRT()`, `InitMuJoCo(m_pMjModel,m_pMjData)`. Then `MuJoCoViz::Initialize(modelFile)` + `MuJoCoViz::Start()` (global GL/physics thread). `m_nEcatCycle=1000`. **No `CEcatMaster` is created in SIM.**
  - **HW path:** original baseline EtherCAT init (`new CEcatMaster()`, `CAxisNRMKCore` per axis, `m_pcEcatMaster->Init(cycle,DC)`), with a `static_cast<CAxisNRMKCore*>(...)->Init(*m_pcEcatMaster, driveMode)` because the array is now `CAxis**`.
  - `InitSimulation()` exists but is a **stub** (all sim setup was folded into `InitEtherCAT`).
- **`proc_main_control` SIM branch:** reads state from `m_pSimRobot->GetJointPosition/Velocity/Torque(nCnt)` (instead of `CAxisNRMKCore::GetCurrentPos/Vel/Tor`); applies `Update()` output via `m_pEcatAxis[nCnt]->MoveTorque(...)`; guard `if(!m_bSimulationMode && !m_bEcatOP) continue;` (sim always runs); LED status block is **hardware-only**.
- **`proc_ethercat_control` SIM branch** (this is the actual physics driver): sets `m_bEcatOP=TRUE`; `m_pSimRobot->StepRTSimulation(0.001)` → `UpdateMuJoCoFromRT()`; per joint `MuJoCoViz::SendJointTorqueCommand(i, torque, t)`; `MuJoCoViz::SendPhysicsStepCommand(t)`; then `MuJoCoViz::GetJointFeedback(i,pos,vel,tor)` → `m_pEcatAxis[i]->UpdateCurrentParams(pos,vel,tor)`; `MuJoCoViz::UpdateRobotState(...)`. HW branch = baseline `ReadSlaves`/`WriteSlaves`. Note this variant's loop is `while(!CheckStopTask())` (baseline/ROS2 used `while(TRUE)`).
- **`DeInit`/`IsMoving`/`GetCurrentRobotState`** all branch on `m_bSimulationMode`.

**MuJoCo class stack (RT-safe, lock-free):**

| Class / API | Signature | Semantics |
|---|---|---|
| `CAxisRT : public CAxis` | `StepSimulation(double dt)` etc. | Pure-RT motor sim (PID pos/vel + `MotorDynamics{inertia,damping,friction}`), **no MuJoCo dep**. Control modes POS/VEL/TORQUE. |
| `CAxisRTMuJoCo : public CAxisRT` | ctor `(eAxisType, int mjJointId, encRes,gear,trans,absEnc,ccw,enabled)` | RT axis + MuJoCo viz link. `StepSimulation` override; `InitMuJoCo(mjModel*,mjData*)`; lock-free `RTVisualizationData m_rtToVizState`/`m_vizToRTState`. |
| `CRobotRTMuJoCo` | `SetAxes(vector<unique_ptr<CAxisRTMuJoCo>>&&)`, `InitRT()`, `InitMuJoCo(mjModel*,mjData*)`, `StepRTSimulation(dt)`, `SetJointTorqueCommand(id,tau)`, `GetJointPosition/Velocity/Torque(id)`, `UpdateMuJoCoFromRT()`, `Shutdown()` | Owns axes; RT-thread facade the app calls. |
| `CMuJoCoVisualizationManager` (singleton) | `Initialize(modelFile)`, `StartVisualization()`, `UpdateRobotState(n,pos,vel,tor,t)`, `SendJointTorqueCommand/SendPhysicsStepCommand`, `GetJointFeedback(i,&pos,&vel,&tor)` | Runs an **rtposix `POSIX_TASK` visualization+physics thread** at cfg 60 FPS render / **1 kHz physics**; owns `mjModel*/mjData*`, GLFW window (1200×900, title "RAON-RT MuJoCo Simulation (1kHz Physics)"), camera az=90/el=-20/dist=2/lookat=(0,0,1). |
| `namespace MuJoCoViz` | `Initialize/Start/Stop/Shutdown`, `UpdateRobotState`, `SendJointTorqueCommand`, `SendPhysicsStepCommand`, `GetJointFeedback`, `IsActive` | Free-function facade over the singleton (what `Indy7Ctrl.cpp` calls). |

Lock-free IPC primitives (`MuJoCoVisualization.h`): `PhysicsCommand{atomic type/joint_index/value/timestamp/valid}` with `Type{SET_JOINT_TORQUE, SET_JOINT_POSITION, SET_JOINT_VELOCITY, STEP_PHYSICS}`; `LockFreePhysicsQueue<1000>` SPSC ring; `RTVisualizationData` with `atomic double joint_positions/velocities/torques[8]` (**max 8 joints**), `UpdateFromRT`/`ReadForVisualization`. All cross-thread state is `std::atomic` — no mutex in the RT→physics→viz path. Uses `#include <posix_rt.h>` (rtposix) for its thread, and `#include <mujoco/mujoco.h>` + `<GLFW/glfw3.h>` under `#ifdef MUJOCO_ENABLED`.

##### 11.5 MJCF model `models/indy7.xml` + `test_simulation.cpp`

`indy7.xml` (`<mujoco model="indy">`): `angle="radian" autolimits="true"`; `<option gravity="0 0 -9.81" integrator="RK4" timestep="0.001"/>` (**1 ms = 1 kHz physics, matches RT loop**). Assets: checker grid material + 7 collision meshes `Indy7_c_0..6` (the `.stl` files; visual `Indy7_v_*` meshes present in dir but not referenced by this MJCF). Kinematics: fixed `base` → serial chain `link1..link6` with 6 hinge joints:

| Joint | body / pos | axis | range (rad) |
|---|---|---|---|
| `joint0` | link1 @ (0,0,0.0775) | 0 0 1 | ±3.05433 |
| `joint1` | link2 @ (0,-0.109,0.222) | 0 0 1 | ±3.05433 |
| `joint2` | link3 @ (-0.45,0,-0.0305) | 0 0 1 | ±3.05433 |
| `joint3` | link4 @ (-0.267,0,-0.075) | 0 0 1 | ±3.05433 |
| `joint4` | link5 @ (0,-0.114,0.083) | 0 0 1 | ±3.05433 |
| `joint5` | link6 @ (-0.168,0,0.069) | 0 0 1 | ±3.75246 |

Each `<body>` carries `inertial` (mass+diaginertia+quat). Actuators: 6 `<motor>` (direct torque, `gear="1"`, `ctrllimited`) with torque `ctrlrange` ±431.97 (j0,j1), ±197.23 (j2), ±79.79 (j3,j4,j5). Sensors: 18 total — `actuatorpos/actuatorvel/actuatorfrc` per joint (frc with `noise="0.001"`). `mjJointId` is assigned as `nCnt` (slave order) in `InitEtherCAT`, so cfg slave order MUST match MJCF joint order.

**`test_simulation.cpp` — stale/orphan.** Standalone `main` selecting HW vs SIM by `argv[1]=="sim"`. It calls `g_pRobot->EnableRobot()`, `g_pRobot->GetCurrentRobotState(ROBOT_STATE&)`, and uses type `ROBOT_STATE state; state.pos[0]` — **none of these exist** in the current `Indy7Ctrl.h` (the real API is `GetCurrentRobotState() → IndyRobotState`, no `EnableRobot`, no `ROBOT_STATE`). It is **not listed in the Makefile SOURCES**, so it neither compiles nor links into `Indy7Ctrl.out`. Treat as dead reference code, not a working entrypoint.

##### 11.6 Python UI/GUI (both variants) — protocol is ROS2 rclpy, NOT TCP 7420

Both `scripts/` dirs ship two independent PyQt6 GUIs. **Neither uses the C++ `CExtInterface` TCP/7420 or CRC16 socket path** — they talk to the C++ side **purely over ROS2** via `rclpy`, matching the `indy_iface` topic/service names in §11.2. (`EXTERNAL_INTERFACE_PORT=7420` in the cfg is still consumed by the C++ `CExtInterface` for the legacy teleop socket, independent of these GUIs.)

- **`UICtrl.py`** (basic): `ROS2Worker(QThread)` node `indy_ui_controller`; clients for `set_pos`/`set_all_pos`/`get_gains`/`set_gains`; subscription to topic **`joint_info`** (⚠ **mismatch** — the C++ publisher advertises `indy_state`, so this GUI's actual-position/graph feed never updates). Tabs: Position (6 sliders ±min/max from config), Gains, Real-Time Graphs (pyqtgraph pos/vel/tor; vel/tor are fake `pos*0.1`/`pos*0.05` placeholders). Deps: `PyQt6, qdarktheme, pyqtgraph, rclpy, indy_iface`.
- **`UiCtrlNG.py`** ("next-gen", the intended GUI): subscribes to correct topic **`indy_state`**; adds `get_control_mode`/`set_control_mode` clients and a **Control-Mode `QComboBox`** (Gravity Comp / Full Dynamics / Computed Torque / Adaptive) + live monitor polled every 1 s; async service helpers `set_joint_position/set_all_positions/get_gains/set_gains/get_control_mode/set_control_mode` (call_async). No graphs tab. Deps add `QComboBox`.
- **`commons.py`**: `load_config`/`ensure_config` (writes default 6-joint ±180° `config.json`) + `trimesh_to_pythreejs` (imports `pythreejs`). **Identical across both variants.**
- **`config.json`**: `{"UI":{"JointSpace":{"Joint1..6":{name,min:-180,max:180}}}}`. **Identical across both variants.**

**Mujoco-variant script deltas** (vs `Indy7_ROS2` scripts): `config.json` and `commons.py` identical; `UICtrl.py` differs only in theme call (`qdarktheme.setup_theme("light")` vs `.load_stylesheet("light")`); `UiCtrlNG.py` additionally (a) `#!/usr/bin/env python3` shebang, (b) imports `sensor_msgs.msg.JointState` and **publishes `/joint_states`** (names `joint0..5`, positions) in `joint_callback` for **RViz**, (c) uses `rclpy.spin_until_future_complete(...,timeout_sec=5.0)` instead of manual `future.done()` polling.

##### 11.7 Build (Makefile) diffs

Common to all three: `CC=g++`, `-O2/-O3 -std=gnu++17`, output `bin/Indy7Ctrl.out`, links `-lm -lrt -lpthread -lEMasterApp -lrtposix -lrbdl -lrbdl_urdfreader`, includes `/opt/rt_posix`, `/opt/etherlab`, `/opt/emaster_app`, `/usr/include/eigen3`.

- **`Indy7` (baseline):** `-O2`; sources add `CalibCapture.cpp`, `VisualServo.cpp`; extra deps **ViSP** (`-lvisp_core -lvisp_io -lvisp_detection -lvisp_sensor`, includes `/home/raimlab/visp/build/...` + `visp/modules/*`), **RealSense** (`-lrealsense2` from `/usr/local/lib/x86_64-linux-gnu`), OpenCV4, PCL-1.14. **No ROS2, no MuJoCo.**
- **`Indy7_ROS2`:** `-O3 -flto -D_GNU_SOURCE -include cstdio/cstring/cstdlib`; `ROS_DIR=/opt/ros/**jazzy**`; `INDY_IFACE_DIR=/home/raimlab/ros_ws/install/indy_iface`; `CFLAGS_ROS = -I<indy_iface> $(shell find $(ROS_INCLUDE) -maxdepth 1 -type d | sed 's/^/-I/')`; adds sources `ROS2Node.cpp ROS2Executor.cpp ROS2IndyIface.cpp`; `LDFLAGS_ROS` = `-lrclcpp -lrcl -lrcutils -lrmw -lrosidl_* -lstd_msgs__* -lbuiltin_interfaces__* -ltracetools -lstatistics_msgs__rosidl_typesupport_cpp -llibstatistics_collector` + `-lindy_iface__rosidl_*`. **Drops** CalibCapture/VisualServo/ViSP/RealSense.
- **`Indy7_ROS2_Mujoco`:** as ROS2 **but** `ROS_DIR=/opt/ros/**humble**` (explicit per-package `-I$(ROS_INCLUDE)/<pkg>` list, not the `find` glob); `MUJOCO_DIR=/home/raimlab/dev_env/mujoco-2.3.7` → `-I.../include -L.../lib -lmujoco`; `CFLAGS += $(MUJOCO_INCLUDE) -DMUJOCO_ENABLED`; adds sources `AxisRT.cpp AxisRTMuJoCo.cpp MuJoCoVisualization.cpp`; `LDFLAGS += -lrbdl -lrbdl_urdfreader -lglfw -lGL -ldl` (+ `$(MUJOCO_LIB)`).

##### 11.8 Comparison table

| Aspect | `App/Indy7` (baseline) | `App/Indy7_ROS2` | `App/Indy7_ROS2_Mujoco` |
|---|---|---|---|
| Entrypoint | `main.cpp` → `CRobotIndy7::Init(bSim)` | same | same (`test_simulation.cpp` orphan) |
| EtherCAT (IgH via EMasterApp) | Yes (always) | Yes (always) | Yes in HW mode; **replaced by MuJoCo in SIM mode** |
| ROS2 bridge | No | **Yes** (jazzy, indy_iface: 1 pub + 6 srv) | **Yes** (humble, same nodes) |
| MuJoCo simulation | No | No | **Yes** (`CAxisRTMuJoCo`/`CRobotRTMuJoCo`/`MuJoCoViz`, 1 kHz RK4) |
| Runtime HW/SIM switch | — | — | **Yes** (`m_bSimulationMode` from cfg `SIMULATION_MODE`) |
| Axis pointer type | `CAxisNRMKCore**` | `CAxisNRMKCore**` | `CAxis**` (polymorphic base) |
| FullDynControllerRT | full (IK/Pose/trajectory/"jieun") | **stripped** (grav/fulldyn/CTC only) | **stripped** (same as ROS2) |
| ViSP / RealSense / calib | Yes | No | No |
| RT tasks (cfg) | 6 (incl. Visual Servo) | 5 (logger = no-op) | 5 (TASK4 disabled) |
| RT loop / cycle | 1 kHz (`TASK_PERIOD=1000000` ns) | same | same; physics 1 kHz |
| UI | terminal keyboard (`DoInput`) | PyQt6+rclpy (UICtrl/UiCtrlNG) | same GUIs + RViz `/joint_states` |
| UI↔C++ protocol | keyboard / TCP7420 (ext iface) | **ROS2 rclpy** (indy_iface) | **ROS2 rclpy** (+RViz) |
| Extra deps | ViSP, realsense2, OpenCV4, PCL | rclcpp/rcl/rmw + indy_iface | + libmujoco, glfw, GL, dl |
| URDF (RBDL, cfg) | `.../Indy7/indy7.urdf` | `.../Indy7/indy7_v2.urdf` | `.../Indy7/indy7.urdf` |
| ROS distro | — | `/opt/ros/jazzy` | `/opt/ros/humble` |

All three share identical EtherCAT slave config (7 slaves: 6 NRMK CORE-class axes — `CAxisNRMKCore`, `SLAVE_TYPE=0` — + 1 EOAT sensor `SLAVE_TYPE=1`), vendor `0x0000089a`, axis product `0x30000000`, sensor product `0x10000007`, `DRIVE_MODE=10` (CST/cyclic-torque), DC enabled, `CYCLE_TIME=1000000` ns — see the Indy7-baseline section for the full PDO/CIA402 detail; the ROS2/Mujoco variants add no EtherCAT-protocol changes.

---
#### 12. Calibration utilities — `App/CalibUtils` (eye-to-hand)

Offline, host-side (non-RT) toolkit that produces the **static robot-base → camera transform `rMc`** (and camera intrinsics) consumed at runtime by `App/Indy7/VisualServo`. Nothing in this directory is real-time, nor does it touch EtherCAT/IgH — it is a one-shot bench calibration step whose only output that feeds the control pipeline is `rPc.yaml` + `camera.xml`. The physical arrangement is **eye-to-hand**: the RealSense camera is fixed in the world (robot base), and an AprilTag marker is rigidly attached to the robot end-effector (TCP).

##### 12.1 Frame-naming convention (ViSP `aMb` / `aPb`)
- `r` = robot base (reference), `e` = end-effector / TCP, `c` = camera (RealSense color optical frame), `o` = object (the AprilTag 36h11 marker).
- `M` = 4×4 homogeneous matrix; **`aMb` expresses frame `b` in frame `a`** (transforms points from `b`→`a`). `P` = the same rigid transform written as a ViSP `vpPoseVector` 6-tuple `[tx, ty, tz, θu_x, θu_y, θu_z]` (translation in metres + rotation as axis-angle / theta-u vector, radians).
- Therefore: `rPe`/`rMe` = TCP pose in base; `cPo`/`cMo` = marker pose in camera; `rPc`/`rMc` = camera pose in base (the calibration goal); `eMc` = camera in TCP (eye-in-hand naming — see caveat 12.9); `ePo`/`eMo` = marker in TCP.

##### 12.2 Files & LOC
| Path | LOC | Role |
|---|---|---|
| `App/CalibUtils/eye_to_hand_calib.py` | 199 | Python AX=ZB eye-to-hand solver; reads `pose_rPe_*.yaml` + `pose_cPo_*.yaml`, computes `rMc`, writes `rPc.yaml`/`rPc.txt` + `rMc_visualization.png`. |
| `App/CalibUtils/save_camera_params.cpp` | 44 | ViSP+RealSense utility; queries RealSense color intrinsics and writes them as `camera.xml`. |
| `App/CalibUtils/visualize_rPc.py` | 64 | Standalone 3-D matplotlib viewer of a single hardcoded `rPc` pose (draws base + camera frames). |
| `App/CalibUtils/Makefile` | 26 | Builds `save_camera_params` against ViSP + librealsense2. |
| `App/CalibUtils/camera.xml` | 30 | Output/input: ViSP `vpXmlParserCamera` intrinsics file. |
| `App/CalibUtils/pose_rPe_{1..12}.yaml` | 10 ea | Input capture: TCP pose in base (`rPe`), ViSP `vpPoseVector` YAML. |
| `App/CalibUtils/pose_cPo_{1..12}.yaml` | 10 ea | Input capture: AprilTag pose in camera (`cPo`), produced by `visp-compute-apriltag-poses`. |
| `App/CalibUtils/rPc.yaml` / `rPc.txt` | 11 / 5 | Output: base→camera transform (pose-vector / 4×4 matrix). |
| `App/CalibUtils/eMc.yaml` / `eMc.txt` | 10 / 4 | Pre-computed transform artefacts (ViSP hand-eye run — see 12.9). |
| `App/CalibUtils/ePo.yaml` / `ePo.txt` | 11 / 4 | Pre-computed `eMo` (marker-in-TCP) artefacts. |
| `App/CalibUtils/image{0001..0012}.png` | — | 12 calibration images fed to the AprilTag pose binary. |
| `App/CalibUtils/save_camera_params` | — | Prebuilt binary of `save_camera_params.cpp`. |
| `App/CalibUtils/visp-compute-apriltag-poses` | — | **Prebuilt** ViSP sample binary; no source in repo. Generates `pose_cPo_*.yaml` from images. |
| `App/CalibUtils/rMc_visualization.png`, `rPc_visualization.png` | — | Rendered outputs of the two Python scripts. |

##### 12.3 The eye-to-hand pipeline (end-to-end)
1. **Intrinsics** — build & run `save_camera_params [out.xml] [camName] [W] [H]` → `camera.xml` (defaults `camera.xml RealSense_color 640 480`). Opens the RealSense color stream, reads the *actual* initialised resolution/intrinsics from the device, saves via ViSP.
2. **Robot-side capture** — during teleoperation the operator jogs the arm to N poses; each `s`/`S` keypress in `App/Indy7/Indy7Ctrl.cpp` (case at line 604) calls `GetCurrentPose(m_Pose)` then both:
   - `CRobotIndy7::SaveRobotPose()` → appends a row to `/home/raimlab/RAON-RT/App/Indy7/calib_data/robot_poses.csv` (rotation-matrix form, secondary log), and
   - `s_calibCapture.Capture(m_Pose)` (`CalibCapture`) → writes `pose_rPe_<N>.yaml` (ViSP `vpPoseVector` of `rMe`) into `/home/raimlab/RAON-RT/App/CalibUtils`.
   The **12 calibration images are NOT captured here** — `CalibCapture` saves only the robot pose; image acquisition is a separate step not present in this subsystem (caveat 12.9).
3. **Camera-side pose extraction** — `visp-compute-apriltag-poses --tag-size 0.09 --input image%04d.png --intrinsic camera.xml --camera-name RealSense_color --output pose_cPo_%d.yaml` detects one 36h11 tag per image and writes `cMo` as `pose_cPo_<N>.yaml`.
4. **Hand-eye solve** — `python3 eye_to_hand_calib.py` pairs `pose_rPe_*` with `pose_cPo_*`, solves for `rMc`, prints residuals, writes `rPc.yaml` + `rPc.txt`, renders `rMc_visualization.png`.
5. **Runtime consumption** — `VisualServo::Init()` loads `camera.xml` (via `vpXmlParserCamera::parse`) and `rPc.yaml` (via `vpArray2D<double>::loadYAML` → `vpHomogeneousMatrix`) to get `rMc`; the servo loop computes `goal = rMc * cMo * s_Toffset`.

##### 12.4 `eye_to_hand_calib.py` — algorithm detail
Solves the eye-to-hand relation **`rMe_i · eMo = rMc · cMo_i`** (i.e. `A X = Z B` with `A=rMe`, `B=cMo`, `X=eMo`, `Z=rMc`), reformulated on relative motions to a classic `AX=XB`:
- Builds all pairwise relative motions `A_ij = rMe_i⁻¹·rMe_j`, `B_ij = cMo_i⁻¹·cMo_j` (O(n²) pairs).
- **Rotation** (Park & Martin 1994 style): accumulates `M_rot += outer(β, α)` where `α = rotvec(Ra)`, `β = rotvec(Rb)`; recovers `Rx` from SVD `M_rot = U S Vᵀ` as `Rx = Vᵀᵀ · diag(1,1,det(Vᵀ)·det(U)) · Uᵀ` (proper-rotation correction).
- **Translation**: least-squares `(Ra − I)·tx = Rx·tb − ta` stacked over all pairs (`np.linalg.lstsq`). Yields `X = eMo`.
- **`rMc` recovery**: `rMc_i = rMe_i · eMo · cMo_i⁻¹` per capture, then averaged — translation by mean, rotation by SVD-orthogonalised sum. Reports mean residuals (cm / deg) and "Distance base→camera".

`load_pose_yaml()` strips `#`-comment lines, parses the ViSP `data:` list, treats `[tx,ty,tz]` + `[θu_x,θu_y,θu_z]`, converts theta-u→matrix via `scipy Rotation.from_rotvec`, returns 4×4.

`rPc.yaml` written by this script is a bare 6×1 pose vector `[t_mean; rotvec(R_mean)]` with a leading `#` comment; `rPc.txt` is the full 4×4 `rMc`.

**File-ordering note:** both globs use `sorted()` → lexicographic order `1,10,11,12,2,3,…,9` (NOT numeric). Because *both* `rPe` and `cPo` lists sort identically, the i-th pairing is preserved and the relative-motion method is order-invariant — no correctness bug, but the ordering is non-monotonic.

##### 12.5 `save_camera_params.cpp` — what it writes
CLI: `argv[1]`=output XML (`camera.xml`), `argv[2]`=camera name (`RealSense_color`), `argv[3]`=width (`640`), `argv[4]`=height (`480`). Opens `rs2::config` color stream `W×H @ 30 RS2_FORMAT_RGB8`, then reads **actual** intrinsics from the opened device (`rs.getIntrinsics(RS2_STREAM_COLOR)` → `intr.width/height`) and `rs.getCameraParameters(RS2_STREAM_COLOR, perspectiveProjWithDistortion)`. Saves via `vpXmlParserCamera::save(cam, output, camName, actualW, actualH)`, checking `!= SEQUENCE_OK`.

`camera.xml` format (ViSP `vpCameraParameters`): `<name>`, `<image_width>/<image_height>`, `<model><type>perspectiveProjWithDistortion</type>` with `<px><py>` (focal in px), `<u0><v0>` (principal point), `<kud><kdu>` (radial distortion, undistort/distort). Committed sample: 640×480, px=601.064, py=599.600, u0=320.407, v0=230.548, kud=−0, kdu=0 (distortion effectively disabled).

##### 12.6 `visualize_rPc.py`
Standalone diagnostic. **Hardcodes** a pose `tx,ty,tz = -0.030688, 0.0463749, -0.0533527`, `tu = 2.21612, -0.00103439, 2.17288` (labelled "rPc" but these are actually the `ePo`/`eMo` values, see 12.9), builds `R` via `from_rotvec`, draws robot-base + camera frames and a dashed base→camera arrow, prints RPY/distance. **Saves to a hardcoded absolute path** `/home/raimlab/RAON-RT/App/CalibUtils/rPc_visualization.png` (will raise if that tree is absent). Note `draw_frame` uses `R.T` columns as axes (differs from the identical-named helper in `eye_to_hand_calib.py`, which uses `R` columns directly).

##### 12.7 Capture-side classes (produced by `App/Indy7`)
`App/Indy7/CalibCapture.{h,cpp}` — thin ViSP wrapper that "confines all ViSP dependencies" for pose capture. Default ctor outdir `"calib_data"`; the global instance in `Indy7Ctrl.cpp` is `CalibCapture s_calibCapture("/home/raimlab/RAON-RT/App/CalibUtils")`. `Capture(pose)` converts a `CControllerFullDynamicsRT::Pose` → `vpHomogeneousMatrix` (`ToMatrix`, copying `m_rotation` 3×3 + `m_position`) → `vpPoseVector` → `rPe.saveYAML("<outDir>/pose_rPe_<count>.yaml", rPe)`; `m_count` starts at **1** (ctor) and increments per capture; `Reset()` sets it to 0 (header comment says "0-based" but ctor makes the first file `_1`).

##### 12.8 API / signature table
| Symbol (file) | Signature | One-line semantics |
|---|---|---|
| `load_pose_yaml` (`eye_to_hand_calib.py`) | `(filepath) -> 4×4 np.ndarray` | Parse ViSP pose-vector YAML (theta-u) → homogeneous matrix. |
| `solve_eye_to_hand` (`eye_to_hand_calib.py`) | `(rMe_list, cMo_list) -> 4×4 X` | Park-Martin AX=XB on pairwise relative motions → `X=eMo`. |
| `skew`,`rot_to_vec` (`eye_to_hand_calib.py`) | `(v)->3×3`, `(R)->rotvec` | Skew-symmetric / matrix→axis-angle helpers. |
| `draw_frame` (both `.py`) | `(ax,R,t,label,scale)` | Quiver an RGB=XYZ coordinate triad in 3-D. |
| `main` (`save_camera_params.cpp`) | `int(argc,argv)` | Open RealSense, read intrinsics, save `camera.xml`. |
| `vpXmlParserCamera::save` | `(cam, file, name, W, H) -> SEQUENCE_OK` | Write intrinsics XML (used by save_camera_params). |
| `vpXmlParserCamera::parse` | `(cam, file, name, model) -> SEQUENCE_OK` | Read intrinsics XML (used by `VisualServo::Init`). |
| `CalibCapture::CalibCapture` | `(const std::string& outDir="calib_data")` | mkdir 0777, `m_count=1`. |
| `CalibCapture::Capture` | `(const Pose&) -> void` | Save `pose_rPe_<N>.yaml` (`vpPoseVector` of `rMe`). |
| `CalibCapture::ToMatrix` | `static (const Pose&) -> vpHomogeneousMatrix` | Copy RBDL 3×3+3 pose → ViSP 4×4. |
| `visp-compute-apriltag-poses` (CLI) | see below | 36h11 tag pose per image → `pose_cPo_%d.yaml`. |

`visp-compute-apriltag-poses` options (from binary synopsis): `--tag-size <m>` (default 0.03), `--tag-z-aligned` (default false), `--input <images fmt>` e.g. `image-%d.jpg`, `--intrinsic <xml>` (default `camera.xml`), `--camera-name <name>` (default `Camera`), `--output <fmt>` (default `pose_cPo_%d.yaml`), `--no-interactive`, `--help`. Assumes exactly one tag per image.

##### 12.9 I/O table (file → produced by → consumed by → meaning)
| File | Produced by | Consumed by | Meaning |
|---|---|---|---|
| `camera.xml` | `save_camera_params` (ViSP `vpXmlParserCamera::save`) | `VisualServo::Init` (`parse`); `visp-compute-apriltag-poses --intrinsic` | RealSense color intrinsics (640×480, px/py/u0/v0, no distortion). |
| `image0001..0012.png` | external capture (NOT in this subsystem) | `visp-compute-apriltag-poses --input` | 12 calibration frames of the TCP-mounted tag. |
| `pose_rPe_<N>.yaml` | `CalibCapture::Capture` (on `s` key) | `eye_to_hand_calib.py` | TCP pose in base `rMe` (ViSP pose-vector). |
| `robot_poses.csv` | `CRobotIndy7::SaveRobotPose` (on `s` key) | — (redundant log; matches `pose_rPe`) | Same captures as CSV with 3×3 rotation; only 1 row committed. |
| `pose_cPo_<N>.yaml` | `visp-compute-apriltag-poses` | `eye_to_hand_calib.py` | AprilTag pose in camera `cMo`. |
| `rPc.yaml` | `eye_to_hand_calib.py` | **`VisualServo::Init` (runtime `rMc`)** | Base→camera transform, 6×1 pose-vector. |
| `rPc.txt` | `eye_to_hand_calib.py` | (human reference) | Base→camera 4×4 matrix. |
| `eMc.yaml`/`eMc.txt` | ViSP hand-eye run (no source in repo) | (reference only) | Unlabeled transform, t=[0.5458,−0.2838,−0.0464], θu=[−1.3177,0.9466,1.1502]; filename implies TCP→camera (eye-in-hand). |
| `ePo.yaml`/`ePo.txt` | ViSP hand-eye run | (reference only) | `eMo` marker-in-TCP, t=[−0.0307,0.0464,−0.0534], θu=[2.2161,−0.0010,2.1729]. |
| `rMc_visualization.png` | `eye_to_hand_calib.py` | (human) | 3-D plot of `rMc` + TCP dots. |
| `rPc_visualization.png` | `visualize_rPc.py` | (human) | 3-D plot of a hardcoded pose. |

##### 12.10 How `rMc` feeds `App/Indy7/VisualServo`
`VisualServo::Init` (default `calibDir = /home/raimlab/RAON-RT/App/CalibUtils`): (1) `vpXmlParserCamera::parse(cam, calibDir+"/camera.xml", "RealSense_color", perspectiveProjWithDistortion)`; (2) `vpArray2D<double>::loadYAML(calibDir+"/rPc.yaml", rPc)` → `rMc = vpHomogeneousMatrix(rPc)`; (3) queries RealSense presence only (no stream open). The non-RT servo loop (`VisualServo::Loop`, 640×480 RGBA @30) detects an AprilTag **36h11, tagSize = 0.09 m**, `HOMOGRAPHY_VIRTUAL_VS`, and computes the goal TCP pose as **`goal = rMc · cMo · s_Toffset`**, EMA-filtered (α=0.15). `s_Toffset = translation(−0.15,0,0) · Rxyz(π/2, 0, −π/2)` (tag→TCP mount offset: 15 cm along robot +x, TCP z→robot −x, TCP y→robot +z). Thus the calibration's sole runtime product is the static `rMc` in `rPc.yaml`.

##### 12.11 External dependencies (exact)
- **C++**: ViSP (`visp3/sensor/vpRealSense2.h`, `visp3/core/vpCameraParameters.h`, `vpXmlParserCamera.h`, `vpHomogeneousMatrix.h`, `vpPoseVector.h`), librealsense2 (`rs2::config/pipeline`, `RS2_STREAM_COLOR`, `RS2_FORMAT_RGB8`). Link (Makefile): `-lvisp_core -lvisp_sensor -lvisp_io -lrealsense2`, `-std=c++17 -O2`, includes for OpenCV4 (`/usr/include/opencv4`), PCL 1.14 (`/usr/include/pcl-1.14`), Eigen3 (`/usr/include/eigen3`) — OpenCV/PCL/Eigen are include-only (ViSP transitive headers), not directly used in `save_camera_params.cpp`.
- **Python**: `numpy`, `yaml` (PyYAML), `scipy.spatial.transform.Rotation`, `matplotlib` + `mpl_toolkits.mplot3d`, `glob`, `os`.
- **AprilTag**: via ViSP `vpDetectorAprilTag` (family `TAG_36h11`) inside the prebuilt `visp-compute-apriltag-poses` binary (ViSP sample; no in-repo source).
- No IgH/`ecrt.h`, no `rtposix`, no RBDL/Eigen math used directly here (RBDL types enter only via the shared `CControllerFullDynamicsRT::Pose` in `CalibCapture`).

---
<a id="13-integration"></a>
#### 13. 통합 지침 — IgH EtherCAT + PREEMPT_RT (Kria KV260) 파이프라인에 붙이기

이 절은 RAON-RT를 당신의 **KV260 / IgH stable-1.6 / PREEMPT_RT / generic 드라이버** 환경 위에 얹기 위한 구체적 매핑·차단요소·순서다. (배경: EtherCAT은 원격이 USB NIC라 eth0에 안전, ~1 ms 천장.)

##### 13.1 계층 매핑 — 무엇이 이미 당신 스택인가

| RAON-RT 요소 | 당신 스택에서의 대응 | 결론 |
|---|---|---|
| `EMasterApp` → `libEMasterApp` (IgH `ecrt.h` 래퍼) | IgH stable-1.6 마스터 그대로 | **그대로 재사용** — §3의 `ecrt_*` 인벤토리가 stable-1.6 API와 일치(request_master/create_domain/slave_config/reg_pdo_entry/config_dc/activate/receive/domain_process/queue/send/application_time/sync_reference_clock). generic 드라이버여도 마스터 API는 동일 |
| `CEcatSlaveBase`/`CSlaveCIA402Base` (CST 토크) | 당신이 붙일 서보 슬레이브 | **재사용** — 고정 5-Rx(`0x1600`)/5-Tx(`0x1a00`) PDO 맵(§4.1). 실드라이브 ESI의 vendor/product/DC AssignActivate만 맞추면 됨 |
| `rtposix` (`/opt/rt_posix`, `-lrtposix`, `posix_rt.h`) | **없음** — KIST 내부 RT 래퍼, 저장소 밖 | **차단요소 #1** — 아래 13.3 shim 필요 |
| `CRobot` RT 태스크 모델 (create/set_period/start) | PREEMPT_RT + `pthread` SCHED_FIFO | rtposix shim 위에서 그대로 동작 |
| `.cfg`(INI) 설정 구동 | — | **재사용** — §2.2/§6.2가 전체 키 스펙 |
| `-mtune=native -flto -O3` | aarch64 Cortex-A53(KV260) | 네이티브 빌드면 OK, **크로스 빌드 시 `-mtune=native` 제거/`-mcpu=cortex-a53`** |
| ViSP/RealSense/RBDL/ROS2/MuJoCo | 앱 계층 선택 의존 | 코어 EtherCAT+RT 붙이기엔 **불필요** — App/Indy7의 제어기·비전만 걷어내면 순수 EtherCAT 골격이 남음 |

##### 13.2 `ecrt_*` 호출 인벤토리 = 당신의 IgH 검증 체크리스트

`libEMasterApp`가 실제로 쓰는 IgH 심볼은 §3.5 표가 전부다(SDO 호출 없음, 베이스에는 vendor/product 하드코딩 없음). 당신의 stable-1.6 빌드에 이 심볼들이 있는지만 확인하면 링크가 보장된다. **DC 관련만 특히 확인**: `ecrt_master_application_time`, `ecrt_master_sync_reference_clock`, `ecrt_master_sync_slave_clocks`, `ecrt_slave_config_dc`, `ecrt_master_select_reference_clock`. DC 레퍼런스 클럭은 `Init()`이 **자동 선택하지 않는다** — 필요하면 슬레이브 하나에 `SetAsDCRef()` 명시 호출(§3.4).

##### 13.3 차단요소 #1 — `rtposix` shim (가장 중요)

RAON-RT의 RT 태스크·타이밍은 전부 `posix_rt.h`(rtposix)를 통한다. 저장소에 **없고** 표준도 아니다. 코드가 실제로 호출하는 표면은 좁으므로, PREEMPT_RT `pthread` 위에 얇은 shim을 만들면 rtposix 없이 KV260에서 구동 가능하다. 걷어내야 할 심볼(§6.1/§5.13/§10 근거):

| rtposix 심볼 | 용도 | PREEMPT_RT shim 구현 방향 |
|---|---|---|
| `POSIX_TASK` / `PTASK` (타입) | 태스크 핸들 | `pthread_t` + 주기/시작시각 담는 struct |
| `create_rt_task(&t, name, stack=2MiB, prio)` | 태스크 생성 | `pthread_attr_setstacksize` + `SCHED_FIFO` + `sched_priority=prio` |
| `set_task_period(&t, start_ns, period_ns)` | 주기 설정 | struct에 저장, 루프에서 `clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, next)` |
| `start_task(&t, fn, arg)` | 실행 | `pthread_create(&t, attr, fn, arg)`; fn은 `void(*)(void*)` |
| `wait_next_period(NULL)` | 다음 주기까지 블록 | `clock_nanosleep`로 절대 시각 대기, `next += period` |
| `read_timer() → RTTIME(ns)` | 모노토닉 ns | `clock_gettime(CLOCK_MONOTONIC)` → ns |
| `SET_TM_NOW` (상수) | 즉시 시작 | 0 또는 현재 시각 센티널 |
| `cpu_relax()` | 바쁜대기 | `asm volatile("yield")`(ARM) 또는 no-op |
| `getch/getche` | 키입력(main/keyboard 태스크) | `termios` 논블로킹 read (Defines.h에 `getch` 있음) |

프로세스 시작 시 `mlockall(MCL_CURRENT|MCL_FUTURE)`는 `main.cpp`가 직접 호출(rtposix 아님) — 그대로 유지. **우선순위는 cfg의 `PRIORITY`(0~99, SCHED_FIFO)**; 당신 커널의 `rtprio` ulimit과 EtherCAT IRQ 스레드 우선순위 배치를 고려해 97/95를 배정(EtherCAT > 제어? RAON은 main P97 > ecat P95 순).

##### 13.4 최소 브링업 레시피 (순수 EtherCAT 골격만 붙일 때)

당신이 붙일 코드는 `CRobot`을 상속한 **구체 로봇 클래스** 하나다. 필수 오버라이드는 `InitEtherCAT()`(베이스는 `return FALSE` 스텁, §6.1). 순서:

1. **`/opt` 배치**: `/opt/etherlab`(IgH 헤더/lib), rtposix 대신 shim, `/opt/emaster_app`(= 루트 `make install` 산출물, §2.2). App Makefile은 `-I/opt/emaster_app/include -L/opt/emaster_app/lib -lEMasterApp`를 참조.
2. **라이브러리 빌드**: `EMasterApp/Makefile`에서 `-mtune=native` 조정 후 `cd EMasterApp && make install`(루트 `make`가 이걸 호출). 컴파일 소스는 4개뿐(`EcatMasterBase/EcatSlaveBase/SlaveCIA402Base/SlaveNRMKEndTool.cpp`). 다른 슬레이브(ELMO/EPOS4/Beckhoff/KistFT/FBG)는 **헤더온리** → 쓰려면 include만; `SlaveKistarHand.cpp`는 **SOURCES 누락**이라 쓰려면 Makefile에 추가(§4.9).
3. **`.cfg` 작성**: §2.2/§6.2 키 스펙대로. **불변식**: `[RT_TASKS] NO_OF_TASKS` == 당신이 `AddTaskFunction()`한 개수(§6.1, 불일치 시 `InitRTTasks` FALSE). `[ECAT_MASTER] CYCLE_TIME=1000000`(ns=1ms), `DC_ENABLED`, 슬레이브별 `VENDOR_ID/PRODUCT_CODE`(hex, 실드라이브 ESI 값), `DC_ACTIVATE_WORD`(기본 `0x300`=cyclic+SYNC0), `DRIVE_MODE=10`(CST).
4. **구체 로봇의 `InitEtherCAT()`**(패턴은 §3.8/§6.1):
   ```
   m_pcEcatMaster = new CEcatMaster();
   for each 슬레이브 in cfg:
       axis = new CAxisNRMKCore(...); axis->SetVendorInfo(vid,pcode);
       axis->SetDCInfo(dcSup, actWord, shift); axis->SetXxxLimits(...);
       axis->Init(*m_pcEcatMaster, (INT8)nDriveMode);  // 내부에서 master->AddSlave
       AddAxis(axis);
   m_pcEcatMaster->Init(nCycleTime_ns, bDCEnabled);     // OP까지 브링업
   ```
   **슬레이브는 물리 버스 순서대로 등록**(`AddSlave`가 position=삽입 index, alias=0, §3.3). `InitSlaves`는 `#등록==#응답슬레이브`를 강제하므로 예기치 않은 커플러/실패 슬레이브가 있으면 마스터 init 전체가 중단.
5. **RT 태스크 본문**(당신이 각 `proc_xxx(void* apRobot)`에 작성, §6.1):
   ```
   CRobot* r=(CRobot*)apRobot;
   while(!r->CheckStopTask()){ wait_next_period(NULL);
       master->ReadSlaves(); /*제어*/ master->WriteSlaves(read_timer()); }
   ```

##### 13.5 하드웨어 구동 전 반드시 수정할 검증된 결함 (§14 요약)

- **비-NRMK CiA402 축의 토크 변환이 항등(identity)** — `CAxis::ConvertTor2Res/Res2Tor`가 계산 후 입력을 그대로 반환하는 버그(§5.3). 실제 스케일링은 `CAxisNRMKCore`만 올바르다(τ/gear/Kt·currentRatio, §5.5). 다른 드라이브를 쓰면 `ConvertTor2Res`를 직접 구현하거나 NRMKCore 방식을 이식.
- **PDO 등록 실패가 조용히 무시됨** — `RegisterPDOEntry` 반환형이 `UINT32`라 `if(offset<0)` 가드가 전부 죽은 코드. 실패 시 offset=`0xFFFFFFFF`로 남아 다음 사이클 `domain_pd+0xFFFFFFFF` OOB 크래시(§4.0). **모든 PDO index/subindex를 실드라이브 ESI와 대조**하고, 필요하면 반환형을 `INT64`로 고쳐 가드 복구.
- **2-도메인 = 사이클당 receive/send 2회**(§3.3) — 1 ms 예산에 반영. 단일 도메인이 필요하면 마스터 개조.
- **`ecrt_request_master(0)` — 마스터 인덱스 0 하드코딩**(§3.3). 다중 마스터면 소스 수정.
- **`OnRecvAxisCommand` 스텁** — TCP `SET_POS`가 ACK만 하고 모션 없음(§6.1). 수신 CRC 미검증(§6.3).
- KistFT/KistarHand 슬레이브 레지스터 맵 버그(§4.7/§4.9): F/T 채널 오프셋 덮어쓰기, Add-info subindex +2 어긋남 → 해당 센서 쓰려면 `RegisterPDO()` 수정.
- `SlaveEPOS4.h`는 이름과 달리 **ELMO 설정**(vendor `0x9a`)이다(§4.3) — 실제 Maxon EPOS4면 vendor/product 교정.

##### 13.6 결정론/타이밍 참고

- 목표 주기 1 ms(cfg `CYCLE_TIME=1000000`), DC 켜짐. `WriteSlaves(appTime)`의 `appTime`은 매 사이클 `read_timer()`(모노토닉 ns) — DC drift 보정(`sync_reference_clock`/`sync_slave_clocks`)은 DC 켜졌을 때만 수행. 오직 **SYNC0**만 설정(SYNC1=0, §3.4).
- `FullDynControllerRT`는 Eigen malloc 비활성·SSE flush-to-zero·**500 µs 데드라인 모니터링**을 하지만 이건 x86 SSE 경로 가정(`__SSE__`) — aarch64에선 SSE intrinsic이 컴파일 제외되므로 무해하나, 동등한 결정론 최적화는 별도(§10).
- 당신 커널(`-rt-kv260c`)의 zocl/DPU 등 다른 RT 경로와 EtherCAT IRQ의 CPU 격리(isolcpus/affinity)를 함께 설계.

##### 13.7 붙이는 세션에서 바로 쓸 수 있는 진입점 요약

- EtherCAT 마스터 공개 API: §3.3 `CEcatMaster` 표 / §3.4 `CEcatSlaveBase` 표.
- 축 명령/상태 API: §5.11 표(`MoveTorque/MoveAxis/GetCurrentPos/…`).
- 로봇 오케스트레이션/RT 태스크: §6.1. 설정 키 전체: §6.2(구조체별 필드) + §2.2(파일 포맷).
- CST 서보 슬레이브 PDO/FSM: §4.1(제어/상태워드, `AnalyzeStatusWord`, `WriteToSlave` 서보온 시퀀스).

---
<a id="14-appendix"></a>
#### 14. 부록 — 외부 의존성 표 & 전체 검증 주의사항

##### 14.1 외부 의존성 통합 표 (선설치 필요, 저장소 밖)

| 의존성 | 용도 | 기대 경로 (원본) | 필요 구성요소 |
|---|---|---|---|
| **IgH EtherLab EtherCAT master** (`ecrt.h`, `-lethercat`) | EtherCAT 마스터 | `/opt/etherlab/{include,lib}` | `libEMasterApp`(전 계층 근간) |
| **rtposix** (`posix_rt.h`, `-lrtposix`) | RT 태스크/타이밍 | `/opt/rt_posix/{include,lib}` | `CRobot` RT 태스크, App. **저장소 밖 KIST 라이브러리 → shim 필요(§13.3)** |
| **libEMasterApp** (본 저장소 산출물) | EtherCAT HAL | `/opt/emaster_app/{include,lib}` (루트 `make install`) | 모든 App |
| **RBDL** + `rbdl_urdfreader` (`-lrbdl -lrbdl_urdfreader`) | 강체동역학/URDF | 시스템 | `FullDynControllerRT`(App 제어기) |
| **Eigen3** | 선형대수 | `/usr/include/eigen3` | 제어기 |
| **ViSP** core/io/detection/sensor | 비주얼서보/AprilTag | `/home/raimlab/visp/build`(개발자 특정) | App/Indy7, CalibUtils |
| **librealsense2** | RGB-D 카메라 | `/usr/local/...`(x86 triplet) | App/Indy7, CalibUtils |
| **OpenCV 4**, **PCL 1.14** | ViSP 전이 의존(include-only) | `/usr/include/opencv4`, `/usr/include/pcl-1.14` | 비전 경로 |
| **ROS 2 Jazzy** / **Humble** | 미들웨어 | `/opt/ros/jazzy`(Indy7_ROS2) · `/opt/ros/humble`(Mujoco) | ROS2 변형 앱 |
| **indy_iface** (커스텀 ROS2 msg/srv) | 조인트/게인/모드 IF | `/home/raimlab/ros_ws/install/indy_iface` | ROS2 변형 앱 |
| **MuJoCo 2.3.7** + GLFW + OpenGL + libdl | 물리 시뮬/렌더 | `/home/raimlab/dev_env/mujoco-2.3.7` | Indy7_ROS2_Mujoco |
| **zstd/zlib** | ROS2 상태 압축 | 시스템 | `ROS2AxisInfo` |
| **Python 3** (PyQt6, qdarktheme, pyqtgraph, rclpy, numpy, PyYAML, scipy, matplotlib, pythreejs, trimesh) | GUI/캘리브/플롯 | 시스템 | App 스크립트, CalibUtils |
| **시스템**: g++(gcc 11), `-lm -lrt -lpthread`, GCC 확장(`__typeof__`, `#pragma pack`) | 툴체인 | — | 전체 |

> **핵심 순수 EtherCAT+RT 골격**에 실제로 필요한 것: IgH(`/opt/etherlab`) + rtposix(또는 shim) + libEMasterApp뿐. RBDL/Eigen/ViSP/RealSense/ROS2/MuJoCo는 전부 **App 계층 선택 의존**이다.

##### 14.2 하드웨어 구동 전 Top 차단요소 (심각도 순)

| # | 결함 | 위치 | 영향 |
|---|---|---|---|
| 1 | PDO 등록 실패가 조용히 통과(`UINT32` 반환→가드 죽음), offset=`0xFFFFFFFF` | §4.0 | 다음 사이클 OOB 크래시 |
| 2 | 비-NRMK CiA402 축의 토크↔카운트 변환이 **항등 캐스트** | §5.3 | 잘못된 토크 명령(스케일 없음) |
| 3 | `rtposix` 저장소 밖 → 빌드/링크 불가 | §13.3 | shim 없으면 구동 불가 |
| 4 | `SlaveEPOS4`가 실제로 ELMO 설정(vendor `0x9a`) | §4.3 | 잘못된 슬레이브 바인딩 |
| 5 | KistFT F/T 읽기 맵/ KistarHand 레지스터 맵 버그 | §4.7/§4.9 | 센서값 뒤섞임/OOB |
| 6 | DC 레퍼런스 클럭 미자동선택 (`SetAsDCRef` 명시 필요) | §3.4 | DC 동기 어긋남 |
| 7 | 2-도메인 = 사이클당 receive/send 2회 | §3.3 | 1ms 예산 압박 |
| 8 | `OnRecvAxisCommand` 스텁 / 수신 CRC 미검증 | §6.1/§6.3 | TCP 명령 무동작·무결성 |
| 9 | `-mtune=native` (aarch64 크로스 부적합) | §2.1 | 크로스 빌드 오작동 |
| 10 | 다수 하드코딩 경로(`/opt`, `/home/raimlab`, URDF/로그 폴더) | 전반 | 경로 수정 없이는 빌드/로깅 실패 |

##### 14.3 전체 검증 주의사항 (서브시스템별, 162항목)

> 아래는 각 리더의 코드-원문 재확인(적대적 검증) 산출물이다. 붙이기 전 해당 섹션과 대조하라. 접두 태그는 서브시스템 키다.


**§2 — `build-config`** (12항목)

- Root `make`/`make all` builds ONLY libEMasterApp (the EtherCAT lib). The Indy7 App executables are NOT built by the root Makefile — each App must be built manually via `cd App/<variant> && make`, and requires /opt/emaster_app, /opt/etherlab, /opt/rt_posix already installed.
- Root `make install` is the ONLY step that copies into /opt/emaster_app (include/ + lib/). Plain `make all` copies libs/headers only into the in-repo $ROOT/include/EMasterApp and $ROOT/lib/EMasterApp.
- EMasterApp/Makefile compiles only 4 cpp files (EcatMasterBase, EcatSlaveBase, SlaveCIA402Base, SlaveNRMKEndTool). SlaveKistarHand.cpp and Interface/EcatInterface.cpp are NOT compiled into the library although headers are still shipped to /opt.
- Makefile `examples` and `distclean` targets reference Examples/SuperMicroSurgery which does NOT exist in this repo — these targets will fail.
- x86-only paths hardcoded that break on the KV260 aarch64 target: `-L/usr/local/lib/x86_64-linux-gnu` (RealSense in App/Indy7), MuJoCo at /home/raimlab/dev_env/mujoco-2.3.7 (likely x86 binaries), and `-I/usr/include/c++/11` (gcc-11-specific).
- All Makefiles use `-mtune=native`; EMasterApp + both ROS2 Apps also use `-flto`. These assume compiling ON the target; cross-compiling for aarch64 requires removing -mtune=native.
- ROS 2 distro is inconsistent across Apps: App/Indy7_ROS2 uses /opt/ros/jazzy, App/Indy7_ROS2_Mujoco uses /opt/ros/humble. indy_iface must be rebuilt for whichever distro is chosen.
- URDF_PATH in INDY7.cfg is a hardcoded absolute path under /home/raimlab/RAON-RT/App/Indy7/ (note the dir is 'RAON-RT', not this repo's 'RAON-RT-Revision-main'); must be repointed. indy_iface at /home/raimlab/ros_ws/install/indy_iface and ViSP at /home/raimlab/visp/build are also user-home absolute paths.
- cfg parser quirks: VENDOR_ID/PRODUCT_CODE parsed as HEX via std::stoul base 16 (fallback decimal); DC_ACTIVATE_WORD hex UINT16; all other numeric keys are atoi/atof. Comments use ';' (whole-line or trailing). POS_BEFORE_EXIT is written back into the cfg on shutdown via WritePrivateProfileString.
- Two config bugs in ConfigRobot.cpp ReadSystemConfig: AGING_DURATION is stored into m_stSystem.bAging (wrong field, duration effectively ignored); the MuJoCo XML key is literally spelled 'MOJUCO_XML_PATH'.
- Torque-limit units are undocumented; 8-axis uses per-mille-style values (2110) while INDY7 uses small values (21-117.73). DRIVE_MODE differs fundamentally: 8-axis/ELMO use 1 (Profile Position), INDY7 uses 10 (Cyclic Synchronous Torque). Verify CIA402 object scaling before enabling torque mode.
- libethercat (IgH userspace) is linked, but the ec_master kernel module + EtherCAT NIC driver are runtime prerequisites not built by this repo. App/CalibUtils is a standalone one-file ViSP/RealSense tool disconnected from the main build graph.

**§3 — `emaster-core`** (18항목)

- ecrt_request_master(0): master index is hardcoded to 0 in EcatMasterBase.cpp — multi-master or non-zero index requires a code change.
- CIA402 constants ALL carry a `CIA402_` prefix (control words, status words, AND drive modes: e.g. CIA402_OPERATION_ENABLED, CIA402_CYCLIC_POSITION) — grep for the prefixed symbol name.
- The auxiliary TCP interface's only implemented command, HEAD_GET_ECAT_STATE=0x01, is dispatched under HEAD_COMMON ('C'=0x43), NOT under HEAD_ECAT ('E'=0x45) — the HEAD_ECAT switch is empty, so a client sending 'E',0x01 gets no reply.
- EcatInterface.cpp is NOT compiled into libEMasterApp (Makefile SOURCES lists only EcatMasterBase.cpp, EcatSlaveBase.cpp, SlaveCIA402Base.cpp, SlaveNRMKEndTool.cpp) and no App/CRobot code instantiates CEcatInterface — it is an unused, largely-stubbed TCP server (empty HEAD_ECAT handler, discarded CRC, no-op SendAck, unpopulated GetCmdData, and m_pcEcatMaster stored-but-never-dereferenced).
- Two-domain design (separate input + output domains) means each control cycle issues TWO full ecrt_master_receive+ecrt_master_send round-trips (one in ReadSlaves, one in WriteSlaves) — extra bus/CPU cost.
- DC reference clock is NOT auto-selected in Init(); integrator must call slave->SetAsDCRef() after EnableDC if a specific DC reference is needed. Only SYNC0 is configured (EnableDC passes SYNC1 cycle/shift = 0,0). DC sync calls run only when dcEnabled=TRUE.
- AddSlave() sets alias=0 and position=vector insertion index (size captured before push_back), so slaves MUST be registered in physical bus/ring order; alias addressing is unsupported via this path.
- InitSlaves() hard-fails unless (# successfully initialized slaves) == GetRespSlaveNo() (bus-responding slaves) — an unexpected coupler or a single PDO-config failure aborts the whole master init.
- SetDeviceType() maps only eDIGITAL_*/eANALOG_*/eFTSensor/eCIA402 to an I/O slave type; eTERMINAL, eJUNCTION, eKistarHand, eUNKNOWN (and any unlisted value) fall through to eNO_IO. An eNO_IO slave SKIPS InitSyncs()/PDO config in Init() and is skipped in the Read/Write PDO loops (loop skip keys on device type eTERMINAL/eJUNCTION). A real I/O slave must use a device type that maps to non-eNO_IO.
- Hardcoded absolute paths in Makefile: /opt/etherlab (IgH: include, lib, -lethercat) and /opt/rt_posix (include, lib, -lrtposix); THIRD_PARTY_DIR=/opt. Must exist at those exact prefixes on the KV260 target or cross-sysroot.
- CFLAGS uses -mtune=native — correct only for native KV260 (Cortex-A53) builds; will mis-tune if cross-compiled from x86 and must be overridden.
- RT period/priority/affinity are NOT in this subsystem — scheduling lives in the rtposix task layer (proc_ethercat_control, registered via AddTaskFunction, uses wait_next_period/read_timer). This code only consumes a caller-supplied ns app-time (read_timer()/GetCurrTimeInNs()) passed into WriteSlaves() -> ecrt_master_application_time.
- No SDO calls (ecrt_slave_config_sdo*) or PDO entry indices/subindices/vendor-product IDs exist in the base classes (verified: 0 'sdo' hits); they live in concrete slave subclasses (SlaveCIA402Base, SlaveNRMKEndTool, Beckhoff/ELMO/EPOS4 headers). AssignActivate word and DC shift must come from each slave's ESI/XML (Device->Dc->AssignActivate) via SetDCInfo.
- RegisterPDOEntry returns UINT32 but the source flags error as -1/<0; the internal 'unRet < 0' check on an unsigned value never triggers — rely on the return as a valid byte offset only when slave init already succeeded.
- The cycleTime argument to CEcatMaster::Init() is in NANOSECONDS and is reused verbatim as the DC SYNC0 cycle time in each slave's EnableDC(); DeInit() emits a final ReadSlaves/WriteSlaves(GetCurrTimeInNs()) before ecrt_release_master.
- The .a static library only archives object files (ar rc + ranlib, no external symbols resolved); only the .so links -lm -lrt -lpthread -lethercat -lrtposix. Final executables must link IgH/rtposix themselves when using the .a.
- SlaveKistarHand.cpp exists in Device/ but is NOT in the Makefile SOURCES, so it is not built into libEMasterApp despite header-level references.
- The interface wire framing: the 2-byte Length field encodes dataLen+2, but the total on-wire frame = Length + 10 (PACKET_MIN_LENGTH-1); usNoOfSlaves is 2-byte big-endian in the reply; a dead static pbTail={0x3E,0x5D} contradicts the real tail bytes 0x5D 0x03 used in build/parse.

**§4 — `emaster-slaves`** (15항목)

- CRITICAL: RegisterPDOEntry returns UINT32 (unsigned) and results go into UINT32 off* vars, so BOTH the internal `if(unRet<0)` guard (EcatSlaveBase.cpp:107) AND every RegisterPDO override's `if(0 > (offX = RegisterPDOEntry(...)))` are dead (always false). A failed PDO-entry registration is silent: no log, RegisterPDO() returns TRUE, offset left 0xFFFFFFFF -> next WriteToSlave/ReadFromSlave dereferences domain_pd+0xFFFFFFFF (OOB/crash). Never trust RegisterPDO()'s return; validate PDO index/subindex against the slave ESI first.
- Only CSlaveCIA402Base and CSlaveNrmkEndtool have their .cpp compiled into libEMasterApp (EMasterApp/Makefile SOURCES = EcatMasterBase.cpp, EcatSlaveBase.cpp, SlaveCIA402Base.cpp, SlaveNRMKEndTool.cpp). SlaveKistarHand.cpp is NOT listed, so CSlaveKistarHand's ctor/RegisterPDO/InitSyncs/WriteToSlave/ReadFromSlave are absent from the built library - a future build must add SlaveKistarHand.cpp or linking fails. All other slaves (ELMO, EPOS4, EK1100, EL2024, CU1124, KistFT, FBGSensor) are header-only; ELMO/EPOS4 rely on the compiled SlaveCIA402Base.cpp.
- CSlaveEPOS4 is mislabeled: configured with ELMO's vendor 0x0000009a and product 0x00100002 (identical to CSlaveELMO), NOT a real Maxon EPOS4. Maxon's true vendor 0x000000fb exists only as a commented #define, with an inline '/* this is for ELMO */' comment, and alt product 0x00030924 ('1층') is also commented. Set correct vendor/product before using a real EPOS4.
- SlaveKistFT.h RegisterPDO() copy-paste bugs corrupt the WHOLE F/T read: Tx/Ty/Tz are written into GET_OFFSET(Fx/Fy/Fz) (overwriting them, so GetFx/GetFy/GetFz return the torque channels), GET_OFFSET(Tx/Ty/Tz) stay indeterminate (params not memset) so GetTx/GetTy/GetTz read garbage/OOB offsets, and Count is registered at 0x6000:06 (dup of Tz) instead of 0x6000:07. Only force-channel data survives, mislabeled.
- SlaveKistarHand.cpp RegisterPDO() re-registers StatusIn1/StatusIn2 at 0x0006:0x33/0x34 (overwriting their 0x01/0x02 offsets, so GetServoStatus/GetControlMode read the ADD1/ADD2 slots) and maps AddInfoIn1..14 to 0x0006:0x35..0x42, but the descriptor labels 0x33..0x40 as ADD1..ADD14 and has no 0x41/0x42. The last two registrations fail; the dead guard swallows the failure and leaves 0xFFFFFFFF offsets -> OOB reads. A +2 subindex mismatch/overrun that must be reconciled.
- SlaveKistarHand.h has a broken include guard: '#ifndef _ECAT_SLAVE_KIST_HAND_' has no matching '#define', and the closing comment says _ECAT_SLAVE_KIST_FT_. Double-inclusion is not actually prevented.
- ODR hazard: SlaveBeckhoffEL2024.h (beckhoff_el2024_*), SlaveKistFT.h (slave_2_*/kist_ft_syncs) and SlaveFBGSensor.h (slave_0_*) define their ec_pdo_entry_info_t / ec_pdo_info_t / ec_sync_info_t descriptor arrays as non-static header globals. Including any one header in more than one .cpp causes multiple-definition link errors; wrap in a single TU or mark static/inline. (KistFT and FBG also #define KIST_FT_ACTIVATE_WORD/SYNC0_SHIFT unguarded -> macro-redefinition warnings if co-included; KistarHand redefines them too.)
- CSlaveCIA402Base live PDO map is only 5 Rx + 5 Tx entries (array declared [11], 10 initialized). Profile velocity/accel/decel (0x6081/83/84), quick-stop decel (0x6085), max-profile vel/acc (0x607F/0x60C5), error code (0x603F), absolute/additional position (0x2fe4:02), motor rated current (0x6075) and an unlabeled 0x60f4 are ALL commented out in cia402_pdo_entries and in RegisterPDO()/ReadFromSlave()/WriteToSlave(). Their Set*/Get* accessors exist but are dead; GetErrorCode() always returns 0. Header comment '/* todo: make this configurable */' - not runtime-configurable.
- AnalyzeStatusWord() has a fall-through: 'case CIA402_PROFILE_VELOCITY' lacks a break and falls into the CSV/CSP/CST cases, so in PV mode the cyclic bit12 logic runs after and overrides the PV servo-status decision. Verify before relying on PV-mode status handling.
- EL2024 declares 4 DO channels (mapping objects 0x1600..0x1603) but only channel 1 (0x7000:01) is registered/written via SetLedValue(); the entry is 1 bit wide yet WriteToSlave writes a full 8 bits at that offset. Channels 2-4 are dead in code.
- DC: ELMO/EPOS4/KistarHand/NRMK use activate word 0x300 (bit8 cyclic + bit9 SYNC0). KistFT, FBG and KistarHand define KIST_FT_SYNC0_SHIFT=125000 ns but leave DC disabled (SetDCSupported(FALSE); the SetDCActivateWord/ShiftTime calls are commented out). ELMO/EPOS4/NRMK use SYNC0 shift = 0. RT task periods/priorities/deadlines are NOT set in these slave files - they come from the master/RT-task layer. Also KistarHand's InitSyncs sets the input SM to EC_WD_ENABLE (unusual; others use WD_DISABLE for the TxPDO SM).
- Hardcoded build paths in EMasterApp/Makefile: THIRD_PARTY_DIR=/opt, IgH EtherCAT master at /opt/etherlab (include /opt/etherlab/include, lib -L/opt/etherlab/lib -lethercat), rt_posix at /opt/rt_posix (-L/opt/rt_posix/lib -lrtposix). CFLAGS use -Wall -O3 -mtune=native -flto; retarget -mtune for the Kria KV260 (aarch64) cross build. make install writes to ../include/EMasterApp and ../lib/EMasterApp (INSTALL_DIR=PROJ_ROOT_DIR=..).
- Naming/comment copy-paste is pervasive: SlaveELMO.h banner+trailing #endif+class-comment say 'SlaveEPOS4'; SlaveBeckhoffCU1124.h banner says 'EK1100'; SlaveFBGSensor.h banner/trailing say 'KistFT' (but its guard _ECAT_SLAVE_LAN9252_FBG_ is correct); SlaveKistarHand.h banner/trailing say 'KistFT'. Rely on the class name and vendor/product IDs, not the file banners.
- Beckhoff CU1124 uses SetDeviceType(eTERMINAL) even though an eJUNCTION enum value exists; eTERMINAL maps to eNO_IO so junction/coupler slaves skip PDO configuration entirely in Init(). Alternate product codes for a different physical install ('1층'/1st-floor) are present as commented #defines in CU1124 (0x04685432), ELMO (0x00030924) and EPOS4 (0x00030924) - confirm the correct product code for the target bus.
- CIA402 WriteToSlave/ReadFromSlave do NOT early-return when the slave is not OP (the IsSlaveOp()/IsSlaveOnline() early-returns are commented out in WriteToSlave; ReadFromSlave only forces eServoDisconnected). NRMK's Read/WriteToSlave DO early-return on !IsSlaveOnline(); KistFT/FBG have no online guard at all.

**§5 — `crobot-axis`** (14항목)

- CAxis::ConvertTor2Res and ConvertRes2Tor are effectively identity casts: both compute the physically-correct value into a local variable and then discard it, returning (INT32)adTor / (double)adRes. Any drive class that does NOT override them (plain CAxisCIA402, CAxisEPOS4, and CAxisELMO which calls the base) sends unscaled torque as raw counts. Only CAxisNRMKCore overrides them with real gear/Kt/current-ratio math.
- CAxisRT::MoveAxis is broken: m_dTargetPos is never assigned on any path (only a discarded local `targetPos`). Due to missing braces after `else if (!abAbs)`, that branch's controlled statement is `SetState(eAxisEmergency);` — so a RELATIVE command (abAbs==FALSE) forces the axis into eAxisEmergency, while an ABSOLUTE command (default abAbs==TRUE) returns TRUE with NO state change and NO target update. `return TRUE;` is unconditional. Position control of the pure-RT sim axis is unusable as-shipped. MoveHome/StopAxis/EmgStopAxis on CAxisRT are explicit stubs returning FALSE.
- CAxisRT::MoveTorque and CAxisMuJoCo::MoveTorque only store m_dTargetTorq; the lines that set control mode to CONTROL_TORQUE and the servo/limit checks are commented out. The default control mode is CONTROL_POSITION, so torque commands take effect only if SetTorqueControl() was called separately, after which StepSimulation/ApplyToMuJoCo consume m_dTargetTorq.
- CAxisELMO::OnSlaveStatusChanged sets m_bFirstHome = FALSE immediately before the `if (TRUE == m_bFirstHome)` start-position-capture block, making that block dead code -- the ELMO axis never captures its start/home position through this callback.
- CAxisNRMKCore constructor forwards adGearRatio into the base CAxisCIA402 adTransRatio slot (CAxisCIA402(...,adGearRatio,adGearRatio,...)), then corrects it by calling SetResolution(adEncRes,adGearRatio,adTransRatio). Net values end up correct but the base ctor line is misleading.
- CSlaveCIA402 is a typedef of CSlaveCIA402Base (SlaveCIA402Base.h:363), not a separate concrete class. All four CiA402 axis variants (generic/NRMKCore/ELMO/EPOS4) embed this SAME generic slave with its fixed RxPDO 0x1600 (0x6040/0x607A/0x60FF/0x6071/0x6060) and TxPDO 0x1a00 (0x6041/0x6064/0x606C/0x6077/0x6061) map. The device-specific SlaveELMO.h/SlaveEPOS4.h classes are NOT wired into the Axis layer. PDO/SDO indices, ESI vendor/product IDs and DC-sync registers all live in the slave/master subsystem, not the Axis layer.
- CRobotRTMuJoCo::InitRT hardcodes a 6-axis INDY7 gear/Kt/current-ratio/torque-limit table and fixed limits (position +/-35 deg, velocity 150 deg/s, profile 130 deg/s, accel 10000). Any real robot must replace this table; ConfigureFromFile(std::string) is declared but NOT defined in AxisRTMuJoCo.cpp. Also GetJointTorque returns the commanded target (GetTargetTorq), not a measured torque.
- CAxisRTMuJoCo external-force feedback is a no-op: RTVisualizationData has no external-force fields, so SetExternalForcesFromMuJoCo() and UpdateExternalForcesFromVisualization() only toggle the data_updated flag (comment: 'skip or implement as needed'). MuJoCo visualization bodies compile only under #ifdef MUJOCO_ENABLED, but AxisRTMuJoCo.h includes <mujoco/mujoco.h> unconditionally.
- eCommType has eAxisMuJoCo = 0x20; BOTH CAxisRT and CAxisMuJoCo construct the base with (eCommType)0x20, so the pure-RT (non-MuJoCo) sim axis reports comm type eAxisMuJoCo. Do not infer MuJoCo usage from GetCommType().
- Sim axes are state-driven, not event-driven: CAxisRT/CAxisRTMuJoCo advance only when StepSimulation(dt) is ticked (CRobotRTMuJoCo::StepRTSimulation at 1 kHz); CAxisMuJoCo advances only when UpdateFromMuJoCo()/ApplyToMuJoCo() are called. Nothing moves without an external RT tick.
- SetResolution's third parameter is named adEncRatio in the header but stored into m_dTransRatio; the m_dEncoderRatio member exists but is unused in the conversion formulas. Encoder decode multiplier (X1/X2/X4) must be pre-folded into adEncRes by the caller. Also, m_dTransRatio is NOT initialized in the CAxis ctor (only via SetResolution), so a bare CAxis has an indeterminate trans ratio.
- CAxisMuJoCo::ComputePIDPosition/Velocity store the clamped PID *output* back into pid.integral (not a real integral accumulator); ApplyToMuJoCo reads pid.integral as the output torque. The MuJoCo PIDController struct also lacks the integral_limit anti-windup field that CAxisRT's has. Non-standard and easy to misread.
- IsLimitConfigured() loops with `nCnt < sizeof(bLimits)` over a BOOL[6]; this is only safe because BOOL is `typedef bool` (Defines.h), making sizeof==6. If BOOL were ever widened, the loop would read out of bounds. IsLimitConfigured requires all six limit pairs (pos/vel/acc/dec/jerk/torque) to be set.
- No absolute hardcoded filesystem paths appear in these Axis files; the only hardcoded values are numeric (INDY7 gear table, PID gains, limits) in CRobotRTMuJoCo::InitRT and the sim-axis constructors. File banner comments are wrong for AxisELMO.h/.cpp (say 'AxisEPOS4'), and AxisCIA402.cpp (Description says 'Header for'); AxisNRMKCore.cpp's Name field says '.h' but its Description correctly says 'Implementation'.

**§6 — `crobot-orch`** (15항목)

- InitEtherCAT() is a PROTECTED base stub returning FALSE — a concrete robot (e.g. CRobotIndy7 in App/Indy7/Indy7Ctrl.cpp) MUST override it to new CEcatMaster(), build each slave (new CAxisNRMKCore + SetVendorInfo/SetDCInfo/limits + ->Init(*m_pcEcatMaster,(INT8)nDriveMode) + AddAxis), then m_pcEcatMaster->Init(nCycleTime, bDCEnabled). CRobot itself never constructs the master. InitEtherCAT/InitRTTasks/UpdateExtInterfaceData/OnRecvAxisCommand/DoAgingTest are all protected virtuals, not public.
- CRobot::OnRecvAxisCommand() is a STUB: it copies the incoming VEC_AXIS_CMD into a local but does nothing (the m_qAxisCmd.push is commented out; the m_vstAxisCmds member is never written). TCP SET_POS commands are ACK'd but produce NO robot motion in current code.
- InitRTTasks() returns FALSE unless the number of AddTaskFunction() calls exactly equals [RT_TASKS] NO_OF_TASKS. The sample Config/8_axis_testbed.cfg sets NO_OF_TASKS=4 while CRobotIndy7 registers 6 task functions — that combination fails; the DEPLOYED App/Indy7/INDY7.cfg correctly sets NO_OF_TASKS=6.
- posix_rt.h is NOT in the repo — it ships with the rtposix library at /opt/rt_posix/include, linked via -lrtposix. PTASK=POSIX_TASK and PTASKFCN (effectively void(*)(void*)) come from there. create_rt_task uses a hardcoded 2 MiB (2*1024*1024) stack; priorities are the config PRIORITY field (0-99, per cfg comment SCHED_FIFO).
- DeInit() has a hardcoded usleep(2000000) (2 s) to let RT tasks exit before EtherCAT teardown, then persists each axis GetCurrentRawPos() back to the INI as [AXISn] POS_BEFORE_EXIT via CConfigRobot::WriteLastPosition. m_pcConfigRobot is deleted here; m_pcExtInterface is never freed (leak) and m_pcEcatMaster is only DeInit'd, not deleted by the base.
- Received TCP packets are NEVER CRC-verified — ParseRecvPacket only checks the STX header and ETX trailer. CRC16-ARC (poly 0x8005, reflect in/out, init 0, xor-out 0) is computed on SEND only, over bytes [SpinId..end-of-payload] (STX & ETX excluded).
- eCommand ASCII comments are wrong: CMD_ROBOT=0x82 (comment 'R'), CMD_AXIS=0x65 ('A'), CMD_ECAT_MASTER=0x77 ('M'), CMD_ECAT_SLAVE=0x83 ('S'), CMD_BINARY_RESPONSE=0x66 ('B'). Use the numeric values, not the letters.
- InterpretCmdAxis: the SUBCMD_GET_STATE case has no break and FALLS THROUGH into SUBCMD_SET_POS. SET_POS payload is int(deg*1000) big-endian, converted via ConvertDeg2Rad(value/PRECISION_FACTOR(1000)). InterpretCmdEcatSlave bodies are all empty and all GET_*/SET_VEL/ACC/TOR subcommands are unimplemented.
- ReadSystemConfig BUG: AGING_DURATION is read into m_stSystem.bAging (ConfigRobot.cpp:384), overwriting the aging flag; nAgingDur is never populated from the cfg.
- Hand support is incomplete: [ECAT_MASTER] SLAVEHANDNUMBER is read into nNoOfHands, but no Read* method ever fills m_vstHandEcatSlaveList, so GetHandEcatSlaveList() always returns empty. All slaves (incl. sensors/hands) are parsed from [AXISn] sections regardless of SLAVE_TYPE.
- CConfigRobot::UpdateConfiguration() and CreateDefaultConfig() are DECLARED in the header but have NO implementation in ConfigRobot.cpp (link error if called). LoadDefaultConfig() is a no-op stub.
- Sim mode: CRobot::Init(TRUE) skips InitExtInterface, InitEtherCAT, and InitRTTasks entirely — no ext-iface, no EtherCAT bus, no RT tasks are created.
- Minor bugs: GetTotalRTTasks() always returns 0 (m_nTotalRTTasks never incremented); GetState() is declared BOOL but returns an eRobotStateMach; UpdateAxisState has an off-by-one bound check (id > size) and sets dCurPos/dCurVel/dCurAcc ALL to (BYTE)GetCurrentPos() (lossy + all from position), leaving dCurTor stale. GetName()/wire robot-name is the URDF path in the Indy7 build (CRobotIndy7::Init assigns m_strName=strURDFPath), not [SYSTEM] NAME.
- BUILD PATHS come from TWO Makefiles: the REPO-ROOT Makefile stages the prebuilt EtherCAT lib (DESTDIR?=/opt, INSTALL_DIR=/opt/emaster_app; copies include/EMasterApp + lib/EMasterApp there; EMasterApp/Makefile is what links IgH via -lethercat into libEMasterApp). App/Indy7/Makefile has NO DESTDIR (its INSTALL_DIR is the repo root) and only links -lEMasterApp — it does NOT link -lethercat directly. App includes are hardcoded: /opt/emaster_app/include, /opt/etherlab/include (IGH), /opt/rt_posix, /usr/include/eigen3, and /home/raimlab/visp/build (ViSP, developer-specific).
- EtherCAT wire-state bytes sent to the TCP client are IgH ECAT_STATE_MACH values eNONE=0x00/eINIT=0x01/ePRE_OP=0x02/eSAFE_OP=0x04/eOP=0x08 and ECAT_WC_STATE domain eWC_NO_EXCHANGED=0/eWC_INCOMPLETE=1/eWC_COMPLETE=2 (from include/EMasterApp/EcatCommon.h). Default per-slave DC activate word is 0x300; DC/vendor/product fields are parsed as hex from the INI. CiA-402 DRIVE_MODE mapping (1=PP,3=PV,4=PT,6=HM,7=IP,8=CSP,9=CSV,10=CST) is confirmed by ValidateCIA402DriveMode in the same header.

**§7 — `crobot-sensor`** (16항목)

- CSensorNRMKEndTool::Start()/ReadData()/Calibrate() all require IsOnline()==TRUE, but bOnline is set TRUE only by SetState(eSensorRunning). After Init() the state is eSensorIdle (offline), so Start() returns FALSE. No code path brings the sensor online from the EtherCAT AL/OP state — the integrator must call SetState(eSensorRunning) (or equivalent) manually once the slave reaches OP, otherwise the sensor never starts.
- CSensorNRMKEndTool::Calibrate() is a no-op STUB: its body is fully commented out and it always returns TRUE without calling CSensorFT::Calibrate/ZeroBias. F/T bias-zeroing is effectively unavailable through the NRMK class as written.
- m_bSlaveInitialized is never set to TRUE (only reset FALSE in DeInit). InitSlave()'s 'already initialized' guard is dead code. Also the Init(CEcatMaster&) precondition check on m_bSlaveInitialized is commented out.
- CSensorNRMKEndTool::GetGripper() returns m_cNrmkSlave.GetIStatus() (the IStatus input PDO 0x6000:01), not a dedicated gripper-position feedback; the code comment admits this is an assumption. There is no read-back of the commanded gripper value.
- F/T LoadCalibrationFromFile/SaveCalibrationToFile do a raw binary read/write of the whole ST_FT_CALIBRATION struct (std::ios::binary). This is endianness/ABI/padding-fragile between the Kria ARM target and any host that authored the file.
- CSensorFT::ZeroBias() calls ProcessRawData() 100x on the SAME latched raw data without fresh acquisition inside the base loop (BIAS_SAMPLES=100). A meaningful bias requires the derived ReadData() to refresh raw data between iterations, which the stubbed NRMK Calibrate never arranges.
- CSensorFT remains abstract: it does NOT override Init/DeInit/Start/Stop/Reset/SetSampleRate/SetFilterCutoff (still pure-virtual from CSensor), so it cannot be instantiated directly.
- MuJoCoVisualization is entirely gated behind -DMUJOCO_ENABLED and is compiled ONLY in App/Indy7_ROS2_Mujoco (per its Makefile). Everywhere else the class methods compile to stubs returning false.
- The MuJoCo visualization/physics thread is spawned with spawn_nrt_task (NON-real-time). Its 1 kHz physics / 60 Hz render loop is driven by std::chrono wall-clock, not a PREEMPT_RT period/deadline — do not treat it as an RT task.
- StepMuJoCoPhysics() calls mj_step() AND THEN does m_pMjData->time += timestep, double-advancing MuJoCo's simulation time relative to the physics step.
- MuJoCoAxisExample.cpp is NOT built (absent from every Makefile) and has no main(); it is example/reference code only. Its lower half (MuJoCoROS2Node) is entirely commented out.
- Feedback/state arrays in the MuJoCo subsystem are hard-capped at 8 joints (RTVisualizationData, m_jointPositions[8], etc.); m_numJoints = min(model->njnt, 8).
- Hardcoded build paths: RT_POSIX_DIR=/opt/rt_posix and MUJOCO_DIR=/home/raimlab/dev_env/mujoco-2.3.7 (from App/Indy7_ROS2_Mujoco/Makefile). posix_rt.h / librtposix are NOT in the repo — they are an external dependency at /opt/rt_posix.
- CKistarHand is NOT a CSensor subclass and does not participate in the sensor state machine; it is an independent gripper wrapper. Its rad<->wire conversion assumes 8192 user-units per pi rad (RAD2USR/USR2RAD).
- KISTAR slave default vendor ID is 0x00000000 (product 0x00000004); a reference comment in SlaveKistarHand.h names a different device 'IFBOX4NEWIF' (vendor 0x00828845, product 0x00009252) that is NOT the active config. NRMK EndTool: vendor 0x0000089a, product 0x10000007, activate word 0x0300, sync0 shift 0. KISTAR activate word 0x0300, sync0 shift 125000 ns.
- The sensor state machine (eSensorState) has no INIT/PREOP/SAFEOP/OP handling itself; EtherCAT AL-state transitions and DC sync live in the CEcatSlaveBase/CEcatMaster layer. SetVendorInfo/SetDCInfo are forwarded verbatim to the owned slave.

**§8 — `global-core`** (15항목)

- No EtherCAT bus code in Global/: ST_ECAT_STATES/ST_ECAT_METADATA are passive UINT8/UINT16 data holders only. No ecrt.h, no PDO entry indices/subindices, no SDO, no DC sync, no INIT/PREOP/SAFEOP/OP state logic anywhere in this layer despite the 'includes EtherCAT state machine' comment.
- No RT primitives here except GetCurrTimeInNs() (CLOCK_MONOTONIC, ns). No rtposix/create_rt_task, no thread priorities/periods/deadlines, no SCHED_FIFO, no mlockall. Socket/Serial/logging all allocate on the heap and poll with 1 ms std::this_thread::sleep_for -> NOT usable on an RT/EtherCAT cyclic task.
- CRC16 ctor BUG: the member init_value is never assigned (ctor param shadows it; body sets polynomial/reflect_in/reflect_out/xor_output only, and the member has no in-class initializer). CRC results depend on uninitialized memory; CRC16_ARC's intended 0x0000 init is only correct by luck. Fix ctor before relying on it.
- GetPrivateProfileString off-by-one: writes buffer[buffer_len]='\0', one past a buffer_len-sized array. Callers must over-allocate by 1.
- GetPrivateProfileInt is fragile: matches section with strcmp against '[section]' but fgets keeps the trailing newline, so it typically never matches and returns defval; also returns 0 (not defval) when fopen fails. Prefer GetPrivateProfileString + atoi.
- WritePrivateProfileString creates its mkstemp temp file 'PRIVPROFXXXXXX' in the CURRENT WORKING DIRECTORY (relative), then rename()s over file_name -> fails with EXDEV if CWD and the target file are on different filesystems; also not thread-safe.
- Duplicate definitions across Comm headers: both Socket.h and Serial.h define 'struct stSendData' AND 'constexpr auto MAX_RECV_BUFF_LEN' (8192 in Socket.h vs 4095 in Serial.h). Including both in one translation unit is an ODR/redefinition conflict.
- Memory leaks in both CTcpClient::Send and CSerialComm::Send: they new char[len] into a queued stSendData whose buffer is never delete[]'d by the send thread. Leaks under sustained traffic.
- Partial-send bug in both proc_thread_send loops: 'nIndex += nBytesToSend; nBytesToSend -= nBytesToSend;' assumes one full send()/write(); partial transfers are mishandled.
- GetOSTime() malloc(200)s a string on every log line and callers never free it -> per-log-line leak. Also uses deprecated ftime(). AssertReport() is an empty stub (TODO: save Logfile); AssertOutputString's abSave/abShowTime params are ignored.
- CSerialComm::SetParams(LPTTYSTRUCT) is an empty STUB: serial params other than baud (via Init arg) and ctor defaults cannot be set. Also RTS/CTS flow bug: CRTSCTS is OR'd into c_iflag instead of c_cflag, so hardware flow control never actually engages.
- CTcpServer has no mutex protecting m_vTcpClient while the accept thread push_back's, the 1 s reaper thread erase's, and SendToClients iterates -> data race / iterator invalidation under concurrency. m_vTcpClient.reserve(10). Default server port in SOCKET_INFO ctor is 7421.
- CSocket error handling is via thrown std::runtime_error (only CTcpServer::Start catches them); direct CSocket callers must wrap in try/catch. Socket.cpp uses #include <Socket.h> (angle brackets) so the build needs -IGlobal/Comm on the include path.
- Structs ST_ROBOT_METADATA, ST_AXIS_METADATA and TTYSTRUCT contain a TSTRING (std::string) inside a #pragma pack(1)/packed struct -> NOT POD, must never be memcpy'd or wire-serialized despite the packing attribute. Only ST_AXIS_CMD (16 B) and ST_AXIS_STATE (34 B) are genuinely packed/POD-serializable.
- Serial.cpp file header comment is mislabeled 'Socket.cpp' (copy-paste). Serial device path is hardcoded as '/dev/'+port; default port 'ttyACM0', default baud 9600, termios default baud in the switch is B115200.

**§9 — `ros2`** (16항목)

- ROS2Imu.h does NOT exist in the repo (only ROS2Imu.cpp, which #includes it) — ROS2Imu.cpp cannot compile as-is.
- Only ROS2Node.cpp, ROS2Executor.cpp, ROS2IndyIface.cpp are compiled by the Indy7 apps. ROS2AxisInfo, ROS2Imu, ROS2PointCloud, ROS2PrismIface are dormant/legacy and NOT built.
- ROS2Common.h has the sensor_msgs, axis_info typedefs and includes COMMENTED OUT, so the legacy AxisInfo/Imu/PointCloud/Prism wrappers will not compile against it without restoring those lines.
- CROS2Executor(int domain_id) ctor is buggy: it builds InitOptions.set_domain_id() but then calls rclcpp::init(0,NULL) WITHOUT the options, so the domain id is silently ignored. Apps use the default ctor (default ROS_DOMAIN_ID).
- No mutex/lock/atomic between the ROS2 spin threads (service callbacks that mutate m_pController gains/refs/mode) and the RT control loop that reads them — a genuine data race on the target hardware.
- PublishRobotState() is called INLINE from the RT control thread (proc_main_control), i.e. a DDS publish happens inside the RT cycle — risk to the RT deadline; consider a non-RT publisher thread.
- Threading model is one std::thread + one SingleThreadedExecutor PER node (7 threads for the Indy7 set); the StaticSingleThreadedExecutor member m_pExecutor is allocated but never used to spin. CreateSpinThread's abMulti arg is ignored.
- 6-DOF (Indy7) is hardcoded everywhere: IndyRobotState/IndyControlGains default size 6; service handlers validate ==6 / <6 / control_mode<=3. Non-6-DOF robots require edits.
- Units: indy_state.actual_pos published in DEGREES (rad->deg); set_pos/set_all_pos inputs are DEGREES (deg->rad). actual_vel/actual_tor are NOT unit-converted.
- The two consuming apps target DIFFERENT ROS 2 distros: App/Indy7_ROS2 = Jazzy (/opt/ros/jazzy), App/Indy7_ROS2_Mujoco = Humble (/opt/ros/humble). indy_iface must be rebuilt per distro.
- Hardcoded absolute paths in both Makefiles: /home/raimlab/ros_ws/install/indy_iface, /opt/ros/{jazzy|humble}, /opt/rt_posix, /opt/etherlab, /opt/emaster_app, /usr/include/eigen3; Mujoco also /home/raimlab/dev_env/mujoco-2.3.7.
- indy_iface (JointInfo msg + GetGains/SetGains/SetPos/SetAllPos/SetControlMode/GetControlMode srvs), axis_info, and prism_iface are EXTERNAL ROS2 packages — no .msg/.srv/.hpp are present anywhere on disk; JointInfo fields (is_fault, actual_pos, actual_vel, actual_tor as std::array<...,6>) are inferred from PublishState() usage.
- DDS backend is Fast-RTPS/Fast-DDS (fastrtps typesupport libs linked). Service clients (CROS2*Cli) are defined but NOT instantiated by the Indy7 apps (host/UI side).
- ROS2PrismIface.h/.cpp file banners wrongly say 'ConfigParser.h/.cpp' — cosmetic mislabel, unrelated to Global/ConfigParser.*.
- ROS2PointCloud.cpp includes lz4.h/zstd.h but publishes uncompressed, and has a leftover printf plus an unused 'compressed_msg' allocation. ROS2AxisInfo.cpp DOES use ZSTD_compress(level 5) to pack a serialized AxisState into std_msgs/ByteMultiArray (needs -lzstd).
- IndyStatePub QoS = KeepLast(1) default reliable (HISTORY_DEPTH=1); legacy pubs/subs use best_effort (Imu/JointState) or best_effort+durability_volatile (PointCloud/AxisInfoCmd). Services use rclcpp defaults.

**§10 — `app-indy7`** (16항목)

- Default config file is hardcoded to "ELMO.cfg" (CRobot/ConfigRobot.h:14 DEFAULT_CONFIGURATION_FULLPATH), NOT INDY7.cfg — the binary MUST be launched as `./Indy7Ctrl.out -f INDY7.cfg` or it will try to read ELMO.cfg.
- Many absolute hardcoded /home/raimlab/... paths that will not exist on a KV260 target: URDF_PATH=/home/raimlab/RAON-RT/App/Indy7/indy7.urdf (cfg); global s_calibCapture dir /home/raimlab/RAON-RT/App/CalibUtils (Indy7Ctrl.cpp:14); VisualServo default calib dir same; make_csv writes /home/raimlab/RAON-RT/App/Indy7/rt_log_results; SaveRobotPose writes /home/raimlab/RAON-RT/App/Indy7/calib_data; SaveISOHWResults writes /home/raimlab/RAON-RT/App/Indy7/iso_csv/hardware; RunISOCubeIKValidation writes /home/raimlab/RAON-RT/App/Indy7/iso_csv/virtual and calls system("python3 /home/raimlab/RAON-RT/App/Indy7/iso_csv/plot_iso_virtual.py").
- Makefile is x86-centric and must be reworked for ARM/KV260: -mtune=native, ViSP libs under /home/raimlab/visp/build/lib, and librealsense2 under -L/usr/local/lib/x86_64-linux-gnu (literal x86_64 path). Include paths reference /home/raimlab/visp/modules and /usr/include/pcl-1.14, /usr/include/opencv4.
- RT SSE optimizations (_MM_SET_FLUSH_ZERO_MODE / DENORMALS_ZERO, <xmmintrin.h>/<pmmintrin.h>) are guarded by __SSE__ and are x86-only — they compile out and give no benefit on ARM; the intended flush-to-zero/denormal behavior must be re-implemented for aarch64.
- Torque limit wiring bug in Indy7Ctrl.cpp InitEtherCAT (~line 341): SetTorqueLimits(dTorLimitL, dJerkLimitU) passes the JERK upper limit as the torque UPPER limit (JERK_LIMIT_U=0 in cfg for all axes), so the configured TORQUE_LIMIT_U (e.g. 21.0/47.5/117.73) is never applied as the upper torque bound via this call.
- No torque saturation exists in the RT torque path of CControllerFullDynamicsRT (base CController::SaturateOutput is never called). Joint safety relies solely on velocity/accel reference clamps (MAX_JOINT_VEL 0.5–0.6 rad/s, MAX_JOINT_ACC 2.0 rad/s², MAX_REF_LEAD 0.10–0.15 rad, MAX_ROT_VEL 0.30 rad/s). Any raw torque spike (e.g. RBDL NaN) is written straight to the drives.
- SaveISOHWResults AP/RP statistics divide a sum of 10 cycle samples by 30.0 (mean[k]/=30.0, d_std uses d_sq_sum/30.0) instead of 10 — the reported ISO 9283 accuracy/repeatability numbers are numerically wrong as written.
- RunISOCubeIKValidation builds pt_label via std::to_string(pt+1).c_str() into a const char* — the temporary std::string is destroyed immediately, leaving pt_label dangling for pt<5 (undefined behavior in the subsequent logging).
- 'q' is intercepted globally in proc_keyboard_control as StopTasks() BEFORE reaching DoInput(), so the 'q'-key ISO-HW hardware test in DoInput() is effectively shadowed/unreachable.
- URDF must contain a link/body literally named "tcp" (m_body_id = model.GetBodyId("tcp") in Init); tcp_local_point is {0,0,0}. GetBodyId returning an invalid id is not checked.
- CRobotIndy7::Init assigns m_strName = GetSystemConf().strURDFPath (robot NAME field overwritten with the URDF path) before passing it to InitController — cosmetic but confusing; the URDF path, not the name, is what InitController consumes.
- eInverseKinematics_6dof at runtime does NOT run RBDL IK in the RT loop — Update() only does UpdateTrajectory()+ComputeComputedTorque(); the RBDL IK (num_steps=1000) runs earlier in SetTargetPose() on the non-RT keyboard thread. ComputeInverseKinematics_6dof() is dead/legacy code. RunISOCubeIKValidation and SetTargetPose also do non-RT RBDL model loads / IK (URDFReadFromFile allocates) — never call these from an RT task.
- LogRingBuffer capacity is 65536 entries (~65 s at 1 kHz), but proc_logger sleeps 24 s per capture; the header comment claiming '10 minutes' is inaccurate. push() silently drops on overflow.
- SIMULATION_MODE=0 in the shipped cfg means it expects real EtherCAT hardware (7 slaves) at startup; DC_ENABLED=1, CYCLE_TIME=1000000 ns. Vendor ID 0x0000089a (Neuromeka), motor product 0x30000000, EOAT product 0x10000007 are the only EtherCAT identity fields set here — full PDO/SDO/CiA-402 state machine is in CRobot/AxisNRMKCore + AxisCIA402 + EMasterApp, not in App/Indy7.
- Visual servoing camera pipeline (pipe.start, RS2_STREAM_COLOR 640x480 RGBA8 30fps) is opened inside VisualServo::Loop() on the deliberately-demoted SCHED_OTHER proc_visual_servo thread; running it at RT priority would starve proc_ethercat_control and trip the Sync Manager watchdog on all slaves (documented in the source comment).
- VisualServo requires runtime files camera.xml (view name 'RealSense_color') and rPc.yaml in the calib dir, plus a live RealSense device; Init() fails (VS disabled, warn-only) if absent — the main controller still runs.

**§11 — `app-variants`** (15항목)

- Hardcoded absolute paths pervade all cfg/source and will break on the KV260 target: cfg URDF_PATH=/home/raimlab/RAON-RT/App/Indy7/indy7.urdf (and indy7_v2.urdf); Makefiles hardcode /opt/rt_posix, /opt/etherlab, /opt/emaster_app, ROS at /opt/ros/jazzy (ROS2) vs /opt/ros/humble (Mujoco), INDY_IFACE_DIR=/home/raimlab/ros_ws/install/indy_iface, MUJOCO_DIR=/home/raimlab/dev_env/mujoco-2.3.7, baseline ViSP at /home/raimlab/visp/build and realsense at /usr/local/lib/x86_64-linux-gnu.
- MuJoCo model path is a latent bug: InitEtherCAT (SIM) calls mj_loadXML(GetSystemConf().strMojucoXmlPath) but the Mujoco INDY7.cfg has NO 'MOJUCO_XML_PATH' key, so ConfigRobot defaults strMojucoXmlPath to the literal 'TEST.xml' (relative). SIM mode will fail to load the model until MOJUCO_XML_PATH=.../models/indy7.xml is added to the cfg. (Config key is misspelled 'MOJUCO_XML_PATH' in ConfigRobot.cpp line 401.)
- Mujoco variant cfg ships SIMULATION_MODE=0, so out-of-the-box it runs HARDWARE/EtherCAT, not MuJoCo. Set SIMULATION_MODE=1 (feeds Init(abSim)) to exercise the sim harness.
- test_simulation.cpp is stale/orphan: NOT in the Makefile SOURCES and calls APIs that do not exist in the current Indy7Ctrl.h (EnableRobot(), GetCurrentRobotState(ROBOT_STATE&), type ROBOT_STATE). It will not build against the current header; do not treat it as a runnable simulation entrypoint. The real state API is GetCurrentRobotState() -> IndyRobotState.
- Topic-name mismatch in the basic GUI: C++ publishes robot state on topic 'indy_state' (node 'indy_state_pub'), but scripts/UICtrl.py subscribes to 'joint_info' — its actual-position readback and graphs never update. Only UiCtrlNG.py subscribes to the correct 'indy_state'.
- ROS2 executor threading is non-RT: CROS2Executor::Init() spawns one plain std::thread per node each running its own SingleThreadedExecutor::spin() at SCHED_OTHER; the allocated StaticSingleThreadedExecutor* m_pExecutor is dead/unused. ROS2 spinning is outside the rtposix RT scheduler — fine for telemetry but do not put hard-RT work in service callbacks.
- State is published in DEGREES: GetCurrentRobotState() applies ConvertRad2Deg to positions before filling JointInfo.actual_pos; set_pos/set_all_pos accept DEGREES and ConvertDeg2Rad before SetReferencePos. Any KV260 consumer must respect deg on the wire, rad internally. actual_vel/actual_tor are NOT converted (rad/s, Nm).
- Both ROS2 variants use the OLDER/simpler FullDynControllerRT (only Gravity/FullDyn/CTC/Adaptive) and DROP the baseline App/Indy7 'jieun' additions: Jacobian & RBDL 6-DOF IK, the Pose struct, ComputeTcpFK, StartJointTrajectory/5th-order trajectory, RunISOCubeIKValidation, ViSP visual servoing, and TCP-trajectory CSV logging. If IK/visual-servo is needed on target, it must be ported forward from the baseline.
- proc_logger is a no-op stub (returns immediately) in both ROS2 variants; the baseline's 24-second ring-buffer CSV logger and its hardcoded output dir /home/raimlab/RAON-RT/App/Indy7/rt_log_results are absent here.
- SetControlMode() service handler dereferences m_pEcatAxis[i]->GetCurrentPos() for all axes to seed the reference position; in the Mujoco SIM path m_pEcatAxis holds CAxisRTMuJoCo (base CAxis*) pointers so this works polymorphically, but it assumes axes are allocated — calling the service before InitEtherCAT completes would deref null.
- RTVisualizationData / the MuJoCo feedback path support a MAX of 8 joints (atomic arrays [8]); GetJointFeedback loops i<6 with fixed double[6] buffers. Extending DOF beyond 6 requires touching MuJoCoVisualization.h array sizes and the MJCF actuator/sensor lists.
- Mujoco Makefile links ROS2 against /opt/ros/humble while Indy7_ROS2 links against /opt/ros/jazzy — the two variants target DIFFERENT ROS2 distros; the indy_iface package must be built for whichever distro is active or link/ABI errors follow.
- CRobot/AxisMuJoCo.{h,cpp} and CRobot/MuJoCoAxisExample.cpp exist but are NOT compiled by the Mujoco Makefile (it uses CAxisRTMuJoCo instead). Do not assume CAxisMuJoCo is the live sim axis; it is legacy.
- MuJoCoVisualization.h includes <posix_rt.h> and runs the GL/physics loop as an rtposix POSIX_TASK with a GLFW window (1200x900) — this needs an X/GL display; on a headless KV260 the visualization thread will fail (Initialize/Start return false and the code logs a warning and continues, so control still runs but no rendering).
- DEFAULT_CONFIGURATION_FULLPATH is 'ELMO.cfg' (ConfigRobot.h); every variant must be launched with '-f INDY7.cfg' or it loads the wrong/default config.

**§12 — `calib`** (11항목)

- Every path is hardcoded to /home/raimlab and MUST be changed for KV260 deployment: Makefile VISP_BUILD=/home/raimlab/visp/build, VISP_SRC=/home/raimlab/visp/modules; visualize_rPc.py savefig '/home/raimlab/RAON-RT/App/CalibUtils/rPc_visualization.png' (crashes if tree absent); VisualServo default calibDir and CalibCapture global s_calibCapture both '/home/raimlab/RAON-RT/App/CalibUtils'; SaveRobotPose '/home/raimlab/RAON-RT/App/Indy7/calib_data/robot_poses.csv'. RS2 include/lib pinned to /usr/local.
- This subsystem contains ZERO EtherCAT/IgH/PDO/SDO/DC/RT content. It is an offline bench-calibration step. Its only handoff into the RT/EtherCAT pipeline is the static rMc transform in rPc.yaml (plus camera.xml intrinsics), loaded once by the non-RT VisualServo thread. A future controller consuming camera-detected target poses in robot-base coordinates depends on this file; it must be regenerated whenever the fixed camera is physically re-mounted.
- visp-compute-apriltag-poses and save_camera_params are PREBUILT binaries; only save_camera_params.cpp has source in-repo. visp-compute-apriltag-poses is an unmodified ViSP sample (no source here) and must be rebuilt from the ViSP tree for a new arch (ARM/KV260).
- The 12 calibration images (image0001..0012.png) are NOT captured by any code in this subsystem. CalibCapture::Capture saves ONLY pose_rPe_<N>.yaml; the operator's 's' keypress does not grab an image. A separate/manual image-acquisition step (matching the pose captures 1:1) is required and is undocumented in-repo.
- eMc.yaml/eMc.txt and ePo.yaml/ePo.txt are pre-computed artefacts from a ViSP hand-eye run whose source is NOT in the repo; only the Python solver (eye_to_hand_calib.py, produces rPc.*) is present. eMc.yaml is unlabeled and its filename ('end-effector to camera') implies an eye-IN-hand convention that conflicts with the eye-to-HAND arrangement — treat its interpretation as ambiguous, do not assume rMc == eMc.
- Committed rPc.txt and rPc.yaml are INCONSISTENT snapshots from different runs: rPc.yaml t=[-0.803,0.240,1.198] vs rPc.txt t=[-0.847,0.190,1.062]. eye_to_hand_calib.py writes both in one run, so the committed pair should not be trusted as coherent; re-run the solver to regenerate.
- visualize_rPc.py hardcodes a pose labelled 'rPc' that is actually the ePo/eMo values ([-0.030688,0.0463749,-0.0533527] / [2.21612,-0.00103439,2.17288], identical to ePo.yaml), i.e. it visualises the wrong transform. Its draw_frame also uses R.T for axes whereas eye_to_hand_calib.py's identically-named helper uses R columns.
- rPc.yaml written by the Python solver uses a leading '#'-prefixed comment line, whereas ViSP saveYAML writes a bare (no-'#') header line (see ePo.yaml). VisualServo loads rPc.yaml via vpArray2D<double>::loadYAML; confirm ViSP loadYAML tolerates the '#' comment on the target ViSP version, or strip it, before relying on the runtime load.
- eye_to_hand_calib.py sorts pose files lexicographically (order 1,10,11,12,2,3,...,9), not numerically. Correspondence is preserved because both rPe and cPo lists sort identically and the relative-motion solve is order-invariant, but do not assume file index N maps to solver index N.
- camera.xml intrinsics have distortion disabled (kud=-0, kdu=0). save_camera_params requests perspectiveProjWithDistortion but the RealSense factory color intrinsics carry no distortion, so the model is effectively distortion-free at 640x480. tagSize is 0.09 m at runtime (VisualServo) and must be passed as --tag-size 0.09 to visp-compute-apriltag-poses (its default is 0.03).
- CalibCapture::Reset() sets m_count=0 but the constructor sets m_count=1, and the header comment claims '0-based index' while the first saved file is pose_rPe_1.yaml (1-based). robot_poses.csv (SaveRobotPose, separate counter m_nPoseCapture, header written on #1) is a redundant CSV of the same captures; only 1 of 12 rows is committed.

---

*본 가이드 끝. 생성: RAON-RT-Revision-main 전체 디렉토리 서브시스템별 병렬 심층 분석 + EtherCAT/RT 핵심 4개 섹션 적대적 검증(코드 원문 재확인). 2026-07-23.*
