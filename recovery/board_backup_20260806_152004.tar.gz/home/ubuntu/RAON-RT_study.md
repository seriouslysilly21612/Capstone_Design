# RAON-RT 학습 로그 (질문 & 답변)

> **이 문서는?** `~/RAON-RT` 코드를 공부하며 주고받은 **질문과 답변을 파일별로 누적**하는 기록입니다.
> 새 질문이 생기면 아래 **학습 순서(8단계)의 파일 순서**에 맞는 위치에 계속 추가됩니다.
> 질문이 특정 코드에 관한 것이면 **그 코드를 문서 안에 함께 실어**, 이 문서만 봐도 원본 파일을 열 필요가 없도록 작성합니다.

- **대상 저장소**: `~/RAON-RT` (+ RT 계층은 `~/RT-POSIX`)
- **시작일**: 2026-07-29
- **관련 문서**: `~/RAON-RT_guide.md`(개념 설명서) · `~/RAON-RT_guide_for_CLAUDE.md`(상세 레퍼런스)

---

## 📚 학습 순서 (8단계)

순서의 논리: **켜짐 → 주기 → 통신 → 변환 → 루프 → 계산**

### 0단계 — 지도 (읽기 전 30분)
| 파일 | 줄수 |
|---|---|
| `~/RAON-RT_guide.md` §1~§4 | — |
| `README.md.txt` | 40 |

### 1단계 — 설정이라는 "조종석" (~600줄)
| 파일 | 줄수 | 볼 것 |
|---|---|---|
| `App/Indy7/INDY7.cfg` | 319 | **가장 먼저 정독.** 이 파일이 로봇의 모든 것을 정함 |
| `Global/ConfigParser.h/.cpp` | 242 | INI 파서 (가볍게) |
| `Global/Defines.h` | 635 | **정독 말고 훑기** — 어떤 타입·로그 매크로가 있는지만 |

### 2단계 — 실시간의 정체 (`~/RT-POSIX`, ~900줄) ⭐
| 파일 | 줄수 | 볼 것 |
|---|---|---|
| `examples/task.c` | **61** | **여기서 시작.** 실시간 태스크의 전형 패턴이 61줄에 다 있음 |
| `include/posix_rt.h` | 135 | `POSIX_TASK` 구조체와 API 전체 목록 |
| `src/posix_rt.c` | 693 | `create_rt_task` / `set_task_period` / `wait_next_period` 구현만 |

### 3단계 — 프로그램이 켜지는 뼈대 (~470줄)
| 파일 | 줄수 | 볼 것 |
|---|---|---|
| `App/Indy7/main.cpp` | 100 | 진입점 — cfg 로드 → 로봇 생성 → `Init` → 대기 |
| `App/Indy7/Indy7Ctrl.h` | 100 | 클래스 선언 + 5개 태스크 함수 선언 |
| `CRobot/Robot.h` | 115 | `CRobot`이 무엇을 소유하는가 |
| `CRobot/Robot.cpp` | 252 | **`InitRTTasks()`가 하이라이트** — cfg + RT-POSIX 결합 지점 |

### 4단계 — EtherCAT 통신 밑바닥 (~1800줄)
| 파일 | 줄수 | 볼 것 |
|---|---|---|
| `EMasterApp/Device/EcatCommon.h` | 253 | 상태(INIT/PREOP/SAFEOP/OP), CiA402 상수 사전 |
| `EMasterApp/Device/EcatMasterBase.h` | 76 | 마스터 API 목록 |
| `EMasterApp/Device/EcatMasterBase.cpp` | 391 | **`Init`/`ReadSlaves`/`WriteSlaves`** — IgH `ecrt_*` 호출 순서 |
| `EMasterApp/Device/EcatSlaveBase.h/.cpp` | 494 | PDO 등록·오프셋, DC 설정 |
| `EMasterApp/Device/SlaveCIA402Base.h/.cpp` | 1000 | 서보 PDO 맵 + 서보온 상태머신 |

### 5단계 — 카운트를 라디안으로 바꾸는 계층 (~1750줄)
| 파일 | 줄수 | 볼 것 |
|---|---|---|
| `CRobot/Axis.h` | 349 | 축의 개념·상태머신·한계 |
| `CRobot/Axis.cpp` | 721 | **단위 변환 수식** (엔코더↔라디안, 전류↔토크) |
| `CRobot/AxisCIA402.h/.cpp` | 646 | 슬레이브와 결선, 콜백 2개 |
| `CRobot/AxisNRMKCore.h/.cpp` | 156 | **가장 짧고 가장 중요** — 토크→전류→카운트 실제 공식 |
| `CRobot/ConfigRobot.h/.cpp` | 781 | cfg → 구조체 (필요할 때 참조) |

### 6단계 — 심장 박동 본문 (798줄)
| 파일 | 줄수 | 볼 것 |
|---|---|---|
| `App/Indy7/Indy7Ctrl.cpp` | 798 | 5개 `proc_*` 태스크 함수 본문 + `InitEtherCAT()` |

### 7단계 — 토크를 계산하는 두뇌 (~840줄)
| 파일 | 줄수 | 볼 것 |
|---|---|---|
| `App/Indy7/Controller.h/.cpp` | 322 | 추상 베이스, 포화·검증 |
| `App/Indy7/FullDynControllerRT.h` | 142 | 4개 모드 enum, RT 성능 구조체 |
| `App/Indy7/FullDynControllerRT.cpp` | 537 | **중력보상 → CTC → 풀다이내믹 순으로** |

### 8단계 — 곁가지 (필요할 때만)
| 파일 | 줄수 | 언제 |
|---|---|---|
| `CRobot/Sensor.h`, `SensorFT.cpp`, `SensorNRMKEndTool.cpp` | ~950 | 힘/토크 센서·그리퍼가 필요할 때 |
| `CRobot/ExtInterface.cpp` + `Global/Comm/Socket.cpp`, `CRC16.cpp` | ~1400 | 외부 GUI 연동이 필요할 때 |
| `Global/Comm/ROS2*.cpp` | — | ROS2 붙일 때 |

> **가장 빠르게 "아하"가 오는 3곳**: ① `RT-POSIX/examples/task.c`(61줄) ② `AxisNRMKCore.cpp`의 `MoveTorque` ③ `Indy7Ctrl.cpp`의 `proc_main_control`

---
---

# 질문 & 답변 (파일별)

---

## 0단계

### `README.md.txt`
*(아직 질문 없음)*

---

## 1단계

### 📄 `App/Indy7/INDY7.cfg`

---

#### Q1. `[SYSTEM]` 섹션 인자들의 의미와, 지금 들어 있는 값에 대한 설명

**질문한 코드** (`App/Indy7/INDY7.cfg` 4~23행):

```ini
EXTERNAL_INTERFACE_ENABLED=1
EXTERNAL_INTERFACE_PORT=7420
TELEOPERATION_MODE=2
TELEOPERATION_CONSTANT_SCALING=0.3
URDF_PATH=/home/airlab2/indy-ros2/indy_description/urdf_files/indy7.urdf
ENABLE_CONTROLLER_AT_STARTUP=1
DEFAULT_CONTROLLER_MODE=0
ROBOT_DOF=6
KP_0=800.0
KD_0=80.0
KP_1=600.0
KD_1=60.0
KP_2=400.0
KD_2=40.0
KP_3=200.0
KD_3=20.0
KP_4=150.0
KD_4=15.0
KP_5=100.0
KD_5=10.0
```

참고로 선택 범위 바로 위(1~3행)는 다음과 같습니다:

```ini
[SYSTEM]
NAME=INDY7
SIMULATION_MODE=0
```

**답변**

`[SYSTEM]` 섹션은 **"로봇의 정체성과 제어기 기본값"**을 정하는 부분입니다.

##### 1. 외부 통신 인터페이스

```ini
EXTERNAL_INTERFACE_ENABLED=1
EXTERNAL_INTERFACE_PORT=7420
```

- **의미**: 외부 GUI·티치펜던트가 TCP로 붙어 로봇 상태를 받아 가고 명령을 보내는 서버를 켤지 여부와 포트.
- **값 해석**: `1` = 켜짐. `CRobot::Init()`이 `InitExtInterface()`를 호출해 포트 7420에 TCP 서버를 띄웁니다. 클라이언트가 접속하면 로봇·마스터·축 메타데이터를 자동으로 밀어 줍니다(CRC16-ARC로 무결성 검사하는 자체 바이너리 프로토콜).

> ⚠️ **나가는 방향(상태 전송)은 동작하지만, 들어오는 위치 명령은 실제 모션이 되지 않습니다.** 명령을 받아 ACK까지 보내지만 이를 축으로 전달하는 콜백(`CRobot::OnRecvAxisCommand`)이 비어 있는 스텁이라서요. 현재는 사실상 **텔레메트리 전용**입니다.
>
> 또한 `SIMULATION_MODE=1`이면 외부 인터페이스·EtherCAT·RT 태스크가 **모두 생성되지 않습니다.** 지금은 `0`(실물 모드)이라 정상 동작합니다.

##### 2. 원격조작 (텔레오퍼레이션)

```ini
TELEOPERATION_MODE=2
TELEOPERATION_CONSTANT_SCALING=0.3
```

- **의미**: 원격조작 모드 번호와 **동작 축소 비율**(조작자가 1 움직이면 로봇은 0.3만 움직이는 식 — 미세 작업용 스케일링).
- **값 해석**: 코드를 전수 검색한 결과, 이 두 값은 `ConfigRobot`이 구조체(`nTeleMode`, `dTeleScalingRatio`)로 읽어 두기만 하고 **어디서도 사용하지 않습니다.** 이 버전에서는 **죽은 설정**이라 `2`와 `0.3`은 현재 아무 기능적 의미가 없습니다. (향후 확장용으로 자리만 잡아 둔 상태)

##### 3. 로봇 모델 경로 ⚠️

```ini
URDF_PATH=/home/airlab2/indy-ros2/indy_description/urdf_files/indy7.urdf
```

- **의미**: **토크 계산의 근간**입니다. URDF에는 각 링크의 질량·관성·길이가 들어 있고, RBDL이 이걸 읽어야 "이 자세에서 중력을 버티려면 몇 뉴턴미터가 필요한가"를 계산할 수 있습니다.
- **값 해석**: 이건 **다른 PC(`airlab2` 계정)의 경로**이고 ROS2 패키지(`indy-ros2`) 안을 가리킵니다. 현재 머신에는 **존재하지 않습니다**(확인 완료). 이 상태로는 URDF 로드가 실패해 제어기 초기화가 실패합니다.

이 머신에 있는 URDF (바꿔 쓸 후보):
- `/home/ubuntu/RAON-RT-Revision-main/App/Indy7/indy7.urdf` (및 `indy7_v2.urdf`)
- `/home/ubuntu/RAON-RT-multistart/App/Indy7/indy7.urdf`

> `~/RAON-RT`에는 URDF가 없어서 다른 트리에서 가져와야 합니다. 이 프로젝트 전반의 **하드코딩된 절대경로 문제**의 대표 사례입니다.

**이 값을 쓰는 코드** (`App/Indy7/Indy7Ctrl.cpp` 116~134행):

```cpp
BOOL
CRobotIndy7::InitController(const TSTRING& astrURDFPath)
{
    ...
    const unsigned int dof = m_pcConfigRobot->GetSystemConf().nRobotAxis; // Get from system config
    if (dof == 0)
    {
        DBG_LOG_ERROR("(%s) Cannot initialize RT Controller: Invalid DOF = 0", "CRobotIndy7");
        return FALSE;
    }

    // Create RT Controller
    m_pController = new CControllerFullDynamicsRT(astrURDFPath, dof);
```

##### 4. 제어기 시작 설정

```ini
ENABLE_CONTROLLER_AT_STARTUP=1
DEFAULT_CONTROLLER_MODE=0
```

- **의미**: 프로그램이 뜨자마자 제어기를 켤지(`1`), 아니면 키보드로 켤 때까지 기다릴지(`0`). 그리고 어떤 제어 모드로 시작할지.

**모드 번호 매핑** (`App/Indy7/Indy7Ctrl.cpp` 12~15행):

```cpp
#define CTRL_MODE_GRAV_COMP     0
#define CTRL_MODE_FULL_DYN      1
#define CTRL_MODE_CTC           2
#define CTRL_MODE_ADAPTIVE      3
```

| 값 | 모드 | 토크 법칙 |
|---|---|---|
| **0** | **중력 보상** ← 현재 값 | τ = g(q) |
| 1 | 풀 다이내믹스 | τ = M·q̈_ref + h + (Kp·e + Kd·ė) |
| 2 | 계산 토크(CTC) | τ = M·(q̈_ref + Kp·e + Kd·ė) + h |
| 3 | 적응 제어 | **미구현** — 경고 후 중력보상으로 폴백 |

**모드를 적용하는 코드** (`App/Indy7/Indy7Ctrl.cpp` 145~163행):

```cpp
    INT32 nDefaultControllerMode = m_pcConfigRobot->GetSystemConf().nDefaultControllerMode;

    switch(nDefaultControllerMode)
    {
        case CTRL_MODE_GRAV_COMP:
            m_pController->SetControlMode(CControllerFullDynamicsRT::eGravityCompensation);
            break;
        case CTRL_MODE_CTC:
            m_pController->SetControlMode(CControllerFullDynamicsRT::eComputedTorque);
            break;
        case CTRL_MODE_FULL_DYN:
            m_pController->SetControlMode(CControllerFullDynamicsRT::eFullDynamics);
            break;
        default:
            DBG_LOG_WARN("(%s) Invalid controller mode %d, defaulting to Gravity Compensation",
                            "CRobotIndy7", nDefaultControllerMode);
            m_pController->SetControlMode(CControllerFullDynamicsRT::eGravityCompensation);
            break;
    }
```

- **값 해석**: `0` = **중력 보상 모드로 시작**합니다. 가장 안전한 선택입니다 — 로봇이 자기 무게만 상쇄해서 제자리에 떠 있고, 사람이 손으로 밀면 힘없이 따라옵니다(직접 교시 가능). 위치 추종을 하지 않으니 모델이 조금 틀려도 폭주하지 않습니다. `ENABLE_CONTROLLER_AT_STARTUP=1`과 조합하면 **"켜자마자 중력보상 상태로 대기"**가 됩니다.

##### 5. 자유도

```ini
ROBOT_DOF=6
```

- **의미**: 관절 개수. 제어기 차원, 게인 벡터 크기, RT 벡터 사전 할당(`m_vCurrentPos` 등)이 전부 이 값을 따릅니다.
- **값 해석**: `6` = Indy7의 6축. 주의할 점은 이 값을 **EtherCAT 축 개수에서 세지 않고 cfg에서 직접 읽는다**는 것입니다(`Indy7Ctrl.cpp:125`에서 `GetTotalAxis()`가 주석 처리되고 설정값을 씀). 따라서 `ROBOT_DOF`와 실제 슬레이브 수가 어긋나면 조용히 불일치가 생길 수 있습니다. `0`이면 초기화가 실패합니다.

##### 6. 관절별 PD 게인 ⭐

```ini
KP_0=800.0   KD_0=80.0     (J0, 베이스)
KP_1=600.0   KD_1=60.0
KP_2=400.0   KD_2=40.0
KP_3=200.0   KD_3=20.0
KP_4=150.0   KD_4=15.0
KP_5=100.0   KD_5=10.0     (J5, 손목)
```

- **의미**: 목표 각도를 따라가게 만드는 되먹임 게인입니다. **Kp는 위치 오차에 대한 강성**(딱딱함), **Kd는 속도 오차에 대한 감쇠**(제동)입니다.

**게인이 실제로 들어가는 자리** (`App/Indy7/FullDynControllerRT.cpp`, CTC 함수 내부):

```cpp
    // Computed torque control: τ = M(q)[q̈_ref + Kp*e_pos + Kd*e_vel] + h(q,q̇)
    ...
    m_vel_error = m_Qd_ref - m_Qd;
    ...
        m_Qdd[i] = m_Qdd_ref[i] + m_Kp[i] * m_pos_error[i] + m_Kd[i] * m_vel_error[i];
```

**값 해석 — 두 가지 뚜렷한 패턴**

**① 베이스에서 손목으로 갈수록 게인이 작아집니다** (800 → 100). 베이스 관절(J0)은 팔 전체의 무게와 관성을 짊어지므로 강하게 잡아야 하고, 손목 관절(J5)은 작고 가벼운 링크만 움직이므로 게인이 크면 떨림(chattering)이 생깁니다.

**② Kd가 정확히 Kp의 1/10로 고정돼 있습니다.** 계산 토크 제어는 관성 행렬 M(q)을 곱해 비선형성을 상쇄하므로, 닫힌 루프 오차 방정식이 각 관절마다 **ë + Kd·ė + Kp·e = 0** 으로 깔끔하게 분리됩니다. 그러면 감쇠비 ζ = Kd / (2√Kp)로 계산할 수 있습니다:

| 관절 | Kp | 고유진동수 ω=√Kp | 감쇠비 ζ | 성격 |
|---|---|---|---|---|
| J0 | 800 | 28.3 rad/s | **1.41** | 과감쇠 — 느리지만 오버슈트 없음 |
| J1 | 600 | 24.5 | 1.22 | 과감쇠 |
| J2 | 400 | 20.0 | **1.00** | 임계감쇠 |
| J3 | 200 | 14.1 | 0.71 | 표준(√2/2) |
| J4 | 150 | 12.2 | 0.61 | 약간 언더 |
| J5 | 100 | 10.0 | **0.50** | 언더감쇠 — 빠르지만 살짝 출렁 |

즉 **베이스는 안정성 우선(과감쇠), 손목은 응답성 우선(언더감쇠)**으로 설계된 값입니다. 무거운 관절이 출렁이면 위험하고, 가벼운 손목은 빠릿해야 하니 합리적인 배분입니다.

> 💡 **두 가지 덧붙일 점**
>
> **(1) 이 cfg 값들은 코드의 내장 기본값과 완전히 동일합니다.** `ROBOT_DOF`가 6이 아닐 때 쓰는 폴백 로직이 만들어 내는 숫자가 정확히 800/600/400/200/150/100입니다. 즉 하드코딩돼 있던 Indy7 튜닝값을 설정파일로 빼낸 것입니다.
>
> ```cpp
> // App/Indy7/Indy7Ctrl.cpp 174~209행
>     std::vector<double> Kp, Kd;
>     if (dof == 6) // Indy7 specific gains
>     {
>        for (int nCnt = 0; nCnt < dof; nCnt++)
>        {
>            Kp.push_back(m_pcConfigRobot->GetSystemConf().vKp[nCnt]);
>            Kd.push_back(m_pcConfigRobot->GetSystemConf().vKd[nCnt]);
>        }
>     }
>     else // Generic gains for other DOF configurations
>     {
>         Kp.resize(dof);  Kd.resize(dof);
>         for (unsigned int i = 0; i < dof; ++i)
>         {
>             if (i < 2)      // Base and shoulder joints - high gains
>             {
>                 Kp[i] = 800.0 - i * 200.0;  // 800, 600
>                 Kd[i] = 80.0 - i * 20.0;    // 80, 60
>             }
>             else if (i < 4) // Elbow and wrist - moderate gains
>             {
>                 Kp[i] = 400.0 - (i-2) * 200.0;  // 400, 200
>                 Kd[i] = 40.0 - (i-2) * 20.0;    // 40, 20
>             }
>             else            // End-effector joints - lower gains
>             {
>                 Kp[i] = 150.0 - (i-4) * 50.0;   // 150, 100
>                 Kd[i] = 15.0 - (i-4) * 5.0;     // 15, 10
>             }
>         }
>     }
>     m_pController->SetControlGains(Kp, Kd);
> ```
>
> **(2) 지금 설정(`DEFAULT_CONTROLLER_MODE=0`)에서는 이 게인이 로드만 되고 쓰이지는 않습니다.** 중력보상은 오차 되먹임이 없기 때문입니다:
>
> ```cpp
> // App/Indy7/FullDynControllerRT.cpp
> CControllerFullDynamicsRT::ComputeGravityCompensation(std::vector<double>& avOutputTorque)
> {
>     // Gravity compensation: τ = g(q)
>     RigidBodyDynamics::InverseDynamics(m_rbdlModel, m_Q, m_zero_vector, m_zero_vector, m_g);
>
>     for (unsigned int i = 0; i < m_uDOF; ++i) {
>         avOutputTorque[i] = m_g[i];
>     }
>
>     return TRUE;
> }
> ```
>
> 게인은 CTC나 풀 다이내믹스로 모드를 바꾸는 순간부터 효력이 생깁니다.

##### 한 줄 정리

이 섹션은 **"6축 Indy7을, 외부 GUI 연결을 열어 둔 채, 켜자마자 중력보상 모드로 대기시키고, 나중에 위치 제어로 전환할 때 쓸 관절별 PD 게인을 베이스는 단단하게·손목은 부드럽게 준비해 둔"** 설정입니다.

실제로 손볼 필요가 있는 건 **`URDF_PATH` 하나**입니다(다른 PC 경로라 현재 머신에서 로드 실패). `TELEOPERATION_*`은 미사용이라 무시해도 됩니다.

---

#### Q2. `Main Control Task`랑 `PI Controller Task`랑 뭔 차이야?

**질문한 코드** (`App/Indy7/INDY7.cfg` 34~67행, `[RT_TASKS]` 태스크 정의부):

```ini
[TASK0]
ENABLED=1
NAME=Main Control Task
PRIORITY=97
TASK_PERIOD=1000000
START_DELAY=0

[TASK1]
ENABLED=1
NAME=EtherCAT Control Task
PRIORITY=95
TASK_PERIOD=1000000
START_DELAY=0

[TASK2]
ENABLED=1
NAME=Keyboard Input Task
PRIORITY=50
TASK_PERIOD=0
START_DELAY=0

[TASK3]
ENABLED=1
NAME=Terminal Printer
PRIORITY=49
TASK_PERIOD=1000000000
START_DELAY=0

[TASK4]
ENABLED=0
NAME=PI Controller Task
PRIORITY=89
TASK_PERIOD=10000000
START_DELAY=0
```

**답변**

**비교 대상이 아닙니다** — 하나는 심장이고, 하나는 이름만 남은 유령입니다.

| | TASK0 "Main Control Task" | TASK4 "PI Controller Task" |
|---|---|---|
| 실제 실행 함수 | `proc_main_control` ✅ 이름과 일치 | **`proc_logger`** ❌ 이름과 무관 |
| 함수 내용 | 1ms 제어 루프 (심장) | **`{ return; }` — 빈 껍데기** |
| 활성화 | `ENABLED=1` | **`ENABLED=0` (실행 안 됨)** |
| "PI"의 뜻 | — | **비례-적분(P-I) 아님. Physik Instrumente(회사명)** |

##### 1. cfg의 `NAME`은 라벨일 뿐, 바인딩은 "등록 순번"으로 됩니다 ⚠️

이게 핵심입니다. `CRobot::InitRTTasks()` (`CRobot/Robot.cpp`):

```cpp
CRobot::InitRTTasks()
{
	VEC_TASK_CONF vTaskConf = m_pcConfigRobot->GetTaskList();
	INT32 nTotalRtTasks = (INT32)vTaskConf.size();

	if ((INT32)m_vTaskFunctions.size() != nTotalRtTasks)
		return FALSE;

	/* separate task creation from execution */
	for (int nCnt = 0; nCnt < nTotalRtTasks; nCnt++)
	{
		PTASK taskTemp;

		create_rt_task(&taskTemp, (const PCHAR)vTaskConf[nCnt].strName.c_str(), 0, vTaskConf[nCnt].nPriority);

		if (0 != vTaskConf[nCnt].nPeriod)
		{
			RTTIME tmStartDelay;
			if (0 == vTaskConf[nCnt].nStartDelay)
				tmStartDelay = SET_TM_NOW;
			else
				tmStartDelay = read_timer() + vTaskConf[nCnt].nStartDelay;

			set_task_period(&taskTemp, tmStartDelay, vTaskConf[nCnt].nPeriod);
		}
		m_vTask.push_back(taskTemp);
	}

	for (int nCnt = 0; nCnt < nTotalRtTasks; nCnt++)
	{
		if (TRUE == vTaskConf[nCnt].bEnabled)
		{
			start_task(&m_vTask[nCnt], m_vTaskFunctions[nCnt], this);   // ← 순번(nCnt)으로 짝지음
		}
	}
	return TRUE;
}
```

`strName`은 `create_rt_task`에 **스레드 이름표**로만 넘어갑니다(디버깅·`ps` 표시용). 실제로 무슨 함수가 도는지는 `m_vTaskFunctions[nCnt]` — **등록된 순서**가 결정합니다.

등록 순서는 생성자에 박혀 있습니다 (`App/Indy7/Indy7Ctrl.cpp` 55~59행):

```cpp
    AddTaskFunction(&proc_main_control);       // index 0 → [TASK0]
    AddTaskFunction(&proc_ethercat_control);   // index 1 → [TASK1]
    AddTaskFunction(&proc_keyboard_control);   // index 2 → [TASK2]
    AddTaskFunction(&proc_terminal_output);    // index 3 → [TASK3]
    AddTaskFunction(&proc_logger);             // index 4 → [TASK4]  ← "PI Controller Task"
```

**실제 매핑:**

| cfg | 이름표 | 실제 함수 | 일치? |
|---|---|---|---|
| TASK0 | Main Control Task | `proc_main_control` | ✅ |
| TASK1 | EtherCAT Control Task | `proc_ethercat_control` | ✅ |
| TASK2 | Keyboard Input Task | `proc_keyboard_control` | ✅ |
| TASK3 | Terminal Printer | `proc_terminal_output` | ✅ |
| **TASK4** | **PI Controller Task** | **`proc_logger`** | ❌ |

##### 2. 그 `proc_logger`마저 빈 함수입니다

`App/Indy7/Indy7Ctrl.cpp` 791~796행 **전부**입니다:

```cpp
void
proc_logger(void* apRobot)
{

    return;
}
```

> 참고: `RAON-RT-Revision-main` 버전에는 링버퍼로 24초간 궤적을 모아 CSV로 저장하는 실제 로거가 들어 있지만, `~/RAON-RT`에서는 `DataRecorder.h`와 함께 걷어내진 상태입니다.

게다가 `ENABLED=0`이라 `start_task`가 아예 호출되지 않습니다. 즉 **태스크 객체는 만들어지고 10ms 주기까지 설정되지만, 실행은 되지 않습니다** (위 코드에서 생성 루프와 시작 루프가 분리돼 있기 때문).

##### 3. "PI"는 비례-적분 제어기가 아닙니다

가장 헷갈리기 쉬운 부분입니다. `PI Controller`를 보면 자연히 **P-I(Proportional-Integral) 제어기**를 떠올리게 되고, "메인 제어기가 따로 있는데 왜 PI 제어기가 또 있지?" 하는 의문이 생깁니다.

근거는 루트 `Makefile` 8~14행에 있습니다:

```makefile
PROJ_ROOT_DIR=.
ROBOT_DIR=$(PROJ_ROOT_DIR)/CRobot
CONFIG_DIR=$(PROJ_ROOT_DIR)/Config
ECAT_DIR=$(PROJ_ROOT_DIR)/EMasterApp
PI_CONTROLLER_DIR=$(PROJ_ROOT_DIR)/PI_GCS2          ← 여기
EXAMPLES_DIR=$(PROJ_ROOT_DIR)/Examples
USURGERY_ROBOT_DIR=$(EXAMPLES_DIR)/SuperMicroSurgery
```

**PI GCS2** = **P**hysik **I**nstrumente 사의 **G**eneral **C**ommand **S**et 2.0 — 정밀 피에조 스테이지 컨트롤러를 제어하는 통신 프로토콜입니다. 바로 아래 줄의 `SuperMicroSurgery`(미세수술 로봇) 예제에서 쓰던 것으로 보입니다. 미세수술에는 나노미터급 정밀 스테이지가 필요하니 자연스러운 조합입니다.

즉 `[TASK4]`는 **다른 로봇(미세수술 로봇)의 설정 템플릿을 복사해 오면서 남은 흔적**입니다. `PI_GCS2/`와 `Examples/` 디렉토리는 이 저장소에 아예 존재하지 않습니다(확인 완료).

우선순위 89, 주기 10ms라는 값도 이 해석과 맞습니다 — 실시간 제어(97/95)보다는 낮고 UI(50/49)보다는 높은, **외부 장비와 주기적으로 통신하는 태스크**에 어울리는 설정입니다.

##### 정리

`Main Control Task`는 **로봇의 심장**(1ms, 우선순위 97, 관절 상태 읽기 → 토크 계산 → 토크 명령)이고, `PI Controller Task`는 **세 겹으로 죽어 있는 유산**입니다:

1. 이름이 실제 함수(`proc_logger`)와 무관하고,
2. 그 함수조차 `return;`뿐이며,
3. `ENABLED=0`이라 시작조차 되지 않습니다.

> 💡 **교훈**: **cfg의 `NAME`을 믿지 말고 등록 순번을 보라.** 나중에 태스크를 추가·삭제할 때 순서가 밀리면 엉뚱한 함수가 엉뚱한 주기·우선순위로 돌게 되는데, 이름은 그대로라서 알아채기 어렵습니다.
>
> 또한 `InitRTTasks()`의 첫 가드 때문에 **`NO_OF_TASKS`와 `AddTaskFunction()` 호출 수가 정확히 같아야** 합니다(다르면 `FALSE` 반환 → RT 태스크가 하나도 안 뜸).

---

#### Q3. TASK0, TASK1은 왜 굳이 99, 98로 하지 않고 97, 95로 한 거야? 그리고 왜 EtherCAT이 메인 컨트롤보다 우선순위가 더 높아?

**관련 코드** (`App/Indy7/INDY7.cfg` 25~30행, 우선순위 규칙 주석):

```ini
;==========================================================================
; Real-time Tasks
; TASK_PERIOD : period in nanoseconds
; START_DELAY : delay execution of tasks in nanoseconds
; PRIORITY : 0 (lowest) - 99 (highest)
;==========================================================================
```

**답변**

##### 0. 먼저 전제 정정 — EtherCAT이 더 **낮습니다**

위 주석대로 **숫자가 클수록 높은 우선순위**입니다(리눅스 `SCHED_FIFO` 규약). 따라서 `Main Control(97) > EtherCAT(95)` — 메인 제어가 더 높습니다.

> `nice` 값은 작을수록 우선인데 실시간 우선순위는 반대라 헷갈리기 쉬운 지점입니다.

##### 1. 왜 99/98이 아니라 97/95인가

**① 99는 커널이 이미 쓰고 있습니다.**

이 보드(`5.15.199-rt91-rt-kv260c`)에서 확인한 결과:

```
RTPRIO PRI CLS COMMAND
    99 139  FF migration/0
    99 139  FF migration/1
    99 139  FF migration/2
    99 139  FF migration/3
    99 139  RR multipathd
    50  90  FF irq/14-zynqmp-i
    50  90  FF watchdogd
    50  90  FF irq/40-ff960000
    ... (IRQ 스레드 전부 50)
```

`migration/N`은 **stop-machine** 스레드로, CPU 핫플러그·스케줄러 밸런싱 같은 "전 CPU를 멈춰 세워야 하는 일"을 처리합니다. 사용자 태스크가 같은 99로 끼어들어 CPU를 놓지 않으면 **커널이 스스로를 정리할 수 없어 시스템 전체가 멎습니다**(RCU stall, 워치독 리셋). 관례적으로 **99는 커널 몫으로 비워 둡니다.**

**② 98은 "나보다 급한 것"을 위한 여유.** 비상정지 감시 태스크, EtherCAT NIC IRQ 스레드 승격 등 나중에 더 급한 게 생길 수 있습니다. 앱이 이미 천장(99)이면 위로 갈 자리가 없습니다.

**③ 97과 95 사이의 빈칸(96)도 같은 의도.** 붙여 놓으면 중간에 하나 넣을 때 전부 다시 번호를 매겨야 합니다.

**④ 사실 절대값 자체는 중요하지 않습니다.** 중요한 건 **상대 순서**와 **다른 RT 스레드(IRQ 50)보다 위인가**입니다. 이 cfg의 전체 배치를 보면 의도가 드러납니다:

| 태스크 | 우선순위 | 위치 |
|---|---|---|
| Main Control | 97 | IRQ(50)보다 훨씬 위 — 절대 밀리면 안 됨 |
| EtherCAT | 95 | 〃 |
| (PI Controller) | 89 | 〃 (비활성) |
| Keyboard Input | 50 | **IRQ 스레드와 동급** — 급하지 않음 |
| Terminal Printer | 49 | **IRQ보다 아래** — 가장 안 급함 |

##### 2. 왜 메인 제어가 EtherCAT보다 높은가

핵심 사실: **두 태스크는 서로 신호를 주고받지 않습니다.** 각자 독립적인 무한 루프이고 각자 `wait_next_period(NULL)`로 자기 주기를 기다릴 뿐입니다. 세마포어도 배리어도 없습니다.

```cpp
// App/Indy7/Indy7Ctrl.cpp — proc_ethercat_control (핵심부)
    while (TRUE)
    {
        wait_next_period(NULL);
        tmCurrent = read_timer();

        pRobot->m_bEcatOP = FALSE;

        pRobot->m_pcEcatMaster->ReadSlaves();          // 수신
        pRobot->UpdateExtInterfaceData();

        if (TRUE == pRobot->m_pcEcatMaster->IsAllSlavesOp() && TRUE == pRobot->m_pcEcatMaster->IsMasterOp())
        {
            pRobot->m_bEcatOP = TRUE;
        }
        tmSend = read_timer();
        pRobot->m_pcEcatMaster->WriteSlaves(tmSend);   // 송신 (+DC 시각 갱신)
        tmEcat = read_timer();
        ...
    }
```

두 태스크 모두 주기가 1ms(`TASK_PERIOD=1000000`)이고 `START_DELAY=0`이라 **거의 같은 순간에 깨어납니다.** 누가 먼저 CPU를 잡느냐를 결정하는 건 **오직 우선순위뿐**입니다.

즉 여기서 우선순위는 "과부하 시 누가 이기나"를 정하는 장치가 아니라, **매 사이클의 실행 순서(위상)를 고정하는 장치**로 쓰입니다. 우선순위 차이가 없으면 어떤 사이클엔 계산이 먼저, 어떤 사이클엔 통신이 먼저 도는 **비결정적 순서**가 됩니다.

**Main(97) > EtherCAT(95)일 때 매 사이클 순서:**

```
주기 시작 → 둘 다 깨어남
  ① Main(97)  : 축에서 q, q̇ 읽기 → 토크 계산 → MoveTorque()
                 (슬레이브 객체의 목표 토크 필드에 값이 채워짐)
  ② Ecat(95)  : ReadSlaves()  → 새 상태 수신
                 WriteSlaves() → ①이 방금 채운 토크를 프레임에 실어 송신
```

**왜 이 순서인가 — 두 가지 이유**

**(1) 계산이 "긴 축"이고 마감이 걸려 있습니다.** 제어기는 RBDL로 질량행렬·중력항을 푸는 무거운 연산이고 코드에 **500µs 데드라인**이 명시돼 있습니다(`SetDeadline(500000)`). 반면 EtherCAT 태스크는 메모리 복사와 송수신 시스템콜 정도로 짧습니다. **긴 작업에 먼저 CPU를 통째로 주고 짧은 작업이 남는 시간에 들어가게** 하는 배치입니다.

**(2) 통신 쪽 지터는 (원래는) DC가 흡수합니다.** "계산이 먼저면 송신 시각이 계산 시간만큼 흔들리지 않나?" — 맞습니다. 일반론으로는 분산 클럭이 켜져 있으면 **슬레이브가 프레임 도착 순간이 아니라 SYNC0 시각에 데이터를 반영**하므로, 다음 SYNC0 전에만 도착하면 송신 지터가 구동 시각으로 번지지 않습니다. **흡수 장치가 있는 통신 쪽을 뒤로, 없는 계산 쪽을 앞으로** 둔다는 설계 논리입니다.

> ⚠️ **정정 (Q4에서 확인)**: 이 cfg에서는 그 흡수가 **실제로 일어나지 않습니다.** `[ECAT_MASTER] DC_ENABLED=1`은 있지만 **슬레이브별 `DC_SUPPORT` 키가 cfg에 아예 없어** 전부 0(미지원)으로 읽히고, 결국 각 슬레이브는 `ecrt_slave_config_dc(sc, 0,0,0,0,0)` — **SYNC0 없이** 설정됩니다. 마스터 쪽 `ecrt_master_application_time()`·`sync_reference_clock()`·`sync_slave_clocks()`만 매 사이클 돌 뿐입니다. 따라서 **현재 설정에서는 송신 시각 지터가 그대로 구동 지터가 됩니다.** 근거 코드는 Q4의 A항 참조.
>
> 이 정정에도 **(1)의 논리(마감 있는 무거운 계산에 CPU를 먼저)는 그대로 유효**합니다.

##### 3. 덧붙임 — 이 배치에서 눈여겨볼 점

이 보드의 IRQ 스레드가 **전부 50**이라는 점은 기억해 둘 만합니다. IgH를 **generic 드라이버**로 쓰면 프레임 수신이 커널 네트워크 스택을 거치므로, 그 경로가 앱 태스크(95/97)보다 한참 아래(50)에 놓입니다. 두 앱 태스크가 `wait_next_period`로 잠들어 있는 동안은 문제없지만, 우선순위 계층을 설계할 때 **"수신 경로가 내 태스크보다 아래에 있다"**는 건 인지하고 있어야 할 조건입니다.

##### 정리

- **99를 피한 이유**: 커널(`migration/N`)에게 양보하고 위쪽에 여유를 남기려는 관례.
- **메인이 EtherCAT보다 높은 이유**: 매 사이클 "계산 → 송신" 순서를 고정하면서, 마감이 빡빡한 계산에 CPU를 먼저 주기 위함.

---

#### Q4. `[AXIS0]`의 각 인자가 무엇을 나타내고, 가지고 있는 값은 무슨 의미인가?

**질문한 코드** (`App/Indy7/INDY7.cfg` 79~116행):

```ini
[AXIS0]
ENABLED=1
CONNECTED=1
NAME=AXIS 0
PHYSICAL_POS=0
VENDOR_ID = 0x0000089a
PRODUCT_CODE = 0x30000000
SLAVE_TYPE=0
AUTO_SERVO_ON= 0
ABSOLUTE_ENCODER=0
MOVE_CCW=0
JOINT_TYPE=0
DRIVE_MODE=10
ENCODER_RESOLUTION=65536
GEAR_RATIO=121
TRANSMISSION_RATIO=1.0
TORQUE_CONSTANT=0.0884
CURRENT_RATIO=48.0
ONE_TURN_REF=360.0
HOMING_METHOD=3
HOME_POSITION_OFFSET=50080
HOME_SEARCH_REFERENCE=1.0
OPERATING_VELOCITY=130
OPERATING_ACCELERATION=10000
OPERATING_DECELERATION=10000
POSITION_LIMIT_U=35.0
POSITION_LIMIT_L=-35.0
VELOCITY_LIMIT_U=150
VELOCITY_LIMIT_L=0
ACCELERATION_LIMIT_U=10000
ACCELERATION_LIMIT_L=0
DECELERATION_LIMIT_U=10000
DECELERATION_LIMIT_L=0
TORQUE_LIMIT_U=117.73
TORQUE_LIMIT_L=0
JERK_LIMIT_U=0
JERK_LIMIT_L=0
POS_BEFORE_EXIT=46888
```

**답변**

`[AXIS0]`은 **EtherCAT 슬레이브 하나 = 관절 하나**를 정의합니다. 역할별로 6개 그룹으로 묶입니다.

##### A. 이 슬레이브가 누구인가 (EtherCAT 신원)

| 키 | 값 | 의미 |
|---|---|---|
| `ENABLED` | 1 | 이 축을 사용할지 |
| `CONNECTED` | 1 | 물리적으로 연결돼 있는지 (0이면 강제 비활성) |
| `NAME` | AXIS 0 | 라벨 |
| `PHYSICAL_POS` | 0 | EtherCAT 링에서의 물리 위치 |
| `VENDOR_ID` | `0x0000089a` | **Neuromeka(NRMK)** 벤더 ID |
| `PRODUCT_CODE` | `0x30000000` | **CORE 서보 드라이브** |
| `SLAVE_TYPE` | 0 | **0=축(모터), 1=센서** |

`SLAVE_TYPE`이 분기점입니다. `InitEtherCAT()`이 이 값으로 `CAxisNRMKCore`(모터)를 만들지 `CSensorNRMKEndTool`(센서)을 만들지 결정합니다. `[AXIS6]`은 같은 벤더에 `PRODUCT_CODE=0x10000007`, `SLAVE_TYPE=1`인 엔드툴이라 모터 파라미터가 아예 없습니다:

```ini
[AXIS6]                         ; 물리적 Slave #6 (엔드이펙터)
ENABLED=1
CONNECTED=1
NAME=EOAT
PHYSICAL_POS=6
VENDOR_ID = 0x0000089a
PRODUCT_CODE = 0x10000007
SLAVE_TYPE=1
```

`VENDOR_ID`/`PRODUCT_CODE`는 16진수로 파싱되며(`std::stoul(str, NULL, 16)`), `ecrt_master_slave_config()`에 넘어가 **"버스 0번 자리에 정말 이 제품이 꽂혀 있는가"**를 대조합니다.

###### 🔎 `PHYSICAL_POS`는 왜 모든 축이 0인가 (관절은 직렬로 이어져 있는데)

**읽히기만 하고 어디에서도 쓰이지 않는 죽은 설정이기 때문입니다.** 전수 검색 결과 소비처가 없습니다:

```
CRobot/ConfigRobot.h:55     INT32 nPhyPos;                 ← 선언
CRobot/ConfigRobot.h:111    nPhyPos = 0;                   ← 초기화
CRobot/ConfigRobot.cpp:172  stSlave.nPhyPos = atoi(str);   ← 읽기
(끝 — 사용하는 코드 없음)
```

**실제 버스 위치는 "등록 순서"가 정합니다:**

```cpp
// EMasterApp/Device/EcatMasterBase.cpp
CEcatMasterBase::AddSlave(CEcatSlaveBase* acEcatSlaveBase)
{
    size_t szSlaveNo = m_vEcatSlaves.size();          // ← 지금까지 등록된 개수
    m_vEcatSlaves.push_back(acEcatSlaveBase);
    acEcatSlaveBase->SetAlias((UINT16)0);
    acEcatSlaveBase->SetPosition((UINT16)szSlaveNo);  // ← 이게 링에서의 위치
}
```

`InitEtherCAT()`이 cfg를 `AXIS0 → AXIS6` 순서로 훑으며 각 축의 `Init()`(내부에서 `AddSlave` 호출)을 부르므로, **cfg의 섹션 순서가 곧 물리적 링 순서**가 됩니다. `PHYSICAL_POS`에 뭘 적든 결과가 같습니다.

실제 cfg도 일관성이 없어 이를 뒷받침합니다:

| 섹션 | PHYSICAL_POS |
|---|---|
| AXIS0, 1, 2, 4, 5 | 0 |
| **AXIS3** | **키 자체가 없음** (기본값 0) |
| AXIS6 | 6 |

AXIS6만 6인 것도 기능이 아니라 **사람 보라고 남긴 표기**입니다 (그 줄에 `; 물리적 Slave #6 (엔드이펙터)` 주석이 붙어 있음).

> ⚠️ **함정**: 순서가 곧 위치이므로 **cfg에서 섹션 순서를 바꾸면 실제 슬레이브 매핑이 어긋납니다.** 그런데 `PHYSICAL_POS`를 고쳐도 아무 효과가 없으니, "위치를 바꾸려면 이 값을 고치면 되겠지"라고 생각하면 빠집니다.
>
> 센서 분기의 `int nPos = nTotalSlaves - 1 - nCnt; // 역순으로 센서 생성`은 **배열 저장 인덱스**만 뒤집는 것이고 `AddSlave` 호출 순서는 루프 순서 그대로라, 버스 위치는 정상적으로 6번이 됩니다. (함수 첫 줄의 `// 1) End-Effector 슬레이브를 가장 먼저 등록` 주석도 실제 코드와 맞지 않습니다.)

> ⚠️ **DC 키 부재 — Q3의 DC 설명을 정정하게 만든 발견**
>
> `[ECAT_MASTER] DC_ENABLED=1`은 있지만 축마다 `DC_SUPPORT`/`DC_ACTIVATE_WORD`/`DC_SYNC0_SHIFT`가 **cfg에 아예 없어** 전부 0으로 읽힙니다. 그 결과:
>
> ```cpp
> // EMasterApp/Device/EcatSlaveBase.cpp — CEcatSlaveBase::EnableDC
>         if ( TRUE == IsDCSupported())
>         {
>             ecrt_slave_config_dc(m_pEcatSlaveConfig, GetDCActivateWord(), aunCyleTime, GetDCShiftTime(), 0, 0);
>             m_bIsDCEnabled = TRUE;
>         }
>         else
>         {
>             /* The AssignActivate word is vendor-specific ... Set this to zero,
>             * if the slave shall be operated without distributed clocks (default). */
>             ecrt_slave_config_dc(m_pEcatSlaveConfig, 0, 0, 0, 0, 0);
>         }
> ```
>
> 마스터는 `DC_ENABLED=1`이라 매 슬레이브에 `EnableDC()`를 부르지만, 위 `else` 분기를 타서 **SYNC0가 설정되지 않습니다.**
>
> ```cpp
> // EMasterApp/Device/EcatMasterBase.cpp — CEcatMasterBase::InitSlaves
>         bRet = m_vEcatSlaves[nCnt]->InitSlave((UINT16)(0), (UINT16)(nCnt), m_stEcatMasterDesc);
>         if ( TRUE == m_bIsDCEnabled )
>             m_vEcatSlaves[nCnt]->EnableDC(m_unCycleTime);
> ```
>
> → 슬레이브는 **프레임이 도착한 시점에** 데이터를 반영하므로, 송신 시각 지터가 그대로 구동 지터가 됩니다. (마스터 쪽 `application_time`/`sync_*` 호출만 매 사이클 돎)

##### B. 어떻게 구동할 것인가

| 키 | 값 | 의미 |
|---|---|---|
| `DRIVE_MODE` | **10** | CiA402 동작 모드 = `0x0A` = **CST (주기 동기 토크)** ⭐ |
| `AUTO_SERVO_ON` | 0 | Init 시 자동 서보온 안 함(모드 설정만) |
| `OPERATING_VELOCITY` | 130 | 프로파일 속도 |
| `OPERATING_ACCELERATION` | 10000 | 프로파일 가속도 |
| `OPERATING_DECELERATION` | 10000 | 프로파일 감속도 |

`DRIVE_MODE=10`이 이 로봇의 정체성입니다 — 드라이브에 위치나 속도가 아니라 **매 사이클 목표 토크를 직접** 내려보냅니다. 그래서 상위에서 동역학으로 토크를 계산해야 하며, `MoveAxis`/`MoveVelocity`는 드라이브 모드 검사에 걸려 거부됩니다.

`OPERATING_*` 3종은 프로파일 모드용이라 **CST에서는 실질적으로 미사용**입니다. (게다가 이 값이 들어가는 프로파일 속도/가속도 PDO 항목은 `SlaveCIA402Base`의 PDO 맵에서 주석 처리돼 있어 실제 전송도 안 됩니다.)

##### C. 카운트 ↔ 물리량 변환 상수 ⭐

| 키 | 값 | 의미 |
|---|---|---|
| `ENCODER_RESOLUTION` | 65536 | 모터 1회전당 엔코더 카운트 (2¹⁶) |
| `GEAR_RATIO` | **121** | 감속비 — 모터 121바퀴 = 관절 1바퀴 |
| `TRANSMISSION_RATIO` | 1.0 | 추가 전동비(벨트·볼스크류). 없음 |
| `ONE_TURN_REF` | 360.0 | 1회전 기준값 → **⚠️ 무시됨** |
| `JOINT_TYPE` | 0 | 0 = 회전 관절(revolute) |
| `MOVE_CCW` | 0 | 0이면 **방향 부호 = −1** |
| `ABSOLUTE_ENCODER` | 0 | **증분 엔코더** — 전원 끄면 절대 위치 상실 |

```cpp
// CRobot/Axis.cpp
CAxis::ConvertRadMM2Res(double adPos)
{
	return (INT32)((adPos / m_dOneTurnRef) * m_dTransRatio * m_dGearRatio * m_dResolution * m_nDirection);
}
```

> ⚠️ **`ONE_TURN_REF=360.0`은 적용되지 않습니다.** `InitEtherCAT()`이 `SetOneTurnRef(360.0)`을 호출하지만:
>
> ```cpp
> CAxis::SetOneTurnRef(double adOneTurnRef)
> {
> 	if (eAxisRevolute == GetAxisType())
> 		return FALSE;          // ← 회전 관절이면 아무것도 안 하고 반환
>
> 	m_dOneTurnRef = adOneTurnRef;
> 	return TRUE;
> }
> ```
>
> 회전 관절은 생성자에서 이미 고정됩니다: `m_dOneTurnRef = (eAxisRevolute == aeAxisType) ? TWO_M_PI : 1.;`
> → **실제로는 2π가 쓰입니다.** 이 키는 직선 관절(볼스크류 리드 등)용이며, 만약 360이 적용됐다면 변환이 57.3배 어긋났을 겁니다.

**실제 수치:**
- 관절 1회전(2π rad) = `1.0 × 121 × 65536` = **7,929,856 카운트**
- 1도 ≈ **22,027 카운트**
- 위치 한계 ±35° ≈ **±771,000 카운트**

##### D. 토크 변환

| 키 | 값 | 의미 |
|---|---|---|
| `TORQUE_CONSTANT` | 0.0884 | 모터 토크 상수 Kt [Nm/A] |
| `CURRENT_RATIO` | 48.0 | 전류[A] → 드라이브 명령 카운트 |

```cpp
// CRobot/AxisNRMKCore.cpp
CAxisNRMKCore::MoveTorque(double adTor)
{
	if (FALSE == IsMovable()) return FALSE;

	/* only allow this when in any of the torque-based operation mode */
	if ((CIA402_CYCLIC_TORQUE != m_cEcSlave.GetActualDriveMode()) && (CIA402_PROFILE_TORQUE != m_cEcSlave.GetActualDriveMode()))
		return FALSE;

	// motor_torque = adTor / m_dGearRatio
	double dmotorcurrent = (adTor / m_dGearRatio / m_dTorqueConstant);

	m_cEcSlave.SetTargetTor((INT16)(dmotorcurrent * m_dCurrentRatio * m_nDirection));

	return TRUE;
}
```

**관절 토크 → (÷121) 모터 토크 → (÷0.0884) 모터 전류 → (×48) 드라이브 카운트 → (×−1) 방향**

값의 정합성이 드러납니다. `TORQUE_LIMIT_U=117.73`을 역산하면:

```
전류 = 117.73 / 121 / 0.0884 = 11.0 A
검산: 11.0 A × 0.0884 Nm/A × 121 = 117.7 Nm  ✓
```

즉 **117.73 Nm = 정확히 모터 전류 11 A에 해당하는 관절 토크**. 드라이브 명령값으로는 528 카운트(INT16 범위 내).

##### E. 안전 한계

| 키 | 값 | 단위 | 비고 |
|---|---|---|---|
| `POSITION_LIMIT_U/L` | +35.0 / −35.0 | **도(°)** | 회전 관절이면 자동 rad 변환 |
| `VELOCITY_LIMIT_U/L` | 150 / 0 | — | 변환 없음 |
| `ACCELERATION_LIMIT_U/L` | 10000 / 0 | — | |
| `DECELERATION_LIMIT_U/L` | 10000 / 0 | — | |
| `TORQUE_LIMIT_U/L` | 117.73 / 0 | Nm | **⚠️ 적용 안 됨** |
| `JERK_LIMIT_U/L` | 0 / 0 | — | 미사용 |

위치 한계만 단위 변환이 일어납니다:

```cpp
CAxis::SetPositionLimits(double adLower, double adUpper, BOOL abIsRad)
{
	double dLower = adLower; double dUpper = adUpper;
	if (FALSE == abIsRad && eAxisRevolute == GetAxisType())
	{
		dLower = ConvertDeg2Rad(dLower);
		dUpper = ConvertDeg2Rad(dUpper);
	}
	return SetLimits(m_pstAxisLimits->stPos, dLower, dUpper);
}
```

> ⚠️ **`TORQUE_LIMIT_U=117.73`은 축에 전달되지 않습니다.** `InitEtherCAT()`의 인자가 잘못돼 있습니다:
>
> ```cpp
> m_pEcatAxis[nCnt]->SetTorqueLimits(stSlaveInfo.dTorLimitL, stSlaveInfo.dJerkLimitU);
> //                                                          ↑ dTorLimitU 여야 함
> ```
>
> `JERK_LIMIT_U=0`이 들어가므로 축의 토크 한계는 **[0, 0]**이 됩니다.
> 다만 `CAxisNRMKCore::MoveTorque`가 `IsAllowableTorque()`를 검사하지 않으므로 **실제 토크 명령이 막히지는 않습니다.** 실질적 토크 제한은 제어기 쪽(`CController::SaturateOutput`)에서 걸립니다. 지금은 무해하지만 cfg 값이 의미를 잃은 잠복 버그입니다.
>
> 참고: 한계 6종(위치·속도·가속·감속·저크·토크)이 **모두 설정돼야** `IsLimitConfigured()`→`IsMovable()`이 참이 되어 축이 움직입니다. `SetTorqueLimits(0,0)`도 "설정됨"으로 치므로 이 조건은 통과합니다.

##### F. 홈잉 (원점 설정)

| 키 | 값 | 의미 |
|---|---|---|
| `HOMING_METHOD` | **3** | `0=미설정, 1=시작위치, 2=탐색, 3=수동, 4=드라이브내장` |
| `HOME_POSITION_OFFSET` | 50080 | 홈으로 지정할 **엔코더 카운트** |
| `HOME_SEARCH_REFERENCE` | 1.0 | 방법 2에서만 쓰임 → **여기선 무시** |
| `POS_BEFORE_EXIT` | 46888 | 지난 종료 시 위치 |

열거형 (`CRobot/Axis.h`):

```cpp
typedef enum
{
	eAxisHomingNotSet = 0,
	eAxisHomeStartPos,      // 1
	eAxisHomeSearch,        // 2
	eAxisHomeManual,        // 3
	eAxisHomeBuiltin,       // 4
} eHomingMethod;
```

`HOMING_METHOD=3`(수동)이므로 `InitEtherCAT()`이 이렇게 처리합니다:

```cpp
            if (eAxisHomeSearch == ehomingtemp)
                m_pEcatAxis[nCnt]->SetHomeReference(stSlaveInfo.dHomeSearchRef);

            else if (eAxisHomeManual == ehomingtemp)
                m_pEcatAxis[nCnt]->SetHomePosition(stSlaveInfo.nHomePositionOffset);   // ← 50080
```

**홈 위치가 하는 일**은 "몇 번 카운트를 0도로 표시할 것인가"입니다:

```cpp
// CRobot/Axis.cpp — CAxis::UpdateCurrentParams
	/* Calculate position from the home or starting position, depending whether Home Position is configured */
	INT32 nCurrentPos = m_pstAxisRawParams->nPos - GetHomePosition();
	if (FALSE == IsHomeSet())
		nCurrentPos = m_pstAxisRawParams->nPos - GetStartRawPos();
```

엔코더가 50080을 가리킬 때 이 관절은 **0 rad**로 보고됩니다. 증분 엔코더라 전원을 끄면 절대 위치를 잃기 때문에 이런 기준점이 필요합니다.

> **`POS_BEFORE_EXIT=46888`은 현재 아무 데도 쓰이지 않습니다.** `SetPositionBeforeExit(46888)`로 축에 넣긴 하지만, 소비하는 유일한 줄이 `CAxisNRMKCore`에서 **주석 처리**돼 있습니다:
>
> ```cpp
> 			if (eAxisHomeStartPos == GetHomingMethod())
> 			{
> 				SetHomePosition(nStartPos);
> 				// SetHomePosition(nStartPos - GetPositionBeforeExit());
> 			}
> ```
>
> 종료 시 갱신하는 코드도 `CRobot::DeInit()`에서 주석 처리돼 있습니다:
>
> ```cpp
> 	// for (INT nCnt = 0; nCnt < GetTotalAxis(); nCnt++)
> 	// {
> 	// 	m_pcConfigRobot->WriteLastPosition(nCnt, m_vAxis[nCnt]->GetCurrentRawPos());
> 	// }
> ```
>
> → **46888은 과거 어느 시점에 기록된 뒤 고정된 화석**입니다. (`CAxisCIA402`/`CAxisELMO`에는 그 줄이 살아 있지만, Indy7은 `CAxisNRMKCore`를 쓰고 그쪽이 콜백을 오버라이드합니다.)

###### 🔎 `POS_BEFORE_EXIT`는 애초에 왜 필요한 값인가

**증분 엔코더(`ABSOLUTE_ENCODER=0`)가 전원을 끄면 절대 위치를 잃기 때문입니다.** 원래 설계 의도는 **"소프트웨어로 만든 값싼 절대 위치 기억장치"**입니다.

**① 종료할 때** — 현재 원시 엔코더 카운트를 cfg에 되씁니다:

```cpp
// CRobot/ConfigRobot.cpp
CConfigRobot::WriteLastPosition(INT32 anAxis, INT32 anRawPos)
{
	TSTRING strKey = "AXIS" + TOSTRING(anAxis);
	TSTRING strValue = TOSTRING(anRawPos);
	WritePrivateProfileString(strKey.c_str(), "POS_BEFORE_EXIT", strValue.c_str(), m_strConfigPath.c_str());
```

**② 다음 부팅 때** — 저장된 값으로 홈을 역산합니다:

```cpp
SetHomePosition(nStartPos - GetPositionBeforeExit());
```

**③ 결과** — 표시 위치 계산식이 `raw − home`이므로:

```
표시 위치 = raw − (R_start − R_exit)
부팅 순간(raw = R_start) → 표시 위치 = R_exit
```

즉 **껐을 때의 각도 그대로 다시 시작**합니다. 이게 없으면 매 부팅마다 물리적 원점 복귀(호밍)를 하거나, 팔이 있는 자리를 무조건 0으로 삼아야 합니다.

- **전제 조건**: 전원이 꺼진 동안 **팔이 움직이지 않아야** 함. 사람이 밀거나 중력에 처지면 그만큼 어긋납니다.
- **현재 상태**: ①(저장)·②(복원) 양쪽 다 주석 처리되어 기능 정지. 게다가 ②는 `eAxisHomeStartPos`(방법 1) 분기 안에만 있는데 AXIS0~3은 방법 3이라 애초에 그 경로를 타지 않습니다. → `46888`은 아무도 안 읽는 화석.

###### 🔎 `HOME_POSITION_OFFSET=50080`이라는 값의 유래를 유추할 수 있는가

가능합니다. 전 축의 값을 물리 단위로 환산하면 뚜렷한 패턴이 나옵니다 (환산: 모터 회전 = offset/65536, 관절각 = offset ÷ (gear×65536/360)):

| 축 | offset (counts) | 모터 회전수 | 관절각 | 홈잉 방법 |
|---|---|---|---|---|
| **AXIS0** | **50080** | **0.7642** | **2.27°** | 3 (사용됨) |
| AXIS1 | 5699 | 0.0870 | 0.26° | 3 (사용됨) |
| AXIS2 | 41470 | 0.6328 | 1.88° | 3 (사용됨) |
| AXIS3 | −21035 | −0.3210 | −1.14° | 3 (사용됨) |
| AXIS4 | −6619836 | −101.01 | −360.04° | 1 (무시됨) |
| AXIS5 | −1021383 | −15.59 | −55.55° | 1 (무시됨) |

**추론 근거 세 가지:**

**① 실제로 쓰이는 네 축이 전부 "모터 1회전 미만"입니다.** 0.76 / 0.087 / 0.63 / −0.32 회전. 관절각으로는 0.26°~2.27°의 아주 작은 값 — "설계된 위치"가 아니라 **미세한 잔차**의 크기입니다.

**② 값이 전부 불규칙합니다.** 의도적으로 정한 값이라면 0, 65536(1회전), 관절 90°에 해당하는 값처럼 둥근 수가 나올 텐데 그렇지 않습니다.

**③ "모터 1회전 이내"라는 성질이 결정적입니다.** 증분 엔코더가 인덱스(Z) 펄스를 기준으로 0을 잡으면, **그 전기적 0과 관절의 진짜 기구학적 0 사이 잔차는 정의상 모터 1회전 안에** 들어옵니다. 네 축이 모두 그 범위인 건 우연으로 보기 어렵습니다.

**→ 결론(추론)**: 50080은 계산·설계로 나온 값이 아니라 **캘리브레이션 때 읽어서 적은 실측 카운트**입니다. 팔을 기구적 영점(정렬 지그/기계적 스토퍼)에 세워 놓고 그때 드라이브가 보고한 원시 카운트를 그대로 옮겨 적은 것으로 보입니다. → **로봇 개체마다 다른 값**이고, 모터·감속기를 분해했다 재조립하면 다시 잡아야 합니다.

**AXIS4/5가 이 해석을 뒷받침합니다.** −101.01 회전(관절 −360.04°, 거의 정확히 한 바퀴)과 −15.59 회전(−55.55°)은 위 범위를 완전히 벗어납니다. 둘 다 `HOMING_METHOD=1`이라 **읽히지 않는 값**이므로 아무도 관리하지 않았고, 다른 캘리브레이션 세션의 잔재이거나 카운터 감김이 누적된 흔적으로 보입니다. **쓰이는 값은 규칙적이고 안 쓰이는 값은 엉망**이라는 대비 자체가 "쓰이는 값들은 실제로 측정해 관리된 것"이라는 방증입니다.

> 이 항목은 코드로 증명되는 사실이 아니라 **수치 패턴에서 끌어낸 추론**입니다. 확증하려면 캘리브레이션 절차 문서나 당시 기록이 필요합니다.

> ⚠️ **축마다 홈잉 방식이 다릅니다** (전체 cfg를 훑은 결과):
>
> | 축 | HOMING_METHOD | 결과 |
> |---|---|---|
> | AXIS0~3 | **3 (수동)** | 홈 = cfg 고정 카운트 (50080 / 5699 / 41470 / −21035) |
> | **AXIS4~5** | **1 (시작 위치)** | 홈 = **부팅 순간 팔이 있던 자리** |
>
> 방법 1은 `OnSlaveStatusChanged`에서 `SetHomePosition(nStartPos)`를 부르므로 **켤 때 팔이 어디 있었든 그 자세가 0도**가 됩니다. AXIS4/5의 `HOME_POSITION_OFFSET`(−6619836, −1021383)은 방법 1에서 읽히지 않아 무의미합니다. J4·J5만 기준점이 부팅 자세에 좌우된다는 뜻이라, 재현성이 필요하면 눈여겨봐야 합니다.

##### 축별 주요 상수 비교 (전체 cfg에서 추출)

| 축 | GEAR_RATIO | TORQUE_CONSTANT | CURRENT_RATIO | TORQUE_LIMIT_U | HOMING_METHOD |
|---|---|---|---|---|---|
| AXIS0 | 121 | 0.0884 | 48.0 | 117.73 | 3 |
| AXIS1 | 121 | 0.0884 | 48.0 | 117.73 | 3 |
| AXIS2 | 121 | 0.087 | 96.0 | 47.5 | 3 |
| AXIS3 | 101 | 0.058 | 96.0 | 21.0 | 3 |
| AXIS4 | 101 | 0.058 | 96.0 | 21.0 | **1** |
| AXIS5 | 101 | 0.058 | 96.0 | 21.0 | **1** |

베이스 쪽(J0/J1)이 감속비·토크 한계가 크고, 손목 쪽(J3~J5)이 작습니다 — Q1의 PD 게인 배분(800→100)과 같은 물리적 이유입니다.

##### 정리

`[AXIS0]`은 **"버스 0번의 Neuromeka CORE 드라이브를, 감속비 121·엔코더 65536의 회전 관절로, CST(토크) 모드로 구동하되, 엔코더 50080을 0도로 삼고, ±35°·11A 범위 안에서 쓰겠다"**는 선언입니다.

**실제로 작동하지 않는 값 셋**: `ONE_TURN_REF`(회전 관절이라 무시) · `TORQUE_LIMIT_U`(인자 실수로 전달 안 됨) · `POS_BEFORE_EXIT`(소비처가 주석 처리). 여기에 **DC 키 부재**로 SYNC0도 꺼져 있습니다.

---

### 📄 `Global/ConfigParser.h` / `.cpp`

---

#### Q5. `GetPrivateProfileString`, `GetPrivateProfileInt`, `WritePrivateProfileString` 세 함수가 하는 일 (내부 함수 포함)

**답변**

`Global/ConfigParser.cpp`(242줄)는 **윈도우의 INI 파일 API를 리눅스에서 흉내 낸 것**입니다. 외부 라이브러리 없이 표준 C 파일 입출력만 씁니다. RAON-RT의 `.cfg`가 `[섹션] 키=값` 형식이라 이 세 함수가 모든 설정 읽기·쓰기의 바닥을 담당합니다.

헤더에 공개된 전부(`Global/ConfigParser.h`):

```cpp
extern BOOL IsExistFile(const char*);
extern BOOL IsExistDir(const char*);

extern size_t 	GetPrivateProfileString(const char* section, const char* entry, const char* def, char* buffer, size_t buffer_len, const char* file_name);
extern int 		GetPrivateProfileInt(const char* section, const char* entry, int defval, const char* fname);
extern BOOL 	WritePrivateProfileString(const char* section, const char* entry, const char* def, const char* file_name);
```

##### 보조 함수 2개

파일/디렉토리 존재 확인용. `stat()` 하나로 끝납니다.

```cpp
BOOL IsExistFile(const char* strName)
{
	struct stat stInfo;
	if (0 == stat(strName, &stInfo))     // 파일 정보 조회 성공 = 존재
		return TRUE;
	return FALSE;
}

BOOL IsExistDir(const char* strName)
{
	struct stat stInfo;
	if (0 == stat(strName, &stInfo) && stInfo.st_mode & S_IFDIR)  // + 디렉토리 비트 확인
		return TRUE;
	return FALSE;
}
```

`stat()`은 파일 메타정보(크기·권한·종류)를 가져오는 시스템 콜입니다. 성공(0 반환) 자체가 "존재한다"는 뜻이고, `IsExistDir`는 `S_IFDIR` 비트로 디렉토리인지 추가 확인합니다. `CConfigRobot::ReadConfiguration()`이 cfg를 열기 전에 `IsExistFile`로 먼저 확인합니다.

##### 1. `GetPrivateProfileString` — 문자열 읽기 (주력)

`[섹션]`에서 `키=값`을 찾아 값 문자열을 `buffer`에 담아 줍니다. 못 찾으면 **기본값(`def`)**을 대신 넣습니다.

```
GetPrivateProfileString("SYSTEM", "ROBOT_DOF", "0", str, 1024, "INDY7.cfg")
                         ↑섹션    ↑키          ↑기본값 ↑받을곳 ↑크기  ↑파일
```

| 단계 | 하는 일 | 쓰는 함수 |
|---|---|---|
| ① 파일 열기 | 실패하면 즉시 0 반환 | `fopen(file_name, "r")` |
| ② 섹션 찾기 | `"[SYSTEM]"` 문자열을 만들어 한 줄씩 비교 | `sprintf`, `fgets`, `strncasecmp` |
| ③ 키 찾기 | 섹션 안에서 한 줄씩 키 이름 비교 | `fgets`, `strncasecmp` |
| ④ 값 추출 | 마지막 `=` 뒤를 값으로 봄 | `strrchr(tmpbuf, '=')` |
| ⑤ 다듬기 | 앞뒤 공백·개행 제거 | `isspace` |
| ⑥ 복사 | buffer로 옮기고 길이 반환 | `strncpy` |

두 개의 `do { ... } while` 루프가 핵심 — 각각 "섹션을 만날 때까지" · "키를 만날 때까지" 한 줄씩 읽습니다:

```cpp
	sprintf(tmpsec, "[%s]", section);    /* "[SYSTEM]" 형태로 조립 */
	slen = strlen(tmpsec);

	do {
		if (!fgets(tmpbuf, __MAX_PATH__ - 1, fp))   // EOF면 = 못 찾음
		{
			strncpy(buffer, def, buffer_len);        // → 기본값 반환
			return strlen(buffer);
		}
	} while (strncasecmp(tmpbuf, tmpsec, slen));     // 앞 slen 글자만 비교
```

**알아둘 점 두 가지:**

- **`strncasecmp`(앞부분만, 대소문자 무시)로 비교**하는 게 중요합니다. `fgets`가 읽은 줄에는 개행이 붙고, cfg에는 `[AXIS6]  ; 물리적 Slave #6` 처럼 주석이 붙기도 하는데, 앞 7글자만 보므로 문제없이 매칭됩니다.
- **못 찾으면 조용히 기본값이 들어갑니다.** 오류를 내지 않습니다. Q4에서 본 `DC_SUPPORT` 키 부재 → 조용히 0(미지원)이 된 것이 바로 이 동작 때문입니다. **키 이름 오타도 같은 방식으로 조용히 넘어갑니다.**

##### 2. `GetPrivateProfileInt` — 정수 읽기 (**실제로는 아무도 안 씀**)

위와 거의 같지만 값에서 숫자만 뽑아 `int`로 돌려줍니다.

```cpp
	for (i = 0; isdigit(ep[i]); i++)   // 숫자 문자만 골라 담고
		value[i] = ep[i];
	return atoi(value);                 // 정수로 변환
```

그런데 호출 횟수가 **0회**입니다:

| 함수 | 사용 횟수 |
|---|---|
| `GetPrivateProfileString` | **67회** |
| `GetPrivateProfileInt` | **0회** |
| `WritePrivateProfileString` | 1회 |
| `IsExistFile` / `IsExistDir` | 4회 / 0회 |

`CConfigRobot`은 전부 `GetPrivateProfileString`으로 문자열을 받은 뒤 직접 `atoi(str)`/`atof(str)`로 변환합니다. 왜 안 쓰는가 — 섹션 비교 방식이 다릅니다:

```cpp
	} while (strcmp(tmpbuf, tmpsec));   // ← 전체 비교 (String 버전은 strncasecmp)
```

`fgets`가 읽은 `tmpbuf`는 `"[SYSTEM]\n"`(개행 포함)인데 `tmpsec`은 `"[SYSTEM]"`이라 **절대 같아지지 않습니다.** 결국 EOF까지 가서 **항상 기본값만 반환**합니다. 사실상 고장 나 있어 아무도 쓰지 않는 것으로 보입니다. `isdigit`만으로 숫자를 뽑는 것도 음수(`-21035`)와 소수점(`0.0884`)을 처리하지 못해 이 프로젝트엔 애초에 부적합합니다.

##### 3. `WritePrivateProfileString` — 값 쓰기/갱신

`[섹션] 키=값`을 파일에 기록합니다. 이미 있으면 그 줄만 바꾸고, 없으면 추가합니다.

**핵심 아이디어는 "원본을 직접 고치지 않는다"**입니다. 임시 파일에 한 줄씩 복사하다가 해당 줄만 새 값으로 바꿔 쓰고, 마지막에 파일을 통째로 갈아 끼웁니다:

```cpp
	int tmpfd = mkstemp(tname);       // ① 임시 파일 생성 (PRIVPROFXXXXXX)
	...
	wfp = fdopen(tmpfd, "w");         // ② 파일 디스크립터 → FILE* 변환
	...
	fprintf(wfp, "%s", tmpbuf);       // ③ 원본을 한 줄씩 임시 파일로 복사
	...
	fprintf(wfp, "%s=%s\n", entry, def);  // ④ 대상 줄만 새 값으로
	...
	unlink(file_name);                // ⑤ 원본 삭제
	rename(tname, file_name);         // ⑥ 임시 파일을 원본 이름으로 (교체 완료)
```

쓰다가 중간에 죽어도 원본이 반쯤 망가지지 않습니다(`rename`은 원자적). 설정 파일을 다루는 흔한 안전 기법입니다.

**쓰이는 함수**: `mkstemp`(겹치지 않는 임시 파일 생성) · `fdopen`(정수 fd를 `FILE*`로 감쌈) · `fprintf`(복사·기록) · `unlink`(삭제) · `rename`(이름 교체).

**네 가지 경우를 나눠 처리:**

| 상황 | 동작 |
|---|---|
| 파일이 아예 없음 | 새로 만들고 `[섹션]`+`키=값` 기록 |
| 섹션이 없음 | 파일 끝에 섹션을 새로 추가 |
| 섹션은 있는데 키가 없음 | 그 섹션 끝에 키를 추가 |
| 키가 있음 | **그 줄만 교체**하고 나머지는 그대로 복사 |

RAON-RT에서 쓰는 곳은 딱 하나 — `CConfigRobot::WriteLastPosition()`(종료 시 `POS_BEFORE_EXIT` 되쓰기). Q4에서 봤듯 호출부가 주석 처리돼 지금은 실행되지 않습니다.

##### 정리

| 함수 | 역할 | 실제 사용 | 방식 |
|---|---|---|---|
| `IsExistFile` / `IsExistDir` | 존재 확인 | 4회 / 0회 | `stat()` |
| `GetPrivateProfileString` | 문자열 읽기 | **67회 (주력)** | 섹션→키 순차 탐색, 못 찾으면 기본값 |
| `GetPrivateProfileInt` | 정수 읽기 | **0회 (사실상 고장)** | 섹션 비교가 개행 때문에 항상 실패 |
| `WritePrivateProfileString` | 쓰기/갱신 | 1회 | 임시 파일 복사 후 `rename` 교체 |

한 줄 요약: **설정 읽기는 전부 `GetPrivateProfileString` 하나가 담당하고, 숫자 변환은 호출한 쪽에서 `atoi`/`atof`로 직접 합니다.**

> 잔버그 둘: `GetPrivateProfileString`의 마지막 `buffer[buffer_len] = '\0';`는 인덱스가 하나 넘칩니다(`buffer_len - 1`이어야 함). `GetPrivateProfileInt`는 값이 비었을 때 `fclose` 없이 반환해 파일 핸들이 샙니다.

### `Global/Defines.h`
*(아직 질문 없음)*

---

## 2단계

### 📄 `~/RT-POSIX/examples/task.c`

---

#### Q6. 이 파일 코드 전체 설명

**대상 코드** (`~/RT-POSIX/examples/task.c` 전문, 61줄):

```c
#include <stdio.h>
#include "posix_rt.h"
#include <string.h>


POSIX_TASK g_stRtTask1;
POSIX_TASK g_stRtTask2;

void sample_periodic_proc(void* arg)
{
    int nCnt = 0;
    while (1)
    {
        printf("PERIODIC TASK: %d\n", nCnt++);
        wait_next_period(NULL);
    }
}

void sample_proc(void* arg)
{
    int *nRet = (int*) arg;
    printf("ONESHOT TASK\n");
    *nRet = 55;
}

void signal_handler(int nSignal)
{
    init_lowlevel_logger(TRUE);
    DBG_INFO("RT-POSIX has been signalled [%d]", nSignal);
    exit(0);
}

int main()
{

    signal(SIGTERM, signal_handler);
    signal(SIGINT, signal_handler);
    
    /* Lock all current and future pages from preventing of being paged to swap */
    mlockall(MCL_CURRENT | MCL_FUTURE);

    int nRet = 0;
    init_lowlevel_logger(FALSE);
    create_rt_task(&g_stRtTask1, (const PCHAR)"PERIODIC", 0, 99);
    set_task_period(&g_stRtTask1, SET_TM_NOW, 1000000000);
    
    create_rt_task(&g_stRtTask2, (const PCHAR)"ONESHOT", 0, 80);
    
    start_task(&g_stRtTask1, &sample_periodic_proc, NULL);
    start_task(&g_stRtTask2, &sample_proc, (void*) &nRet);
    
    // periodic task will run only twice
    sleep(2);
    
    // check if the value from the ONESHOT thread has been acquired successfully
    printf("nRet: %d\n", nRet);

    return RET_SUCC;
}
```

**답변**

RT-POSIX 사용법 전체가 61줄에 압축된 파일입니다. **RAON-RT의 5개 태스크가 전부 이 패턴을 따르므로**, 이 파일을 이해하면 3단계(`Robot.cpp`의 `InitRTTasks`)가 그대로 읽힙니다.

##### 전체 구조 — 네 덩어리

```
① 전역 태스크 핸들 2개      POSIX_TASK g_stRtTask1, g_stRtTask2
② 태스크 함수 2개            sample_periodic_proc / sample_proc
③ 시그널 핸들러              signal_handler
④ main                       설정 → 생성 → 시작 → 대기 → 종료
```

##### main을 순서대로 따라가기

**1) 종료 신호 처리기 등록**

`Ctrl+C`(SIGINT)나 `kill`(SIGTERM)을 받았을 때 그냥 죽지 않고 정리 절차를 밟게 합니다. 실시간 프로그램은 모터를 돌리는 도중 강제 종료되면 위험하니 필수 습관입니다.

**2) 메모리 잠금 — 실시간의 기본 전제**

```c
    mlockall(MCL_CURRENT | MCL_FUTURE);
```

리눅스는 평소 안 쓰는 메모리를 디스크(스왑)로 밀어냅니다. 1ms 주기로 도는 도중 밀려난 페이지를 다시 불러오면 **수 밀리초가 날아갑니다.** `mlockall`은 "지금 것도(`MCL_CURRENT`), 앞으로 할당할 것도(`MCL_FUTURE`) 전부 물리 메모리에 못 박아라"는 뜻입니다.

**3) 태스크 생성** — 인자는 `(핸들, 이름, 스택크기, 우선순위)`

**여기서 두 태스크의 성격이 갈립니다** — 차이는 딱 하나, **`set_task_period`를 부르느냐**:

- `PERIODIC`: 주기를 **1,000,000,000 ns = 1초**로 설정 → 주기 태스크
- `ONESHOT`: 주기 설정 없음 → 한 번 실행되고 끝

`SET_TM_NOW`는 "지금 즉시 시작" 센티널입니다(`posix_rt.h`: `#define SET_TM_NOW (RTTIME)-99`).

**생성과 시작이 분리**된 점이 중요합니다. `create_rt_task`는 스레드 속성만 준비하고 실행하지 않습니다. 덕분에 모든 태스크의 주기·우선순위를 다 세팅한 뒤 한꺼번에 출발시킬 수 있습니다. → RAON-RT `InitRTTasks()`가 "생성 루프 → 시작 루프"로 두 번 도는 이유.

**4) 태스크 시작** — 인자는 `(핸들, 실행할 함수, 함수에 넘길 인자)`

세 번째 인자가 `void*`인 게 핵심입니다. `PERIODIC`은 `NULL`, `ONESHOT`은 결과를 받으려고 `&nRet`을 넘깁니다. **RAON-RT는 이 자리에 로봇 객체 `this`를 넘깁니다** — 그래서 태스크 함수에서 로봇의 모든 것에 접근할 수 있습니다.

**5) 두 태스크 함수**

주기 태스크는 **무한 루프 + `wait_next_period`**입니다. `wait_next_period(NULL)`가 실시간 주기의 심장으로, 단순 `sleep`과 달리 **"다음 주기 경계라는 절대 시각까지"** 재우기 때문에 앞선 작업이 얼마나 걸렸든 주기가 밀리지 않습니다. 인자 `NULL` 자리는 오버런(주기를 놓친 횟수)을 받는 곳인데 여기선 무시합니다.

단발 태스크는 루프 없이 한 번 실행 후 반환하며, `void*` 인자를 원래 타입으로 캐스팅해 쓰는 전형적 패턴입니다.

**6) 마무리**

`main`은 2초 기다렸다 단발 태스크가 남긴 값을 출력하고 끝냅니다. 주기가 1초이므로 그동안 `PERIODIC TASK: 0`, `1` 두 번이 찍힙니다 — 주석 `// periodic task will run only twice`가 이 뜻입니다. `main`이 반환하면 프로세스가 종료되며 주기 태스크도 함께 사라집니다.

##### API 요약

| 함수 | 하는 일 |
|---|---|
| `create_rt_task(핸들, 이름, 스택, 우선순위)` | 스레드 속성 준비 (SCHED_FIFO, 우선순위, 스택). **아직 실행 안 함** |
| `set_task_period(핸들, 시작시각, 주기ns)` | 주기 태스크로 만듦. 안 부르면 단발 태스크 |
| `start_task(핸들, 함수, 인자)` | 실제로 스레드 생성·실행 |
| `wait_next_period(NULL)` | 다음 주기 경계까지 잠듦 (주기 태스크 전용) |
| `mlockall(...)` | 메모리를 스왑에서 보호 |

##### RAON-RT와의 대응 ⭐

| `task.c` (예제) | RAON-RT | 위치 |
|---|---|---|
| `POSIX_TASK g_stRtTask1;` | `std::vector<PTASK> m_vTask` | `Robot.h` |
| `create_rt_task(&t, "PERIODIC", 0, 99)` | `create_rt_task(&taskTemp, cfg이름, 0, cfg우선순위)` | `Robot.cpp` |
| `set_task_period(&t, SET_TM_NOW, 1000000000)` | `set_task_period(&taskTemp, tmStartDelay, cfg주기)` | `Robot.cpp` |
| `start_task(&t, &fn, NULL)` | `start_task(&m_vTask[n], m_vTaskFunctions[n], this)` | `Robot.cpp` |
| `while(1){ ...; wait_next_period(NULL); }` | `while(!CheckStopTask()){ wait_next_period(NULL); ... }` | `Indy7Ctrl.cpp` |
| `mlockall(MCL_CURRENT\|MCL_FUTURE)` | 동일 | `main.cpp` |
| `signal(SIGINT, signal_handler)` | 동일 | `main.cpp` |

**가장 큰 차이는 값의 출처**입니다. 예제는 이름·주기·우선순위가 코드에 박혀 있지만 RAON-RT는 **전부 `.cfg`에서 읽습니다.** 그래서 `InitRTTasks()`가 설정 개수만큼 루프를 돌 뿐, 구조 자체는 이 61줄과 같습니다.

##### 눈여겨볼 디테일 넷

**① 스택 크기 `0`의 의미** — `SET_DEFAULT_STKSZ`(=0), "기본값 쓰라"는 뜻. 기본값은 `DEFAULT_STKSIZE = 65536`(64KB)인데 **이 보드(aarch64)는 `PTHREAD_STACK_MIN`이 128KB**(확인함)라 그대로 쓰면 `pthread_attr_setstacksize`가 `EINVAL`로 실패합니다. `~/RT-POSIX`에는 이미 보정 코드가 들어가 있습니다:

```c
// src/posix_rt.c — _create_task
	if (anStkSize < (INT)PTHREAD_STACK_MIN || anStkSize == (INT)SET_DEFAULT_STKSZ)
		apTask->ullStackSize = (UINT64)DEFAULT_STKSIZE;
	else
		apTask->ullStackSize = (UINT64)anStkSize;

	// [kv260-merge] aarch64 glibc has PTHREAD_STACK_MIN=128K > DEFAULT_STKSIZE(64K);
	// clamp so default/small requests stay valid on every architecture.
	if (apTask->ullStackSize < (UINT64)PTHREAD_STACK_MIN)
		apTask->ullStackSize = (UINT64)PTHREAD_STACK_MIN;
```

**② 우선순위 99** — 예제라서 최고값을 썼지만, Q3에서 봤듯 이 보드는 커널 `migration/N`이 99를 씁니다. RAON-RT가 97/95를 쓰는 이유가 여기 있습니다.

**③ `wait_next_period`의 위치** — 예제는 **일을 하고 나서** 대기(`printf`→`wait`), RAON-RT는 **대기하고 나서** 일합니다(`wait`→`ReadSlaves`). 둘 다 유효하며, 첫 반복이 즉시 실행되느냐 한 주기 기다렸다 실행되느냐만 다릅니다.

**④ 동기화 장치가 없다** — `main`이 `sleep(2)` 후 `nRet`을 읽는데 그 사이 다른 스레드가 그 변수에 씁니다. 예제라 넘어가지만 실무에선 뮤텍스/조건 변수가 필요한 자리입니다. (RAON-RT도 같은 문제를 안고 있어 두 1ms 태스크가 **우선순위 순서에만 의존해** 실행 순서를 맞춥니다 — Q3 참조.)

##### 참고: `commons.h`에서 오는 것들

`RET_SUCC`(=0), `TRUE/FALSE`, `PCHAR`/`PVOID` 같은 타입 별칭, `DBG_INFO`/`DBG_ERROR` 로그 매크로, `PTASKFCN`(태스크 함수 포인터 타입 = `void(*)(void*)`)가 모두 여기서 정의됩니다.

### `~/RT-POSIX/include/posix_rt.h`
*(아직 질문 없음)*

### `~/RT-POSIX/src/posix_rt.c`
*(아직 질문 없음)*

---

## 3단계

### 📄 `App/Indy7/main.cpp`

---

#### Q7. C++ 문법을 몰라서 이해가 안 감 — 코드 순서대로 말로 풀어서 설명

**대상 코드** (`App/Indy7/main.cpp` 전문, 100줄)

```cpp
#include <cstdio>
#include <unistd.h>
#include "ConfigRobot.h"
#include "Indy7Ctrl.h"
#include "ExtInterface.h"

void signal_handler     (int nSignal);

CConfigRobot    *g_cConfigRobot;
CRobotIndy7        *g_cRobot;
CExtInterface   *g_cExtInterface;

int main(int argc, char **argv)
{
    g_cConfigRobot = NULL;
    g_cRobot = NULL;
    g_cExtInterface = NULL;

    DBG_LOG_INFO("=======================ROBOT APPLICATION STARTED!======================");

    int nOpt;
    BOOL bDefConfig = TRUE;
    TSTRING myFile = TSTRING(DEFAULT_CONFIGURATION_FULLPATH);
    
    while ((nOpt = getopt(argc, argv, "f:")) != -1)
    {
        switch (nOpt)
        {
        case 'f':
            myFile = TSTRING(optarg);
            DBG_LOG_INFO("Using configuration file: %s", myFile.c_str());
            bDefConfig = FALSE;
            break;
        default:
            break;
        }
    }
    if (TRUE == bDefConfig)
    {
        DBG_LOG_INFO("Using default configuration file: %s", myFile.c_str());
    }

    BOOL bSimMode = TRUE;
    g_cConfigRobot = new CConfigRobot();
    
    /* Load Configuration File */
    
    if (FALSE == IsExistFile(myFile.c_str()))
    {
        DBG_LOG_ERROR("Cannot read configration file %s!", myFile.c_str());
        return FALSE;
    }
    g_cConfigRobot->ReadConfiguration(myFile);
    bSimMode = g_cConfigRobot->GetSystemConf().bSim;

    g_cRobot = new CRobotIndy7(g_cConfigRobot);

    signal(SIGTERM, signal_handler);
    signal(SIGINT, signal_handler);

    /* Lock all current and future pages from preventing of being paged to swap */
    mlockall(MCL_CURRENT | MCL_FUTURE);

    // Determine whether to execute aging on start-up
    // g_cRobot->EnableAgingTest(g_cConfigRobot->GetSystemConf().bAging, g_cConfigRobot->GetSystemConf().nAgingDur);

    /* Initialize Robot */
    if (FALSE == g_cRobot->Init(bSimMode))
    {
        DBG_LOG_ERROR("Cannot Start Control Application!");
        return RET_FAIL;
    }

    while (!g_cRobot->CheckStopTask())
    {
        cpu_relax();
        usleep(1000);
    }

    // g_cRobot->WriteDataLog();

    DBG_LOG_INFO("=======================ROBOT APPLICATION ENDED!=======================");
    return RET_SUCC;
}

void signal_handler(int nSignal)
{
    DBG_LOG_INFO("RT-POSIX has been signalled [%d]", nSignal);
    g_cRobot->DeInit();
}
```

**답변**

##### 0. 파일 맨 위 — 준비물과 전역 변수

**`#include`**는 "다른 파일의 내용을 여기에 붙여넣어라"입니다. `<...>`는 시스템 제공, `"..."`는 이 프로젝트 파일. 설정 로더·로봇 클래스·외부 통신을 쓰겠다는 선언입니다.

`void signal_handler(int nSignal);`은 **함수 "예고"**입니다. C++는 위에서 아래로 읽으므로, 아래에 정의된 함수를 위에서 쓰려면 미리 알려야 합니다. 실제 내용은 파일 끝에 있습니다.

```cpp
CConfigRobot    *g_cConfigRobot;
```

여기서 **`*`가 포인터**입니다. `CRobotIndy7 g_cRobot;`은 "로봇 객체 그 자체"지만 `CRobotIndy7 *g_cRobot;`은 **"객체가 있는 곳의 주소를 담는 변수"**입니다. 아직 실물은 없고 주소를 적을 빈칸만 만든 상태.

이름 앞 `g_`는 **전역 변수**. 이 프로젝트 관례로 `n`=정수, `b`=참/거짓, `str`=문자열, `m_`=클래스 멤버.

> **왜 전역인가?** 맨 아래 `signal_handler` 때문입니다. 시그널 핸들러는 OS가 호출하므로 **인자를 마음대로 받을 수 없습니다.** 그래서 로봇 객체를 전역에 두고 어디서든 꺼내 씁니다.

##### 1. main 시작 — 빈칸 초기화

`argc`는 **명령줄 단어 개수**, `argv`는 **그 단어들**. `./Indy7Ctrl.out -f INDY7.cfg`면 argc=3, argv=`["./Indy7Ctrl.out", "-f", "INDY7.cfg"]`.

`NULL`은 **"아직 아무것도 안 가리킴"**. 포인터를 만들자마자 쓰레기 주소가 있을 수 있어 명시적으로 비웁니다.

`DBG_LOG_INFO`는 함수처럼 보이지만 **매크로**(`Defines.h`). "화면에 로그 한 줄"로 보면 됩니다.

##### 2. 명령줄 옵션 읽기

`TSTRING`은 **문자열 타입의 별명**(실제로는 `std::string`). `DEFAULT_CONFIGURATION_FULLPATH`는 `"ELMO.cfg"` — **아무 옵션 없이 실행하면 `ELMO.cfg`를 읽으려 합니다.**

`getopt`는 리눅스 표준 함수로 명령줄 옵션을 하나씩 꺼내 줍니다. `"f:"`는 **"`-f` 옵션을 받고, 뒤에 값이 따라온다(`:`)"**. 옵션이 떨어지면 `-1`을 반환해 while이 끝납니다.

`myFile.c_str()`에서 **`.`은 "이 객체의 무엇"**. `c_str()`은 C++ 문자열을 C 스타일로 바꿔 주는데, `printf` 계열이 C 스타일만 알아듣기 때문에 필요합니다.

`if (TRUE == bDefConfig)` — **`==`는 "같은가?"**, `=`는 "넣어라". 값을 왼쪽에 쓰는 스타일(요다 조건)은 실수로 `=`를 하나만 쳤을 때 컴파일 에러가 나게 해 버그를 막는 관습입니다.

##### 3. 설정 파일 읽기

```cpp
    g_cConfigRobot = new CConfigRobot();
```

**`new`**는 "객체를 하나 만들어라"이고, 결과로 **만들어진 객체의 주소**를 돌려줍니다. 그 주소를 빈 포인터에 담으면 이제 실제 객체를 가리킵니다.

```cpp
    g_cConfigRobot->ReadConfiguration(myFile);
    bSimMode = g_cConfigRobot->GetSystemConf().bSim;
```

**`->`가 포인터 전용 접근 기호**입니다:

- `객체.기능()` — 객체를 직접 들고 있을 때
- `포인터->기능()` — 주소만 들고 있을 때

마지막 줄은 두 단계가 붙어 있습니다. `GetSystemConf()`가 설정 묶음(구조체)을 통째로 돌려주고 거기서 `.bSim` 항목을 꺼냅니다 = cfg의 `SIMULATION_MODE`.

##### 4. 로봇 객체 만들기

```cpp
    g_cRobot = new CRobotIndy7(g_cConfigRobot);
```

로봇 본체를 만들며 **설정 객체를 건네줍니다.** 겉보기엔 한 줄이지만 안에서 생성자가 돌며 **5개 실시간 태스크 함수가 등록**됩니다(`AddTaskFunction(&proc_main_control)` 등). 아직 실행은 안 되고 목록에만 오릅니다.

##### 5. 종료 신호 처리기 등록

`SIGINT`=`Ctrl+C`, `SIGTERM`=`kill`. **"이 신호가 오면 `signal_handler`를 실행해라"**고 OS에 등록합니다.

`signal_handler`에 **괄호가 없는 게 포인트**입니다. `signal_handler()`는 "지금 실행"이지만, **괄호 없이 이름만 쓰면 "그 함수 자체"**를 값으로 넘긴다는 뜻입니다.

##### 6. 메모리 잠그기

`mlockall`은 **"내 메모리는 스왑으로 밀어내지 마라"**. `|`는 **비트 OR**로 옵션을 합치는 기호 — "지금 메모리(`MCL_CURRENT`) + 앞으로 생길 메모리(`MCL_FUTURE`) 둘 다".

##### 7. 진짜 초기화

```cpp
    if (FALSE == g_cRobot->Init(bSimMode))
```

**이 파일에서 가장 무거운 줄.** 안에서: 동역학 제어기 생성(URDF 읽기) → 외부 통신 서버(7420) 시작 → EtherCAT 마스터·슬레이브 7개 초기화 → **실시간 태스크 5개 생성·기동**.

즉 **이 줄이 끝나는 순간부터 로봇이 1ms마다 살아 움직입니다.** `bSimMode`가 참이면 EtherCAT도 태스크도 만들지 않고 넘어갑니다.

##### 8. 대기 루프

```cpp
    while (!g_cRobot->CheckStopTask())
    {
        cpu_relax();
        usleep(1000);
    }
```

**`!`는 "아니다"** — "정지 신호가 **아닌 동안** 반복".

헷갈리기 쉬운 점: **`main`은 이제 아무 일도 안 합니다.** 실제 제어는 5개 실시간 태스크가 각자 하고, `main`은 1ms씩 자면서 "끝낼 때가 됐나?"만 봅니다. `cpu_relax()`는 CPU에 "잠깐 쉬어도 된다"고 주는 힌트입니다.

##### 9. 종료

`return`은 `main`을 끝내고 OS에 결과를 돌려줍니다. `RET_SUCC`=0(성공), `RET_FAIL`=-1(실패).

##### 10. 맨 아래, 신호가 왔을 때

`Ctrl+C`를 누르면 OS가 이 함수를 대신 호출하고, 하는 일은 **로봇 정리**(`DeInit`) 하나 — 태스크 정지 → 2초 대기 → EtherCAT 해제. 여기서 로봇을 **전역 변수**로 둔 이유가 드러납니다: 이 함수는 `main` 바깥이라 `main`의 지역 변수에 접근할 수 없습니다.

##### 전체 흐름 한눈에

```
① 명령줄에서 -f 로 설정 파일 이름 받기 (없으면 ELMO.cfg)
② 파일 존재 확인 → 설정 읽기 → 시뮬레이션 모드인지 판단
③ 설정을 건네주며 로봇 객체 생성 (이때 태스크 5개 "등록"만)
④ Ctrl+C 처리기 등록
⑤ 메모리 잠금 (실시간 준비)
⑥ Init() ← 여기서 EtherCAT 연결 + 태스크 5개 실제 기동
⑦ main은 1ms마다 자면서 종료 신호만 감시
⑧ Ctrl+C → signal_handler → DeInit → 정리 후 종료
```

##### 나온 C++ 문법 정리

| 기호 | 뜻 | 예 |
|---|---|---|
| `*` (선언부) | 포인터 = 주소를 담는 변수 | `CRobotIndy7 *g_cRobot;` |
| `new` | 객체를 만들고 그 주소를 돌려줌 | `new CRobotIndy7(...)` |
| `.` | 객체의 멤버 접근 | `myFile.c_str()` |
| `->` | **포인터**를 통한 멤버 접근 | `g_cRobot->Init(...)` |
| `==` | 같은가? (`=`는 대입) | `TRUE == bDefConfig` |
| `!` | 아니다 | `!CheckStopTask()` |
| `\|` | 비트 OR, 옵션 합치기 | `MCL_CURRENT \| MCL_FUTURE` |
| 함수명(괄호 없이) | 함수 자체를 값으로 전달 | `signal(SIGINT, signal_handler)` |

> 사소한 흠: 설정 파일이 없을 때 `return FALSE;`로 끝내는데 `FALSE`는 0이라 셸에는 **"정상 종료"**로 보고됩니다. `RET_FAIL`(-1)이 맞습니다. 스크립트로 자동화할 때 실패를 감지하지 못합니다.

### `App/Indy7/Indy7Ctrl.h`
*(아직 질문 없음)*

### `CRobot/Robot.h`
*(아직 질문 없음)*

### `CRobot/Robot.cpp`
*(아직 질문 없음)*

---

## 4단계

### `EMasterApp/Device/EcatCommon.h`
*(아직 질문 없음)*

### `EMasterApp/Device/EcatMasterBase.h` / `.cpp`
*(아직 질문 없음)*

### `EMasterApp/Device/EcatSlaveBase.h` / `.cpp`
*(아직 질문 없음)*

### `EMasterApp/Device/SlaveCIA402Base.h` / `.cpp`
*(아직 질문 없음)*

---

## 5단계

### `CRobot/Axis.h`
*(아직 질문 없음)*

### `CRobot/Axis.cpp`
*(아직 질문 없음)*

### `CRobot/AxisCIA402.h` / `.cpp`
*(아직 질문 없음)*

### `CRobot/AxisNRMKCore.h` / `.cpp`
*(아직 질문 없음)*

### `CRobot/ConfigRobot.h` / `.cpp`
*(아직 질문 없음)*

---

## 6단계

### `App/Indy7/Indy7Ctrl.cpp`
*(아직 질문 없음 — 단, 1단계 Q1에서 `InitController()` 일부를 인용함)*

---

## 7단계

### `App/Indy7/Controller.h` / `.cpp`
*(아직 질문 없음)*

### `App/Indy7/FullDynControllerRT.h`
*(아직 질문 없음)*

### `App/Indy7/FullDynControllerRT.cpp`
*(아직 질문 없음 — 단, 1단계 Q1에서 중력보상·CTC 일부를 인용함)*

---

## 8단계

### `CRobot/Sensor.h` / `SensorFT.cpp` / `SensorNRMKEndTool.cpp`
*(아직 질문 없음)*

### `CRobot/ExtInterface.cpp` / `Global/Comm/Socket.cpp` / `CRC16.cpp`
*(아직 질문 없음)*

### `Global/Comm/ROS2*.cpp`
*(아직 질문 없음)*
