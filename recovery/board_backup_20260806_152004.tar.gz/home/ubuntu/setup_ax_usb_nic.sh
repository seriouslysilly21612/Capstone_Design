#!/bin/bash
# Permanent install of ASIX ax_usb_nic driver for AX88179B on Kria (-rt-kv260c)
# Run with:  sudo bash ~/setup_ax_usb_nic.sh
set -u

KVER="$(uname -r)"
KO="/home/ubuntu/ax_usb_nic.ko"
SRC="/home/ubuntu/ASIX_USB_NIC_Linux_Driver_Source_v4.1.0"
DEST="/lib/modules/${KVER}/kernel/drivers/net/usb"

say(){ printf '\n\033[1;36m### %s\033[0m\n' "$*"; }
ok(){  printf '\033[1;32m  ✔ %s\033[0m\n' "$*"; }
warn(){ printf '\033[1;33m  ! %s\033[0m\n' "$*"; }

if [ "$(id -u)" -ne 0 ]; then echo "run as root: sudo bash $0"; exit 1; fi
[ -f "$KO" ] || { echo "missing $KO"; exit 1; }

say "1. Install ax_usb_nic.ko into module tree"
install -D -m 644 "$KO" "${DEST}/ax_usb_nic.ko"
depmod -a
ok "installed at $(modinfo -n ax_usb_nic 2>/dev/null || echo '??')"

say "2. Install udev rule (forces ASIX proprietary config, blocks cdc_ncm)"
if [ -f "${SRC}/50-ax_usb_nic.rules" ]; then
  install -m 644 "${SRC}/50-ax_usb_nic.rules" /etc/udev/rules.d/50-ax_usb_nic.rules
  ok "udev rule installed"
else
  warn "ASIX rules file not found; writing a minimal equivalent"
  cat > /etc/udev/rules.d/50-ax_usb_nic.rules <<'EOF'
ACTION!="add", GOTO="ax_usb_nic_end"
SUBSYSTEM!="usb", GOTO="ax_usb_nic_end"
ENV{DEVTYPE}!="usb_device", GOTO="ax_usb_nic_end"
ENV{PROPRIETARY_MODE}="1"
ATTR{idVendor}=="0b95", ATTR{idProduct}=="1790", ATTR{bConfigurationValue}!="$env{PROPRIETARY_MODE}", ATTR{bConfigurationValue}="$env{PROPRIETARY_MODE}"
LABEL="ax_usb_nic_end"
EOF
fi
udevadm control --reload-rules

say "3. Ensure blacklist + autoload (idempotent)"
grep -qs '^blacklist ax88179_178a' /etc/modprobe.d/ax_usb_nic_blacklist.conf \
  || echo 'blacklist ax88179_178a' > /etc/modprobe.d/ax_usb_nic_blacklist.conf
grep -qsx 'ax_usb_nic' /etc/modules-load.d/ax_usb_nic.conf \
  || echo 'ax_usb_nic' > /etc/modules-load.d/ax_usb_nic.conf
ok "blacklist + modules-load in place"

say "4. Load ax_usb_nic now (pulls mii dep)"
modprobe -r ax88179_178a 2>/dev/null || true   # unused in-tree module (blacklisted at boot)
modprobe mii 2>/dev/null || true
modprobe ax_usb_nic && ok "ax_usb_nic loaded" || warn "modprobe ax_usb_nic failed"

say "5. Switch the attached adapter into ASIX proprietary config"
ASIX_DEV=""
for d in /sys/bus/usb/devices/*/; do
  [ -f "${d}idVendor" ] || continue
  if [ "$(cat ${d}idVendor)" = "0b95" ] && [ "$(cat ${d}idProduct)" = "1790" ]; then
    ASIX_DEV="$d"; break
  fi
done
if [ -n "$ASIX_DEV" ]; then
  cur="$(cat ${ASIX_DEV}bConfigurationValue 2>/dev/null)"
  echo "  device: ${ASIX_DEV}  current config: ${cur}"
  if [ "$cur" != "1" ]; then
    echo 1 > "${ASIX_DEV}bConfigurationValue" 2>/dev/null && ok "switched to config 1" || warn "config switch write failed"
  else
    ok "already config 1"
  fi
  udevadm trigger --action=add --subsystem-match=usb 2>/dev/null || true
  sleep 2
else
  warn "ASIX 0b95:1790 not currently attached — replug it after this finishes"
fi

say "6. VERIFY"
echo "-- lsmod:"; lsmod | grep -E 'ax_usb_nic|ax88179|cdc_ncm' || echo "   (none)"
echo "-- ax_usb_nic bound interfaces:"; ls /sys/bus/usb/drivers/ax_usb_nic/ 2>/dev/null | grep -E '[0-9]+-[0-9]' || echo "   (no usb interface bound yet)"
echo "-- USB netdev -> driver:"
for n in /sys/class/net/enx*; do
  [ -e "$n" ] || continue
  printf "   %s -> %s\n" "$(basename $n)" "$(basename $(readlink -f $n/device/driver 2>/dev/null))"
done
echo "-- last 12 dmesg lines (look for 'ax_usb_nic ... Controller 4.1.0' and NO '-32'):"
dmesg | tail -12

echo
echo "=== DONE. If netdev -> ax_usb_nic and no -32 above, permanent setup is complete. ==="
echo "    Plug in the ethernet cable, then:  sudo dhclient enxc8a362ec54c4 && ip -br addr show enxc8a362ec54c4"